// Web app for the compliance engine. Plain JavaScript, no build step: it talks to the same
// /api/v1 endpoints as Swagger, with the same permissions and e-signatures.

import * as viz from "./charts.js";
import { LANGS, lang, locale, setLang, tr } from "./i18n.js";

const API = "/api/v1";
const view = document.getElementById("view");

// ----- labels ------------------------------------------------------------------------------

const ROLES = {
  admin: "مدير النظام",
  quality_manager: "مدير الجودة",
  supervisor: "مشرف",
  operator: "عامل",
  auditor: "مدقق",
};
const ACTIVITIES = {
  pre_op_inspection: "فحص قبل التشغيل",
  cleaning: "تنظيف",
  sanitizing: "تعقيم",
  deep_clean: "تنظيف عميق",
  after_use: "تنظيف بعد الاستخدام",
};
const RESULTS = { pass: "مطابق", fail: "غير مطابق" };
const MEANINGS = { performed: "نفّذ", verified: "راجع", approved: "اعتمد" };
const DISPOSITIONS = {
  not_applicable: "لا ينطبق (لم يتأثر أي منتج)",
  released_after_evaluation: "أُفرج عنه بعد التقييم",
  reworked: "أُعيد تشغيله",
  diverted: "حُوِّل إلى استخدام آخر",
  destroyed: "أُتلف",
};
const ALERT_KINDS = {
  ccp_deviation: "انحراف في نقطة تحكم حرجة",
  sanitation_failure: "إخفاق في فحص النظافة",
  missed_check: "تأخر فحص",
  supplier_document_expiring: "قرب انتهاء مستند مورد",
  supplier_document_expired: "انتهاء مستند مورد",
  supplier_review_due: "موعد إعادة تقييم مورد",
  training_expiring: "قرب انتهاء صلاحية تدريب",
  training_expired: "انتهاء صلاحية تدريب",
};
const SEVERITIES = { critical: "حرج", major: "مهم" };
const CHANNELS = { email: "البريد الإلكتروني", whatsapp: "واتساب" };
const DELIVERY = { pending: "قيد الانتظار", sent: "أُرسلت", failed: "أخفقت" };
const FIELD_NAMES = {
  value: "القيمة",
  measured_at: "وقت القياس",
  notes: "ملاحظات",
  lot_id: "التشغيلة",
  production_run_id: "أمر الإنتاج",
  area: "المنطقة",
  activity: "النشاط",
  chemical: "المادة",
  concentration_ppm: "التركيز",
  result: "النتيجة",
  performed_at: "وقت التنفيذ",
};

// Mirrors the server's permission matrix, only to decide what to show.
const CAN = {
  write: ["admin", "quality_manager", "supervisor", "operator"],
  verify: ["admin", "quality_manager", "supervisor"],
  close: ["admin", "quality_manager"],
  ccp: ["admin", "quality_manager"],
  users: ["admin"],
  notify: ["admin", "quality_manager"],
  audit: ["admin", "quality_manager", "auditor"],
  documents: ["admin", "quality_manager"],
  suppliers: ["admin", "quality_manager"],
  training: ["admin", "quality_manager"],
};
const can = (what) => state.user && CAN[what].includes(state.user.role);

// ----- state and API -----------------------------------------------------------------------

const state = {
  token: sessionStorage.getItem("ce.token"),
  user: null,
  tenant: localStorage.getItem("ce.tenant") || "",
};

class ApiError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

// The session ended and the login page is already showing; nothing else to report.
class SessionEnded extends ApiError {}

// The API speaks English; these show its user-facing messages in Arabic. Anything not listed
// is shown as the server sent it.
const SERVER_MESSAGES = [
  [/^Invalid tenant, email or password$/, () => "رمز المنشأة أو البريد الإلكتروني أو كلمة المرور غير صحيح"],
  [/^This account is locked after (\d+) wrong passwords in a row; ask an administrator to unlock it$/, (n) => `هذا الحساب مقفل بعد ${n} محاولات خاطئة متتالية لكلمة المرور، يرجى مراجعة مدير النظام لفتحه`],
  [/^(Signature rejected: the password is incorrect|Current password is incorrect)(?: \((\d+) attempts? left before the account is locked\)|(; the account is now locked))?$/, (what, left, locked) =>
    (what.startsWith("Signature") ? "رُفض التوقيع: كلمة المرور غير صحيحة" : "كلمة المرور الحالية غير صحيحة") +
    (left ? ` (تبقّى ${left} من المحاولات قبل قفل الحساب)` : locked ? "، وقد قُفل الحساب" : "")],
  [/^Invalid or expired token$|^Missing bearer token$/, () => "انتهت الجلسة، يرجى تسجيل الدخول مجددًا."],
  [/^User is inactive or no longer exists$/, () => "الحساب معطَّل أو لم يعد موجودًا"],
  [/^Role '.+' lacks permission '.+'$/, () => "ليست لدى دورك صلاحية تنفيذ هذا الإجراء"],
  [/^A record must be verified by someone other than its author$/, () => "يجب أن يراجع السجلَّ شخصٌ غير الذي سجّله"],
  [/^A record cannot be dated in the future$/, () => "لا يجوز أن يكون تاريخ السجل في المستقبل"],
  [/^This .+ is already (performed|verified|approved)$/, () => "هذا السجل موقَّع بالفعل"],
  [/^This alert is already acknowledged$/, () => "تم تأكيد الاطلاع على هذا التنبيه مسبقًا"],
  [/^This corrective action is already closed$/, () => "هذا الإجراء التصحيحي مغلق بالفعل"],
  [/^The amendment does not change anything$|^This does not change anything$/, () => "لم يتغير شيء"],
  [/^The new password must differ from the current one$/, () => "يجب أن تختلف كلمة المرور الجديدة عن الحالية"],
  [/^This account is not locked$/, () => "هذا الحساب غير مقفل"],
  [/^You cannot change your own role or deactivate yourself$/, () => "لا يمكنك تغيير دورك أو تعطيل حسابك بنفسك"],
  [/^User '(.+)' already exists$/, (e) => `يوجد مستخدم بالبريد ${e} بالفعل`],
  [/^Control point with code '(.+)' already exists$/, (c) => `توجد نقطة تحكم بالرمز ${c} بالفعل`],
  [/^critical_min must not be greater than critical_max$/, () => "يجب ألا يتجاوز الحد الأدنى الحد الأقصى"],
  [/^set critical_min, critical_max or both$/, () => "يجب تحديد حد أدنى أو حد أقصى أو كليهما"],
  [/^a failed check needs a corrective_action$/, () => "الفحص غير المطابق يتطلب توثيق الإجراء التصحيحي"],
  [/^date_from must not be after date_to$/, () => "يجب ألا يكون تاريخ البداية بعد تاريخ النهاية"],
  [/^A report can cover at most (\d+) days$/, (n) => `لا يجوز أن تتجاوز فترة التقرير ${n} يومًا`],
  [/^Changing a controlled form needs a new revision number/, () => "تعديل النموذج المضبوط يتطلب رقم إصدار جديد (ضبط الوثائق)"],
  [/^Another form already uses the code '(.+)'$/, (c) => `الرمز ${c} مستخدم في نموذج آخر`],
  [/^Send the PDF file/, () => "أرسل ملف PDF (بحد أقصى 20 ميغابايت)"],
  [/^(.+) '.+' was not found$/, () => "العنصر المطلوب غير موجود"],
  [/^(E-mail|WhatsApp) \(.+\) is not configured on the server$/, (c) => `${c === "WhatsApp" ? "واتساب" : "البريد الإلكتروني"} غير مُهيَّأ على الخادم`],
  [/^(E-mail|WhatsApp) is not set up: /, (c) => `${c === "WhatsApp" ? "واتساب" : "البريد الإلكتروني"} غير مُهيَّأ: أدخل إعداداته في صفحة «الإشعارات»`],
  [/^Supplier '(.+)' is not approved \(status: (\w+)\)$/, (c, st) => `المورد ${c} غير معتمد (الحالة: ${SUPPLIER_STATUS[st] || st})، فلا يجوز الاستلام منه`],
  [/^Supplier '(.+)' has an expired required document: (.+) \(expired (\S+)\)$/, (c, d, at) => `لا يجوز الاستلام من المورد ${c}: انتهت صلاحية المستند الإلزامي «${d}» في ${at}`],
  [/^Cannot approve: the required document '(.+)' expired on (\S+)/, (d, at) => `لا يمكن الاعتماد: انتهت صلاحية المستند الإلزامي «${d}» في ${at}. أضف المستند المجدد أو اعتمد بشروط`],
  [/^The next review date must be in the future$/, () => "يجب أن يكون موعد إعادة التقييم في المستقبل"],
  [/^Supplier with code '(.+)' already exists$/, (c) => `يوجد مورد بالرمز ${c} بالفعل`],
  [/^Course with code '(.+)' already exists$/, (c) => `توجد دورة بالرمز ${c} بالفعل`],
  [/^This document is already withdrawn$/, () => "هذا المستند مسحوب بالفعل"],
  [/^The evaluation period cannot end in the future$/, () => "لا يجوز أن تنتهي فترة التقييم في المستقبل"],
  [/^Training cannot be dated in the future$/, () => "لا يجوز أن يكون تاريخ التدريب في المستقبل"],
  [/^Course '(.+)' is no longer active$/, (c) => `الدورة ${c} موقوفة`],
  [/^You are not qualified to record (\S+): valid training is needed in (.+)$/, (c, m) => `لا يمكنك تسجيل ${c}: يلزم تدريب ساري المفعول في ${m}`],
  [/^Enter the password of the mail account$/, () => "أدخل كلمة مرور حساب البريد"],
  [/^Enter the WhatsApp access token$/, () => "أدخل رمز الوصول (Access Token) لواتساب"],
];

function serverText(message) {
  for (const [pattern, text] of SERVER_MESSAGES) {
    const m = pattern.exec(message);
    if (m) return text(...m.slice(1));
  }
  return message;
}

function errorText(detail) {
  if (typeof detail === "string") return serverText(detail);
  if (Array.isArray(detail)) {
    return detail
      .map((e) => {
        const where = (e.loc || []).filter((p) => p !== "body").join(".");
        return where ? `${FIELD_NAMES[where] || where}: ${e.msg}` : e.msg;
      })
      .join(" — ");
  }
  return "حدث خطأ غير متوقع";
}

async function api(method, path, body, { raw = false } = {}) {
  const headers = {};
  if (state.token) headers.Authorization = `Bearer ${state.token}`;
  const binary = body instanceof Blob;
  if (body !== undefined) headers["Content-Type"] = binary ? "application/pdf" : "application/json";
  let response;
  try {
    response = await fetch(API + path, {
      method,
      headers,
      body: body === undefined || binary ? body : JSON.stringify(body),
    });
  } catch {
    throw new ApiError(0, "تعذّر الاتصال بالخادم. تأكد من تشغيل Docker ومن اتصال الجهاز بالشبكة نفسها.");
  }
  if (response.status === 401 && path !== "/auth/token") {
    const detail = await response.json().catch(() => ({}));
    logout(errorText(detail.detail) || "انتهت الجلسة، يرجى تسجيل الدخول مجددًا.");
    throw new SessionEnded(401, "انتهت الجلسة");
  }
  if (!response.ok) {
    const detail = await response.json().catch(() => ({ detail: response.statusText }));
    throw new ApiError(response.status, errorText(detail.detail));
  }
  if (raw) return response;
  if (response.status === 204) return null;
  return response.json();
}

const get = (path, params) => api("GET", path + query(params));
const post = (path, body = {}) => api("POST", path, body);
const patch = (path, body) => api("PATCH", path, body);

function query(params) {
  if (!params) return "";
  const q = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== null && value !== "" && value !== false) q.set(key, value);
  }
  const text = q.toString();
  return text ? `?${text}` : "";
}

// ----- DOM helpers -------------------------------------------------------------------------

// Attributes people read; text children and these go through tr() for the worker languages.
const TRANSLATED_ATTRS = new Set(["placeholder", "title", "aria-label"]);

// h("div", {class: "x", onclick: fn}, "text", child) -- text is always inserted as text.
function h(tag, attrs = {}, ...children) {
  const el = document.createElement(tag);
  for (const [key, value] of Object.entries(attrs || {})) {
    if (value === undefined || value === null || value === false) continue;
    if (key.startsWith("on")) el.addEventListener(key.slice(2), value);
    else if (key === "class") el.className = value;
    else if (value === true) el.setAttribute(key, "");
    else el.setAttribute(key, TRANSLATED_ATTRS.has(key) ? tr(String(value)) : value);
  }
  for (const child of children.flat()) {
    if (child === undefined || child === null || child === false) continue;
    el.append(child instanceof Node ? child : typeof child === "string" ? tr(child) : String(child));
  }
  return el;
}

function render(...nodes) {
  view.replaceChildren(...nodes.flat(Infinity).filter((n) => n !== null && n !== undefined && n !== false));
  view.focus({ preventScroll: true });
}

function toast(message, kind = "") {
  const el = h("div", { class: `toast ${kind}`, role: "status" }, message);
  document.getElementById("toasts").append(el);
  setTimeout(() => el.remove(), kind === "error" ? 7000 : 4000);
}

// Date formats follow the chosen language, always with Western digits.
const fmt = (options) => new Intl.DateTimeFormat(`${locale()}-u-nu-latn`, options);
let dateFmt = fmt({ year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" });
// Bidi isolates keep "72 °C" and dates from being reordered next to Arabic or English text.
const ltr = (text) => `\u2066${text}\u2069`;
const isolate = (text) => `\u2068${text}\u2069`;
const when = (iso) => (iso ? isolate(dateFmt.format(new Date(iso))) : "");
const num = (text) => (text === null || text === undefined ? "" : String(Number(text)));
const badge = (text, kind = "") => h("span", { class: `badge ${kind}` }, text);
const years = (n) => (n === 1 ? "سنة واحدة" : n === 2 ? "سنتان" : `${n} ${n >= 3 && n <= 10 ? "سنوات" : "سنة"}`);
const serialTag = (serial) => (serial ? h("span", { class: "serial ltr" }, serial) : null);

function limits(item) {
  const unit = item.unit ? ` ${item.unit}` : "";
  if (item.critical_min !== null && item.critical_max !== null) {
    return `${tr("من")} ${ltr(num(item.critical_min))} ${tr("إلى")} ${ltr(num(item.critical_max) + unit)}`;
  }
  if (item.critical_min !== null) return `${ltr(num(item.critical_min) + unit)} (${tr("حد أدنى")})`;
  return `${ltr(num(item.critical_max) + unit)} (${tr("حد أقصى")})`;
}

function field(label, input, hint) {
  return h("label", {}, label, input, hint ? h("span", { class: "hint" }, hint) : null);
}

const input = (name, attrs = {}) => h("input", { name, ...attrs });
const textarea = (name, attrs = {}) => h("textarea", { name, ...attrs });

function select(name, options, attrs = {}) {
  return h(
    "select",
    { name, ...attrs },
    Object.entries(options).map(([value, label]) => h("option", { value }, label))
  );
}

const passwordInput = () =>
  input("password", { type: "password", required: true, autocomplete: "current-password" });
const signField = (label = "كلمة المرور (توقيع إلكتروني)") =>
  field(label, passwordInput(), "يُسجَّل التوقيع باسمك ووقته، ولا يمكن تعديله.");

// Reads a form into an object: empty fields are left out, numbers stay text (exact decimals).
function formData(form) {
  const data = {};
  for (const el of form.elements) {
    if (!el.name || el.disabled) continue;
    if (el.type === "checkbox") data[el.name] = el.checked;
    else if (el.value.trim() !== "") {
      data[el.name] = el.type === "datetime-local" ? new Date(el.value).toISOString() : el.value.trim();
    }
  }
  return data;
}

// A form whose submit handler gets the data; shows errors inside the form.
function apiForm(children, onSubmit, submitLabel = "حفظ", attrs = {}) {
  const error = h("div", { class: "error-box", hidden: true });
  const button = h("button", { type: "submit" }, submitLabel);
  const form = h("form", attrs, error, children, h("div", { class: "actions" }, button));
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    error.hidden = true;
    button.disabled = true;
    try {
      await onSubmit(formData(form), form);
    } catch (exc) {
      if (exc instanceof SessionEnded) return;
      error.textContent = tr(exc.message);
      error.hidden = false;
    } finally {
      button.disabled = false;
    }
  });
  return form;
}

const panel = (title, ...content) => h("details", { class: "panel" }, h("summary", {}, title), content);
const empty = (text) => h("div", { class: "empty" }, text);

// ----- icons (simple line icons, drawn for this app) ---------------------------------------

const ICONS = {
  home: "M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1z",
  chart: "M3 3v18h18M7 15l4-4 3 3 6-6",
  thermo: "M14 14.8V5a2 2 0 1 0-4 0v9.8a4 4 0 1 0 4 0zM12 9v7",
  drop: "M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11z",
  list: "M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01",
  review: "M9 11l3 3 8-8M20 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11",
  capa: "M12 9v4M12 17h.01M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z",
  bell: "M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0",
  file: "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6M8 13h8M8 17h5",
  folder: "M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
  target: "M12 2a10 10 0 1 0 .01 0zM12 6a6 6 0 1 0 .01 0zM12 10a2 2 0 1 0 .01 0z",
  users: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8",
  send: "M22 2L11 13M22 2l-7 20-4-9-9-4z",
  lock: "M5 11h14v10H5zM8 11V7a4 4 0 0 1 8 0v4",
  user: "M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z",
  tv: "M3 5h18v12H3zM8 21h8M12 17v4",
  menu: "M4 6h16M4 12h16M4 18h16",
  moon: "M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z",
  sun: "M12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10zM12 1v2M12 21v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M1 12h2M21 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4",
  logout: "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9",
  plus: "M12 5v14M5 12h14",
  check: "M20 6L9 17l-5-5",
  x: "M18 6L6 18M6 6l12 12",
  clock: "M12 2a10 10 0 1 0 .01 0zM12 6v6l4 2",
  minus: "M5 12h14",
  download: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3",
  printer: "M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2M6 14h12v8H6z",
  truck: "M1 4h14v12H1zM15 9h4l3 3v4h-7M5.5 21a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM18.5 21a2 2 0 1 0 0-4 2 2 0 0 0 0 4z",
  cap: "M22 9L12 4 2 9l10 5 10-5zM6 11v5c3 2 9 2 12 0v-5M22 9v6",
  globe: "M12 2a10 10 0 1 0 .01 0zM2 12h20M12 2c3 3 4 6.5 4 10s-1 7-4 10c-3-3-4-6.5-4-10s1-7 4-10z",
};

function icon(name) {
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("viewBox", "0 0 24 24");
  svg.setAttribute("class", "icon");
  svg.setAttribute("aria-hidden", "true");
  const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
  path.setAttribute("d", ICONS[name]);
  svg.append(path);
  return svg;
}

// ----- theme -------------------------------------------------------------------------------

function isDark() {
  const set = document.documentElement.dataset.theme;
  return set ? set === "dark" : matchMedia("(prefers-color-scheme: dark)").matches;
}

function paintThemeButton() {
  document.getElementById("theme-toggle").replaceChildren(icon(isDark() ? "sun" : "moon"));
}

document.getElementById("theme-toggle").addEventListener("click", () => {
  const next = isDark() ? "light" : "dark";
  document.documentElement.dataset.theme = next;
  try {
    localStorage.setItem("ce.theme", next);
  } catch {
    // private mode: the choice lasts for this page only
  }
  paintThemeButton();
  route(); // charts read colours when drawn
});

// ----- language ----------------------------------------------------------------------------

// Fixed text in index.html, kept in Arabic there and translated here.
function translateShell() {
  document.title = tr("نظام الجودة وسلامة الغذاء");
  document.getElementById("brand-name").textContent = tr("نظام الجودة");
  const labels = {
    sidebar: "القائمة الرئيسية",
    "menu-toggle": "القائمة",
    bell: "التنبيهات المفتوحة",
    "theme-toggle": "تبديل الوضع الليلي",
    logout: "تسجيل الخروج",
    "lang-toggle": "تغيير اللغة",
  };
  for (const [id, text] of Object.entries(labels)) document.getElementById(id).setAttribute("aria-label", tr(text));
  document.getElementById("lang-toggle").replaceChildren(icon("globe"), h("span", { class: "lang-name" }, LANGS[lang()].name));
}

function switchLang(code) {
  if (code === lang()) return;
  setLang(code);
  rebuildFormats();
  translateShell();
  if (state.user) {
    document.getElementById("user-role").textContent = tr(ROLES[state.user.role]);
    document.getElementById("new-record").replaceChildren(icon("plus"), h("span", { class: "hide-sm" }, "قراءة جديدة"));
    buildNav();
  }
  route();
}

const langButtons = () =>
  Object.entries(LANGS).map(([code, { name }]) =>
    h("button", { type: "button", lang: code, "aria-current": String(code === lang()), onclick: () => switchLang(code) }, name)
  );

function closeLangMenu() {
  document.querySelector(".lang-menu")?.remove();
  document.getElementById("lang-toggle").setAttribute("aria-expanded", "false");
}

document.getElementById("lang-toggle").addEventListener("click", (event) => {
  event.stopPropagation();
  if (document.querySelector(".lang-menu")) return closeLangMenu();
  const menu = h("div", { class: "lang-menu", role: "menu" }, langButtons());
  menu.addEventListener("click", closeLangMenu);
  event.currentTarget.after(menu);
  event.currentTarget.setAttribute("aria-expanded", "true");
});
document.addEventListener("click", closeLangMenu);
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") closeLangMenu();
});

setLang(lang());
translateShell();

// ----- login / session ---------------------------------------------------------------------

function logout(message) {
  state.token = null;
  state.user = null;
  sessionStorage.removeItem("ce.token");
  document.body.classList.add("anon");
  if (message) sessionStorage.setItem("ce.loginMessage", message);
  if (location.hash !== "#/login") location.hash = "#/login";
  else route();
}

function loginPage() {
  document.body.classList.add("anon");
  const message = sessionStorage.getItem("ce.loginMessage");
  sessionStorage.removeItem("ce.loginMessage");
  const form = apiForm(
    [
      field("رمز المنشأة", input("tenant", { required: true, value: state.tenant, autocomplete: "organization", class: "ltr" })),
      field("البريد الإلكتروني", input("email", { type: "email", required: true, autocomplete: "username", class: "ltr" })),
      field("كلمة المرور", input("password", { type: "password", required: true, autocomplete: "current-password" })),
    ],
    async (data) => {
      const token = await api("POST", "/auth/token", data);
      state.token = token.access_token;
      state.tenant = data.tenant;
      sessionStorage.setItem("ce.token", state.token);
      localStorage.setItem("ce.tenant", data.tenant);
      await loadUser();
      location.hash = "#/home";
    },
    "تسجيل الدخول"
  );
  render(
    h(
      "div",
      { class: "login-wrap" },
      h(
        "div",
        { class: "login-art" },
        h("h2", {}, "سجلات سلامة الغذاء جاهزة للتدقيق في كل لحظة"),
        h(
          "ul",
          {},
          h("li", {}, "مراقبة النقاط الحرجة بتوقيع إلكتروني ومراجعة شخص ثانٍ"),
          h("li", {}, "إجراءات تصحيحية وتنبيهات فورية بالبريد وواتساب"),
          h("li", {}, "تقارير مرقمة مضبوطة الإصدار وتحليل للبيانات")
        )
      ),
      h(
        "div",
        { class: "login" },
        h("div", { class: "logo" }, h("img", { src: "icons/icon-192.png", width: 56, height: 56, alt: "" })),
        h("div", { class: "lang-row", role: "group", "aria-label": "اللغة" }, langButtons()),
        h("h1", {}, "تسجيل الدخول"),
        h("p", { class: "muted" }, "نظام الجودة وسلامة الغذاء"),
        message ? h("p", { class: "error-box" }, message) : null,
        form
      )
    )
  );
}

async function loadUser() {
  state.user = await get("/auth/me");
  document.body.classList.remove("anon");
  document.getElementById("factory-name").textContent = state.tenant;
  document.getElementById("user-name").textContent = state.user.full_name;
  document.getElementById("user-role").textContent = tr(ROLES[state.user.role]);
  document.getElementById("user-initial").textContent = (state.user.full_name.trim()[0] || "?").toUpperCase();
  const quick = document.getElementById("new-record");
  quick.hidden = !can("write");
  quick.replaceChildren(icon("plus"), h("span", { class: "hide-sm" }, "قراءة جديدة"));
  buildNav();
}

const NAV = [
  ["", [
    ["#/home", "لوحة التحكم", "home", true],
    ["#/analytics", "تحليل البيانات", "chart", true],
  ]],
  ["التسجيل اليومي", [
    ["#/ccp/new", "قراءة نقطة حرجة", "thermo", "write"],
    ["#/sanitation/new", "النظافة والتعقيم", "drop", "write"],
    ["#/records", "السجلات", "list", true],
    ["#/review", "المراجعة", "review", "verify"],
  ]],
  ["المتابعة", [
    ["#/capa", "الإجراءات التصحيحية", "capa", true],
    ["#/alerts", "التنبيهات", "bell", true],
    ["#/reports", "التقارير", "file", true],
    ["#/documents", "ضبط الوثائق", "folder", true],
    ["#/suppliers", "اعتماد الموردين", "truck", true],
    ["#/training", "التدريب والكفاءة", "cap", true],
    ["#/tv", "شاشة العرض", "tv", true],
  ]],
  ["الإعدادات", [
    ["#/admin/ccps", "خطة الهاسب", "target", "ccp"],
    ["#/admin/users", "المستخدمون", "users", "users"],
    ["#/admin/notifications", "الإشعارات", "send", "notify"],
    ["#/audit", "السجل الأمني", "lock", "audit"],
    ["#/account", "حسابي", "user", true],
  ]],
];

function buildNav() {
  const nav = document.getElementById("nav");
  nav.replaceChildren(
    ...NAV.map(([group, links]) => {
      const shown = links.filter(([, , , need]) => need === true || can(need));
      if (!shown.length) return null;
      return h(
        "div",
        { class: "nav-group" },
        group ? h("span", {}, group) : null,
        shown.map(([href, label, ic]) => h("a", { href }, icon(ic), h("span", {}, label)))
      );
    }).filter(Boolean)
  );
  markNav();
}

function pageLabel() {
  const current = location.hash.split("?")[0];
  for (const [group, links] of NAV) {
    for (const [href, label] of links) if (current === href || current.startsWith(`${href}/`)) return [group, label];
  }
  return ["", ""];
}

function markNav() {
  const current = location.hash.split("?")[0];
  let best = null;
  for (const a of document.querySelectorAll("#nav a")) {
    a.classList.remove("active");
    a.removeAttribute("aria-current");
    const href = a.getAttribute("href");
    if ((current === href || current.startsWith(`${href}/`)) && (!best || href.length > best.getAttribute("href").length)) best = a;
  }
  if (best) {
    best.classList.add("active");
    best.setAttribute("aria-current", "page");
  }
  const [group, label] = pageLabel();
  document.getElementById("crumbs").textContent = [state.tenant, tr(group), tr(label)].filter(Boolean).join(" / ");
  openMenu(false);
}

function openMenu(open) {
  document.getElementById("sidebar").classList.toggle("open", open);
  document.getElementById("scrim").hidden = !open;
  document.getElementById("menu-toggle").setAttribute("aria-expanded", String(open));
}

document.getElementById("menu-toggle").append(icon("menu"));
document.getElementById("menu-toggle").addEventListener("click", () => openMenu(!document.getElementById("sidebar").classList.contains("open")));
document.getElementById("scrim").addEventListener("click", () => openMenu(false));
document.getElementById("bell").prepend(icon("bell"));
document.getElementById("logout").append(icon("logout"));
paintThemeButton();

async function refreshBell() {
  try {
    const summary = await get("/alerts/summary");
    const count = document.getElementById("bell-count");
    count.textContent = summary.open_alerts;
    count.hidden = !summary.open_alerts;
  } catch {
    // the page itself reports connection problems
  }
}

// A page title row: title, optional subtitle and actions.
function pageHead(title, sub, ...actions) {
  return h(
    "div",
    { class: "page-head" },
    h("div", {}, h("h1", {}, title), sub ? h("p", { class: "sub" }, sub) : null),
    actions.length ? h("div", { class: "actions" }, actions) : null
  );
}

// ----- shared pieces -----------------------------------------------------------------------

function signatures(list) {
  if (!list.length) return h("p", { class: "muted" }, "لا توجد توقيعات");
  return h(
    "div",
    {},
    list.map((s) =>
      h(
        "div",
        { class: "sig" },
        badge(MEANINGS[s.meaning] || s.meaning, s.meaning === "performed" ? "" : "ok"),
        h("strong", {}, s.signer_name),
        h("small", {}, ROLES[s.signer_role] || s.signer_role),
        h("small", {}, when(s.signed_at)),
        s.comment ? h("span", {}, `«${s.comment}»`) : null,
        s.intact ? badge("التوقيع سليم", "ok") : badge("عُدِّل السجل بعد توقيعه!", "bad")
      )
    )
  );
}

function isVerified(record) {
  return record.signatures.some((s) => s.meaning === "verified");
}

function verifyForm(path, onDone, label = "مراجعة وتوقيع") {
  return apiForm(
    [h("div", { class: "fields" }, field("تعليق (اختياري)", input("comment", { maxlength: 500 })), signField())],
    async (data) => {
      await post(`${path}/verify`, data);
      toast("تمت المراجعة والتوقيع", "ok");
      onDone();
    },
    label
  );
}

function changesText(changes) {
  return Object.entries(changes)
    .map(([key, change]) => {
      const show = (v) => (v === null ? "فارغ" : ACTIVITIES[v] || RESULTS[v] || v);
      return `${FIELD_NAMES[key] || key}: من ${show(change.from)} إلى ${show(change.to)}`;
    })
    .join("، ");
}

function amendmentsBlock(record, reload) {
  if (!record.amendments.length) return null;
  return h(
    "div",
    { class: "card" },
    h("h3", {}, "التصحيحات"),
    record.amendments.map((a) =>
      h(
        "div",
        { class: "card" },
        h("p", {}, serialTag(a.serial), " ", h("strong", {}, changesText(a.changes))),
        h("p", {}, "السبب: ", isolate(a.reason), " · ", h("small", {}, when(a.amended_at))),
        signatures(a.signatures),
        a.verified
          ? badge("روجع التصحيح", "ok")
          : can("verify")
            ? panel("مراجعة التصحيح", verifyForm(`/amendments/${a.id}`, reload, "مراجعة التصحيح"))
            : badge("بانتظار المراجعة", "warn")
      )
    )
  );
}

function capaLink(record) {
  if (!record.corrective_action_id) return null;
  const open = record.corrective_action_status === "open";
  return h(
    "a",
    { href: `#/capa/${record.corrective_action_id}` },
    badge(open ? "إجراء تصحيحي مفتوح" : "إجراء تصحيحي مغلق", open ? "bad" : "ok")
  );
}

async function controlPoints() {
  return get("/control-points");
}

// ----- pages -------------------------------------------------------------------------------

function alertCard(alert, reload) {
  const open = !alert.acknowledged_at;
  return h(
    "div",
    { class: `card ${open ? (alert.severity === "critical" ? "deviation" : "warn") : ""}` },
    h(
      "div",
      { class: "actions" },
      badge(SEVERITIES[alert.severity], alert.severity === "critical" ? "bad" : "warn"),
      h("strong", {}, ALERT_KINDS[alert.kind]),
      h("small", {}, when(alert.raised_at))
    ),
    h("p", { class: "ltr", style: "text-align:start" }, alert.message),
    alert.record_type === "ccp_reading" ? h("a", { href: `#/ccp/${alert.record_id}` }, "عرض القراءة") : null,
    alert.record_type === "sanitation_record" ? h("a", { href: `#/sanitation/${alert.record_id}` }, "عرض السجل") : null,
    alert.record_type === "supplier" ? h("a", { href: `#/suppliers/${alert.record_id}` }, "عرض المورد") : null,
    alert.record_type === "supplier_document" ? h("a", { href: "#/suppliers?show=expiring" }, "عرض الموردين") : null,
    alert.record_type === "training_record" ? h("a", { href: "#/training" }, "عرض مصفوفة التدريب") : null,
    open
      ? can("verify")
        ? panel(
            "تأكيد الاطلاع على التنبيه",
            apiForm(
              [field("الإجراء المتخذ", input("comment", { maxlength: 500, placeholder: "مثال: أُوقف الخط وأُبلغ قسم الجودة" }))],
              async (data) => {
                await post(`/alerts/${alert.id}/acknowledge`, data);
                toast("تم تأكيد الاطلاع على التنبيه", "ok");
                reload();
              },
              "تأكيد"
            )
          )
        : null
      : h("p", { class: "muted" }, `تم الاطلاع ${when(alert.acknowledged_at)}`, alert.acknowledgement ? `: ${alert.acknowledgement}` : "")
  );
}

async function ccpNewPage() {
  const points = await controlPoints();
  if (!points.length) {
    render(h("h1", {}, "قراءة نقطة تحكم حرجة"), empty("لم تُعرَّف أي نقطة تحكم حرجة بعد. يضيفها مدير الجودة من «خطة الهاسب»."));
    return;
  }
  const byId = Object.fromEntries(points.map((p) => [p.id, p]));
  const pointSelect = h(
    "select",
    { name: "control_point_id", required: true },
    points.map((p) => h("option", { value: p.id }, `${p.code} | ${p.name}`))
  );
  const info = h("p", { class: "muted" });
  const value = input("value", { required: true, inputmode: "decimal", class: "ltr big", pattern: "-?[0-9]+([.,][0-9]+)?" });
  const caField = field(
    "الإجراء التصحيحي الفوري المتخذ",
    textarea("corrective_action", { maxlength: 2000 }),
    "القراءة خارج الحدود الحرجة: يجب توثيق الإجراء المتخذ"
  );
  const status = h("div");
  const lots = await get("/lots").catch(() => []);
  const update = () => {
    const p = byId[pointSelect.value];
    info.textContent = `${isolate(p.parameter)} · ${tr("الحد الحرج")}: ${limits(p)}${p.monitoring_frequency ? ` · ${isolate(p.monitoring_frequency)}` : ""}`;
    const v = Number(value.value.replace(",", "."));
    const has = value.value.trim() !== "" && !Number.isNaN(v);
    const out = has && ((p.critical_min !== null && v < Number(p.critical_min)) || (p.critical_max !== null && v > Number(p.critical_max)));
    caField.hidden = !out;
    caField.querySelector("textarea").required = out;
    status.className = has ? `live-check ${out ? "bad" : "ok"}` : "";
    status.replaceChildren(...(has ? [icon(out ? "x" : "check"), out ? "انحراف: القيمة خارج الحدود الحرجة" : "ضمن الحدود الحرجة"] : []));
  };
  pointSelect.addEventListener("change", update);
  value.addEventListener("input", update);
  const form = apiForm(
    [
      field("نقطة التحكم", pointSelect),
      info,
      h("div", { class: "fields" }, field("القيمة", value), status),
      caField,
      panel(
        "تفاصيل إضافية (اختياري)",
        h(
          "div",
          { class: "fields" },
          field("وقت القياس", input("measured_at", { type: "datetime-local" }), "إذا تُرك فارغًا يُستخدم الوقت الحالي"),
          field(
            "التشغيلة",
            h("select", { name: "lot_id" }, h("option", { value: "" }, "—"), lots.map((l) => h("option", { value: l.id }, `${l.lot_code} · ${l.item_name}`)))
          ),
          field("ملاحظات", textarea("notes", { maxlength: 2000 }))
        )
      ),
      signField(),
    ],
    async (data) => {
      data.value = data.value.replace(",", ".");
      if (caField.hidden) delete data.corrective_action;
      const saved = await post("/ccp-readings", data);
      toast(saved.within_limits ? "سُجِّلت القراءة" : "سُجِّل انحراف، وفُتح إجراء تصحيحي، وأُرسل تنبيه", saved.within_limits ? "ok" : "error");
      location.hash = `#/ccp/${saved.id}`;
    },
    "تسجيل وتوقيع"
  );
  render(h("h1", {}, "تسجيل قراءة نقطة تحكم حرجة"), h("div", { class: "card" }, form));
  update();
}

async function sanitationNewPage() {
  const result = select("result", RESULTS, { required: true });
  const caField = field("الإجراء التصحيحي", textarea("corrective_action", { maxlength: 2000 }), "الفحص غير مطابق: يجب توثيق الإجراء المتخذ");
  const update = () => {
    const failed = result.value === "fail";
    caField.hidden = !failed;
    caField.querySelector("textarea").required = failed;
  };
  result.addEventListener("change", update);
  const form = apiForm(
    [
      h(
        "div",
        { class: "fields" },
        field("المنطقة / المعدة", input("area", { required: true, maxlength: 100, placeholder: "MIXER-1" })),
        field("النشاط", select("activity", ACTIVITIES, { required: true })),
        field("المادة المستخدمة", input("chemical", { maxlength: 100 })),
        field("التركيز (ppm)", input("concentration_ppm", { inputmode: "decimal", class: "ltr" })),
        field("النتيجة", result)
      ),
      caField,
      panel(
        "تفاصيل إضافية (اختياري)",
        h(
          "div",
          { class: "fields" },
          field("وقت التنفيذ", input("performed_at", { type: "datetime-local" }), "إذا تُرك فارغًا يُستخدم الوقت الحالي"),
          field("ملاحظات", textarea("notes", { maxlength: 2000 }))
        )
      ),
      signField(),
    ],
    async (data) => {
      if (caField.hidden) delete data.corrective_action;
      const saved = await post("/sanitation-records", data);
      toast(saved.result === "pass" ? "سُجِّل الفحص" : "سُجِّل عدم مطابقة، وفُتح إجراء تصحيحي", saved.result === "pass" ? "ok" : "error");
      location.hash = `#/sanitation/${saved.id}`;
    },
    "تسجيل وتوقيع"
  );
  render(h("h1", {}, "تسجيل فحص نظافة وتعقيم"), h("div", { class: "card" }, form));
  update();
}

async function recordsPage(params) {
  const tab = params.get("tab") || "ccp";
  const tabs = h(
    "div",
    { class: "tabs" },
    h("a", { href: "#/records?tab=ccp", class: tab === "ccp" ? "active" : "" }, "قراءات النقاط الحرجة"),
    h("a", { href: "#/records?tab=sanitation", class: tab === "sanitation" ? "active" : "" }, "النظافة والتعقيم")
  );
  const results = h("div");
  let filters;
  if (tab === "ccp") {
    const points = await controlPoints();
    filters = h(
      "div",
      { class: "fields" },
      field("نقطة التحكم", h("select", { name: "control_point_id" }, h("option", { value: "" }, "الكل"), points.map((p) => h("option", { value: p.id }, p.code)))),
      field("من", input("measured_from", { type: "datetime-local" })),
      field("إلى", input("measured_to", { type: "datetime-local" })),
      h("label", { class: "check" }, input("deviations_only", { type: "checkbox" }), "الانحرافات فقط"),
      h("label", { class: "check" }, input("unverified_only", { type: "checkbox" }), "بانتظار المراجعة فقط")
    );
  } else {
    filters = h(
      "div",
      { class: "fields" },
      field("المنطقة", input("area", { maxlength: 100 })),
      field("من", input("performed_from", { type: "datetime-local" })),
      field("إلى", input("performed_to", { type: "datetime-local" })),
      h("label", { class: "check" }, input("failures_only", { type: "checkbox" }), "غير المطابق فقط"),
      h("label", { class: "check" }, input("unverified_only", { type: "checkbox" }), "بانتظار المراجعة فقط")
    );
  }
  const load = async (data = {}) => {
    const rows = tab === "ccp" ? await get("/ccp-readings", { ...data, limit: 200 }) : await get("/sanitation-records", { ...data, limit: 200 });
    results.replaceChildren(rows.length ? (tab === "ccp" ? ccpTable(rows) : sanitationTable(rows)) : empty("لا توجد سجلات"));
  };
  const form = apiForm([filters], load, "عرض");
  // Links from the dashboard and analytics arrive with their filters in the address.
  for (const [key, value] of params) {
    const el = form.elements.namedItem(key);
    if (!el) continue;
    if (el.type === "checkbox") el.checked = value === "1" || value === "true";
    else el.value = value;
  }
  render(h("h1", {}, "السجلات"), tabs, h("div", { class: "card" }, form), results);
  await load(formData(form));
}

function performer(record) {
  const s = record.signatures.find((x) => x.meaning === "performed");
  return s ? s.signer_name : "";
}

function statusBadges(record) {
  return [
    isVerified(record) && record.verified ? badge("تمت المراجعة", "ok") : badge("بانتظار المراجعة", "warn"),
    record.amended ? badge("مصحَّح", "") : null,
  ];
}

function ccpTable(rows) {
  return h(
    "div",
    { class: "table-wrap" },
    h(
      "table",
      {},
      h("thead", {}, h("tr", {}, ["الرقم", "الوقت", "النقطة", "القيمة", "الحدود", "الحالة", "المسجِّل", ""].map((t) => h("th", {}, t)))),
      h(
        "tbody",
        {},
        rows.map((r) =>
          h(
            "tr",
            { class: `clickable ${r.within_limits ? "" : "deviation"}`, onclick: () => (location.hash = `#/ccp/${r.id}`) },
            h("td", { class: "ltr nowrap" }, r.serial || "—"),
            h("td", {}, when(r.measured_at)),
            h("td", {}, r.control_point_code),
            h("td", { class: "ltr" }, `${num(r.value)} ${r.unit}`),
            h("td", {}, limits(r)),
            h("td", {}, r.within_limits ? badge("ضمن الحدود", "ok") : badge("انحراف", "bad")),
            h("td", {}, performer(r)),
            h("td", {}, statusBadges(r))
          )
        )
      )
    )
  );
}

function sanitationTable(rows) {
  return h(
    "div",
    { class: "table-wrap" },
    h(
      "table",
      {},
      h("thead", {}, h("tr", {}, ["الرقم", "الوقت", "المنطقة", "النشاط", "المادة", "النتيجة", "المسجِّل", ""].map((t) => h("th", {}, t)))),
      h(
        "tbody",
        {},
        rows.map((r) =>
          h(
            "tr",
            { class: `clickable ${r.result === "fail" ? "deviation" : ""}`, onclick: () => (location.hash = `#/sanitation/${r.id}`) },
            h("td", { class: "ltr nowrap" }, r.serial || "—"),
            h("td", {}, when(r.performed_at)),
            h("td", { class: "ltr" }, r.area),
            h("td", {}, ACTIVITIES[r.activity]),
            h("td", {}, [r.chemical, r.concentration_ppm ? `${num(r.concentration_ppm)} ppm` : ""].filter(Boolean).join(" ")),
            h("td", {}, r.result === "pass" ? badge("مطابق", "ok") : badge("غير مطابق", "bad")),
            h("td", {}, performer(r)),
            h("td", {}, statusBadges(r))
          )
        )
      )
    )
  );
}

async function ccpDetailPage(id) {
  const r = await get(`/ccp-readings/${id}`);
  const reload = () => ccpDetailPage(id);
  const amend = apiForm(
    [
      h(
        "div",
        { class: "fields" },
        field("القيمة الصحيحة", input("value", { inputmode: "decimal", class: "ltr" })),
        field("وقت القياس الصحيح", input("measured_at", { type: "datetime-local" })),
        field("ملاحظات", input("notes", { maxlength: 2000 }))
      ),
      field("سبب التصحيح", textarea("reason", { required: true, maxlength: 2000 })),
      field("الإجراء التصحيحي", textarea("corrective_action", { maxlength: 2000 }), "مطلوب فقط إذا جعل التصحيحُ القراءةَ انحرافًا"),
      signField(),
    ],
    async (data) => {
      if (data.value) data.value = data.value.replace(",", ".");
      await post(`/ccp-readings/${id}/amendments`, data);
      toast("سُجِّل التصحيح، وهو بانتظار المراجعة", "ok");
      reload();
    },
    "تسجيل التصحيح"
  );
  render(
    h("p", {}, h("a", { href: "#/records?tab=ccp" }, "→ السجلات")),
    h("h1", {}, `قراءة ${r.control_point_code} | ${r.control_point_name}`),
    serialTag(r.serial),
    h(
      "div",
      { class: `card ${r.within_limits ? "" : "deviation"}` },
      h(
        "dl",
        { class: "facts" },
        h("dt", {}, "القيمة"), h("dd", {}, h("span", { class: "ltr" }, `${num(r.value)} ${r.unit}${r.amended ? " *" : ""}`)),
        h("dt", {}, "الحد الحرج"), h("dd", {}, limits(r)),
        h("dt", {}, "الحالة"), h("dd", {}, r.within_limits ? badge("ضمن الحدود", "ok") : badge("انحراف", "bad"), " ", capaLink(r)),
        h("dt", {}, "وقت القياس"), h("dd", {}, when(r.measured_at)),
        r.corrective_action ? [h("dt", {}, "الإجراء الفوري"), h("dd", {}, r.corrective_action)] : null,
        r.notes ? [h("dt", {}, "ملاحظات"), h("dd", {}, r.notes)] : null,
        h("dt", {}, "المراجعة"), h("dd", {}, statusBadges(r))
      )
    ),
    h("div", { class: "card" }, h("h3", {}, "التوقيعات"), signatures(r.signatures)),
    amendmentsBlock(r, reload),
    can("verify") && !isVerified(r) ? panel("مراجعة القراءة", verifyForm(`/ccp-readings/${id}`, reload)) : null,
    can("write") ? panel("تصحيح القراءة (تبقى القراءة الأصلية محفوظة)", amend) : null
  );
}

async function sanitationDetailPage(id) {
  const r = await get(`/sanitation-records/${id}`);
  const reload = () => sanitationDetailPage(id);
  const amend = apiForm(
    [
      h(
        "div",
        { class: "fields" },
        field("المنطقة", input("area", { maxlength: 100 })),
        field("النشاط", h("select", { name: "activity" }, h("option", { value: "" }, "دون تغيير"), Object.entries(ACTIVITIES).map(([v, l]) => h("option", { value: v }, l)))),
        field("المادة", input("chemical", { maxlength: 100 })),
        field("التركيز (ppm)", input("concentration_ppm", { inputmode: "decimal", class: "ltr" })),
        field("النتيجة", h("select", { name: "result" }, h("option", { value: "" }, "دون تغيير"), Object.entries(RESULTS).map(([v, l]) => h("option", { value: v }, l)))),
        field("ملاحظات", input("notes", { maxlength: 2000 }))
      ),
      field("سبب التصحيح", textarea("reason", { required: true, maxlength: 2000 })),
      field("الإجراء التصحيحي", textarea("corrective_action", { maxlength: 2000 }), "مطلوب فقط إذا جعل التصحيحُ النتيجةَ غير مطابقة"),
      signField(),
    ],
    async (data) => {
      await post(`/sanitation-records/${id}/amendments`, data);
      toast("سُجِّل التصحيح، وهو بانتظار المراجعة", "ok");
      reload();
    },
    "تسجيل التصحيح"
  );
  render(
    h("p", {}, h("a", { href: "#/records?tab=sanitation" }, "→ السجلات")),
    h("h1", {}, `فحص نظافة: ${r.area}`),
    serialTag(r.serial),
    h(
      "div",
      { class: `card ${r.result === "fail" ? "deviation" : ""}` },
      h(
        "dl",
        { class: "facts" },
        h("dt", {}, "النشاط"), h("dd", {}, ACTIVITIES[r.activity]),
        h("dt", {}, "المادة"), h("dd", {}, [r.chemical, r.concentration_ppm ? `${num(r.concentration_ppm)} ppm` : ""].filter(Boolean).join(" ") || "—"),
        h("dt", {}, "النتيجة"), h("dd", {}, r.result === "pass" ? badge("مطابق", "ok") : badge("غير مطابق", "bad"), " ", capaLink(r)),
        h("dt", {}, "الوقت"), h("dd", {}, when(r.performed_at)),
        r.corrective_action ? [h("dt", {}, "الإجراء الفوري"), h("dd", {}, r.corrective_action)] : null,
        r.notes ? [h("dt", {}, "ملاحظات"), h("dd", {}, r.notes)] : null,
        h("dt", {}, "المراجعة"), h("dd", {}, statusBadges(r))
      )
    ),
    h("div", { class: "card" }, h("h3", {}, "التوقيعات"), signatures(r.signatures)),
    amendmentsBlock(r, reload),
    can("verify") && !isVerified(r) ? panel("مراجعة السجل", verifyForm(`/sanitation-records/${id}`, reload)) : null,
    can("write") ? panel("تصحيح السجل (يبقى الأصل محفوظًا)", amend) : null
  );
}

async function reviewPage() {
  const [readings, checks, amendments] = await Promise.all([
    get("/ccp-readings", { unverified_only: true, limit: 200 }),
    get("/sanitation-records", { unverified_only: true, limit: 200 }),
    get("/amendments", { unverified_only: true, limit: 200 }),
  ]);
  const needsOwn = (r) => !isVerified(r);
  const ccpOwn = readings.filter(needsOwn);
  const sanOwn = checks.filter(needsOwn);
  const item = (title, href, record, path, deviation) =>
    h(
      "div",
      { class: `card ${deviation ? "deviation" : ""}` },
      h("div", { class: "actions" }, serialTag(record.serial), h("a", { href }, h("strong", {}, title)), h("small", {}, `سجّله ${performer(record)} · ${when(record.created_at)}`)),
      record.corrective_action ? h("p", {}, "الإجراء الفوري: ", record.corrective_action) : null,
      panel("مراجعة وتوقيع", verifyForm(path, reviewPage))
    );
  render(
    h("h1", {}, "المراجعة"),
    h("p", { class: "muted" }, "يجب أن تتم المراجعة بواسطة شخص غير الذي سجّل. كل مراجعة توقيع إلكتروني بكلمة المرور."),
    h("h2", {}, `قراءات النقاط الحرجة (${ccpOwn.length})`),
    ccpOwn.length
      ? ccpOwn.map((r) => item(`${r.control_point_code}: ${num(r.value)} ${r.unit} ${r.within_limits ? "" : "(انحراف)"}`, `#/ccp/${r.id}`, r, `/ccp-readings/${r.id}`, !r.within_limits))
      : empty("لا يوجد"),
    h("h2", {}, `فحوصات النظافة (${sanOwn.length})`),
    sanOwn.length
      ? sanOwn.map((r) => item(`${r.area}: ${ACTIVITIES[r.activity]} · ${RESULTS[r.result]}`, `#/sanitation/${r.id}`, r, `/sanitation-records/${r.id}`, r.result === "fail"))
      : empty("لا يوجد"),
    h("h2", {}, `التصحيحات (${amendments.length})`),
    amendments.length
      ? amendments.map((a) =>
          h(
            "div",
            { class: "card" },
            h(
              "div",
              { class: "actions" },
              h("a", { href: a.record_type === "ccp_reading" ? `#/ccp/${a.record_id}` : `#/sanitation/${a.record_id}` }, h("strong", {}, changesText(a.changes))),
              h("small", {}, when(a.amended_at))
            ),
            h("p", {}, "السبب: ", isolate(a.reason)),
            signatures(a.signatures),
            panel("مراجعة التصحيح", verifyForm(`/amendments/${a.id}`, reviewPage, "مراجعة التصحيح"))
          )
        )
      : empty("لا يوجد")
  );
}

async function capaPage(params) {
  const status = params.get("status") || "open";
  const list = await get("/corrective-actions", { status, limit: 200 });
  render(
    h("h1", {}, "الإجراءات التصحيحية"),
    h(
      "div",
      { class: "tabs" },
      h("a", { href: "#/capa?status=open", class: status === "open" ? "active" : "" }, "مفتوحة"),
      h("a", { href: "#/capa?status=closed", class: status === "closed" ? "active" : "" }, "مغلقة")
    ),
    list.length ? list.map((c) => capaCard(c, () => capaPage(params))) : empty(status === "open" ? "لا توجد إجراءات مفتوحة 👍" : "لا يوجد")
  );
}

async function capaDetailPage(id) {
  const c = await get(`/corrective-actions/${id}`);
  render(h("p", {}, h("a", { href: "#/capa" }, "→ الإجراءات التصحيحية")), h("h1", {}, "إجراء تصحيحي"), capaCard(c, () => capaDetailPage(id)));
}

function capaCard(c, reload) {
  const open = c.status === "open";
  const recordHref = c.record_type === "ccp_reading" ? `#/ccp/${c.record_id}` : `#/sanitation/${c.record_id}`;
  return h(
    "div",
    { class: `card ${open ? "deviation" : ""}` },
    h("div", { class: "actions" }, serialTag(c.serial), open ? badge("مفتوح", "bad") : badge("مغلق", "ok"), h("strong", {}, isolate(c.description))),
    h(
      "dl",
      { class: "facts", style: "margin-top:.6rem" },
      h("dt", {}, "الإجراء الفوري"), h("dd", {}, c.immediate_action),
      h("dt", {}, "تاريخ الفتح"), h("dd", {}, when(c.opened_at), " · ", h("a", { href: recordHref }, "السجل")),
      open ? null : [
        h("dt", {}, "السبب الجذري"), h("dd", {}, c.root_cause),
        h("dt", {}, "الإجراء الوقائي"), h("dd", {}, c.preventive_action),
        h("dt", {}, "التصرف في المنتج"), h("dd", {}, DISPOSITIONS[c.product_disposition]),
        h("dt", {}, "تاريخ الإغلاق"), h("dd", {}, when(c.closed_at)),
      ]
    ),
    open ? null : signatures(c.signatures),
    open && can("close")
      ? panel(
          "إغلاق الإجراء (مدير الجودة / مدير النظام)",
          apiForm(
            [
              field("السبب الجذري", textarea("root_cause", { required: true, maxlength: 2000 })),
              field("الإجراء الوقائي", textarea("preventive_action", { required: true, maxlength: 2000 }), "ما الذي سيمنع تكرار المشكلة؟"),
              field("التصرف في المنتج المتأثر", select("product_disposition", DISPOSITIONS, { required: true })),
              field("تعليق (اختياري)", input("comment", { maxlength: 500 })),
              signField("كلمة المرور (توقيع اعتماد)"),
            ],
            async (data) => {
              await post(`/corrective-actions/${c.id}/close`, data);
              toast("أُغلق الإجراء واعتُمد", "ok");
              reload();
            },
            "إغلاق واعتماد"
          )
        )
      : null
  );
}

async function alertsPage(params) {
  const open = params.get("open") !== "all";
  const list = await get("/alerts", { open_only: open, limit: 200 });
  render(
    h("h1", {}, "التنبيهات"),
    h(
      "div",
      { class: "tabs" },
      h("a", { href: "#/alerts", class: open ? "active" : "" }, "المفتوحة"),
      h("a", { href: "#/alerts?open=all", class: open ? "" : "active" }, "الكل")
    ),
    can("verify")
      ? h(
          "div",
          { class: "actions", style: "margin-bottom:1rem" },
          h(
            "button",
            {
              class: "secondary",
              onclick: async () => {
                try {
                  const r = await post("/alerts/scan-missed-checks");
                  toast(r.raised ? `أُنشئ ${r.raised} تنبيه فحص متأخر` : "لا توجد فحوصات متأخرة", "ok");
                  alertsPage(params);
                } catch (exc) {
                  toast(exc.message, "error");
                }
              },
            },
            "البحث عن الفحوصات المتأخرة الآن"
          )
        )
      : null,
    list.length ? list.map((a) => alertCard(a, () => alertsPage(params))) : empty("لا توجد تنبيهات")
  );
}

function isoDate(d) {
  return d.toISOString().slice(0, 10);
}

async function reportsPage() {
  const today = new Date();
  const weekAgo = new Date(Date.now() - 6 * 86400000);
  const [points, lots] = await Promise.all([controlPoints(), get("/lots").catch(() => [])]);
  const period = h(
    "div",
    { class: "fields" },
    field("من تاريخ", input("date_from", { type: "date", value: isoDate(weekAgo) })),
    field("إلى تاريخ", input("date_to", { type: "date", value: isoDate(today) })),
    field("اللغة", select("lang", { ar: "العربية", en: "English" }))
  );
  const read = () => Object.fromEntries([...period.querySelectorAll("input,select")].map((el) => [el.name, el.value]));
  const summaryBox = h("div");

  const download = async (path, extra = {}) => {
    const p = read();
    const params = path.startsWith("/reports/trace") ? { lang: p.lang } : { ...p, ...extra };
    try {
      const response = await api("GET", path + query(params), undefined, { raw: true });
      const blob = await response.blob();
      const name = decodeURIComponent((response.headers.get("content-disposition") || "").split("''")[1] || "report.pdf");
      const url = URL.createObjectURL(blob);
      const a = h("a", { href: url, download: name });
      document.body.append(a);
      a.click();
      a.remove();
      window.open(url, "_blank");
      const number = response.headers.get("x-report-number");
      if (number) toast(`صدر التقرير رقم ${number}، وسُجِّل في «ضبط الوثائق»`, "ok");
      setTimeout(() => URL.revokeObjectURL(url), 60000);
    } catch (exc) {
      if (!(exc instanceof SessionEnded)) toast(exc.message, "error");
    }
  };

  const showSummary = async () => {
    const p = read();
    try {
      const s = await get("/reports/haccp-summary", { date_from: p.date_from, date_to: p.date_to });
      summaryBox.replaceChildren(
        h(
          "div",
          { class: "stats" },
          [
            [s.ccp_readings, "قراءات النقاط الحرجة"],
            [s.ccp_deviations, "انحرافات"],
            [s.sanitation_checks, "فحوصات النظافة"],
            [s.sanitation_failures, "عدم مطابقة النظافة"],
            [s.unverified_records, "بانتظار المراجعة"],
            [s.corrective_actions_opened, "إجراءات فُتحت"],
            [s.corrective_actions_open_now, "مفتوحة حاليًا"],
          ].map(([v, l]) => h("div", { class: "stat" }, h("b", {}, v), l))
        ),
        s.control_points.length
          ? h(
              "div",
              { class: "table-wrap", style: "margin-top:1rem" },
              h(
                "table",
                {},
                h("thead", {}, h("tr", {}, ["النقطة", "قراءات", "انحرافات", "بانتظار المراجعة", "آخر قراءة"].map((t) => h("th", {}, t)))),
                h("tbody", {}, s.control_points.map((c) => h("tr", {}, h("td", {}, `${c.code} | ${c.name}`), h("td", {}, c.readings), h("td", {}, c.deviations), h("td", {}, c.unverified), h("td", {}, when(c.last_reading_at)))))
              )
            )
          : null
      );
    } catch (exc) {
      toast(exc.message, "error");
    }
  };

  const pointSel = h("select", {}, h("option", { value: "" }, "كل النقاط"), points.map((p) => h("option", { value: p.id }, p.code)));
  const areaIn = h("input", { placeholder: "كل المناطق" });
  const capaSel = h("select", {}, h("option", { value: "" }, "الكل"), h("option", { value: "open" }, "المفتوحة"), h("option", { value: "closed" }, "المغلقة"));
  const lotSel = h("select", {}, lots.map((l) => h("option", { value: l.id }, `${l.lot_code} · ${l.item_name}`)));

  const reportCard = (title, control, onClick) =>
    h("div", { class: "card" }, h("h3", {}, title), control ? field("", control) : null, h("div", { class: "actions" }, h("button", { onclick: onClick }, "تنزيل PDF")));

  render(
    h("h1", {}, "التقارير"),
    h("div", { class: "card" }, period, h("div", { class: "actions", style: "margin-top:.8rem" }, h("button", { class: "secondary", onclick: showSummary }, "ملخص الهاسب للفترة"))),
    summaryBox,
    h(
      "div",
      { class: "grid", style: "margin-top:1rem" },
      reportCard("سجل مراقبة النقاط الحرجة", pointSel, () => download("/reports/ccp-log", { control_point_id: pointSel.value })),
      reportCard("سجل النظافة والتعقيم", areaIn, () => download("/reports/sanitation-log", { area: areaIn.value.trim() })),
      reportCard("سجل الإجراءات التصحيحية", capaSel, () => download("/reports/corrective-actions", { status: capaSel.value })),
      reportCard("سجل التدريب (للفترة)", null, () => download("/reports/training-log")),
      reportCard("مصفوفة التدريب والكفاءة", null, () => download("/reports/training-matrix", { date_from: undefined, date_to: undefined })),
      reportCard("قائمة الموردين المعتمدين", null, () => download("/reports/supplier-list", { date_from: undefined, date_to: undefined })),
      lots.length
        ? reportCard("تقرير تتبع تشغيلة (استدعاء تجريبي)", lotSel, () => download(`/reports/trace/${lotSel.value}`))
        : h("div", { class: "card" }, h("h3", {}, "تقرير التتبع"), h("p", { class: "muted" }, "لا توجد تشغيلات مسجلة"))
    )
  );
}

// ----- admin: HACCP plan -------------------------------------------------------------------

async function ccpsPage() {
  const points = await controlPoints();
  const create = apiForm(
    [
      h(
        "div",
        { class: "fields" },
        field("الرمز", input("code", { required: true, maxlength: 64, class: "ltr", placeholder: "CCP-2" })),
        field("الاسم", input("name", { required: true, maxlength: 200, placeholder: "Cooling" })),
        field("الخطر", input("hazard", { required: true, maxlength: 500 })),
        field("المعيار", input("parameter", { required: true, maxlength: 100, placeholder: "Core temperature" })),
        field("الوحدة", input("unit", { required: true, maxlength: 16, placeholder: "°C" })),
        field("حد أدنى", input("critical_min", { inputmode: "decimal", class: "ltr" })),
        field("حد أقصى", input("critical_max", { inputmode: "decimal", class: "ltr" })),
        field("تكرار المراقبة", input("monitoring_frequency", { maxlength: 100, placeholder: "Every hour" })),
        field("تنبيه عند غياب القراءة لمدة (دقيقة)", input("check_interval_minutes", { type: "number", min: 1 }))
      ),
    ],
    async (data) => {
      if (data.check_interval_minutes) data.check_interval_minutes = Number(data.check_interval_minutes);
      await post("/control-points", data);
      toast("أُضيفت النقطة", "ok");
      ccpsPage();
    },
    "إضافة"
  );
  render(
    h("h1", {}, "خطة الهاسب: نقاط التحكم الحرجة"),
    points.length
      ? points.map((p) =>
          h(
            "div",
            { class: "card" },
            h("h3", {}, `${p.code} | ${p.name}`),
            h(
              "dl",
              { class: "facts" },
              h("dt", {}, "الخطر"), h("dd", {}, p.hazard),
              h("dt", {}, "المعيار"), h("dd", {}, `${p.parameter} (${p.unit})`),
              h("dt", {}, "الحد الحرج"), h("dd", {}, limits(p)),
              h("dt", {}, "التكرار"), h("dd", {}, p.monitoring_frequency || "—"),
              h("dt", {}, "تنبيه التأخير"), h("dd", {}, p.check_interval_minutes ? `كل ${p.check_interval_minutes} دقيقة` : "معطَّل")
            ),
            panel(
              "تعديل",
              apiForm(
                [
                  h(
                    "div",
                    { class: "fields" },
                    field("حد أدنى", input("critical_min", { inputmode: "decimal", class: "ltr", value: p.critical_min === null ? "" : num(p.critical_min) })),
                    field("حد أقصى", input("critical_max", { inputmode: "decimal", class: "ltr", value: p.critical_max === null ? "" : num(p.critical_max) })),
                    field("تكرار المراقبة", input("monitoring_frequency", { maxlength: 100, value: p.monitoring_frequency || "" })),
                    field("تنبيه التأخير (دقيقة)", input("check_interval_minutes", { type: "number", min: 1, value: p.check_interval_minutes || "" }))
                  ),
                  field("سبب التعديل", input("reason", { required: true, maxlength: 500, placeholder: "HACCP team review" })),
                ],
                async (data) => {
                  // Send only what changed; a cleared field becomes null.
                  const body = { reason: data.reason };
                  const now = {
                    critical_min: data.critical_min ?? null,
                    critical_max: data.critical_max ?? null,
                    monitoring_frequency: data.monitoring_frequency ?? null,
                    check_interval_minutes: data.check_interval_minutes ? Number(data.check_interval_minutes) : null,
                  };
                  const before = {
                    critical_min: p.critical_min === null ? null : num(p.critical_min),
                    critical_max: p.critical_max === null ? null : num(p.critical_max),
                    monitoring_frequency: p.monitoring_frequency,
                    check_interval_minutes: p.check_interval_minutes,
                  };
                  for (const key of Object.keys(now)) if (String(now[key]) !== String(before[key])) body[key] = now[key];
                  if (Object.keys(body).length === 1) throw new Error("لم يتغير شيء");
                  await patch(`/control-points/${p.id}`, body);
                  toast("عُدِّلت. تحتفظ القراءات السابقة بالحدود التي كانت سارية وقتها.", "ok");
                  ccpsPage();
                }
              )
            )
          )
        )
      : empty("لا توجد نقاط بعد"),
    panel("+ إضافة نقطة تحكم حرجة", create)
  );
}

// ----- admin: users ------------------------------------------------------------------------

async function usersPage() {
  const users = await get("/users");
  const create = apiForm(
    [
      h(
        "div",
        { class: "fields" },
        field("الاسم", input("full_name", { required: true, maxlength: 200 })),
        field("البريد الإلكتروني", input("email", { type: "email", required: true, class: "ltr" })),
        field("الدور", select("role", ROLES, { required: true })),
        field("رقم الجوال (اختياري)", input("phone", { type: "tel", class: "ltr", maxlength: 24, placeholder: "+966501234567" }), "لإرسال التنبيهات إليه عبر واتساب"),
        field("كلمة المرور", input("password", { type: "password", required: true, minlength: 10, autocomplete: "new-password" }), "10 أحرف على الأقل")
      ),
    ],
    async (data) => {
      await post("/users", data);
      toast("أُنشئ المستخدم", "ok");
      usersPage();
    },
    "إضافة مستخدم"
  );
  render(
    h("h1", {}, "المستخدمون"),
    users.map((u) => {
      const me = u.id === state.user.id;
      return h(
        "div",
        { class: `card ${u.locked_at ? "deviation" : !u.is_active ? "warn" : ""}` },
        h(
          "div",
          { class: "actions" },
          h("strong", {}, u.full_name),
          h("span", { class: "ltr" }, u.email),
          u.phone ? h("span", { class: "ltr muted" }, u.phone) : null,
          badge(ROLES[u.role]),
          u.is_active ? null : badge("معطَّل", "warn"),
          u.locked_at ? badge(`مقفل منذ ${when(u.locked_at)}`, "bad") : null,
          !u.locked_at && u.failed_password_attempts ? badge(`${u.failed_password_attempts} محاولة خاطئة`, "warn") : null,
          me ? badge("أنت", "ok") : null
        ),
        u.locked_at || u.failed_password_attempts
          ? h(
              "div",
              { class: "actions", style: "margin-top:.6rem" },
              h(
                "button",
                {
                  class: "secondary",
                  onclick: async () => {
                    try {
                      await post(`/users/${u.id}/unlock`);
                      toast("فُتح الحساب", "ok");
                      usersPage();
                    } catch (exc) {
                      toast(exc.message, "error");
                    }
                  },
                },
                "فتح الحساب"
              )
            )
          : null,
        panel(
          "تعديل",
          apiForm(
            [
              h(
                "div",
                { class: "fields" },
                field("الاسم", input("full_name", { required: true, maxlength: 200, value: u.full_name })),
                field("رقم الجوال", input("phone", { type: "tel", class: "ltr", maxlength: 24, value: u.phone || "", placeholder: "+966501234567" })),
                field("الدور", (() => { const s = select("role", ROLES, { disabled: me }); s.value = u.role; return s; })(), me ? "لا يمكنك تغيير دورك" : null),
                h("label", { class: "check" }, input("is_active", { type: "checkbox", checked: u.is_active, disabled: me }), "الحساب مفعَّل")
              ),
              h("p", { class: "hint" }, "تبقى التوقيعات السابقة بالاسم والدور اللذين كانا وقت التوقيع."),
            ],
            async (data) => {
              const body = {};
              if (data.full_name !== u.full_name) body.full_name = data.full_name;
              if ((data.phone || null) !== (u.phone || null)) body.phone = data.phone || null;
              if (!me && data.role !== u.role) body.role = data.role;
              if (!me && data.is_active !== u.is_active) body.is_active = data.is_active;
              if (!Object.keys(body).length) throw new Error("لم يتغير شيء");
              await patch(`/users/${u.id}`, body);
              toast("تم الحفظ", "ok");
              if (me) await loadUser();
              usersPage();
            }
          )
        ),
        panel(
          "كلمة مرور جديدة",
          apiForm(
            [field("كلمة المرور الجديدة", input("new_password", { type: "password", required: true, minlength: 10, autocomplete: "new-password" }), "أبلغها للمستخدم بنفسك، وعليه تغييرها من «حسابي»")],
            async (data) => {
              await post(`/users/${u.id}/reset-password`, data);
              toast("غُيِّرت كلمة المرور وفُتح الحساب", "ok");
              usersPage();
            },
            "تغيير كلمة المرور"
          )
        )
      );
    }),
    panel("+ مستخدم جديد", create)
  );
}

// ----- admin: notifications ----------------------------------------------------------------

async function notificationsPage() {
  const [settings, recipients, deliveries, users] = await Promise.all([
    get("/settings/notifications"),
    get("/notification-recipients"),
    get("/notification-deliveries", { limit: 50 }),
    get("/people").catch(() => []),
  ]);
  const SOURCES = { app: "مُعدّ من هذه الصفحة", server: "مُعدّ من ملف .env على الخادم" };
  const channelState = (name, st) =>
    h("span", {}, h("strong", {}, CHANNELS[name]), " ", st.configured ? badge("جاهز للإرسال", "ok") : badge("غير مُهيَّأ", "warn"), st.source ? [" ", h("small", { class: "muted" }, SOURCES[st.source])] : null);
  const putSettings = async (path, body) => {
    await api("PUT", path, body);
    toast("حُفظت الإعدادات", "ok");
    notificationsPage();
  };
  const emailForm = apiForm(
    [
      h(
        "div",
        { class: "fields" },
        field("خادم البريد (SMTP)", input("smtp_host", { required: true, maxlength: 200, class: "ltr", value: settings.smtp_host || "", placeholder: "smtp.office365.com" })),
        field("المنفذ", input("smtp_port", { type: "number", min: 1, max: 65535, class: "ltr", value: settings.smtp_port || 587 })),
        field("التشفير", (() => { const el = select("smtp_security", { starttls: "STARTTLS (المنفذ 587)", ssl: "SSL (المنفذ 465)", none: "بلا تشفير" }); el.value = settings.smtp_security || "starttls"; return el; })()),
        field("اسم المستخدم", input("smtp_username", { maxlength: 254, class: "ltr", value: settings.smtp_username || "", autocomplete: "off" })),
        field("كلمة المرور", input("smtp_password", { type: "password", maxlength: 200, autocomplete: "new-password", placeholder: settings.smtp_password_set ? "محفوظة (اتركها فارغة للإبقاء عليها)" : "" })),
        field("عنوان المرسل", input("smtp_from", { type: "email", class: "ltr", value: settings.smtp_from || "", placeholder: "qa@factory.com" }))
      ),
      h("p", { class: "hint" }, "لـ Gmail: فعّل التحقق بخطوتين وأنشئ «كلمة مرور التطبيقات»، واستخدم smtp.gmail.com والمنفذ 587. تُحفظ كلمة المرور مشفّرة ولا تُعرض مجددًا."),
    ],
    (data) => putSettings("/settings/notifications/email", { ...data, smtp_port: Number(data.smtp_port || 587) }),
    "حفظ إعدادات البريد"
  );
  const whatsappForm = apiForm(
    [
      h(
        "div",
        { class: "fields" },
        field("معرّف رقم الهاتف (Phone number ID)", input("phone_number_id", { required: true, maxlength: 64, class: "ltr", inputmode: "numeric", value: settings.whatsapp_phone_number_id || "" }), "من لوحة WhatsApp في Meta for Developers"),
        field("رمز الوصول (Access Token)", input("token", { type: "password", maxlength: 1000, autocomplete: "new-password", placeholder: settings.whatsapp_token_set ? "محفوظ (اتركه فارغًا للإبقاء عليه)" : "" })),
        field("اسم القالب المعتمد (اختياري)", input("template", { maxlength: 100, class: "ltr", value: settings.whatsapp_template || "" }), "بدون قالب لا تصل الرسالة إلا لمن راسل رقم المنشأة خلال آخر 24 ساعة"),
        field("لغة القالب", input("template_language", { maxlength: 16, class: "ltr", value: settings.whatsapp_template_language || "ar" }))
      ),
    ],
    (data) => putSettings("/settings/notifications/whatsapp", data),
    "حفظ إعدادات واتساب"
  );
  const resetButton = (label, path, body) =>
    h("button", { class: "secondary", type: "button", onclick: async () => { if (!confirm("حذف الإعدادات المحفوظة والعودة إلى إعدادات الخادم؟")) return; try { await putSettings(path, body); } catch (exc) { toast(exc.message, "error"); } } }, label);
  const nameIn = input("name", { required: true, maxlength: 200, placeholder: "مدير الجودة" });
  const channelIn = select("channel", CHANNELS);
  const addressIn = input("address", { required: true, class: "ltr", placeholder: "qa@factory.com أو +966501234567" });
  const fromUser = h(
    "select",
    {},
    h("option", { value: "" }, "— اختر موظفًا لتعبئة بياناته —"),
    users.map((u) => h("option", { value: u.id }, `${u.full_name} (${ROLES[u.role]})`))
  );
  const fillFromUser = () => {
    const u = users.find((x) => x.id === fromUser.value);
    if (!u) return;
    nameIn.value = u.full_name;
    if (channelIn.value === "whatsapp") {
      addressIn.value = u.phone || "";
      if (!u.phone) toast("لا يوجد رقم جوال لهذا الموظف. أضفه من صفحة «المستخدمون» أو اكتبه هنا.", "error");
    } else addressIn.value = u.email;
  };
  fromUser.addEventListener("change", fillFromUser);
  channelIn.addEventListener("change", fillFromUser);
  const create = apiForm(
    [
      users.length ? field("من الموظفين", fromUser, "يعبّئ الاسم والبريد أو رقم الجوال تلقائيًا") : null,
      h(
        "div",
        { class: "fields" },
        field("الاسم", nameIn),
        field("القناة", channelIn),
        field("البريد الإلكتروني أو رقم الجوال", addressIn, "رقم واتساب بالصيغة الدولية مع رمز الدولة"),
        field("يستقبل", select("min_severity", { major: "كل التنبيهات", critical: "الحرجة فقط" }))
      ),
    ],
    async (data) => {
      await post("/notification-recipients", data);
      toast("تمت الإضافة", "ok");
      notificationsPage();
    },
    "إضافة"
  );
  const action = (label, fn, cls = "secondary") =>
    h("button", { class: cls, onclick: async () => { try { await fn(); } catch (exc) { toast(exc.message, "error"); } } }, label);
  render(
    h("h1", {}, "إشعارات التنبيهات"),
    h("p", { class: "muted" }, "يُرسَل كل تنبيه تلقائيًا إلى المستلمين المدرجين أدناه بالبريد الإلكتروني أو واتساب، ويعيد الخادم المحاولة إذا أخفق الإرسال."),
    h("h2", {}, "قنوات الإرسال"),
    settings.secrets_unreadable ? h("p", { class: "error-box" }, "تعذّرت قراءة كلمة مرور محفوظة (تغيّر CE_JWT_SECRET على الخادم). أدخلها مجددًا.") : null,
    h(
      "div",
      { class: "grid-2" },
      h("div", { class: `card ${settings.email.configured ? "" : "warn"}` }, channelState("email", settings.email), panel("إعداد البريد الإلكتروني", emailForm, settings.email.source === "app" ? resetButton("حذف إعدادات البريد", "/settings/notifications/email", { smtp_host: null }) : null)),
      h("div", { class: `card ${settings.whatsapp.configured ? "" : "warn"}` }, channelState("whatsapp", settings.whatsapp), panel("إعداد واتساب للأعمال", whatsappForm, settings.whatsapp.source === "app" ? resetButton("حذف إعدادات واتساب", "/settings/notifications/whatsapp", { phone_number_id: null }) : null))
    ),
    settings.updated_at ? h("p", { class: "muted small" }, `آخر تعديل ${when(settings.updated_at)} بواسطة ${settings.updated_by_name || ""}`) : null,
    h("h2", {}, "المستلمون"),
    recipients.length
      ? recipients.map((r) =>
          h(
            "div",
            { class: `card ${r.is_active ? "" : "warn"}` },
            h(
              "div",
              { class: "actions" },
              badge(CHANNELS[r.channel]),
              h("strong", {}, r.name),
              h("span", { class: "ltr" }, r.address),
              badge(r.min_severity === "critical" ? "الحرجة فقط" : "كل التنبيهات"),
              r.is_active ? null : badge("موقوف", "warn")
            ),
            h(
              "div",
              { class: "actions", style: "margin-top:.6rem" },
              action("إرسال رسالة تجريبية", async () => {
                const result = await post(`/notification-recipients/${r.id}/test`);
                toast(result.sent ? "أُرسلت الرسالة التجريبية" : `أخفق الإرسال: ${serverText(result.error)}`, result.sent ? "ok" : "error");
              }),
              action(r.is_active ? "إيقاف" : "تشغيل", async () => {
                await patch(`/notification-recipients/${r.id}`, { is_active: !r.is_active });
                notificationsPage();
              }),
              action(r.min_severity === "critical" ? "استقبال كل التنبيهات" : "الحرجة فقط", async () => {
                await patch(`/notification-recipients/${r.id}`, { min_severity: r.min_severity === "critical" ? "major" : "critical" });
                notificationsPage();
              })
            )
          )
        )
      : empty("لا يوجد مستلمون بعد"),
    panel("+ إضافة مستلم", create),
    h("h2", {}, "آخر الرسائل"),
    h(
      "div",
      { class: "actions", style: "margin-bottom:.8rem" },
      action("إرسال الرسائل المنتظرة الآن", async () => {
        const r = await post("/notifications/dispatch");
        toast(`أُرسل ${r.sent} · ستُعاد ${r.retrying} · أخفق ${r.failed}`, "ok");
        notificationsPage();
      }),
      action("إعادة إرسال ما أخفق", async () => {
        const r = await post("/notifications/retry-failed");
        toast(`أُعيد إلى الانتظار: ${r.requeued}`, "ok");
        notificationsPage();
      })
    ),
    deliveries.length
      ? h(
          "div",
          { class: "table-wrap" },
          h(
            "table",
            {},
            h("thead", {}, h("tr", {}, ["الوقت", "القناة", "إلى", "الحالة", "المحاولات", "آخر خطأ"].map((t) => h("th", {}, t)))),
            h(
              "tbody",
              {},
              deliveries.map((d) =>
                h(
                  "tr",
                  {},
                  h("td", {}, when(d.created_at)),
                  h("td", {}, CHANNELS[d.channel]),
                  h("td", { class: "ltr" }, d.address),
                  h("td", {}, badge(DELIVERY[d.status], d.status === "sent" ? "ok" : d.status === "failed" ? "bad" : "warn")),
                  h("td", {}, d.attempts),
                  h("td", { class: "ltr" }, d.last_error || "")
                )
              )
            )
          )
        )
      : empty("لا توجد رسائل بعد")
  );
}

// ----- document control ------------------------------------------------------------------

async function documentsPage() {
  const [forms, issued] = await Promise.all([get("/document-forms"), get("/issued-reports", { limit: 100 })]);
  const checkResult = h("div");
  const fileInput = h("input", { type: "file", accept: "application/pdf,.pdf" });
  const checkFile = async () => {
    const file = fileInput.files[0];
    if (!file) return toast("اختر ملف PDF أولًا", "error");
    try {
      const result = await api("POST", "/issued-reports/check", file);
      checkResult.replaceChildren(
        result.genuine
          ? h("div", { class: "card" }, badge("أصلي", "ok"), ` هذا الملف هو التقرير رقم `, h("strong", { class: "ltr" }, result.report.serial), ` (${result.report.title})، الصادر ${when(result.report.issued_at)} بواسطة ${result.report.issued_by_name}، ولم يُعدَّل.`)
          : h("div", { class: "card deviation" }, badge("غير مطابق", "bad"), " هذا الملف لا يطابق أي تقرير أصدره النظام، فإما أنه عُدِّل بعد إصداره وإما أنه لم يصدر عن النظام.")
      );
    } catch (exc) {
      if (!(exc instanceof SessionEnded)) toast(exc.message, "error");
    }
  };

  const formCard = (f) =>
    h(
      "div",
      { class: "card" },
      h("div", { class: "actions" }, h("strong", {}, f.title_ar), h("span", { class: "serial ltr" }, f.code), badge(`الإصدار ${f.revision}`)),
      h(
        "dl",
        { class: "facts", style: "margin-top:.6rem" },
        h("dt", {}, "العنوان بالإنجليزية"), h("dd", { class: "ltr" }, f.title_en),
        h("dt", {}, "تاريخ السريان"), h("dd", {}, f.effective_date),
        h("dt", {}, "اعتمده"), h("dd", {}, f.approved_by_name || "—"),
        h("dt", {}, "المرجع"), h("dd", { class: "ltr" }, f.reference || "—"),
        h("dt", {}, "مدة حفظ السجلات"), h("dd", {}, years(f.retention_years))
      ),
      can("documents")
        ? panel(
            "تعديل النموذج",
            apiForm(
              [
                h(
                  "div",
                  { class: "fields" },
                  field("رقم النموذج", input("code", { required: true, maxlength: 32, class: "ltr", value: f.code })),
                  field("الإصدار", input("revision", { required: true, maxlength: 8, class: "ltr", value: f.revision })),
                  field("تاريخ السريان", input("effective_date", { type: "date", required: true, value: f.effective_date })),
                  field("العنوان بالعربية", input("title_ar", { required: true, maxlength: 200, value: f.title_ar })),
                  field("العنوان بالإنجليزية", input("title_en", { required: true, maxlength: 200, class: "ltr", value: f.title_en })),
                  field("اعتمده", input("approved_by_name", { maxlength: 200, value: f.approved_by_name || "" })),
                  field("مدة حفظ السجلات (سنوات)", input("retention_years", { type: "number", min: 1, max: 50, required: true, value: f.retention_years })),
                  field("المرجع", input("reference", { maxlength: 300, class: "ltr", value: f.reference || "" }))
                ),
                field("سبب التعديل", input("reason", { required: true, maxlength: 500, placeholder: "مثال: المراجعة السنوية لخطة الهاسب" })),
                h("p", { class: "hint" }, "أي تعديل في رقم النموذج أو عنوانه أو مرجعه أو مدة الحفظ يتطلب رفع رقم الإصدار، ويُسجَّل التعديل في السجل الأمني."),
              ],
              async (data) => {
                const body = { reason: data.reason };
                for (const key of ["code", "revision", "effective_date", "title_ar", "title_en", "approved_by_name", "reference"]) {
                  if ((data[key] || "") !== (f[key] || "")) body[key] = data[key];
                }
                if (Number(data.retention_years) !== f.retention_years) body.retention_years = Number(data.retention_years);
                if (Object.keys(body).length === 1) throw new Error("لم يتغير شيء");
                await patch(`/document-forms/${f.key}`, body);
                toast("حُفظ النموذج، وسيظهر الإصدار الجديد في التقارير القادمة", "ok");
                documentsPage();
              },
              "حفظ"
            )
          )
        : null
    );

  render(
    h("h1", {}, "ضبط الوثائق"),
    h("p", { class: "muted" }, "كل تقرير يصدره النظام نموذجٌ مضبوط: يُطبع رقم النموذج والإصدار وتاريخ السريان ورقم التقرير في رأس كل صفحة، ويُحفظ كل تقرير صادر برقم متسلسل وبصمة رقمية للتحقق منه لاحقًا."),
    h("h2", {}, "النماذج المضبوطة"),
    forms.map(formCard),
    h("h2", {}, "التحقق من تقرير"),
    h("div", { class: "card" }, h("p", { class: "hint" }, "اختر ملف PDF أصدره النظام (مطبوعًا أو مُرسلًا بالبريد) للتأكد من أنه لم يُعدَّل."), h("div", { class: "actions" }, fileInput, h("button", { onclick: checkFile }, "تحقق")), checkResult),
    h("h2", {}, "سجل التقارير الصادرة"),
    issued.length
      ? h(
          "div",
          { class: "table-wrap" },
          h(
            "table",
            {},
            h("thead", {}, h("tr", {}, ["رقم التقرير", "التقرير", "النموذج", "اللغة", "صدر في", "بواسطة"].map((t) => h("th", {}, t)))),
            h(
              "tbody",
              {},
              issued.map((r) =>
                h(
                  "tr",
                  {},
                  h("td", { class: "ltr nowrap" }, r.serial),
                  h("td", {}, r.title),
                  h("td", { class: "ltr nowrap" }, `${r.form_code} / ${r.form_revision}`),
                  h("td", {}, r.lang === "ar" ? "العربية" : "English"),
                  h("td", {}, when(r.issued_at)),
                  h("td", {}, r.issued_by_name)
                )
              )
            )
          )
        )
      : empty("لم يصدر أي تقرير بعد")
  );
}

// ----- audit, account ----------------------------------------------------------------------

async function auditPage() {
  const [check, events] = await Promise.all([get("/audit/verify"), get("/audit/events", { limit: 100 })]);
  render(
    h("h1", {}, "السجل الأمني"),
    h(
      "div",
      { class: `card ${check.valid ? "" : "deviation"}` },
      check.valid
        ? [badge("سليم", "ok"), ` فُحص ${check.events_checked} حدثًا، ولم يُعبث بأي حدث.`]
        : [badge("توجد مشكلة", "bad"), ` أول حدث معدَّل رقمه ${check.first_invalid_seq}`]
    ),
    h(
      "div",
      { class: "table-wrap" },
      h(
        "table",
        {},
        h("thead", {}, h("tr", {}, ["#", "الوقت", "الحدث", "التفاصيل"].map((t) => h("th", {}, t)))),
        h(
          "tbody",
          {},
          events.map((e) =>
            h("tr", {}, h("td", {}, e.seq), h("td", {}, when(e.occurred_at)), h("td", { class: "ltr" }, e.action), h("td", { class: "ltr hide-sm", style: "font-size:.85rem" }, JSON.stringify(e.payload)))
          )
        )
      )
    )
  );
}

async function accountPage() {
  const u = state.user;
  const training = await myTrainingCard().catch(() => null);
  render(
    h("h1", {}, "حسابي"),
    h(
      "div",
      { class: "card" },
      h("dl", { class: "facts" }, h("dt", {}, "الاسم"), h("dd", {}, u.full_name), h("dt", {}, "البريد الإلكتروني"), h("dd", {}, h("span", { class: "ltr" }, u.email)), h("dt", {}, "الدور"), h("dd", {}, ROLES[u.role]))
    ),
    h(
      "div",
      { class: "card" },
      h("h3", {}, "تغيير كلمة المرور"),
      apiForm(
        [
          field("كلمة المرور الحالية", input("current_password", { type: "password", required: true, autocomplete: "current-password" })),
          field("كلمة المرور الجديدة", input("new_password", { type: "password", required: true, minlength: 10, autocomplete: "new-password" }), "10 أحرف على الأقل"),
        ],
        async (data, form) => {
          await post("/auth/change-password", data);
          form.reset();
          toast("غُيِّرت كلمة المرور", "ok");
        },
        "تغيير"
      )
    ),
    training
  );
}

// ----- dashboard, analytics and TV board ---------------------------------------------------

const LIVE_STATUS = {
  deviation: ["انحراف", "x"],
  overdue: ["متأخر", "clock"],
  due_soon: ["يحين قريبًا", "clock"],
  ok: ["في موعده", "check"],
  no_schedule: ["بلا جدول", "minus"],
};
// Arab work week: Saturday first. Server weekdays: 0 = Monday ... 6 = Sunday.
const WEEK = [[5, "السبت"], [6, "الأحد"], [0, "الإثنين"], [1, "الثلاثاء"], [2, "الأربعاء"], [3, "الخميس"], [4, "الجمعة"]];
const SCORE_PARTS = {
  ccp_compliance: "القراءات ضمن الحدود",
  sanitation_pass: "فحوص النظافة المطابقة",
  verified: "السجلات المراجَعة",
  on_time: "الفحوص في موعدها",
  capa_on_time: "إجراءات أُغلقت في المهلة",
};
const AGE_LABELS = { "0-2": "حتى يومين", "3-7": "3 - 7 أيام", "8-30": "8 - 30 يومًا", "31+": "أكثر من 30 يومًا" };

const pct = (v) => (v === null || v === undefined ? "—" : `${viz.number(v)}%`);
let dayFmt = fmt({ weekday: "long", day: "numeric", month: "long" });
const shortDay = (iso) => iso.slice(5).replace("-", "/");
const longDay = (iso) => dayFmt.format(new Date(`${iso}T12:00:00`));
let timeFmt = fmt({ hour: "2-digit", minute: "2-digit" });

function rebuildFormats() {
  dateFmt = fmt({ year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" });
  dayFmt = fmt({ weekday: "long", day: "numeric", month: "long" });
  timeFmt = fmt({ hour: "2-digit", minute: "2-digit" });
}
const clock = (iso) => (iso ? isolate(timeFmt.format(new Date(iso))) : "—");

function localIso(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

// Arabic counted nouns: 1 دقيقة, 2 دقيقتان, 3-10 دقائق, 11+ دقيقة.
function counted(n, [one, two, few, many]) {
  if (n === 1) return one;
  if (n === 2) return two;
  return `${n} ${n <= 10 ? few : many}`;
}
const MINUTES = ["دقيقة", "دقيقتين", "دقائق", "دقيقة"];
const HOURS = ["ساعة", "ساعتين", "ساعات", "ساعة"];
const DAYS = ["يوم", "يومين", "أيام", "يومًا"];

function relTime(iso) {
  if (!iso) return "";
  const minutes = Math.round((new Date(iso) - Date.now()) / 60000);
  const abs = Math.abs(minutes);
  if (abs < 1) return tr("الآن");
  if (lang() !== "ar") {
    const rel = new Intl.RelativeTimeFormat(`${locale()}-u-nu-latn`, { numeric: "auto" });
    if (abs < 60) return rel.format(minutes, "minute");
    if (abs < 1440) return rel.format(Math.round(minutes / 60), "hour");
    return rel.format(Math.round(minutes / 1440), "day");
  }
  const text = abs < 60 ? counted(abs, MINUTES) : abs < 1440 ? counted(Math.round(abs / 60), HOURS) : counted(Math.round(abs / 1440), DAYS);
  return minutes < 0 ? `منذ ${text}` : `بعد ${text}`;
}

function statusPill(status) {
  const [label, ic] = LIVE_STATUS[status];
  return h("span", { class: `status ${status}` }, icon(ic), label);
}

// Change against the previous period. upGood: whether a rise is an improvement.
function delta(now, before, upGood, unit = "") {
  if (now === null || now === undefined || before === null || before === undefined) {
    return h("span");
  }
  const diff = Math.round((now - before) * 10) / 10;
  if (diff === 0) return h("span", { class: "delta flat" }, "دون تغيير");
  const good = diff > 0 === upGood;
  return h(
    "span",
    { class: `delta ${good ? "good" : "bad"}`, title: "مقارنة بالفترة السابقة" },
    `${diff > 0 ? "▲" : "▼"} ${ltr(viz.number(Math.abs(diff)) + unit)}`
  );
}

function statTile({ label, value, unit = "", href, before, upGood, spark, alarm, deltaUnit }) {
  return h(
    href ? "a" : "div",
    { class: `stat${alarm ? " alarm" : ""}`, href },
    h("span", { class: "label" }, label),
    h("span", { class: "value" }, value === null || value === undefined ? "—" : viz.number(value), unit ? h("small", {}, unit) : null),
    h(
      "span",
      { class: "foot" },
      before !== undefined ? delta(value, before, upGood, deltaUnit ?? unit) : h("span"),
      spark ? viz.sparkline(spark) : null
    )
  );
}

function liveTile(p) {
  const value = p.last_value === null ? "—" : `${viz.number(p.last_value)} ${p.unit}`;
  return h(
    "a",
    { class: `tile ${p.status}`, href: `#/records?tab=ccp&control_point_id=${p.control_point_id}` },
    h("div", { class: "tile-top" }, h("strong", {}, p.code), statusPill(p.status)),
    h("div", { class: "muted small" }, p.name),
    h("div", { class: "reading ltr" }, value),
    h(
      "div",
      { class: "meta" },
      p.last_reading_at ? `${tr("آخر قراءة")} ${relTime(p.last_reading_at)}` : "لا توجد قراءات بعد",
      p.next_due_at ? ` · ${tr(p.status === "overdue" ? "كان موعده" : "الموعد التالي")} ${clock(p.next_due_at)}` : ""
    ),
    h(
      "div",
      { class: "meta" },
      lang() === "ar" ? `اليوم: ${p.readings_today} قراءة` : `${tr("قراءات اليوم")}: ${p.readings_today}`,
      p.deviations_today ? (lang() === "ar" ? ` · ${p.deviations_today} انحراف` : ` · ${tr("انحرافات")}: ${p.deviations_today}`) : ""
    )
  );
}

const ACTIVITY_TEXT = {
  ccp_reading: (a) => a.title,
  sanitation_record: (a) => `${tr("فحص نظافة:")} ${a.title}`,
  corrective_action: (a) => tr(a.title === "closed" ? "أُغلق إجراء تصحيحي" : "فُتح إجراء تصحيحي"),
};
const ACTIVITY_HREF = { ccp_reading: "#/ccp/", sanitation_record: "#/sanitation/", corrective_action: "#/capa/" };

function activityFeed(items) {
  if (!items.length) return empty("لا يوجد نشاط بعد");
  return h(
    "ul",
    { class: "feed" },
    items.map((a) =>
      h(
        "li",
        {},
        h("span", { class: `dot${a.ok ? "" : " bad"}` }, icon(a.ok ? "check" : a.kind === "corrective_action" ? "capa" : "x")),
        h(
          "a",
          { href: `${ACTIVITY_HREF[a.kind]}${a.record_id}` },
          h("b", {}, isolate(ACTIVITY_TEXT[a.kind](a))),
          h("div", { class: "muted small" }, serialTag(a.serial), " ", a.by || "")
        ),
        h("small", { class: "nowrap" }, relTime(a.at))
      )
    )
  );
}

function scoreCard(data, title = "مؤشر الامتثال") {
  const score = data.score.score;
  const level = score === null ? "" : score >= 95 ? "" : score >= 85 ? "warning" : "critical";
  return h(
    "section",
    { class: "card" },
    h("div", { class: "viz-head" }, h("div", {}, h("h3", {}, title), h("p", { class: "muted small" }, "متوسط المؤشرات التالية، من 100"))),
    h(
      "div",
      { class: "hero" },
      h(
        "div",
        {},
        h("div", { class: "hero-figure" }, score === null ? "—" : viz.number(score), h("small", {}, " / 100")),
        delta(score, data.previous_score.score, true)
      ),
      h(
        "div",
        { class: "score-parts" },
        data.score.parts.length
          ? data.score.parts.map((p) =>
              h(
                "div",
                { class: "score-part" },
                h("span", {}, SCORE_PARTS[p.key]),
                h("div", { class: `meter ${p.value >= 95 ? "" : p.value >= 85 ? "warning" : "critical"}` }, h("i", { style: `width:${p.value}%` })),
                h("b", {}, pct(p.value))
              )
            )
          : h("p", { class: "muted" }, "لا توجد بيانات في هذه الفترة")
      )
    ),
    level === "critical" ? h("p", { class: "error-box", style: "margin:.75rem 0 0" }, "المؤشر دون 85: راجع البنود الأقل نسبة أعلاه.") : null
  );
}

function dailyColumns(daily, onPick) {
  return viz.columns({
    labels: daily.map((d) => shortDay(d.day)),
    titles: daily.map((d) => longDay(d.day)),
    series: [
      { label: "ضمن الحدود", color: "var(--series-1)", values: daily.map((d) => d.ccp_readings - d.ccp_deviations) },
      { label: "انحراف", color: "var(--critical)", values: daily.map((d) => d.ccp_deviations) },
    ],
    onPick,
  });
}

const dailyLegend = () =>
  viz.legend([
    { label: "ضمن الحدود", color: "var(--series-1)" },
    { label: "انحراف", color: "var(--critical)" },
  ]);

function dayHref(day, tab = "ccp") {
  const from = `${day}T00:00`;
  const to = `${day}T23:59`;
  return tab === "ccp" ? `#/records?tab=ccp&measured_from=${from}&measured_to=${to}` : `#/records?tab=sanitation&performed_from=${from}&performed_to=${to}`;
}

async function homePage() {
  const [summary, live, data, alerts] = await Promise.all([
    get("/alerts/summary"),
    get("/analytics/live"),
    get("/analytics"),
    get("/alerts", { open_only: true, limit: 5 }),
  ]);
  const overdue = live.control_points.filter((p) => p.status === "overdue" || p.status === "deviation").length;
  const k = data.kpis;
  const spark = (key) => data.daily.map((d) => d[key]);
  render(
    pageHead(
      `أهلًا ${state.user.full_name}`,
      lang() === "ar"
        ? `${longDay(live.today)} · اليوم ${live.today_records} سجل${live.today_problems ? `، منها ${live.today_problems} غير مطابق` : ""}`
        : `${longDay(live.today)} · ${tr("سجلات اليوم")}: ${live.today_records}${live.today_problems ? ` · ${tr("غير مطابق")}: ${live.today_problems}` : ""}`,
      can("write") ? h("a", { class: "button", href: "#/ccp/new" }, icon("plus"), "قراءة نقطة حرجة") : null,
      can("write") ? h("a", { class: "button secondary", href: "#/sanitation/new" }, icon("drop"), "فحص نظافة") : null,
      h("a", { class: "button secondary", href: "#/tv" }, icon("tv"), "شاشة العرض")
    ),
    h(
      "div",
      { class: "stats" },
      statTile({ label: "تنبيهات مفتوحة", value: summary.open_alerts, href: "#/alerts", alarm: summary.open_critical > 0 }),
      statTile({ label: "نقاط متأخرة أو منحرفة الآن", value: overdue, href: "#/home", alarm: overdue > 0 }),
      statTile({ label: "إجراءات تصحيحية مفتوحة", value: summary.open_corrective_actions, href: "#/capa", alarm: data.capa.overdue_now > 0 }),
      statTile({ label: "سجلات بانتظار المراجعة", value: summary.unverified_records, href: can("verify") ? "#/review" : "#/records" }),
      statTile({ label: "القراءات ضمن الحدود (7 أيام)", value: k.ccp_compliance_pct, unit: "%", href: "#/analytics", before: data.previous.ccp_compliance_pct, upGood: true, spark: data.daily.map((d) => (d.ccp_readings ? (100 * (d.ccp_readings - d.ccp_deviations)) / d.ccp_readings : null)) }),
      statTile({ label: "انحرافات (7 أيام)", value: k.ccp_deviations, href: "#/records?tab=ccp&deviations_only=1", before: data.previous.ccp_deviations, upGood: false, spark: spark("ccp_deviations") })
    ),
    can("verify") ? await qualityTiles() : null,
    h("h2", {}, "حالة نقاط التحكم الحرجة الآن"),
    live.control_points.length
      ? h("div", { class: "board" }, live.control_points.map(liveTile))
      : empty("لم تُعرَّف أي نقطة تحكم حرجة بعد"),
    h(
      "div",
      { class: "grid-3", style: "margin-top:1.25rem" },
      h(
        "div",
        { class: "stack" },
        scoreCard(data, "مؤشر الامتثال لآخر 7 أيام"),
        viz.card({
          title: "قراءات النقاط الحرجة يوميًا",
          subtitle: "انقر على أي يوم لعرض سجلاته",
          legend: dailyLegend(),
          chart: dailyColumns(data.daily, (i) => (location.hash = dayHref(data.daily[i].day))),
          table: {
            head: ["اليوم", "القراءات", "الانحرافات", "فحوص النظافة", "غير المطابقة"],
            rows: data.daily.map((d) => [longDay(d.day), d.ccp_readings, d.ccp_deviations, d.sanitation_checks, d.sanitation_failures]),
          },
        })
      ),
      h(
        "div",
        { class: "stack" },
        h("section", { class: "card" }, h("h3", {}, "آخر النشاطات"), activityFeed(live.activity.slice(0, 8))),
        h(
          "section",
          { class: "card" },
          h("div", { class: "viz-head" }, h("h3", {}, "التنبيهات المفتوحة"), h("a", { href: "#/alerts", class: "small" }, "عرض الكل")),
          alerts.length
            ? h(
                "ul",
                { class: "feed" },
                alerts.map((a) =>
                  h(
                    "li",
                    {},
                    h("span", { class: "dot bad" }, icon("bell")),
                    h("a", { href: "#/alerts" }, h("b", {}, ALERT_KINDS[a.kind]), h("div", { class: "muted small" }, SEVERITIES[a.severity])),
                    h("small", { class: "nowrap" }, relTime(a.raised_at))
                  )
                )
              )
            : empty("لا توجد تنبيهات مفتوحة")
        )
      )
    )
  );
}

// Suppliers and training at a glance (dashboard, supervisors and up).
async function qualityTiles() {
  try {
    const [suppliers, matrix] = await Promise.all([get("/suppliers/overview"), get("/training/matrix")]);
    const stopped = suppliers.filter((r) => !r.can_receive && r.supplier.approval_status !== "rejected").length;
    const docs = suppliers.reduce((n, r) => n + r.stats.documents_expiring + r.stats.documents_expired, 0);
    return h(
      "div",
      { class: "stats" },
      statTile({ label: "موردون موقوف عنهم الاستلام", value: stopped, href: "#/suppliers?show=stopped", alarm: stopped > 0 }),
      statTile({ label: "مستندات موردين منتهية أو قاربت", value: docs, href: "#/suppliers?show=expiring", alarm: docs > 0 }),
      statTile({ label: "الالتزام بالتدريب", value: matrix.compliance_pct, unit: "%", href: "#/training" }),
      statTile({ label: "تدريبات منتهية أو ناقصة", value: matrix.expired + matrix.missing, href: "#/training", alarm: matrix.expired + matrix.missing > 0 })
    );
  } catch {
    return null;
  }
}

// ----- analytics ---------------------------------------------------------------------------

const PRESETS = [
  ["today", "اليوم"],
  ["7", "7 أيام"],
  ["30", "30 يومًا"],
  ["90", "90 يومًا"],
  ["month", "هذا الشهر"],
  ["year", "هذه السنة"],
];

// The factory's date, not the browser's: near midnight they differ when the time zones do.
let factoryDay = { at: 0, iso: "" };
async function factoryToday() {
  if (Date.now() - factoryDay.at > 5 * 60000) factoryDay = { at: Date.now(), iso: (await get("/analytics/live")).today };
  return new Date(`${factoryDay.iso}T12:00:00`);
}

function presetRange(key, today) {
  const to = localIso(today);
  if (key === "today") return [to, to];
  if (key === "month") return [localIso(new Date(today.getFullYear(), today.getMonth(), 1)), to];
  if (key === "year") return [localIso(new Date(today.getFullYear(), 0, 1)), to];
  const from = new Date(today);
  from.setDate(from.getDate() - (Number(key) - 1));
  return [localIso(from), to];
}

function csv(rows) {
  return rows.map((r) => r.map((c) => `"${String(c ?? "").replace(/"/g, '""')}"`).join(",")).join("\r\n");
}

function download(name, text) {
  const blob = new Blob(["﻿", text], { type: "text/csv;charset=utf-8" });
  const a = h("a", { href: URL.createObjectURL(blob), download: name });
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

async function analyticsPage(params) {
  const preset = params.get("range") || (params.get("from") ? "custom" : "30");
  const [dateFrom, dateTo] = preset === "custom" ? [params.get("from"), params.get("to")] : presetRange(preset, await factoryToday());
  const cp = params.get("cp") || "";
  const [data, points] = await Promise.all([
    get("/analytics", { date_from: dateFrom, date_to: dateTo, control_point_id: cp }),
    controlPoints(),
  ]);
  const go = (changes) => {
    const next = new URLSearchParams({ range: preset, from: dateFrom, to: dateTo, cp, ...changes });
    if (next.get("range") !== "custom") {
      next.delete("from");
      next.delete("to");
    }
    if (!next.get("cp")) next.delete("cp");
    location.hash = `#/analytics?${next}`;
  };
  const k = data.kpis;
  const p = data.previous;
  const daily = data.daily;
  const dailyPct = (num, den) => daily.map((d) => (d[den] ? Math.round((1000 * (d[den] - d[num])) / d[den]) / 10 : null));
  const fromInput = input("from", { type: "date", value: dateFrom });
  const toInput = input("to", { type: "date", value: dateTo });
  const custom = () => fromInput.value && toInput.value && go({ range: "custom", from: fromInput.value, to: toInput.value });
  fromInput.addEventListener("change", custom);
  toInput.addEventListener("change", custom);

  const filters = h(
    "div",
    { class: "filters" },
    h(
      "div",
      { class: "segmented", role: "group", "aria-label": "الفترة" },
      PRESETS.map(([key, label]) => h("button", { type: "button", "aria-pressed": String(preset === key), onclick: () => go({ range: key }) }, label))
    ),
    field("من", fromInput),
    field("إلى", toInput),
    field(
      "نقطة خريطة التحكم",
      h(
        "select",
        { onchange: (e) => go({ cp: e.currentTarget.value }) },
        h("option", { value: "" }, "الأكثر قراءات"),
        points.map((pt) => h("option", { value: pt.id, selected: pt.id === cp }, `${pt.code} | ${pt.name}`))
      )
    )
  );

  const exportCsv = () => {
    const rows = [
      ["اليوم", "قراءات النقاط الحرجة", "الانحرافات", "فحوص النظافة", "غير المطابقة", "إجراءات فُتحت", "إجراءات أُغلقت"],
      ...daily.map((d) => [d.day, d.ccp_readings, d.ccp_deviations, d.sanitation_checks, d.sanitation_failures, d.capa_opened, d.capa_closed]),
      [],
      ["النقطة", "الاسم", "القراءات", "الانحرافات", "نسبة المطابقة %", "المتوسط", "الأدنى", "الأعلى", "الانحراف المعياري", "Cpk", "في الموعد %"],
      ...data.control_points.map((c) => [c.code, c.name, c.readings, c.deviations, c.compliance_pct, c.mean, c.minimum, c.maximum, c.stdev, c.cpk, c.on_time_pct]),
    ];
    download(`analytics_${data.date_from}_${data.date_to}.csv`, csv(rows));
  };

  const spc = data.spc;
  const cpStats = spc ? data.control_points.find((c) => c.control_point_id === spc.control_point_id) : null;
  const spcCard = spc
    ? viz.card({
        wide: true,
        title: `خريطة التحكم: ${spc.code} | ${spc.name}`,
        subtitle: [
          `${spc.points.length} قراءة${spc.truncated ? " (آخر القراءات فقط)" : ""}`,
          cpStats && cpStats.cpk !== null ? `مؤشر القدرة Cpk = ${viz.number(cpStats.cpk)} (${cpStats.cpk >= 1.33 ? "قادرة" : cpStats.cpk >= 1 ? "مقبولة بحدود" : "غير قادرة"})` : "يُحسب مؤشر القدرة Cpk من 10 قراءات",
          "انقر على أي نقطة لفتح القراءة",
        ].join(" · "),
        legend: viz.legend([
          { label: "القراءة", color: "var(--series-1)", shape: "line" },
          { label: "الحد الحرج", color: "var(--critical)", shape: "line" },
          { label: "حدود التحكم ±3σ", color: "var(--serious)", shape: "line" },
          { label: "المتوسط", color: "var(--muted)", shape: "line" },
        ]),
        chart: viz.lines({
          height: 260,
          labels: spc.points.map((pt) => shortDay(localIso(new Date(pt.measured_at)))),
          titles: spc.points.map((pt) => `${pt.serial || ""} · ${dateFmt.format(new Date(pt.measured_at))}`),
          series: [{ label: `القيمة (${spc.unit})`, color: "var(--series-1)", values: spc.points.map((pt) => pt.value) }],
          flags: spc.points.map((pt) => (pt.within_limits ? null : "خارج الحد الحرج")),
          refs: [
            { value: spc.critical_min, label: `الحد الأدنى ${viz.number(spc.critical_min)}`, kind: "limit" },
            { value: spc.critical_max, label: `الحد الأقصى ${viz.number(spc.critical_max)}`, kind: "limit" },
            { value: spc.ucl, label: "UCL", kind: "control" },
            { value: spc.lcl, label: "LCL", kind: "control" },
            { value: spc.mean, label: "المتوسط", kind: "mean" },
          ],
          format: (v) => viz.number(v),
          onPick: (i) => (location.hash = `#/ccp/${spc.points[i].record_id}`),
        }),
        table: {
          head: ["الرقم", "الوقت", `القيمة (${spc.unit})`, "الحالة"],
          rows: spc.points.map((pt) => [pt.serial || "", dateFmt.format(new Date(pt.measured_at)), viz.number(pt.value), pt.within_limits ? "ضمن الحدود" : "انحراف"]),
        },
      })
    : h("section", { class: "card" }, h("h3", {}, "خريطة التحكم"), empty("لا توجد قراءات في هذه الفترة"));

  const heatRows = WEEK.map(([w, label]) => ({
    label,
    cells: Array.from({ length: 24 }, (_, hour) => {
      const c = data.heatmap.find((x) => x.weekday === w && x.hour === hour);
      return {
        value: c ? c.problems : 0,
        title: `${label} · الساعة ${String(hour).padStart(2, "0")}:00`,
        detail: [c ? c.records : 0, "سجل في هذه الساعة"],
      };
    }),
  }));

  const pareto = data.control_points.filter((c) => c.readings);
  const people = data.people;
  render(
    pageHead(
      "تحليل البيانات",
      `من ${longDay(data.date_from)} إلى ${longDay(data.date_to)} · المقارنة مع ${longDay(data.previous_from)} - ${longDay(data.previous_to)}`,
      h("button", { type: "button", class: "secondary", onclick: exportCsv }, icon("download"), "تصدير CSV"),
      h("button", { type: "button", class: "secondary", onclick: () => window.print() }, icon("printer"), "طباعة")
    ),
    filters,
    h(
      "div",
      { class: "grid-3" },
      scoreCard(data),
      h(
        "section",
        { class: "card" },
        h("h3", {}, "الإجراءات التصحيحية المفتوحة حسب عمرها"),
        h("p", { class: "muted small" }, `${data.capa.open_now} مفتوح، منها ${data.capa.overdue_now} تجاوز المهلة (${data.capa.target_days} أيام)`),
        viz.hbars({
          rows: Object.entries(data.capa.buckets).map(([key, value]) => ({ label: AGE_LABELS[key], value, color: key === "0-2" || key === "3-7" ? "var(--series-1)" : "var(--critical)" })),
          onPick: () => (location.hash = "#/capa?status=open"),
        })
      )
    ),
    h(
      "div",
      { class: "stats", style: "margin-top:1rem" },
      statTile({ label: "القراءات ضمن الحدود", value: k.ccp_compliance_pct, unit: "%", before: p.ccp_compliance_pct, upGood: true, spark: dailyPct("ccp_deviations", "ccp_readings"), href: "#/records?tab=ccp" }),
      statTile({ label: "انحرافات النقاط الحرجة", value: k.ccp_deviations, before: p.ccp_deviations, upGood: false, spark: daily.map((d) => d.ccp_deviations), href: "#/records?tab=ccp&deviations_only=1", alarm: k.ccp_deviations > 0 }),
      statTile({ label: "فحوص النظافة المطابقة", value: k.sanitation_pass_pct, unit: "%", before: p.sanitation_pass_pct, upGood: true, spark: dailyPct("sanitation_failures", "sanitation_checks"), href: "#/records?tab=sanitation" }),
      statTile({ label: "السجلات المراجَعة", value: k.verified_pct, unit: "%", before: p.verified_pct, upGood: true, href: can("verify") ? "#/review" : "#/records" }),
      statTile({ label: "الفحوص في موعدها", value: k.on_time_pct, unit: "%", before: p.on_time_pct, upGood: true }),
      statTile({ label: "تنبيهات تأخر الفحص", value: k.missed_checks, before: p.missed_checks, upGood: false, href: "#/alerts?open=all" }),
      statTile({ label: "وسيط زمن المراجعة", value: k.median_verify_hours, unit: " ساعة", deltaUnit: "", before: p.median_verify_hours, upGood: false }),
      statTile({ label: "متوسط زمن إغلاق الإجراء", value: k.capa_mean_close_days, unit: " يوم", deltaUnit: "", before: p.capa_mean_close_days, upGood: false, href: "#/capa" }),
      statTile({ label: "إجراءات تصحيحية فُتحت", value: k.capa_opened, before: p.capa_opened, upGood: false, spark: daily.map((d) => d.capa_opened), href: "#/capa" }),
      statTile({ label: "متوسط زمن الاستجابة للتنبيه", value: k.alerts_mean_ack_minutes, unit: " دقيقة", deltaUnit: "", before: p.alerts_mean_ack_minutes, upGood: false, href: "#/alerts?open=all" })
    ),
    h(
      "div",
      { class: "grid-2" },
      viz.card({
        title: "قراءات النقاط الحرجة يوميًا",
        subtitle: "انقر على أي يوم لعرض سجلاته",
        legend: dailyLegend(),
        chart: dailyColumns(daily, (i) => (location.hash = dayHref(daily[i].day))),
        table: { head: ["اليوم", "ضمن الحدود", "انحراف"], rows: daily.map((d) => [longDay(d.day), d.ccp_readings - d.ccp_deviations, d.ccp_deviations]) },
      }),
      viz.card({
        title: "نسبة المطابقة اليومية",
        subtitle: "النسبة المئوية للقراءات وفحوص النظافة المطابقة",
        legend: viz.legend([
          { label: "القراءات ضمن الحدود", color: "var(--series-1)", shape: "line" },
          { label: "فحوص النظافة المطابقة", color: "var(--series-2)", shape: "line" },
        ]),
        chart: viz.lines({
          labels: daily.map((d) => shortDay(d.day)),
          titles: daily.map((d) => longDay(d.day)),
          series: [
            { label: "القراءات ضمن الحدود %", color: "var(--series-1)", values: dailyPct("ccp_deviations", "ccp_readings") },
            { label: "فحوص النظافة المطابقة %", color: "var(--series-2)", values: dailyPct("sanitation_failures", "sanitation_checks") },
          ],
          yMin: 0,
          yMax: 100,
          format: (v) => `${viz.number(v)}%`,
          onPick: (i) => (location.hash = dayHref(daily[i].day)),
        }),
        table: {
          head: ["اليوم", "القراءات ضمن الحدود %", "فحوص النظافة المطابقة %"],
          rows: daily.map((d, i) => [longDay(d.day), pct(dailyPct("ccp_deviations", "ccp_readings")[i]), pct(dailyPct("sanitation_failures", "sanitation_checks")[i])]),
        },
      })
    ),
    h("div", { style: "margin-top:1rem" }, spcCard),
    h(
      "div",
      { class: "grid-2" },
      viz.card({
        title: "الانحرافات حسب نقطة التحكم",
        subtitle: "مرتبة من الأكثر، انقر لعرض الانحرافات",
        chart: pareto.length
          ? viz.hbars({
              rows: pareto.map((c) => ({ label: `${c.code} | ${c.name}`, value: c.deviations, color: "var(--critical)", note: `${c.readings} قراءة · ${pct(c.compliance_pct)} ضمن الحدود` })),
              onPick: (i) => (location.hash = `#/records?tab=ccp&deviations_only=1&control_point_id=${pareto[i].control_point_id}`),
            })
          : empty("لا توجد قراءات"),
        table: {
          head: ["النقطة", "القراءات", "الانحرافات", "ضمن الحدود %"],
          rows: pareto.map((c) => [c.code, c.readings, c.deviations, pct(c.compliance_pct)]),
        },
      }),
      viz.card({
        title: "متى تقع المشكلات؟",
        subtitle: "الانحرافات وفحوص النظافة غير المطابقة حسب اليوم والساعة",
        chart: data.heatmap.length ? viz.heatmap({ rows: heatRows, columns: Array.from({ length: 24 }, (_, i) => String(i)), legend: "مشكلة" }) : empty("لا توجد سجلات"),
        table: {
          head: ["اليوم", "الساعة", "السجلات", "المشكلات"],
          rows: data.heatmap.map((c) => [WEEK.find(([w]) => w === c.weekday)[1], `${String(c.hour).padStart(2, "0")}:00`, c.records, c.problems]),
        },
      })
    ),
    h(
      "div",
      { class: "grid-2", style: "margin-top:1rem" },
      viz.card({
        title: "المطابقة حسب منطقة النظافة",
        subtitle: "نسبة فحوص النظافة المطابقة، انقر لعرض فحوص المنطقة",
        chart: data.areas.length
          ? viz.hbars({
              rows: data.areas.map((a) => ({ label: a.area, value: a.pass_pct ?? 0, note: `${a.checks} فحص · ${a.failures} غير مطابق` })),
              max: 100,
              format: pct,
              onPick: (i) => (location.hash = `#/records?tab=sanitation&area=${encodeURIComponent(data.areas[i].area)}`),
            })
          : empty("لا توجد فحوص نظافة"),
        table: { head: ["المنطقة", "الفحوص", "غير المطابقة", "المطابقة %"], rows: data.areas.map((a) => [a.area, a.checks, a.failures, pct(a.pass_pct)]) },
      }),
      people
        ? viz.card({
            title: "النشاط حسب المستخدم",
            subtitle: "السجلات التي أدخلها كل مستخدم والمراجعات التي وقّعها",
            chart: people.length
              ? h(
                  "div",
                  { class: "table-wrap" },
                  h(
                    "table",
                    { class: "num-table" },
                    h("thead", {}, h("tr", {}, h("th", {}, "المستخدم"), h("th", {}, "السجلات"), h("th", {}, "غير المطابقة"), h("th", {}, "المراجعات"))),
                    h("tbody", {}, people.map((u) => h("tr", {}, h("td", {}, u.name), h("td", {}, u.records), h("td", {}, u.problems), h("td", {}, u.verifications))))
                  )
                )
              : empty("لا يوجد نشاط"),
          })
        : null
    ),
    h("h2", {}, "إحصاءات نقاط التحكم الحرجة"),
    h(
      "div",
      { class: "table-wrap" },
      h(
        "table",
        { class: "num-table" },
        h(
          "thead",
          {},
          h("tr", {}, ["النقطة", "القراءات", "الانحرافات", "ضمن الحدود", "المتوسط", "الأدنى", "الأعلى", "الانحراف المعياري", "Cpk", "في الموعد", "آخر قراءة"].map((c) => h("th", {}, c)))
        ),
        h(
          "tbody",
          {},
          data.control_points.map((c) =>
            h(
              "tr",
              { class: "clickable", onclick: () => go({ cp: c.control_point_id }) },
              h("td", {}, h("strong", {}, c.code), h("div", { class: "muted small" }, c.name)),
              h("td", {}, c.readings),
              h("td", {}, c.deviations ? badge(c.deviations, "bad") : "0"),
              h("td", {}, pct(c.compliance_pct)),
              h("td", { class: "ltr" }, c.mean === null ? "—" : `${viz.number(c.mean)} ${c.unit}`),
              h("td", { class: "ltr" }, viz.number(c.minimum)),
              h("td", { class: "ltr" }, viz.number(c.maximum)),
              h("td", { class: "ltr" }, viz.number(c.stdev)),
              h("td", {}, c.cpk === null ? "—" : badge(viz.number(c.cpk), c.cpk >= 1.33 ? "ok" : c.cpk >= 1 ? "warn" : "bad")),
              h("td", {}, pct(c.on_time_pct)),
              h("td", {}, when(c.last_reading_at))
            )
          )
        )
      )
    ),
    h("p", { class: "muted small" }, "Cpk: 1.33 فأكثر قادرة، ومن 1 إلى 1.33 مقبولة بحدود، وأقل من 1 غير قادرة على البقاء داخل الحدود الحرجة. انقر على أي صف لرسم خريطة التحكم الخاصة به.")
  );
}

// ----- TV board: full screen on a line display, refreshes itself ---------------------------

let tvTimer = null;

async function tvPage() {
  document.body.classList.add("tv");
  const draw = async () => {
    if (!location.hash.startsWith("#/tv")) return;
    const [live, summary] = await Promise.all([get("/analytics/live"), get("/alerts/summary")]);
    const problems = live.control_points.filter((p) => p.status === "overdue" || p.status === "deviation").length;
    render(
      h(
        "div",
        { class: "tv-head" },
        h("div", {}, h("h1", {}, `${state.tenant} · حالة نقاط التحكم الحرجة`), h("p", { class: "muted" }, longDay(live.today))),
        h("div", { class: "actions" }, h("span", { class: "tv-clock" }, isolate(timeFmt.format(new Date()))), h("a", { class: "button secondary", href: "#/home" }, "خروج"))
      ),
      h(
        "div",
        { class: "stats" },
        statTile({ label: "نقاط تحتاج تدخلًا", value: problems, alarm: problems > 0 }),
        statTile({ label: "تنبيهات مفتوحة", value: summary.open_alerts, alarm: summary.open_critical > 0 }),
        statTile({ label: "سجلات اليوم", value: live.today_records }),
        statTile({ label: "غير المطابق اليوم", value: live.today_problems, alarm: live.today_problems > 0 })
      ),
      h("div", { class: "board" }, live.control_points.map(liveTile))
    );
  };
  clearInterval(tvTimer);
  tvTimer = setInterval(() => draw().catch(() => {}), 30000);
  await draw();
}

// ----- supplier approval -------------------------------------------------------------------

const SUPPLIER_STATUS = {
  pending: "قيد الدراسة",
  approved: "معتمد",
  conditional: "معتمد بشروط",
  suspended: "معلَّق",
  rejected: "مرفوض",
};
const STATUS_KIND = { pending: "warn", approved: "ok", conditional: "warn", suspended: "bad", rejected: "bad" };
const RISKS = { low: "منخفضة", medium: "متوسطة", high: "عالية" };
const DOC_TYPES = {
  food_safety_certificate: "شهادة سلامة غذاء (ISO 22000 / FSSC / BRCGS)",
  halal_certificate: "شهادة حلال",
  commercial_registration: "السجل التجاري",
  health_license: "ترخيص صحي / ترخيص الهيئة",
  specification: "مواصفة المنتج / شهادة التحليل",
  audit_report: "تقرير تدقيق المورد",
  questionnaire: "استبيان تقييم ذاتي",
  other: "مستند آخر",
};
const DOC_STATE = { valid: ["ساري", "ok"], expiring: ["قارب على الانتهاء", "warn"], expired: ["منتهٍ", "bad"], withdrawn: ["مسحوب", ""] };
const DECISIONS = { approved: "اعتماد", conditional: "اعتماد بشروط", suspended: "تعليق", rejected: "رفض" };
const ACCEPTED_FILES = "application/pdf,image/jpeg,image/png,image/webp,image/heic,.pdf,.jpg,.jpeg,.png,.webp,.heic";
const MAX_UPLOAD = 10 * 1024 * 1024;

const statusBadge = (status) => badge(SUPPLIER_STATUS[status] || status, STATUS_KIND[status]);
const dayText = (iso) => (iso ? isolate(iso.replaceAll("-", "/")) : "—");

function daysLeftText(days) {
  if (days === null || days === undefined) return "";
  if (days < 0) return `انتهى منذ ${counted(-days, DAYS)}`;
  if (days === 0) return "ينتهي اليوم";
  return `يتبقى ${counted(days, DAYS)}`;
}

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(",")[1]);
    reader.onerror = () => reject(new Error("تعذّرت قراءة الملف"));
    reader.readAsDataURL(file);
  });
}

// Downloads a file the API protects (needs the login token), then opens it.
async function openProtected(path, fallbackName) {
  try {
    const response = await api("GET", path, undefined, { raw: true });
    const blob = await response.blob();
    const name = decodeURIComponent((response.headers.get("content-disposition") || "").split("''")[1] || fallbackName);
    const url = URL.createObjectURL(blob);
    const a = h("a", { href: url, download: name });
    document.body.append(a);
    a.click();
    a.remove();
    const number = response.headers.get("x-report-number");
    if (number) toast(`صدر التقرير رقم ${number}، وسُجِّل في «ضبط الوثائق»`, "ok");
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  } catch (exc) {
    if (!(exc instanceof SessionEnded)) toast(exc.message, "error");
  }
}

const reportButton = (label, path) =>
  h("button", { class: "secondary", type: "button", onclick: () => openProtected(path, "report.pdf") }, icon("download"), label);

async function suppliersPage(params) {
  const rows = await get("/suppliers/overview");
  const show = params.get("show") || "all";
  const filters = {
    all: ["الكل", () => true],
    stopped: ["موقوف عنهم الاستلام", (r) => !r.can_receive],
    expiring: ["مستندات تنتهي قريبًا", (r) => r.stats.documents_expiring > 0 || r.stats.documents_expired > 0],
    review: ["حان موعد إعادة التقييم", (r) => r.review_overdue],
    pending: ["قيد الدراسة", (r) => r.supplier.approval_status === "pending"],
  };
  const shown = rows.filter(filters[show]?.[1] || (() => true));
  const create = apiForm(
    [
      h(
        "div",
        { class: "fields" },
        field("رمز المورد", input("code", { required: true, maxlength: 64, class: "ltr", pattern: "[A-Za-z0-9._\\-]+", placeholder: "SUP-001" }), "أحرف إنجليزية وأرقام فقط"),
        field("اسم المورد", input("name", { required: true, maxlength: 200 })),
        field("المواد الموردة", input("category", { maxlength: 200, placeholder: "دقيق، سكر، عبوات..." })),
        field("درجة الخطورة", select("risk_level", RISKS, { value: "medium" })),
        field("مسؤول التواصل", input("contact_name", { maxlength: 200 })),
        field("الهاتف", input("contact_phone", { maxlength: 32, class: "ltr" })),
        field("البريد الإلكتروني", input("contact_email", { type: "email", class: "ltr" }))
      ),
      h("p", { class: "hint" }, "يبدأ المورد الجديد «قيد الدراسة»، ولا يُستلم منه شيء حتى يُعتمد بقرار موقَّع."),
    ],
    async (data) => {
      const saved = await post("/suppliers", data);
      toast("أُضيف المورد", "ok");
      location.hash = `#/suppliers/${saved.id}`;
    },
    "إضافة المورد"
  );
  create.querySelector("[name=risk_level]").value = "medium";
  const count = (fn) => rows.filter(fn).length;
  render(
    pageHead(
      "اعتماد الموردين",
      "قائمة الموردين المعتمدين وحالة مستنداتهم وتقييماتهم",
      reportButton("قائمة الموردين المعتمدين PDF", "/reports/supplier-list?lang=ar")
    ),
    h(
      "div",
      { class: "stats" },
      statTile({ label: "عدد الموردين", value: rows.length, href: "#/suppliers" }),
      statTile({ label: "معتمد أو معتمد بشروط", value: count((r) => ["approved", "conditional"].includes(r.supplier.approval_status)), href: "#/suppliers" }),
      statTile({ label: "موقوف عنهم الاستلام", value: count((r) => !r.can_receive), href: "#/suppliers?show=stopped", alarm: count((r) => !r.can_receive && r.supplier.approval_status !== "rejected") > 0 }),
      statTile({ label: "مستندات منتهية أو قاربت", value: rows.reduce((n, r) => n + r.stats.documents_expiring + r.stats.documents_expired, 0), href: "#/suppliers?show=expiring" }),
      statTile({ label: "حان موعد إعادة تقييمهم", value: count((r) => r.review_overdue), href: "#/suppliers?show=review", alarm: count((r) => r.review_overdue) > 0 })
    ),
    h(
      "div",
      { class: "tabs" },
      Object.entries(filters).map(([key, [label]]) => h("a", { href: `#/suppliers?show=${key}`, class: show === key ? "active" : "" }, label))
    ),
    shown.length
      ? h(
          "div",
          { class: "table-wrap" },
          h(
            "table",
            {},
            h("thead", {}, h("tr", {}, ["المورد", "المواد", "الاعتماد", "الخطورة", "المستندات", "آخر تقييم", "إعادة التقييم", "الاستلام"].map((t) => h("th", {}, t)))),
            h(
              "tbody",
              {},
              shown.map((r) =>
                h(
                  "tr",
                  { class: `clickable ${r.can_receive ? "" : "deviation"}`, onclick: () => (location.hash = `#/suppliers/${r.supplier.id}`) },
                  h("td", {}, h("strong", {}, r.supplier.name), h("div", { class: "muted small ltr" }, r.supplier.code)),
                  h("td", {}, r.supplier.category || "—"),
                  h("td", {}, statusBadge(r.supplier.approval_status)),
                  h("td", {}, RISKS[r.supplier.risk_level]),
                  h(
                    "td",
                    {},
                    badge(`${r.stats.documents_valid} سارية`, "ok"),
                    r.stats.documents_expiring ? badge(`${r.stats.documents_expiring} قاربت`, "warn") : null,
                    r.stats.documents_expired ? badge(`${r.stats.documents_expired} منتهية`, "bad") : null
                  ),
                  h("td", {}, r.stats.last_score === null ? "—" : `${num(r.stats.last_score)}%`),
                  h("td", {}, dayText(r.supplier.next_review_date), r.review_overdue ? [" ", badge("متأخر", "bad")] : null),
                  h("td", {}, r.can_receive ? badge("مسموح", "ok") : badge("موقوف", "bad"))
                )
              )
            )
          )
        )
      : empty(rows.length ? "لا يوجد موردون في هذا التصنيف" : "لم يُضف أي مورد بعد"),
    can("suppliers") ? panel("+ مورد جديد", create) : null
  );
}

function supplierBlockText(reason) {
  if (!reason) return "";
  let m = /^Supplier '.+' is not approved \(status: (\w+)\)$/.exec(reason);
  if (m) return `لا يُستلم من هذا المورد لأن حالته «${SUPPLIER_STATUS[m[1]] || m[1]}».`;
  m = /^Supplier '.+' has an expired required document: (.+) \(expired (\S+)\)$/.exec(reason);
  if (m) return `لا يُستلم من هذا المورد لانتهاء مستند مطلوب: «${m[1]}» (انتهى في ${dayText(m[2])}).`;
  return serverText(reason);
}

async function supplierDetailPage(id) {
  const d = await get(`/suppliers/${id}`);
  const s = d.supplier;
  const reload = () => supplierDetailPage(id);
  const nameOf = (userId) => d.names[userId] || "";
  const manage = can("suppliers");

  const docRows = d.documents.map((doc) => {
    const [label, kind] = DOC_STATE[doc.state];
    return h(
      "tr",
      { class: doc.state === "expired" && doc.is_required ? "deviation" : doc.state === "withdrawn" ? "muted" : "" },
      h("td", {}, h("strong", {}, doc.title), h("div", { class: "muted small" }, DOC_TYPES[doc.doc_type])),
      h("td", { class: "ltr" }, doc.number || "—"),
      h("td", {}, doc.issuer || "—"),
      h("td", {}, dayText(doc.issued_on)),
      h("td", {}, dayText(doc.expires_on), h("div", { class: "muted small" }, doc.state === "withdrawn" ? "" : daysLeftText(doc.days_left))),
      h("td", {}, badge(label, kind), doc.is_required ? null : [" ", badge("غير إلزامي")]),
      h(
        "td",
        {},
        doc.file_name
          ? h("button", { class: "secondary small", type: "button", onclick: () => openProtected(`/supplier-documents/${doc.id}/file`, doc.file_name) }, icon("download"), "الملف")
          : h("span", { class: "muted small" }, "بلا ملف"),
        manage && doc.state !== "withdrawn"
          ? h(
              "button",
              {
                class: "secondary small",
                type: "button",
                onclick: async () => {
                  const reason = prompt("سبب سحب المستند (مثال: صدرت شهادة مجددة):");
                  if (!reason) return;
                  try {
                    await post(`/supplier-documents/${doc.id}/withdraw`, { reason });
                    toast("سُحب المستند", "ok");
                    reload();
                  } catch (exc) {
                    toast(exc.message, "error");
                  }
                },
              },
              "سحب"
            )
          : null,
        doc.withdrawn_reason ? h("div", { class: "muted small" }, `سُحب: ${doc.withdrawn_reason}`) : null
      )
    );
  });

  const fileInput = h("input", { type: "file", accept: ACCEPTED_FILES });
  const addDocument = apiForm(
    [
      h(
        "div",
        { class: "fields" },
        field("نوع المستند", select("doc_type", DOC_TYPES, { required: true })),
        field("عنوان المستند", input("title", { required: true, maxlength: 200, placeholder: "شهادة FSSC 22000" })),
        field("رقم المستند", input("number", { maxlength: 100, class: "ltr" })),
        field("الجهة المصدرة", input("issuer", { maxlength: 200 })),
        field("تاريخ الإصدار", input("issued_on", { type: "date" })),
        field("تاريخ الانتهاء", input("expires_on", { type: "date" }), "يُنبَّه قبل الانتهاء، ويُوقف الاستلام بعده إن كان المستند إلزاميًا"),
        field("الملف الممسوح (PDF أو صورة، حتى 10 ميغابايت)", fileInput)
      ),
      h("label", { class: "check" }, input("is_required", { type: "checkbox", checked: true }), "مستند إلزامي للاستلام من المورد"),
    ],
    async (data) => {
      const file = fileInput.files[0];
      if (file) {
        if (file.size > MAX_UPLOAD) throw new Error("حجم الملف أكبر من 10 ميغابايت");
        data.file_name = file.name;
        data.content_type = file.type || (file.name.toLowerCase().endsWith(".pdf") ? "application/pdf" : "");
        data.file_base64 = await fileToBase64(file);
      }
      await post(`/suppliers/${id}/documents`, data);
      toast("أُضيف المستند", "ok");
      reload();
    },
    "إضافة المستند"
  );

  const decisionStatus = select("to_status", DECISIONS, { required: true });
  const conditions = field("الشروط", textarea("conditions", { maxlength: 2000, placeholder: "مثال: تقديم شهادة الحلال خلال 30 يومًا" }), "مطلوبة في الاعتماد بشروط");
  const syncConditions = () => {
    const needed = decisionStatus.value === "conditional";
    conditions.hidden = !needed;
    conditions.querySelector("textarea").required = needed;
  };
  decisionStatus.addEventListener("change", syncConditions);
  const riskSelect = select("risk_level", RISKS);
  riskSelect.value = s.risk_level;
  const decide = apiForm(
    [
      h(
        "div",
        { class: "fields" },
        field("القرار", decisionStatus),
        field("درجة الخطورة", riskSelect),
        field("موعد إعادة التقييم", input("next_review_date", { type: "date" }), "إذا تُرك فارغًا: بعد 24 شهرًا للخطورة المنخفضة، و12 للمتوسطة، و6 للعالية")
      ),
      field("أساس القرار", textarea("reason", { required: true, minlength: 3, maxlength: 2000, placeholder: "مثال: تدقيق موقع ناجح، وشهادة FSSC 22000 سارية، وسجل توريد جيد" })),
      conditions,
      signField(),
    ],
    async (data) => {
      if (data.to_status !== "conditional") delete data.conditions;
      await post(`/suppliers/${id}/decisions`, data);
      toast("سُجِّل القرار ووُقِّع", "ok");
      reload();
    },
    "تسجيل القرار وتوقيعه"
  );
  syncConditions();

  const scoreInputs = ["quality_score", "delivery_score", "documentation_score", "service_score"].map((name) =>
    input(name, { type: "number", min: 0, max: 100, step: 1, required: true, class: "ltr" })
  );
  const totalBox = h("div", { class: "live-check" });
  const weights = [40, 25, 20, 15];
  const updateTotal = () => {
    const values = scoreInputs.map((i) => Number(i.value));
    if (scoreInputs.some((i) => i.value === "")) return totalBox.replaceChildren();
    const total = values.reduce((sum, v, i) => sum + v * weights[i], 0) / 100;
    const rec = total >= 80 ? "approved" : total >= 60 ? "conditional" : "suspended";
    totalBox.className = `live-check ${rec === "approved" ? "ok" : "bad"}`;
    totalBox.replaceChildren(`المجموع ${isolate(total.toFixed(1))}% · التوصية: ${SUPPLIER_STATUS[rec]}`);
  };
  scoreInputs.forEach((i) => i.addEventListener("input", updateTotal));
  const today = new Date();
  const evaluate = apiForm(
    [
      h(
        "div",
        { class: "fields" },
        field("من تاريخ", input("period_from", { type: "date", required: true, value: isoDate(new Date(today.getFullYear(), today.getMonth() - 6, today.getDate())) })),
        field("إلى تاريخ", input("period_to", { type: "date", required: true, value: isoDate(today) })),
        field("الجودة (40%)", scoreInputs[0], "مطابقة المواد، والتشغيلات المحظورة، وشهادات التحليل"),
        field("التوريد (25%)", scoreInputs[1], "الالتزام بالموعد والكمية وظروف النقل"),
        field("المستندات (20%)", scoreInputs[2], "سريان الشهادات وتقديمها في وقتها"),
        field("الاستجابة (15%)", scoreInputs[3], "التعامل مع الشكاوى والإجراءات التصحيحية")
      ),
      totalBox,
      field("ملاحظات", textarea("comments", { maxlength: 2000 })),
      signField(),
    ],
    async (data) => {
      for (const k of ["quality_score", "delivery_score", "documentation_score", "service_score"]) data[k] = Number(data[k]);
      await post(`/suppliers/${id}/evaluations`, data);
      toast("سُجِّل التقييم ووُقِّع", "ok");
      reload();
    },
    "تسجيل التقييم وتوقيعه"
  );

  const editForm = apiForm(
    [
      h(
        "div",
        { class: "fields" },
        field("اسم المورد", input("name", { required: true, maxlength: 200, value: s.name })),
        field("المواد الموردة", input("category", { maxlength: 200, value: s.category || "" })),
        field("مسؤول التواصل", input("contact_name", { maxlength: 200, value: s.contact_name || "" })),
        field("الهاتف", input("contact_phone", { maxlength: 32, class: "ltr", value: s.contact_phone || "" })),
        field("البريد الإلكتروني", input("contact_email", { type: "email", class: "ltr", value: s.contact_email || "" })),
        field("ملاحظات", input("notes", { maxlength: 2000, value: s.notes || "" }))
      ),
    ],
    async (data) => {
      const body = {};
      for (const k of ["name", "category", "contact_name", "contact_phone", "contact_email", "notes"]) {
        const v = data[k] ?? null;
        if (v !== (s[k] ?? null)) body[k] = v;
      }
      if (!Object.keys(body).length) throw new Error("لم يتغير شيء");
      await patch(`/suppliers/${id}`, body);
      toast("تم الحفظ", "ok");
      reload();
    }
  );

  render(
    h("p", {}, h("a", { href: "#/suppliers" }, "→ الموردون")),
    pageHead(s.name, isolate(s.code), statusBadge(s.approval_status)),
    h(
      "div",
      { class: `card ${d.can_receive ? "" : "deviation"}` },
      d.can_receive
        ? h("p", {}, badge("الاستلام مسموح", "ok"), " ", s.approval_status === "conditional" ? "معتمد بشروط: راجع الشروط في آخر قرار." : "")
        : h("p", {}, badge("الاستلام موقوف", "bad"), " ", supplierBlockText(d.blocked_reason)),
      h(
        "dl",
        { class: "facts" },
        h("dt", {}, "المواد الموردة"), h("dd", {}, s.category || "—"),
        h("dt", {}, "درجة الخطورة"), h("dd", {}, RISKS[s.risk_level]),
        h("dt", {}, "موعد إعادة التقييم"), h("dd", {}, dayText(s.next_review_date), d.review_overdue ? [" ", badge("متأخر", "bad")] : null),
        h("dt", {}, "التشغيلات المستلمة"), h("dd", {}, `${d.stats.lots_received}`, d.stats.lots_blocked ? ` (منها ${d.stats.lots_blocked} محظورة)` : ""),
        h("dt", {}, "آخر تقييم"), h("dd", {}, d.stats.last_score === null ? "—" : `${num(d.stats.last_score)}%`),
        h("dt", {}, "التواصل"), h("dd", {}, [s.contact_name, s.contact_phone && isolate(s.contact_phone), s.contact_email && isolate(s.contact_email)].filter(Boolean).join(" · ") || "—"),
        s.notes ? [h("dt", {}, "ملاحظات"), h("dd", {}, s.notes)] : null
      ),
      manage ? panel("تعديل بيانات المورد", editForm) : null
    ),
    h("h2", {}, "المستندات والشهادات"),
    d.documents.length
      ? h("div", { class: "table-wrap" }, h("table", {}, h("thead", {}, h("tr", {}, ["المستند", "الرقم", "الجهة المصدرة", "الإصدار", "الانتهاء", "الحالة", ""].map((t) => h("th", {}, t)))), h("tbody", {}, docRows)))
      : empty("لم يُضف أي مستند بعد"),
    manage ? panel("+ إضافة مستند", addDocument) : null,
    h("h2", {}, "قرارات الاعتماد"),
    d.approvals.length
      ? d.approvals.map((a) =>
          h(
            "div",
            { class: "card" },
            h("div", { class: "actions" }, serialTag(a.serial), statusBadge(a.from_status), "←", statusBadge(a.to_status), h("small", {}, when(a.decided_at))),
            h("p", {}, h("strong", {}, "الأساس: "), a.reason),
            a.conditions ? h("p", {}, h("strong", {}, "الشروط: "), a.conditions) : null,
            h("p", { class: "muted small" }, `الخطورة: ${RISKS[a.risk_level]}`, a.next_review_date ? ` · إعادة التقييم: ${a.next_review_date.replaceAll("-", "/")}` : ""),
            signatures(a.signatures)
          )
        )
      : empty("لا توجد قرارات بعد"),
    manage ? panel("+ قرار اعتماد جديد", decide) : null,
    h("h2", {}, "تقييمات الأداء"),
    d.evaluations.length
      ? h(
          "div",
          { class: "table-wrap" },
          h(
            "table",
            {},
            h("thead", {}, h("tr", {}, ["الرقم", "الفترة", "الجودة", "التوريد", "المستندات", "الاستجابة", "المجموع", "التوصية", "التشغيلات", "المقيِّم"].map((t) => h("th", {}, t)))),
            h(
              "tbody",
              {},
              d.evaluations.map((e) =>
                h(
                  "tr",
                  { class: e.recommendation === "suspended" ? "deviation" : "" },
                  h("td", { class: "ltr nowrap" }, e.serial || "—"),
                  h("td", {}, dayText(e.period_from), " - ", dayText(e.period_to)),
                  h("td", {}, e.quality_score),
                  h("td", {}, e.delivery_score),
                  h("td", {}, e.documentation_score),
                  h("td", {}, e.service_score),
                  h("td", {}, h("strong", {}, `${num(e.total_score)}%`)),
                  h("td", {}, statusBadge(e.recommendation)),
                  h("td", {}, `${e.lots_received}`, e.lots_blocked ? ` (${e.lots_blocked} محظورة)` : ""),
                  h("td", {}, nameOf(e.evaluated_by))
                )
              )
            )
          )
        )
      : empty("لا توجد تقييمات بعد"),
    manage ? panel("+ تقييم جديد", evaluate) : null
  );
}

// ----- training and competence -------------------------------------------------------------

const TRAINING_STATUS = {
  valid: ["ساري", "ok"],
  expiring: ["قارب على الانتهاء", "warn"],
  expired: ["منتهٍ", "bad"],
  failed: ["لم يجتز", "bad"],
  missing: ["غير مُدرَّب", "bad"],
  not_required: ["غير مطلوب", ""],
};
const TRAINING_RESULTS = { passed: "اجتاز", attended: "حضر (دون تقييم)", failed: "لم يجتز" };
const METHODS = { classroom: "قاعة تدريب", on_the_job: "في موقع العمل", online: "عن بُعد", external: "جهة خارجية" };

function trainingBadge(status) {
  const [label, kind] = TRAINING_STATUS[status] || [status, ""];
  return badge(label, kind);
}

async function trainingPage(params) {
  const tab = params.get("tab") || "matrix";
  const manage = can("training");
  const tabs = h(
    "div",
    { class: "tabs" },
    [["matrix", "مصفوفة الكفاءة"], ["records", "سجلات التدريب"], ["courses", "الدورات"]].map(([key, label]) =>
      h("a", { href: `#/training?tab=${key}`, class: tab === key ? "active" : "" }, label)
    )
  );
  const head = pageHead(
    "التدريب والكفاءة",
    "من دُرِّب على ماذا، ومتى تنتهي صلاحية تدريبه",
    reportButton("مصفوفة التدريب PDF", "/reports/training-matrix?lang=ar"),
    reportButton("سجل التدريب PDF", `/reports/training-log?lang=ar&date_from=${new Date().getFullYear()}-01-01`)
  );
  if (tab === "courses") return trainingCoursesTab(head, tabs, manage);
  if (tab === "records") return trainingRecordsTab(head, tabs, manage);

  const [matrix, settings] = await Promise.all([get("/training/matrix"), get("/settings/quality")]);
  const gate = manage
    ? apiForm(
        [
          h("label", { class: "check" }, input("enforce_training", { type: "checkbox", checked: settings.enforce_training }), "منع تسجيل قراءة نقطة حرجة ممن لا يحمل تدريبًا ساريًا على الدورات المرتبطة بها"),
          field("التنبيه قبل انتهاء المستندات والتدريب بـ (يومًا)", input("expiry_warning_days", { type: "number", min: 1, max: 180, value: settings.expiry_warning_days, class: "ltr" })),
        ],
        async (data) => {
          const body = {};
          if (data.enforce_training !== settings.enforce_training) body.enforce_training = data.enforce_training;
          if (Number(data.expiry_warning_days) !== settings.expiry_warning_days) body.expiry_warning_days = Number(data.expiry_warning_days);
          if (!Object.keys(body).length) throw new Error("لم يتغير شيء");
          await patch("/settings/quality", body);
          toast("تم الحفظ", "ok");
          trainingPage(params);
        }
      )
    : null;
  render(
    head,
    tabs,
    h(
      "div",
      { class: "stats" },
      statTile({ label: "نسبة الالتزام بالتدريب", value: matrix.compliance_pct, unit: "%", href: "#/training" }),
      statTile({ label: "التدريبات المطلوبة", value: matrix.required, href: "#/training" }),
      statTile({ label: "تقارب الانتهاء", value: matrix.expiring, href: "#/training" }),
      statTile({ label: "منتهية", value: matrix.expired, href: "#/training", alarm: matrix.expired > 0 }),
      statTile({ label: "غير مُدرَّب أو لم يجتز", value: matrix.missing, href: "#/training", alarm: matrix.missing > 0 })
    ),
    h("div", { class: "card" }, h("p", {}, "منع غير المؤهَّلين: ", settings.enforce_training ? badge("مفعَّل", "ok") : badge("غير مفعَّل", "warn")), gate ? panel("إعدادات الكفاءة", gate) : null),
    matrix.courses.length
      ? h(
          "div",
          { class: "table-wrap" },
          h(
            "table",
            { class: "matrix" },
            h("thead", {}, h("tr", {}, h("th", {}, "الموظف"), matrix.courses.map((c) => h("th", { title: c.title }, h("span", { class: "ltr" }, c.code), h("div", { class: "muted small" }, c.title))))),
            h(
              "tbody",
              {},
              matrix.rows.map((row) =>
                h(
                  "tr",
                  {},
                  h("td", {}, h("strong", {}, row.full_name), h("div", { class: "muted small" }, ROLES[row.role], row.required ? ` · ${row.compliant}/${row.required}` : "")),
                  row.cells.map((cell) =>
                    h(
                      "td",
                      {},
                      cell.status === "not_required" ? h("span", { class: "muted" }, "—") : trainingBadge(cell.status),
                      cell.expires_on && cell.status !== "failed" ? h("div", { class: "muted small" }, dayText(cell.expires_on)) : null
                    )
                  )
                )
              )
            )
          )
        )
      : empty(manage ? "لا توجد دورات بعد. أضفها من تبويب «الدورات»." : "لا توجد دورات بعد")
  );
}

async function trainingCoursesTab(head, tabs, manage) {
  const [courses, points] = await Promise.all([get("/training/courses"), controlPoints()]);
  const pointName = Object.fromEntries(points.map((p) => [p.id, p.code]));
  const roleBoxes = (chosen = []) =>
    h("div", { class: "fields" }, Object.entries(ROLES).map(([value, label]) => h("label", { class: "check" }, h("input", { type: "checkbox", name: "required_roles", value, checked: chosen.includes(value) }), label)));
  const pointBoxes = (chosen = []) =>
    points.length
      ? h("div", { class: "fields" }, points.map((p) => h("label", { class: "check" }, h("input", { type: "checkbox", name: "control_point_ids", value: p.id, checked: chosen.includes(p.id) }), `${p.code} | ${p.name}`)))
      : h("p", { class: "muted" }, "لا توجد نقاط تحكم حرجة معرّفة");
  const checked = (form, name) => [...form.querySelectorAll(`input[name=${name}]:checked`)].map((i) => i.value);
  const courseFields = (c = {}) => [
    h(
      "div",
      { class: "fields" },
      c.code ? null : field("رمز الدورة", input("code", { required: true, maxlength: 64, class: "ltr", pattern: "[A-Za-z0-9._\\-]+", placeholder: "HYG-01" })),
      field("اسم الدورة", input("title", { required: true, maxlength: 200, value: c.title || "", placeholder: "أساسيات النظافة الشخصية وسلامة الغذاء" })),
      field("التصنيف", input("category", { maxlength: 100, value: c.category || "", placeholder: "النظافة، الهاسب، المواد المسببة للحساسية..." })),
      field("مدة الصلاحية (بالأشهر)", input("validity_months", { type: "number", min: 1, max: 120, class: "ltr", value: c.validity_months || "" }), "اتركه فارغًا إن كانت الدورة لا تنتهي")
    ),
    h("h4", {}, "الأدوار المطلوب منها هذه الدورة"),
    roleBoxes(c.required_roles),
    h("h4", {}, "نقاط التحكم الحرجة التي تؤهل لها"),
    pointBoxes(c.control_point_ids),
  ];
  const create = apiForm(courseFields(), async (data, form) => {
    delete data.required_roles;
    delete data.control_point_ids;
    data.required_roles = checked(form, "required_roles");
    data.control_point_ids = checked(form, "control_point_ids");
    if (data.validity_months) data.validity_months = Number(data.validity_months);
    await post("/training/courses", data);
    toast("أُضيفت الدورة", "ok");
    location.hash = "#/training?tab=courses";
    route();
  }, "إضافة الدورة");
  render(
    head,
    tabs,
    courses.length
      ? courses.map((c) =>
          h(
            "div",
            { class: `card ${c.is_active ? "" : "warn"}` },
            h("div", { class: "actions" }, h("strong", { class: "ltr" }, c.code), h("strong", {}, c.title), c.category ? badge(c.category) : null, c.is_active ? null : badge("موقوفة", "warn")),
            h(
              "p",
              { class: "muted" },
              c.validity_months ? `الصلاحية: ${counted(c.validity_months, ["شهر", "شهرين", "أشهر", "شهرًا"])}` : "لا تنتهي صلاحيتها",
              " · مطلوبة من: ",
              c.required_roles.length ? c.required_roles.map((r) => ROLES[r]).join("، ") : "—",
              c.control_point_ids.length ? ` · تؤهل لتسجيل: ${c.control_point_ids.map((p) => pointName[p] || "?").join("، ")}` : ""
            ),
            manage
              ? panel(
                  "تعديل",
                  apiForm(
                    [...courseFields(c), h("label", { class: "check" }, input("is_active", { type: "checkbox", checked: c.is_active }), "الدورة فعّالة")],
                    async (data, form) => {
                      const body = {
                        title: data.title,
                        category: data.category ?? null,
                        validity_months: data.validity_months ? Number(data.validity_months) : null,
                        required_roles: checked(form, "required_roles"),
                        control_point_ids: checked(form, "control_point_ids"),
                        is_active: data.is_active,
                      };
                      await patch(`/training/courses/${c.id}`, body);
                      toast("تم الحفظ", "ok");
                      route();
                    }
                  )
                )
              : null
          )
        )
      : empty("لا توجد دورات بعد"),
    manage ? panel("+ دورة جديدة", create) : null
  );
}

async function trainingRecordsTab(head, tabs, manage) {
  const [records, courses, users] = await Promise.all([
    get("/training/records", { limit: 300 }),
    get("/training/courses"),
    manage ? get("/people") : Promise.resolve([]),
  ]);
  const active = courses.filter((c) => c.is_active);
  const attendeeRows = users.map((u) =>
      h(
        "div",
        { class: "attendee" },
        h("label", { class: "check" }, h("input", { type: "checkbox", name: "attendee", value: u.id }), `${u.full_name} (${ROLES[u.role]})`),
        h("select", { "data-result": u.id }, Object.entries(TRAINING_RESULTS).map(([v, l]) => h("option", { value: v }, l))),
        h("input", { "data-score": u.id, type: "number", min: 0, max: 100, step: "0.5", placeholder: "الدرجة", class: "ltr small-input" })
      )
    );
  const create = active.length
    ? apiForm(
        [
          h(
            "div",
            { class: "fields" },
            field("الدورة", h("select", { name: "course_id", required: true }, active.map((c) => h("option", { value: c.id }, `${c.code} | ${c.title}`)))),
            field("تاريخ التدريب", input("trained_on", { type: "date", required: true, value: isoDate(new Date()) })),
            field("المدرب", input("trainer", { required: true, maxlength: 200 })),
            field("طريقة التدريب", select("method", METHODS)),
            field("عدد الساعات", input("duration_hours", { type: "number", min: 0.5, step: 0.5, class: "ltr" })),
            field("رقم الشهادة / المرجع", input("certificate_ref", { maxlength: 100, class: "ltr" }))
          ),
          h("h4", {}, "الحضور ونتيجة كل متدرب"),
          h("div", { class: "attendees" }, attendeeRows),
          field("ملاحظات", textarea("notes", { maxlength: 2000 })),
          signField(),
        ],
        async (data, form) => {
          const attendees = [...form.querySelectorAll("input[name=attendee]:checked")].map((box) => {
            const score = form.querySelector(`[data-score="${box.value}"]`).value;
            return { user_id: box.value, result: form.querySelector(`[data-result="${box.value}"]`).value, ...(score ? { score } : {}) };
          });
          if (!attendees.length) throw new Error("اختر متدربًا واحدًا على الأقل");
          delete data.attendee;
          const saved = await post("/training/records", { ...data, attendees });
          toast(`سُجِّل ${saved.length === 1 ? "سجل تدريب واحد" : `${saved.length} سجلات تدريب`} ووُقِّعت`, "ok");
          route();
        },
        "تسجيل التدريب وتوقيعه"
      )
    : h("p", { class: "muted" }, "أضف دورة فعّالة أولًا من تبويب «الدورات».");
  render(
    head,
    tabs,
    manage ? panel("+ تسجيل جلسة تدريب", create) : null,
    records.length
      ? h(
          "div",
          { class: "table-wrap" },
          h(
            "table",
            {},
            h("thead", {}, h("tr", {}, ["الرقم", "التاريخ", "المتدرب", "الدورة", "المدرب", "النتيجة", "صالح حتى", "الحالة", "سجّله"].map((t) => h("th", {}, t)))),
            h(
              "tbody",
              {},
              records.map((r) =>
                h(
                  "tr",
                  { class: r.state === "failed" || r.state === "expired" ? "deviation" : "" },
                  h("td", { class: "ltr nowrap" }, r.serial || "—"),
                  h("td", {}, dayText(r.trained_on)),
                  h("td", {}, r.user_name),
                  h("td", {}, h("span", { class: "ltr" }, r.course_code), " ", r.course_title),
                  h("td", {}, r.trainer, h("div", { class: "muted small" }, METHODS[r.method], r.duration_hours ? ` · ${num(r.duration_hours)} س` : "")),
                  h("td", {}, TRAINING_RESULTS[r.result], r.score !== null ? ` (${num(r.score)})` : ""),
                  h("td", {}, r.expires_on ? dayText(r.expires_on) : "—"),
                  h("td", {}, trainingBadge(r.state)),
                  h("td", {}, performer(r))
                )
              )
            )
          )
        )
      : empty("لا توجد سجلات تدريب بعد")
  );
}

// My own training and which control points I may record (shown on «حسابي»).
async function myTrainingCard() {
  const [records, competence, points] = await Promise.all([
    get("/training/records", { user_id: state.user.id, limit: 100 }),
    get("/training/my-competence"),
    controlPoints(),
  ]);
  const pointName = Object.fromEntries(points.map((p) => [p.id, `${p.code} | ${p.name}`]));
  const gated = competence.filter((c) => c.qualified === false || c.missing.length === 0);
  return h(
    "div",
    { class: "card" },
    h("h3", {}, "تدريبي"),
    records.length
      ? h(
          "ul",
          { class: "feed" },
          records.map((r) =>
            h(
              "li",
              {},
              h("span", { class: `dot${r.state === "valid" ? "" : " bad"}` }, icon(r.state === "valid" ? "check" : "clock")),
              h("div", {}, h("b", {}, r.course_title), h("div", { class: "muted small" }, dayText(r.trained_on), r.expires_on ? ` · ${tr("صالح حتى")} ${r.expires_on.replaceAll("-", "/")}` : "")),
              trainingBadge(r.state)
            )
          )
        )
      : empty("لا توجد سجلات تدريب لك بعد"),
    gated.some((c) => !c.qualified)
      ? [
          h("h4", {}, "نقاط تحتاج تدريبًا قبل تسجيلها"),
          h("ul", {}, competence.filter((c) => !c.qualified).map((c) => h("li", {}, pointName[c.control_point_id] || "", ": ", c.missing.join("، ")))),
        ]
      : null
  );
}

// ----- router ------------------------------------------------------------------------------

const ROUTES = [
  [/^#\/home$/, homePage],
  [/^#\/analytics$/, analyticsPage],
  [/^#\/tv$/, tvPage],
  [/^#\/ccp\/new$/, ccpNewPage, "write"],
  [/^#\/ccp\/([\w-]+)$/, ccpDetailPage],
  [/^#\/sanitation\/new$/, sanitationNewPage, "write"],
  [/^#\/sanitation\/([\w-]+)$/, sanitationDetailPage],
  [/^#\/records$/, recordsPage],
  [/^#\/review$/, reviewPage, "verify"],
  [/^#\/capa$/, capaPage],
  [/^#\/capa\/([\w-]+)$/, capaDetailPage],
  [/^#\/alerts$/, alertsPage],
  [/^#\/reports$/, reportsPage],
  [/^#\/documents$/, documentsPage],
  [/^#\/admin\/ccps$/, ccpsPage, "ccp"],
  [/^#\/admin\/users$/, usersPage, "users"],
  [/^#\/admin\/notifications$/, notificationsPage, "notify"],
  [/^#\/audit$/, auditPage, "audit"],
  [/^#\/account$/, accountPage],
  [/^#\/suppliers$/, suppliersPage],
  [/^#\/suppliers\/([\w-]+)$/, supplierDetailPage],
  [/^#\/training$/, trainingPage],
];

async function route() {
  const [path, search] = (location.hash || "#/home").split("?");
  const params = new URLSearchParams(search || "");
  viz.hideTip();
  if (path !== "#/tv") {
    document.body.classList.remove("tv");
    clearInterval(tvTimer);
  }
  if (path === "#/logout") return logout();
  if (!state.token) {
    if (path !== "#/login") location.hash = "#/login";
    return loginPage();
  }
  if (path === "#/login") {
    location.hash = "#/home";
    return;
  }
  try {
    if (!state.user) await loadUser();
    markNav();
    refreshBell();
    for (const [pattern, page, need] of ROUTES) {
      const match = path.match(pattern);
      if (!match) continue;
      if (need && !can(need)) return render(empty("هذه الصفحة غير متاحة لدورك"));
      return await (match[1] ? page(match[1], params) : page(params));
    }
    location.hash = "#/home";
  } catch (exc) {
    if (exc instanceof SessionEnded) return;
    render(h("div", { class: "error-box" }, exc.message), h("p", {}, h("a", { href: "#/home" }, "الرئيسية")));
  }
}

window.addEventListener("hashchange", route);
route();

if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("sw.js").catch(() => {});
}
