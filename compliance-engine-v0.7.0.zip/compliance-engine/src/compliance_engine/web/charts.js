// Small SVG charts for the dashboard: no library, works offline on the factory network.
// Every chart redraws to its container's width, has a hover/focus tooltip, and its card has
// a table view, so no value depends on colour or on hovering alone. Text is always set with
// textContent. Plots run left to right (time axis), as on instruments and in reports.

import { tr } from "./i18n.js";

const SVG = "http://www.w3.org/2000/svg";
const fmt = new Intl.NumberFormat("en-US", { maximumFractionDigits: 1 });
export const number = (v) => (v === null || v === undefined ? "—" : fmt.format(v));

function s(tag, attrs = {}, text) {
  const el = document.createElementNS(SVG, tag);
  for (const [k, v] of Object.entries(attrs)) if (v !== undefined && v !== null) el.setAttribute(k, v);
  if (text !== undefined) el.textContent = typeof text === "string" ? tr(text) : text;
  return el;
}

function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === undefined || v === null || v === false) continue;
    if (k === "class") node.className = v;
    else if (k.startsWith("on")) node.addEventListener(k.slice(2), v);
    else node.setAttribute(k, v === true ? "" : v);
  }
  for (const c of children.flat(Infinity)) if (c !== null && c !== undefined && c !== false) node.append(c instanceof Node ? c : typeof c === "string" ? tr(c) : String(c));
  return node;
}

// ----- tooltip (one for the page) ---------------------------------------------------------

let tip;
function tooltip() {
  if (!tip) {
    tip = el("div", { class: "viz-tip", role: "status", hidden: true });
    document.body.append(tip);
  }
  return tip;
}

// rows: [{value, label, color, shape: "line"|"dot"}]; values lead, labels follow.
function showTip(x, y, title, rows) {
  const t = tooltip();
  t.replaceChildren(
    el("div", { class: "viz-tip-title" }, title),
    ...rows.map((r) =>
      el(
        "div",
        { class: "viz-tip-row" },
        r.color ? el("i", { class: `key ${r.shape || "line"}`, style: `--c:${r.color}` }) : null,
        el("b", {}, r.value),
        el("span", {}, r.label)
      )
    )
  );
  t.hidden = false;
  const w = t.offsetWidth;
  const h = t.offsetHeight;
  const left = Math.min(Math.max(8, x - w / 2), window.innerWidth - w - 8);
  const top = y - h - 14 < 8 ? y + 18 : y - h - 14;
  t.style.left = `${left}px`;
  t.style.top = `${top}px`;
}
export function hideTip() {
  if (tip) tip.hidden = true;
}
window.addEventListener("scroll", hideTip, { passive: true });

// Attaches hover + keyboard focus to a hit target.
function hoverable(target, content) {
  target.setAttribute("tabindex", "0");
  const show = (event) => {
    const box = target.getBoundingClientRect();
    const x = event && event.clientX !== undefined && event.type !== "focus" ? event.clientX : box.left + box.width / 2;
    const [title, rows] = content();
    showTip(x, box.top, title, rows);
    target.classList.add("hover");
  };
  const hide = () => {
    hideTip();
    target.classList.remove("hover");
  };
  target.addEventListener("pointermove", show);
  target.addEventListener("focus", show);
  target.addEventListener("pointerleave", hide);
  target.addEventListener("blur", hide);
}

// ----- responsive frame -------------------------------------------------------------------

function frame(draw, height) {
  const box = el("div", { class: "viz", dir: "ltr" });
  let last = 0;
  const redraw = () => {
    const width = Math.floor(box.clientWidth);
    if (!width || width === last) return;
    last = width;
    const svg = s("svg", { width, height, viewBox: `0 0 ${width} ${height}`, role: "img" });
    draw(svg, width, height);
    box.replaceChildren(svg);
  };
  new ResizeObserver(redraw).observe(box);
  return box;
}

function niceMax(v) {
  if (v <= 0) return 1;
  const p = 10 ** Math.floor(Math.log10(v));
  for (const m of [1, 2, 2.5, 5, 10]) if (m * p >= v) return m * p;
  return 10 * p;
}

function ticks(lo, hi, count = 4) {
  const span = hi - lo || 1;
  const raw = span / count;
  const p = 10 ** Math.floor(Math.log10(raw));
  const step = [1, 2, 2.5, 5, 10].map((m) => m * p).find((m) => m >= raw) || raw;
  const out = [];
  for (let v = Math.ceil(lo / step) * step; v <= hi + step / 1e6; v += step) out.push(Number(v.toFixed(6)));
  return out;
}

const compact = (v) => (Math.abs(v) >= 1000 ? `${fmt.format(v / 1000)}K` : fmt.format(v));

function yAxis(svg, ticksList, y, left, right, format = compact) {
  for (const t of ticksList) {
    svg.append(s("line", { x1: left, x2: right, y1: y(t), y2: y(t), class: "grid" }));
    svg.append(s("text", { x: left - 6, y: y(t) + 4, class: "tick", "text-anchor": "end" }, format(t)));
  }
}

// x labels: show about every n-th so they never collide
function xLabels(svg, labels, xCenter, bottom, width) {
  const every = Math.max(1, Math.ceil((labels.length * 46) / width));
  labels.forEach((label, i) => {
    const last = i === labels.length - 1;
    if (!last && (i % every || labels.length - 1 - i < every)) return;
    svg.append(s("text", { x: xCenter(i), y: bottom + 16, class: "tick", "text-anchor": "middle" }, label));
  });
}

// Rounded top (4px) and square base, as a path.
function barPath(x, y, w, h, r = 4) {
  if (h <= 0) return "";
  const rr = Math.min(r, h, w / 2);
  return `M${x},${y + h}V${y + rr}Q${x},${y} ${x + rr},${y}H${x + w - rr}Q${x + w},${y} ${x + w},${y + rr}V${y + h}Z`;
}

// ----- column chart (stacked) -------------------------------------------------------------
// series: [{label, color, values}] stacked bottom-up in order; labels: x labels;
// titles: full tooltip title per column.
export function columns({ labels, titles, series, height = 220, onPick }) {
  return frame((svg, width, H) => {
    const left = 40, right = width - 8, top = 10, bottom = H - 24;
    const totals = labels.map((_, i) => series.reduce((sum, se) => sum + (se.values[i] || 0), 0));
    const max = niceMax(Math.max(...totals, 1));
    const y = (v) => bottom - ((bottom - top) * v) / max;
    yAxis(svg, ticks(0, max), y, left, right);
    const band = (right - left) / labels.length;
    const bw = Math.max(2, Math.min(24, band * 0.62));
    const xc = (i) => left + band * i + band / 2;
    labels.forEach((_, i) => {
      let base = 0;
      const g = s("g", { class: "col" });
      series.forEach((se) => {
        const v = se.values[i] || 0;
        if (!v) return;
        const y0 = y(base), y1 = y(base + v);
        // 2px surface gap between stacked segments
        const top = base + v === totals[i];
        const h = y0 - y1 - (base > 0 ? 2 : 0);
        g.append(
          top
            ? s("path", { d: barPath(xc(i) - bw / 2, y1, bw, h), fill: se.color })
            : s("rect", { x: xc(i) - bw / 2, y: y1, width: bw, height: Math.max(0, h), fill: se.color })
        );
        base += v;
      });
      const hit = s("rect", { x: left + band * i, y: top, width: band, height: bottom - top, class: "hit" });
      hoverable(hit, () => [
        titles ? titles[i] : labels[i],
        [...series].reverse().map((se) => ({ value: number(se.values[i] || 0), label: se.label, color: se.color, shape: "dot" })),
      ]);
      if (onPick) hit.addEventListener("click", () => onPick(i));
      g.append(hit);
      svg.append(g);
    });
    svg.append(s("line", { x1: left, x2: right, y1: bottom, y2: bottom, class: "axis" }));
    xLabels(svg, labels, xc, bottom, width);
  }, height);
}

// ----- line chart -------------------------------------------------------------------------
// series: [{label, color, values (null = gap)}]; refs: [{value, label, kind: "limit"|"mean"|"control"}]
// points: optional per-index flag array marking problem points (drawn as a critical dot).
export function lines({ labels, titles, series, refs = [], height = 220, yMin, yMax, format = compact, flags, onPick }) {
  return frame((svg, width, H) => {
    const left = 44, right = width - 12, top = 12, bottom = H - 24;
    const all = series.flatMap((se) => se.values.filter((v) => v !== null && v !== undefined));
    const refVals = refs.map((r) => r.value).filter((v) => v !== null && v !== undefined);
    let lo = yMin ?? Math.min(...all, ...refVals);
    let hi = yMax ?? Math.max(...all, ...refVals);
    if (!Number.isFinite(lo)) [lo, hi] = [0, 1];
    if (lo === hi) [lo, hi] = [lo - 1, hi + 1];
    if (yMin === undefined || yMax === undefined) {
      const pad = (hi - lo) * 0.08;
      if (yMin === undefined) lo -= pad;
      if (yMax === undefined) hi += pad;
    }
    const tk = ticks(lo, hi);
    const y = (v) => bottom - ((bottom - top) * (v - lo)) / (hi - lo);
    yAxis(svg, tk.filter((t) => t >= lo && t <= hi), y, left, right, format);
    const n = labels.length;
    const x = (i) => (n === 1 ? (left + right) / 2 : left + ((right - left) * i) / (n - 1));

    for (const r of refs) {
      if (r.value === null || r.value === undefined || r.value < lo || r.value > hi) continue;
      svg.append(s("line", { x1: left, x2: right, y1: y(r.value), y2: y(r.value), class: `ref ${r.kind}` }));
      // critical limits are labelled at the right end, control lines and the mean at the left
      const atEnd = r.kind === "limit";
      svg.append(s("text", { x: atEnd ? right - 2 : left + 4, y: y(r.value) - 4, class: `ref-label ${r.kind}`, "text-anchor": atEnd ? "end" : "start" }, r.label));
    }
    for (const se of series) {
      let d = "";
      let pen = false;
      se.values.forEach((v, i) => {
        if (v === null || v === undefined) {
          pen = false;
          return;
        }
        d += `${pen ? "L" : "M"}${x(i)},${y(v)}`;
        pen = true;
      });
      if (se.area) {
        const firstI = se.values.findIndex((v) => v !== null && v !== undefined);
        const lastI = se.values.length - 1 - [...se.values].reverse().findIndex((v) => v !== null && v !== undefined);
        if (firstI >= 0 && pen) svg.append(s("path", { d: `${d}L${x(lastI)},${bottom}L${x(firstI)},${bottom}Z`, fill: se.color, class: "area" }));
      }
      svg.append(s("path", { d, stroke: se.color, class: "line" }));
      // end dot + markers for sparse series
      se.values.forEach((v, i) => {
        if (v === null || v === undefined) return;
        const isFlag = flags && flags[i];
        const isLast = i === se.values.length - 1 || se.values.slice(i + 1).every((u) => u === null || u === undefined);
        if (isFlag || isLast || n <= 40) {
          svg.append(s("circle", { cx: x(i), cy: y(v), r: isFlag ? 5 : 4, class: isFlag ? "dot flag" : "dot", fill: isFlag ? null : se.color }));
        }
      });
    }
    svg.append(s("line", { x1: left, x2: right, y1: bottom, y2: bottom, class: "axis" }));
    xLabels(svg, labels, x, bottom, width);

    // crosshair: snaps to the nearest index
    const cross = s("line", { y1: top, y2: bottom, class: "crosshair", visibility: "hidden" });
    svg.append(cross);
    const hit = s("rect", { x: left, y: top, width: right - left, height: bottom - top, class: "hit" });
    const nearest = (clientX) => {
      const box = svg.getBoundingClientRect();
      const px = clientX - box.left;
      return Math.max(0, Math.min(n - 1, Math.round(((px - left) / (right - left || 1)) * (n - 1))));
    };
    let current = n - 1;
    const show = (i, clientX) => {
      current = i;
      cross.setAttribute("x1", x(i));
      cross.setAttribute("x2", x(i));
      cross.setAttribute("visibility", "visible");
      const box = svg.getBoundingClientRect();
      showTip(clientX ?? box.left + x(i), box.top + top, titles ? titles[i] : labels[i], [
        ...series.map((se) => ({ value: se.values[i] === null || se.values[i] === undefined ? "—" : format(se.values[i]), label: se.label, color: se.color })),
        ...(flags && flags[i] ? [{ value: "⚠", label: flags[i] }] : []),
      ]);
    };
    hit.setAttribute("tabindex", "0");
    hit.addEventListener("pointermove", (e) => show(nearest(e.clientX), e.clientX));
    hit.addEventListener("focus", () => show(current));
    hit.addEventListener("keydown", (e) => {
      if (e.key === "ArrowRight") show(Math.min(n - 1, current + 1));
      if (e.key === "ArrowLeft") show(Math.max(0, current - 1));
      if (e.key === "Enter" && onPick) onPick(current);
    });
    const hide = () => {
      cross.setAttribute("visibility", "hidden");
      hideTip();
    };
    hit.addEventListener("pointerleave", hide);
    hit.addEventListener("blur", hide);
    if (onPick) hit.addEventListener("click", (e) => onPick(nearest(e.clientX)));
    svg.append(hit);
  }, height);
}

// ----- horizontal bars --------------------------------------------------------------------
// rows: [{label, value, note}]; RTL page, so labels sit on the right and bars grow leftward.
export function hbars({ rows, color = "var(--series-1)", max, format = number, onPick }) {
  const top = max ?? niceMax(Math.max(...rows.map((r) => r.value), 1));
  return el(
    "div",
    { class: "hbars" },
    rows.map((r, i) => {
      const fill = el("i", { style: `width:${Math.max(r.value ? 1.5 : 0, (100 * r.value) / top)}%;background:${r.color || color}` });
      const row = el(
        "div",
        { class: `hbar${onPick ? " clickable" : ""}`, tabindex: "0", onclick: onPick ? () => onPick(i) : null },
        el("span", { class: "hbar-label" }, r.label),
        el("span", { class: "hbar-track" }, fill),
        el("b", { class: "hbar-value" }, format(r.value)),
        r.note ? el("small", { class: "hbar-note" }, r.note) : null
      );
      return row;
    })
  );
}

// ----- heatmap ----------------------------------------------------------------------------
// rows: [{label, cells: [{value, title, detail}]}] ; columns: labels. One-hue sequential scale.
export function heatmap({ rows, columns: cols, legend }) {
  const max = Math.max(1, ...rows.flatMap((r) => r.cells.map((c) => c.value)));
  const steps = ["var(--seq-0)", "var(--seq-1)", "var(--seq-2)", "var(--seq-3)", "var(--seq-4)", "var(--seq-5)"];
  const color = (v) => (v <= 0 ? "var(--seq-0)" : steps[Math.min(5, 1 + Math.floor((4.999 * v) / max))]);
  const grid = el(
    "div",
    { class: "heat", dir: "ltr", style: `grid-template-columns: max-content repeat(${cols.length}, minmax(10px, 1fr))` },
    el("span"),
    cols.map((c, i) => el("span", { class: "heat-col" }, i % 3 === 0 ? c : "")),
    rows.map((r) => [
      el("span", { class: "heat-row" }, r.label),
      r.cells.map((c) => {
        const cell = el("i", { class: "heat-cell", style: `background:${color(c.value)}` });
        hoverable(cell, () => [c.title, [{ value: number(c.value), label: legend }, ...(c.detail ? [{ value: c.detail[0], label: c.detail[1] }] : [])]]);
        return cell;
      }),
    ])
  );
  const scale = el(
    "div",
    { class: "heat-scale" },
    el("span", {}, "0"),
    steps.slice(1).map((c) => el("i", { style: `background:${c}` })),
    el("span", {}, number(max))
  );
  return el("div", {}, grid, scale);
}

// ----- sparkline (stat tiles) -------------------------------------------------------------
export function sparkline(values, { color = "var(--accent)" } = {}) {
  const w = 120, h = 32;
  const clean = values.map((v) => (v === null || v === undefined ? null : v));
  const nums = clean.filter((v) => v !== null);
  const svg = s("svg", { width: w, height: h, viewBox: `0 0 ${w} ${h}`, class: "spark", "aria-hidden": "true" });
  if (nums.length < 2) return svg;
  const lo = Math.min(...nums), hi = Math.max(...nums);
  const x = (i) => 2 + ((w - 6) * i) / (clean.length - 1);
  const y = (v) => (hi === lo ? h / 2 : h - 4 - ((h - 8) * (v - lo)) / (hi - lo));
  let d = "", pen = false;
  clean.forEach((v, i) => {
    if (v === null) return (pen = false);
    d += `${pen ? "L" : "M"}${x(i)},${y(v)}`;
    pen = true;
  });
  svg.append(s("path", { d, class: "spark-line" }));
  const li = clean.length - 1 - [...clean].reverse().findIndex((v) => v !== null);
  svg.append(s("circle", { cx: x(li), cy: y(clean[li]), r: 3, fill: color }));
  return svg;
}

// ----- legend -----------------------------------------------------------------------------
export function legend(items) {
  return el(
    "div",
    { class: "legend" },
    items.map((i) => el("span", {}, el("i", { class: `key ${i.shape || "dot"}`, style: `--c:${i.color}` }), i.label))
  );
}

// ----- chart card with a table view --------------------------------------------------------
// table: {head: [..], rows: [[..]]}
export function card({ title, subtitle, chart, table, actions, wide, legend: leg }) {
  const body = el("div", { class: "viz-body" }, leg || null, chart);
  let tableView = null;
  const toggle = table
    ? el("button", {
        type: "button",
        class: "ghost small",
        "aria-pressed": "false",
        onclick: (e) => {
          const on = e.currentTarget.getAttribute("aria-pressed") !== "true";
          e.currentTarget.setAttribute("aria-pressed", String(on));
          e.currentTarget.textContent = tr(on ? "عرض الرسم" : "عرض كجدول");
          if (!tableView) {
            tableView = el(
              "div",
              { class: "table-wrap" },
              el(
                "table",
                { class: "num-table" },
                el("thead", {}, el("tr", {}, table.head.map((c) => el("th", {}, c)))),
                el("tbody", {}, table.rows.map((r) => el("tr", {}, r.map((c) => el("td", {}, c)))))
              )
            );
          }
          body.replaceChildren(...(on ? [tableView] : [leg, chart].filter(Boolean)));
        },
      }, "عرض كجدول")
    : null;
  return el(
    "section",
    { class: `card viz-card${wide ? " wide" : ""}` },
    el(
      "header",
      { class: "viz-head" },
      el("div", {}, el("h3", {}, title), subtitle ? el("p", { class: "muted small" }, subtitle) : null),
      el("div", { class: "actions" }, actions || null, toggle)
    ),
    body
  );
}
