import asyncio
import logging
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request, status
from fastapi.concurrency import run_in_threadpool
from fastapi.encoders import jsonable_encoder
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy.exc import IntegrityError

from compliance_engine.api.routers import (
    analytics,
    auth,
    capa,
    compliance,
    documents,
    inventory,
    master_data,
    notifications,
    records,
    reports,
    settings,
    suppliers,
    training,
)
from compliance_engine.core.config import get_settings
from compliance_engine.core.errors import (
    AuthenticationError,
    BusinessRuleError,
    ConflictError,
    DomainError,
    NotFoundError,
    PermissionDeniedError,
)
from compliance_engine.db.session import get_session_factory
from compliance_engine.services.alerts import scan_all_tenants
from compliance_engine.services.notifications import dispatch_all_tenants

log = logging.getLogger(__name__)
WEB_DIR = Path(__file__).parent / "web"

_STATUS_BY_ERROR: dict[type[DomainError], int] = {
    NotFoundError: status.HTTP_404_NOT_FOUND,
    ConflictError: status.HTTP_409_CONFLICT,
    BusinessRuleError: status.HTTP_422_UNPROCESSABLE_CONTENT,
    AuthenticationError: status.HTTP_401_UNAUTHORIZED,
    PermissionDeniedError: status.HTTP_403_FORBIDDEN,
}


def _domain_error_handler(_: Request, exc: Exception) -> JSONResponse:
    code = next(
        (code for kind, code in _STATUS_BY_ERROR.items() if isinstance(exc, kind)),
        status.HTTP_400_BAD_REQUEST,
    )
    headers = {"WWW-Authenticate": "Bearer"} if code == status.HTTP_401_UNAUTHORIZED else None
    return JSONResponse(status_code=code, content={"detail": str(exc)}, headers=headers)


def _integrity_error_handler(_: Request, __: Exception) -> JSONResponse:
    return JSONResponse(
        status_code=status.HTTP_409_CONFLICT,
        content={"detail": "The request conflicts with existing data"},
    )


def _validation_error_handler(_: Request, exc: Exception) -> JSONResponse:
    """Like FastAPI's default, but never echo the submitted input: it can hold a password."""
    assert isinstance(exc, RequestValidationError)
    errors = [
        {key: value for key, value in error.items() if key in ("type", "loc", "msg")}
        for error in exc.errors()
    ]
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
        content={"detail": jsonable_encoder(errors)},
    )


async def _scan_missed_checks_forever(every_seconds: int) -> None:
    while True:
        await asyncio.sleep(every_seconds)
        try:
            raised = await run_in_threadpool(scan_all_tenants, get_session_factory())
            if raised:
                log.warning("Raised %d alert(s) (missed checks, expiries)", raised)
        except Exception:
            log.exception("Missed-check scan failed")


async def _send_notifications_forever(every_seconds: int) -> None:
    while True:
        await asyncio.sleep(every_seconds)
        try:
            result = await run_in_threadpool(dispatch_all_tenants, get_session_factory())
            if result.sent or result.retrying or result.failed:
                log.info(
                    "Notifications: %d sent, %d to retry, %d failed",
                    result.sent,
                    result.retrying,
                    result.failed,
                )
        except Exception:
            log.exception("Sending notifications failed")


@asynccontextmanager
async def _lifespan(_: FastAPI) -> AsyncIterator[None]:
    config = get_settings()
    tasks = []
    if config.alert_scan_seconds:
        tasks.append(asyncio.create_task(_scan_missed_checks_forever(config.alert_scan_seconds)))
    if config.notify_seconds:
        tasks.append(asyncio.create_task(_send_notifications_forever(config.notify_seconds)))
    yield
    for task in tasks:
        task.cancel()


def create_app() -> FastAPI:
    app = FastAPI(
        title="Smart Food Compliance & Quality Engine",
        version="0.7.0",
        description=(
            "Lot traceability, HACCP monitoring records with e-signatures, corrective actions, "
            "supplier approval, training records, alerts, Arabic/English PDF reports, immutable "
            "records and audit trail for food factories."
        ),
        lifespan=_lifespan,
    )
    app.add_exception_handler(DomainError, _domain_error_handler)
    app.add_exception_handler(IntegrityError, _integrity_error_handler)
    app.add_exception_handler(RequestValidationError, _validation_error_handler)

    for router in (
        auth.router,
        suppliers.router,
        master_data.router,
        inventory.router,
        records.router,
        capa.router,
        notifications.router,
        settings.router,
        training.router,
        reports.router,
        analytics.router,
        documents.router,
        compliance.router,
    ):
        app.include_router(router, prefix="/api/v1")

    @app.get("/health", include_in_schema=False)
    def health() -> dict[str, str]:
        return {"status": "ok"}

    # The web app (PWA): plain HTML/JS served by the API itself, no build step.
    app.mount("/app", StaticFiles(directory=WEB_DIR, html=True), name="app")

    @app.get("/", include_in_schema=False)
    def home() -> RedirectResponse:
        return RedirectResponse("/app/")

    return app


app = create_app()
