"""PDF rendering for compliance reports, in Arabic (right to left) or English.

Arabic text is shaped with HarfBuzz (fpdf2 + uharfbuzz) using the bundled Noto Naskh Arabic
font; Latin text, numbers and codes fall back to Noto Sans. Both fonts are SIL OFL licensed.
"""

from collections.abc import Sequence
from datetime import datetime
from enum import StrEnum
from pathlib import Path
from zoneinfo import ZoneInfo

from fpdf import FPDF
from fpdf.enums import Align, TableCellFillMode
from fpdf.fonts import FontFace

FONT_DIR = Path(__file__).parent / "fonts"
GREY = (235, 235, 235)
RED_FILL = (253, 226, 226)
TEXT = (20, 20, 20)
MUTED = (100, 100, 100)


class Lang(StrEnum):
    AR = "ar"
    EN = "en"


class ReportPdf(FPDF):
    def __init__(
        self,
        lang: Lang,
        title: str,
        company: str,
        meta_lines: Sequence[str],
        footer_text: str,
        control: Sequence[tuple[str, str]] = (),
    ) -> None:
        super().__init__(orientation="L", unit="mm", format="A4")
        self.lang = lang
        self.rtl = lang == Lang.AR
        self.report_title = title
        self.company = company
        self.meta_lines = list(meta_lines)
        self.footer_text = footer_text
        self.control = list(control)
        self.set_auto_page_break(auto=True, margin=16)
        self.set_margins(12, 12, 12)

        self.add_font("naskh", "", FONT_DIR / "NotoNaskhArabic-Regular.ttf")
        self.add_font("naskh", "B", FONT_DIR / "NotoNaskhArabic-Bold.ttf")
        self.add_font("sans", "", FONT_DIR / "NotoSans-Regular.ttf")
        self.add_font("sans", "B", FONT_DIR / "NotoSans-Bold.ttf")
        self.main_font = "naskh" if self.rtl else "sans"
        self.set_fallback_fonts(["sans" if self.rtl else "naskh"])
        self.set_text_shaping(use_shaping_engine=True)
        self.set_text_color(*TEXT)
        self.align = Align.R if self.rtl else Align.L
        self.alias_nb_pages()
        self.set_title(title)
        self.set_creator("Smart Food Compliance & Quality Engine")
        self.add_page()

    # ----- page furniture --------------------------------------------------------------

    def header(self) -> None:
        self.set_font(self.main_font, "B", 15)
        self.cell(0, 8, self.report_title, align=self.align, new_x="LMARGIN", new_y="NEXT")
        self.set_font(self.main_font, "", 10)
        self.cell(0, 6, self.company, align=self.align, new_x="LMARGIN", new_y="NEXT")
        self.set_text_color(*MUTED)
        self.set_font(self.main_font, "", 8.5)
        for line in self.meta_lines:
            self.cell(0, 5, line, align=self.align, new_x="LMARGIN", new_y="NEXT")
        self.set_text_color(*TEXT)
        if self.control:
            self._control_block()
        self.set_draw_color(180, 180, 180)
        self.line(self.l_margin, self.get_y() + 1, self.w - self.r_margin, self.get_y() + 1)
        self.ln(4)

    def _control_block(self) -> None:
        """Document-control row on every page: form number, revision, effective date and
        report number, as label/value boxes."""
        self.ln(1.5)
        cells = list(self.control)
        if self.rtl:
            cells.reverse()
        width = (self.w - self.l_margin - self.r_margin) / len(cells)
        self.set_draw_color(150, 150, 150)
        y = self.get_y()
        for index, (label, value) in enumerate(cells):
            x = self.l_margin + index * width
            self.set_xy(x, y)
            parts = [(label, True), (value, False)]
            if self.rtl:  # the label reads first, so it sits on the right
                parts.reverse()
            for text, is_label in parts:
                self.set_fill_color(*GREY)
                self.set_font(self.main_font if is_label else "sans", "B", 8 if is_label else 8.5)
                self.cell(
                    width * (0.45 if is_label else 0.55),
                    6.5,
                    text,
                    border=1,
                    align=Align.C,
                    fill=is_label,
                )
        self.set_xy(self.l_margin, y + 6.5)

    def footer(self) -> None:
        self.set_y(-12)
        self.set_font(self.main_font, "", 7.5)
        self.set_text_color(*MUTED)
        page = f"{self.page_no()} / {{nb}}"  # no words: Arabic shaping would split the alias
        self.cell(0, 5, self.footer_text, align=self.align)
        self.set_x(self.l_margin)
        self.set_font("sans", "", 7.5)  # the {nb} alias must stay in one font run
        self.cell(0, 5, page, align=Align.L if self.rtl else Align.R)
        self.set_text_color(*TEXT)

    # ----- content ---------------------------------------------------------------------

    def heading(self, text: str) -> None:
        if self.get_y() > self.h - 40:
            self.add_page()
        self.ln(2)
        self.set_font(self.main_font, "B", 12)
        self.cell(0, 7, text, align=self.align, new_x="LMARGIN", new_y="NEXT")

    def paragraph(self, text: str, size: float = 9.5, muted: bool = False) -> None:
        self.set_font(self.main_font, "", size)
        if muted:
            self.set_text_color(*MUTED)
        self.multi_cell(0, 5.5, text, align=self.align, new_x="LMARGIN", new_y="NEXT")
        self.set_text_color(*TEXT)

    def key_values(self, pairs: Sequence[tuple[str, str]]) -> None:
        """Label/value pairs, two per row."""
        rows = [list(pairs[i : i + 2]) for i in range(0, len(pairs), 2)]
        self.set_font(self.main_font, "", 9)
        widths = (14, 36, 14, 36)
        with self.table(
            col_widths=widths if not self.rtl else tuple(reversed(widths)),
            first_row_as_headings=False,
            text_align=self.align,
            borders_layout="NONE",
            line_height=5.5,
            padding=(0.6, 1.5),
        ) as table:
            for row in rows:
                cells: list[tuple[str, bool]] = []
                for label, value in row:
                    cells += [(label, True), (value, False)]
                while len(cells) < 4:
                    cells.append(("", False))
                if self.rtl:
                    cells.reverse()
                table_row = table.row()
                for text, bold in cells:
                    table_row.cell(text, style=FontFace(emphasis="BOLD" if bold else None))
        self.ln(2)

    def data_table(
        self,
        headers: Sequence[str],
        widths: Sequence[float],
        rows: Sequence[Sequence[str]],
        highlight: Sequence[bool] | None = None,
        empty_text: str = "",
        font_size: float = 8,
    ) -> None:
        if not rows:
            self.paragraph(empty_text, muted=True)
            self.ln(1)
            return
        order = list(range(len(headers)))
        if self.rtl:
            order.reverse()
        self.set_font(self.main_font, "", font_size)
        with self.table(
            col_widths=[widths[i] for i in order],
            text_align=self.align,
            line_height=4.6,
            padding=(1, 1.2),
            headings_style=FontFace(emphasis="BOLD", fill_color=GREY),
            cell_fill_mode=TableCellFillMode.NONE,
        ) as table:
            heading = table.row()
            for i in order:
                heading.cell(headers[i])
            for index, row in enumerate(rows):
                style = (
                    FontFace(fill_color=RED_FILL)
                    if highlight is not None and highlight[index]
                    else None
                )
                table_row = table.row(style=style)
                for i in order:
                    table_row.cell(row[i])
        self.ln(3)

    def to_bytes(self) -> bytes:
        return bytes(self.output())


def format_moment(moment: datetime | None, tz: ZoneInfo, lang: Lang = Lang.EN) -> str:
    """Local date and time. Arabic text would reorder 2026-10-08 as 08-10-2026 (bidi rules
    for European digits after Arabic letters); slashes keep the order."""
    if moment is None:
        return ""
    pattern = "%Y/%m/%d %H:%M" if lang == Lang.AR else "%Y-%m-%d %H:%M"
    return moment.astimezone(tz).strftime(pattern)
