"""Alerts: what a supervisor must look at now.

Raised when a CCP reading is outside its critical limits, when a sanitation check fails, and
when a control point with a check interval has gone too long without a reading. Alerts are
shown in the app, sent to the notification recipients by e-mail or WhatsApp (see
`services.notifications`), and closed by acknowledging them once.
"""

import logging
from datetime import UTC, datetime, timedelta
from uuid import UUID

from sqlalchemy import ColumnElement, Exists, exists, func, select
from sqlalchemy.orm import Session, sessionmaker

from compliance_engine.core.errors import ConflictError, NotFoundError
from compliance_engine.db.session import bind_tenant
from compliance_engine.models import (
    Alert,
    Base,
    CcpReading,
    ControlPoint,
    CorrectiveAction,
    RecordAmendment,
    RecordSignature,
    SanitationRecord,
    Supplier,
    SupplierApproval,
    SupplierDocument,
    Tenant,
    TrainingCourse,
    User,
)
from compliance_engine.models.enums import (
    RECEIVING_ALLOWED,
    AlertKind,
    AlertSeverity,
    CorrectiveActionStatus,
    SignatureMeaning,
    SupplierStatus,
)
from compliance_engine.schemas.capa import AcknowledgeAlert, AlertSummary
from compliance_engine.services import wording
from compliance_engine.services.audit import AuditLog
from compliance_engine.services.context import Actor, factory_today
from compliance_engine.services.notifications import queue_for_alert
from compliance_engine.services.settings import warning_days
from compliance_engine.services.training import standings

log = logging.getLogger(__name__)

# Document expiry is watched for suppliers we buy from or are about to approve.
WATCHED_SUPPLIERS = (*RECEIVING_ALLOWED, SupplierStatus.PENDING)

SEVERITY = {
    AlertKind.CCP_DEVIATION: AlertSeverity.CRITICAL,
    AlertKind.MISSED_CHECK: AlertSeverity.CRITICAL,
    AlertKind.SANITATION_FAILURE: AlertSeverity.MAJOR,
    AlertKind.SUPPLIER_DOCUMENT_EXPIRING: AlertSeverity.MAJOR,
    AlertKind.SUPPLIER_DOCUMENT_EXPIRED: AlertSeverity.MAJOR,
    AlertKind.SUPPLIER_REVIEW_DUE: AlertSeverity.MAJOR,
    AlertKind.TRAINING_EXPIRING: AlertSeverity.MAJOR,
    AlertKind.TRAINING_EXPIRED: AlertSeverity.MAJOR,
}


class AlertService:
    def __init__(self, session: Session, tenant_id: UUID, actor_id: UUID | None) -> None:
        self._session = session
        self._tenant_id = tenant_id
        self._actor_id = actor_id
        self._audit = AuditLog(session, tenant_id, actor_id)

    @classmethod
    def for_actor(cls, session: Session, actor: Actor) -> "AlertService":
        return cls(session, actor.tenant_id, actor.user_id)

    def raise_alert(
        self,
        kind: AlertKind,
        message: str,
        *,
        record_type: str | None = None,
        record_id: UUID | None = None,
        control_point_id: UUID | None = None,
    ) -> Alert:
        alert = Alert(
            tenant_id=self._tenant_id,
            kind=kind,
            severity=SEVERITY[kind],
            message=message[:500],
            record_type=record_type,
            record_id=record_id,
            control_point_id=control_point_id,
            raised_at=datetime.now(UTC),
        )
        self._session.add(alert)
        self._session.flush()
        self._audit.record(
            "alert.raised", "alert", alert.id, {"kind": kind, "message": alert.message}
        )
        queue_for_alert(self._session, alert)
        return alert

    def list_alerts(self, open_only: bool, kind: AlertKind | None, limit: int) -> list[Alert]:
        query = select(Alert).order_by(Alert.raised_at.desc()).limit(limit)
        if open_only:
            query = query.where(Alert.acknowledged_at.is_(None))
        if kind is not None:
            query = query.where(Alert.kind == kind)
        return list(self._session.scalars(query))

    def acknowledge(self, alert_id: UUID, command: AcknowledgeAlert) -> Alert:
        alert = self._session.get(Alert, alert_id, with_for_update=True)
        if alert is None:
            raise NotFoundError("Alert", alert_id)
        if alert.acknowledged_at is not None:
            raise ConflictError("This alert is already acknowledged")
        alert.acknowledged_at = datetime.now(UTC)
        alert.acknowledged_by = self._actor_id
        alert.acknowledgement = command.comment
        self._session.flush()
        self._audit.record("alert.acknowledged", "alert", alert.id, {"comment": command.comment})
        return alert

    def summary(self) -> AlertSummary:
        def count(*conditions: ColumnElement[bool], model: type[Base] = Alert) -> int:
            return (
                self._session.scalar(select(func.count()).select_from(model).where(*conditions))
                or 0
            )

        open_alerts = Alert.acknowledged_at.is_(None)
        return AlertSummary(
            open_alerts=count(open_alerts),
            open_critical=count(open_alerts, Alert.severity == AlertSeverity.CRITICAL),
            open_corrective_actions=count(
                CorrectiveAction.status == CorrectiveActionStatus.OPEN, model=CorrectiveAction
            ),
            unverified_records=count(
                ~_has_verification(CcpReading, "ccp_reading"), model=CcpReading
            )
            + count(
                ~_has_verification(SanitationRecord, "sanitation_record"), model=SanitationRecord
            )
            + count(~_has_verification(RecordAmendment, "record_amendment"), model=RecordAmendment),
        )

    def scan_missed_checks(self, now: datetime | None = None) -> list[Alert]:
        """Raise one alert per control point whose check is overdue (once per gap)."""
        now = now or datetime.now(UTC)
        raised = []
        last_reading = (
            select(func.max(CcpReading.measured_at))
            .where(CcpReading.control_point_id == ControlPoint.id)
            .scalar_subquery()
        )
        rows = self._session.execute(
            select(ControlPoint, last_reading).where(
                ControlPoint.check_interval_minutes.is_not(None)
            )
        ).all()
        for control_point, last in rows:
            assert control_point.check_interval_minutes is not None
            since = last or control_point.created_at
            interval = timedelta(minutes=control_point.check_interval_minutes)
            if now <= since + interval:
                continue
            already_raised = self._session.scalar(
                select(
                    exists().where(
                        Alert.kind == AlertKind.MISSED_CHECK,
                        Alert.control_point_id == control_point.id,
                        Alert.raised_at > since,
                    )
                )
            )
            if already_raised:
                continue
            raised.append(
                self.raise_alert(
                    AlertKind.MISSED_CHECK,
                    wording.missed_check(
                        control_point.code,
                        control_point.name,
                        now - since,
                        last is not None,
                        interval,
                    ),
                    control_point_id=control_point.id,
                )
            )
        return raised

    def scan_expiries(self) -> list[Alert]:
        """Raise one alert per supplier document or training that expires within the warning
        days, one more when it has expired, and one per overdue supplier review."""
        today = factory_today()
        warn = warning_days(self._session, self._tenant_id)
        horizon = today + timedelta(days=warn)
        raised: list[Alert] = []

        def already(kind: AlertKind, record_id: UUID, since: datetime | None = None) -> bool:
            conditions = [Alert.kind == kind, Alert.record_id == record_id]
            if since is not None:
                conditions.append(Alert.raised_at > since)
            return bool(self._session.scalar(select(exists().where(*conditions))))

        documents = self._session.execute(
            select(SupplierDocument, Supplier)
            .join(Supplier, Supplier.id == SupplierDocument.supplier_id)
            .where(
                SupplierDocument.withdrawn_at.is_(None),
                SupplierDocument.expires_on <= horizon,
                Supplier.approval_status.in_(WATCHED_SUPPLIERS),
            )
        )
        for document, supplier in documents:
            assert document.expires_on is not None
            kind = (
                AlertKind.SUPPLIER_DOCUMENT_EXPIRED
                if document.expires_on < today
                else AlertKind.SUPPLIER_DOCUMENT_EXPIRING
            )
            if already(kind, document.id):
                continue
            raised.append(
                self.raise_alert(
                    kind,
                    wording.supplier_document(
                        supplier.code, supplier.name, document.title, document.expires_on, today
                    ),
                    record_type="supplier_document",
                    record_id=document.id,
                )
            )

        last_decision = (
            select(func.max(SupplierApproval.decided_at))
            .where(SupplierApproval.supplier_id == Supplier.id)
            .scalar_subquery()
        )
        due = self._session.execute(
            select(Supplier, last_decision).where(
                Supplier.approval_status.in_(RECEIVING_ALLOWED),
                Supplier.next_review_date < today,
            )
        )
        for supplier, decided_at in due:
            assert supplier.next_review_date is not None
            if already(AlertKind.SUPPLIER_REVIEW_DUE, supplier.id, decided_at):
                continue
            raised.append(
                self.raise_alert(
                    AlertKind.SUPPLIER_REVIEW_DUE,
                    wording.supplier_review(
                        supplier.code, supplier.name, supplier.next_review_date
                    ),
                    record_type="supplier",
                    record_id=supplier.id,
                )
            )

        people = {u.id: u for u in self._session.scalars(select(User).where(User.is_active))}
        courses = {
            c.id: c
            for c in self._session.scalars(select(TrainingCourse).where(TrainingCourse.is_active))
        }
        for (user_id, course_id), standing in standings(
            self._session, self._tenant_id, list(people)
        ).items():
            record = standing.record
            if (
                course_id not in courses
                or record is None
                or standing.status not in ("expiring", "expired")
                or record.expires_on is None
            ):
                continue
            kind = (
                AlertKind.TRAINING_EXPIRED
                if standing.status == "expired"
                else AlertKind.TRAINING_EXPIRING
            )
            if already(kind, record.id):
                continue
            course = courses[course_id]
            raised.append(
                self.raise_alert(
                    kind,
                    wording.training(
                        people[user_id].full_name,
                        course.code,
                        course.title,
                        record.expires_on,
                        today,
                    ),
                    record_type="training_record",
                    record_id=record.id,
                )
            )
        return raised


def _has_verification(
    model: type[CcpReading | SanitationRecord | RecordAmendment], record_type: str
) -> Exists:
    return exists().where(
        RecordSignature.record_type == record_type,
        RecordSignature.record_id == model.id,
        RecordSignature.meaning == SignatureMeaning.VERIFIED,
    )


def scan_all_tenants(session_factory: sessionmaker[Session]) -> int:
    """Run the missed-check and expiry scans for every tenant, one transaction each.
    Returns the number of alerts raised."""
    with session_factory() as session:
        tenant_ids = list(session.scalars(select(Tenant.id)))
    total = 0
    for tenant_id in tenant_ids:
        try:
            with session_factory.begin() as session:
                bind_tenant(session, tenant_id)
                service = AlertService(session, tenant_id, None)
                total += len(service.scan_missed_checks()) + len(service.scan_expiries())
        except Exception:  # one tenant's failure must not stop the others
            log.exception("Missed-check scan failed for tenant %s", tenant_id)
    return total
