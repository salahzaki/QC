"""HACCP monitoring records: CCP readings and sanitation checks.

Both are append-only and signed. The person who records an entry signs it as "performed"
in the same request; a supervisor or quality manager later signs it as "verified". A value
outside the critical limits, or a failed sanitation check, cannot be saved without the
immediate corrective action, and it opens a corrective action and raises an alert.

Mistakes are fixed with amendments, never by editing: an amendment stores the corrected
fields (old and new value) and the reason, is signed by its author and verified by a second
person. Records are always shown with their amendments applied.
"""

from collections.abc import Callable, Iterable, Sequence
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from typing import Any
from uuid import UUID

from sqlalchemy import ColumnElement, Select, and_, exists, or_, select, text
from sqlalchemy.orm import Session

from compliance_engine.core.errors import BusinessRuleError, ConflictError, NotFoundError
from compliance_engine.models import (
    CcpReading,
    ControlPoint,
    CorrectiveAction,
    Lot,
    ProductionRun,
    RecordAmendment,
    RecordSignature,
    SanitationRecord,
)
from compliance_engine.models.enums import (
    AlertKind,
    SanitationActivity,
    SanitationResult,
    SignatureMeaning,
)
from compliance_engine.schemas.records import (
    AmendCcpReading,
    Amendment,
    AmendmentView,
    AmendSanitation,
    CcpReadingView,
    CreateControlPoint,
    RecordCcpReading,
    RecordSanitation,
    SanitationRecordView,
    SignRecord,
    UpdateControlPoint,
    check_limits,
)
from compliance_engine.services import wording
from compliance_engine.services.audit import AuditLog
from compliance_engine.services.capa import CapaService
from compliance_engine.services.context import Actor
from compliance_engine.services.signatures import (
    RECORD_TYPES,
    SignatureService,
    canonical,
)
from compliance_engine.services.training import check_competence

# Tablets and PCs are rarely in perfect sync; anything further ahead is a typo.
CLOCK_TOLERANCE = timedelta(minutes=5)

MonitoringRecord = CcpReading | SanitationRecord


def _decimal(places: str) -> Callable[[Any], Decimal]:
    """Read a stored amount back at the column's scale, so 76.5 shows as 76.500 like the rest."""
    return lambda raw: Decimal(raw).quantize(Decimal(places))


# Fields an amendment may correct, with how to read a stored (canonical text) value back.
AMENDABLE: dict[type[MonitoringRecord], dict[str, Callable[[Any], Any]]] = {
    CcpReading: {
        "value": _decimal("0.001"),
        "measured_at": datetime.fromisoformat,
        "notes": str,
        "lot_id": UUID,
        "production_run_id": UUID,
    },
    SanitationRecord: {
        "area": str,
        "activity": SanitationActivity,
        "chemical": str,
        "concentration_ppm": _decimal("0.01"),
        "result": SanitationResult,
        "performed_at": datetime.fromisoformat,
        "notes": str,
    },
}


def within_limits(value: Decimal, low: Decimal | None, high: Decimal | None) -> bool:
    return (low is None or value >= low) and (high is None or value <= high)


def limits_text(low: Decimal | None, high: Decimal | None, unit: str) -> str:
    if low is not None and high is not None:
        return f"{_num(low)} to {_num(high)} {unit}"
    if low is not None:
        return f"min {_num(low)} {unit}"
    return f"max {_num(high)} {unit}"


def _num(value: Decimal | None) -> str:
    return "" if value is None else format(value.normalize(), "f")


def _check_not_future(moment: datetime) -> None:
    if moment > datetime.now(UTC) + CLOCK_TOLERANCE:
        raise BusinessRuleError("A record cannot be dated in the future")


def effective_fields(
    record: MonitoringRecord, amendments: Sequence[RecordAmendment]
) -> dict[str, Any]:
    """The record's amendable fields with every amendment applied, oldest first."""
    parsers = AMENDABLE[type(record)]
    state = {name: getattr(record, name) for name in parsers}
    for amendment in amendments:
        for name, change in amendment.changes.items():
            state[name] = None if change["to"] is None else parsers[name](change["to"])
    return state


class RecordsService:
    def __init__(self, session: Session, actor: Actor) -> None:
        self._session = session
        self._actor = actor
        self._audit = AuditLog(session, actor.tenant_id, actor.user_id)
        self._signatures = SignatureService(session, actor)
        self._capa = CapaService(session, actor)

    # ----- control points --------------------------------------------------------------

    def create_control_point(self, command: CreateControlPoint) -> ControlPoint:
        if self._session.scalar(select(ControlPoint.id).where(ControlPoint.code == command.code)):
            raise ConflictError(f"Control point with code '{command.code}' already exists")
        control_point = ControlPoint(tenant_id=self._actor.tenant_id, **command.model_dump())
        self._session.add(control_point)
        self._session.flush()
        self._audit.record(
            "control_point.created", "control_point", control_point.id, command.model_dump()
        )
        return control_point

    def update_control_point(
        self, control_point_id: UUID, command: UpdateControlPoint
    ) -> ControlPoint:
        control_point = self._session.get(ControlPoint, control_point_id, with_for_update=True)
        if control_point is None:
            raise NotFoundError("Control point", control_point_id)
        changes = {
            name: getattr(command, name) for name in command.model_fields_set if name != "reason"
        }
        try:
            check_limits(
                changes.get("critical_min", control_point.critical_min),
                changes.get("critical_max", control_point.critical_max),
            )
        except ValueError as exc:
            raise BusinessRuleError(str(exc)) from exc
        before = {name: getattr(control_point, name) for name in changes}
        for name, value in changes.items():
            setattr(control_point, name, value)
        self._session.flush()
        self._session.refresh(control_point)  # values as stored, e.g. 74 -> 74.000
        self._audit.record(
            "control_point.updated",
            "control_point",
            control_point.id,
            {"before": before, "after": changes, "reason": command.reason},
        )
        return control_point

    def list_control_points(self) -> list[ControlPoint]:
        return list(self._session.scalars(select(ControlPoint).order_by(ControlPoint.code)))

    # ----- CCP readings ----------------------------------------------------------------

    def record_ccp_reading(self, command: RecordCcpReading) -> CcpReadingView:
        control_point = self._session.get(ControlPoint, command.control_point_id)
        if control_point is None:
            raise NotFoundError("Control point", command.control_point_id)
        check_competence(self._session, self._actor, control_point)
        self._check_links(command.lot_id, command.production_run_id)
        measured_at = command.measured_at or datetime.now(UTC)
        _check_not_future(measured_at)

        ok = within_limits(command.value, control_point.critical_min, control_point.critical_max)
        if not ok and command.corrective_action is None:
            raise BusinessRuleError(
                f"{command.value} {control_point.unit} is outside the critical limits of "
                f"{control_point.code} ({_cp_limits(control_point)}); "
                "record the corrective action taken"
            )

        reading = CcpReading(
            tenant_id=self._actor.tenant_id,
            control_point_id=control_point.id,
            control_point=control_point,
            value=command.value,
            unit=control_point.unit,
            critical_min=control_point.critical_min,
            critical_max=control_point.critical_max,
            within_limits=ok,
            corrective_action=command.corrective_action,
            notes=command.notes,
            lot_id=command.lot_id,
            production_run_id=command.production_run_id,
            measured_at=measured_at,
            recorded_by=self._actor.user_id,
        )
        self._session.add(reading)
        self._session.flush()
        self._audit.record(
            "ccp_reading.recorded", "ccp_reading", reading.id, _without_password(command)
        )
        self._signatures.sign(
            reading, SignatureMeaning.PERFORMED, command.password.get_secret_value()
        )
        if not ok:
            assert command.corrective_action is not None
            self._open_ccp_deviation(reading, command.value, command.lot_id)
            self._session.flush()
        return self.get_ccp_reading(reading.id)

    def list_ccp_readings(
        self,
        control_point_id: UUID | None,
        deviations_only: bool,
        unverified_only: bool,
        limit: int,
        measured_from: datetime | None = None,
        measured_to: datetime | None = None,
    ) -> list[CcpReadingView]:
        amendable_filters: list[ColumnElement[bool]] = []
        if deviations_only:
            amendable_filters.append(CcpReading.within_limits.is_(False))
        if measured_from is not None:
            amendable_filters.append(CcpReading.measured_at >= measured_from)
        if measured_to is not None:
            amendable_filters.append(CcpReading.measured_at < measured_to)

        query = _candidates(select(CcpReading), CcpReading, amendable_filters, limit)
        query = query.order_by(CcpReading.measured_at.desc())
        if control_point_id is not None:
            query = query.where(CcpReading.control_point_id == control_point_id)
        if unverified_only:
            query = _unverified(query, CcpReading)

        views = self._ccp_views(list(self._session.scalars(query).unique()))
        views = [
            v
            for v in views
            if (not deviations_only or not v.within_limits)
            and (measured_from is None or v.measured_at >= measured_from)
            and (measured_to is None or v.measured_at < measured_to)
        ]
        views.sort(key=lambda v: v.measured_at, reverse=True)
        return views[:limit]

    def get_ccp_reading(self, reading_id: UUID) -> CcpReadingView:
        return self._ccp_views([self._get(CcpReading, reading_id)])[0]

    def verify_ccp_reading(self, reading_id: UUID, command: SignRecord) -> CcpReadingView:
        reading = self._get(CcpReading, reading_id)
        self._verify(reading, command)
        return self.get_ccp_reading(reading_id)

    def amend_ccp_reading(self, reading_id: UUID, command: AmendCcpReading) -> CcpReadingView:
        reading = self._get(CcpReading, reading_id, lock=True)
        corrections = command.corrections()
        self._check_links(corrections.get("lot_id"), corrections.get("production_run_id"))
        if corrections.get("measured_at") is not None:
            _check_not_future(corrections["measured_at"])

        def opens_deviation(after: dict[str, Any]) -> bool:
            return not within_limits(after["value"], reading.critical_min, reading.critical_max)

        def open_deviation(after: dict[str, Any]) -> None:
            self._open_ccp_deviation(
                reading, after["value"], after["lot_id"], command.corrective_action
            )

        self._amend(reading, command, opens_deviation, open_deviation)
        return self.get_ccp_reading(reading_id)

    # ----- sanitation ------------------------------------------------------------------

    def record_sanitation(self, command: RecordSanitation) -> SanitationRecordView:
        performed_at = command.performed_at or datetime.now(UTC)
        _check_not_future(performed_at)
        record = SanitationRecord(
            tenant_id=self._actor.tenant_id,
            area=command.area,
            activity=command.activity,
            chemical=command.chemical,
            concentration_ppm=command.concentration_ppm,
            result=command.result,
            corrective_action=command.corrective_action,
            notes=command.notes,
            performed_at=performed_at,
            recorded_by=self._actor.user_id,
        )
        self._session.add(record)
        self._session.flush()
        self._audit.record(
            "sanitation.recorded", "sanitation_record", record.id, _without_password(command)
        )
        self._signatures.sign(
            record, SignatureMeaning.PERFORMED, command.password.get_secret_value()
        )
        if command.result == SanitationResult.FAIL:
            assert command.corrective_action is not None
            self._open_sanitation_failure(
                record, command.area, command.activity, command.corrective_action
            )
            self._session.flush()
        return self.get_sanitation(record.id)

    def list_sanitation(
        self,
        area: str | None,
        failures_only: bool,
        unverified_only: bool,
        limit: int,
        performed_from: datetime | None = None,
        performed_to: datetime | None = None,
    ) -> list[SanitationRecordView]:
        amendable_filters: list[ColumnElement[bool]] = []
        if area is not None:
            amendable_filters.append(SanitationRecord.area == area)
        if failures_only:
            amendable_filters.append(SanitationRecord.result == SanitationResult.FAIL)
        if performed_from is not None:
            amendable_filters.append(SanitationRecord.performed_at >= performed_from)
        if performed_to is not None:
            amendable_filters.append(SanitationRecord.performed_at < performed_to)

        query = _candidates(select(SanitationRecord), SanitationRecord, amendable_filters, limit)
        query = query.order_by(SanitationRecord.performed_at.desc())
        if unverified_only:
            query = _unverified(query, SanitationRecord)

        views = self._sanitation_views(list(self._session.scalars(query)))
        views = [
            v
            for v in views
            if (area is None or v.area == area)
            and (not failures_only or v.result == SanitationResult.FAIL)
            and (performed_from is None or v.performed_at >= performed_from)
            and (performed_to is None or v.performed_at < performed_to)
        ]
        views.sort(key=lambda v: v.performed_at, reverse=True)
        return views[:limit]

    def get_sanitation(self, record_id: UUID) -> SanitationRecordView:
        return self._sanitation_views([self._get(SanitationRecord, record_id)])[0]

    def verify_sanitation(self, record_id: UUID, command: SignRecord) -> SanitationRecordView:
        record = self._get(SanitationRecord, record_id)
        self._verify(record, command)
        return self.get_sanitation(record_id)

    def amend_sanitation(self, record_id: UUID, command: AmendSanitation) -> SanitationRecordView:
        record = self._get(SanitationRecord, record_id, lock=True)
        corrections = command.corrections()
        if corrections.get("performed_at") is not None:
            _check_not_future(corrections["performed_at"])

        def opens_deviation(after: dict[str, Any]) -> bool:
            return bool(after["result"] == SanitationResult.FAIL)

        def open_deviation(after: dict[str, Any]) -> None:
            assert command.corrective_action is not None
            self._open_sanitation_failure(
                record, after["area"], after["activity"], command.corrective_action
            )

        self._amend(record, command, opens_deviation, open_deviation)
        return self.get_sanitation(record_id)

    # ----- amendments ------------------------------------------------------------------

    def list_amendments(self, unverified_only: bool, limit: int) -> list[AmendmentView]:
        query = select(RecordAmendment).order_by(RecordAmendment.amended_at.desc()).limit(limit)
        if unverified_only:
            query = _unverified(query, RecordAmendment)
        amendments = list(self._session.scalars(query))
        signatures = self._signatures.for_records(RecordAmendment, (a.id for a in amendments))
        return [self._amendment_view(a, signatures[a.id]) for a in amendments]

    def verify_amendment(self, amendment_id: UUID, command: SignRecord) -> AmendmentView:
        amendment = self._session.get(RecordAmendment, amendment_id)
        if amendment is None:
            raise NotFoundError("Amendment", amendment_id)
        self._verify(amendment, command)
        return self._amendment_view(
            amendment, self._signatures.for_records(RecordAmendment, [amendment.id])[amendment.id]
        )

    def _amend(
        self,
        record: MonitoringRecord,
        command: Amendment,
        opens_deviation: Callable[[dict[str, Any]], bool],
        open_deviation: Callable[[dict[str, Any]], None],
    ) -> RecordAmendment:
        record_type = RECORD_TYPES[type(record)]
        before = effective_fields(
            record, self._amendments_for(type(record), [record.id])[record.id]
        )
        changes = {
            name: {"from": canonical(before[name]), "to": canonical(value)}
            for name, value in command.corrections().items()
            if canonical(before[name]) != canonical(value)
        }
        if not changes:
            raise BusinessRuleError("The amendment does not change anything")
        after = {**before, **{name: command.corrections()[name] for name in changes}}

        needs_new_action = opens_deviation(after) and not self._capa.for_records([record.id])
        if needs_new_action and command.corrective_action is None:
            raise BusinessRuleError(
                "After this correction the record is a deviation; "
                "record the corrective action taken"
            )
        if not needs_new_action and command.corrective_action is not None:
            raise BusinessRuleError(
                "corrective_action is only accepted when the correction turns the record into "
                "a deviation; add follow-up details when closing its corrective action"
            )

        amendment = RecordAmendment(
            tenant_id=self._actor.tenant_id,
            record_type=record_type,
            record_id=record.id,
            changes=changes,
            reason=command.reason,
            amended_at=datetime.now(UTC),
            amended_by=self._actor.user_id,
        )
        self._session.add(amendment)
        self._session.flush()
        self._audit.record(
            "record.amended",
            record_type,
            record.id,
            {"amendment_id": amendment.id, "changes": changes, "reason": command.reason},
        )
        self._signatures.sign(
            amendment, SignatureMeaning.PERFORMED, command.password.get_secret_value()
        )
        if needs_new_action:
            open_deviation(after)
        self._session.flush()
        return amendment

    def _amendments_for(
        self, model: type[MonitoringRecord], record_ids: Iterable[UUID]
    ) -> dict[UUID, list[RecordAmendment]]:
        ids = list(record_ids)
        result: dict[UUID, list[RecordAmendment]] = {record_id: [] for record_id in ids}
        if not ids:
            return result
        rows = self._session.scalars(
            select(RecordAmendment)
            .where(
                RecordAmendment.record_type == RECORD_TYPES[model],
                RecordAmendment.record_id.in_(ids),
            )
            .order_by(RecordAmendment.amended_at, RecordAmendment.created_at)
        )
        for amendment in rows:
            result[amendment.record_id].append(amendment)
        return result

    # ----- deviations ------------------------------------------------------------------

    def _open_ccp_deviation(
        self,
        reading: CcpReading,
        value: Decimal,
        lot_id: UUID | None,
        immediate_action: str | None = None,
    ) -> CorrectiveAction:
        control_point = reading.control_point
        return self._capa.open_for_deviation(
            record_type="ccp_reading",
            record_id=reading.id,
            description=wording.ccp_deviation(
                control_point.code,
                control_point.name,
                value,
                reading.unit,
                reading.critical_min,
                reading.critical_max,
            ),
            immediate_action=immediate_action or reading.corrective_action or "",
            alert_kind=AlertKind.CCP_DEVIATION,
            control_point_id=control_point.id,
            lot_id=lot_id,
        )

    def _open_sanitation_failure(
        self,
        record: SanitationRecord,
        area: str,
        activity: SanitationActivity,
        immediate_action: str,
    ) -> CorrectiveAction:
        return self._capa.open_for_deviation(
            record_type="sanitation_record",
            record_id=record.id,
            description=wording.sanitation_failure(activity, area),
            immediate_action=immediate_action,
            alert_kind=AlertKind.SANITATION_FAILURE,
        )

    # ----- helpers ---------------------------------------------------------------------

    def _check_links(self, lot_id: UUID | None, production_run_id: UUID | None) -> None:
        if lot_id is not None and self._session.get(Lot, lot_id) is None:
            raise NotFoundError("Lot", lot_id)
        if (
            production_run_id is not None
            and self._session.get(ProductionRun, production_run_id) is None
        ):
            raise NotFoundError("Production run", production_run_id)

    def _get[T: (CcpReading, SanitationRecord)](
        self, model: type[T], record_id: UUID, lock: bool = False
    ) -> T:
        if lock:  # one amendment at a time per record, so "from" values are never stale
            self._session.execute(
                text("SELECT pg_advisory_xact_lock(hashtextextended(:key, 0))"),
                {"key": f"record:{record_id}"},
            )
        record = self._session.get(model, record_id)
        if record is None:
            raise NotFoundError(RECORD_TYPES[model].replace("_", " ").capitalize(), record_id)
        return record

    def _verify(
        self, record: CcpReading | SanitationRecord | RecordAmendment, command: SignRecord
    ) -> None:
        self._signatures.sign(
            record,
            SignatureMeaning.VERIFIED,
            command.password.get_secret_value(),
            command.comment,
        )

    def _amendment_view(
        self, amendment: RecordAmendment, signatures: list[RecordSignature]
    ) -> AmendmentView:
        return AmendmentView(
            id=amendment.id,
            serial=amendment.serial,
            record_type=amendment.record_type,
            record_id=amendment.record_id,
            changes=amendment.changes,
            reason=amendment.reason,
            amended_at=amendment.amended_at,
            amended_by=amendment.amended_by,
            verified=_is_verified(signatures),
            signatures=self._signatures.views(amendment, signatures),
        )

    def _related(
        self, model: type[MonitoringRecord], records: Sequence[MonitoringRecord]
    ) -> tuple[
        dict[UUID, list[RecordSignature]],
        dict[UUID, list[RecordAmendment]],
        dict[UUID, list[AmendmentView]],
        dict[UUID, CorrectiveAction],
    ]:
        ids = [r.id for r in records]
        signatures = self._signatures.for_records(model, ids)
        amendments = self._amendments_for(model, ids)
        all_amendments = [a for group in amendments.values() for a in group]
        amendment_signatures = self._signatures.for_records(
            RecordAmendment, (a.id for a in all_amendments)
        )
        amendment_views = {
            record_id: [self._amendment_view(a, amendment_signatures[a.id]) for a in group]
            for record_id, group in amendments.items()
        }
        return signatures, amendments, amendment_views, self._capa.for_records(ids)

    def _ccp_views(self, readings: Sequence[CcpReading]) -> list[CcpReadingView]:
        signatures, amendments, amendment_views, actions = self._related(CcpReading, readings)
        views = []
        for reading in readings:
            state = effective_fields(reading, amendments[reading.id])
            action = actions.get(reading.id)
            views.append(
                CcpReadingView(
                    id=reading.id,
                    serial=reading.serial,
                    control_point_id=reading.control_point_id,
                    control_point_code=reading.control_point.code,
                    control_point_name=reading.control_point.name,
                    value=state["value"],
                    unit=reading.unit,
                    critical_min=reading.critical_min,
                    critical_max=reading.critical_max,
                    within_limits=within_limits(
                        state["value"], reading.critical_min, reading.critical_max
                    ),
                    corrective_action=action.immediate_action
                    if action
                    else reading.corrective_action,
                    notes=state["notes"],
                    lot_id=state["lot_id"],
                    production_run_id=state["production_run_id"],
                    measured_at=state["measured_at"],
                    recorded_by=reading.recorded_by,
                    created_at=reading.created_at,
                    verified=_fully_verified(signatures[reading.id], amendment_views[reading.id]),
                    signatures=self._signatures.views(reading, signatures[reading.id]),
                    amended=bool(amendments[reading.id]),
                    amendments=amendment_views[reading.id],
                    corrective_action_id=action.id if action else None,
                    corrective_action_status=action.status if action else None,
                )
            )
        return views

    def _sanitation_views(self, records: Sequence[SanitationRecord]) -> list[SanitationRecordView]:
        signatures, amendments, amendment_views, actions = self._related(SanitationRecord, records)
        views = []
        for record in records:
            state = effective_fields(record, amendments[record.id])
            action = actions.get(record.id)
            views.append(
                SanitationRecordView(
                    id=record.id,
                    serial=record.serial,
                    area=state["area"],
                    activity=state["activity"],
                    chemical=state["chemical"],
                    concentration_ppm=state["concentration_ppm"],
                    result=state["result"],
                    corrective_action=action.immediate_action
                    if action
                    else record.corrective_action,
                    notes=state["notes"],
                    performed_at=state["performed_at"],
                    recorded_by=record.recorded_by,
                    created_at=record.created_at,
                    verified=_fully_verified(signatures[record.id], amendment_views[record.id]),
                    signatures=self._signatures.views(record, signatures[record.id]),
                    amended=bool(amendments[record.id]),
                    amendments=amendment_views[record.id],
                    corrective_action_id=action.id if action else None,
                    corrective_action_status=action.status if action else None,
                )
            )
        return views


def _is_verified(signatures: Sequence[RecordSignature]) -> bool:
    return any(s.meaning == SignatureMeaning.VERIFIED for s in signatures)


def _fully_verified(
    signatures: Sequence[RecordSignature], amendments: Sequence[AmendmentView]
) -> bool:
    return _is_verified(signatures) and all(a.verified for a in amendments)


def _verified(
    model: type[CcpReading | SanitationRecord | RecordAmendment], record_type: str
) -> Any:
    return exists().where(
        RecordSignature.record_type == record_type,
        RecordSignature.record_id == model.id,
        RecordSignature.meaning == SignatureMeaning.VERIFIED,
    )


def _unverified(
    query: Select[Any], model: type[CcpReading | SanitationRecord | RecordAmendment]
) -> Select[Any]:
    """Records missing a verification, on the record itself or on any of its amendments."""
    record_type = RECORD_TYPES[model]
    condition = ~_verified(model, record_type)
    if model is not RecordAmendment:
        unverified_amendment = exists().where(
            RecordAmendment.record_type == record_type,
            RecordAmendment.record_id == model.id,
            ~exists().where(
                RecordSignature.record_type == "record_amendment",
                RecordSignature.record_id == RecordAmendment.id,
                RecordSignature.meaning == SignatureMeaning.VERIFIED,
            ),
        )
        condition = or_(condition, unverified_amendment)
    return query.where(condition)


def _candidates(
    query: Select[Any],
    model: type[MonitoringRecord],
    amendable_filters: list[ColumnElement[bool]],
    limit: int,
) -> Select[Any]:
    """Filters on fields an amendment can change are checked again on the amended values,
    so amended records always stay candidates (and the limit is applied afterwards)."""
    if not amendable_filters:
        return query.limit(limit)
    amended = exists().where(
        RecordAmendment.record_type == RECORD_TYPES[model],
        RecordAmendment.record_id == model.id,
    )
    return query.where(or_(and_(*amendable_filters), amended))


def _cp_limits(control_point: ControlPoint) -> str:
    return limits_text(control_point.critical_min, control_point.critical_max, control_point.unit)


def _without_password(command: RecordCcpReading | RecordSanitation) -> dict[str, Any]:
    return command.model_dump(exclude={"password"})
