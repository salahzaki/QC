from uuid import UUID

from sqlalchemy import select
from sqlalchemy.orm import Session

from compliance_engine.core.errors import (
    BusinessRuleError,
    ConflictError,
    LoginRejectedError,
    NotFoundError,
    PasswordRejectedError,
)
from compliance_engine.core.permissions import Role
from compliance_engine.core.security import (
    TokenClaims,
    create_access_token,
    hash_password,
    verify_password,
)
from compliance_engine.db.session import bind_tenant
from compliance_engine.models import Tenant, User
from compliance_engine.schemas.identity import (
    ChangePassword,
    CreateTenant,
    CreateUser,
    LoginRequest,
    ResetPassword,
    UpdateUser,
)
from compliance_engine.services.audit import AuditLog
from compliance_engine.services.context import Actor
from compliance_engine.services.lockout import check_password, unlock

INVALID_LOGIN = "Invalid tenant, email or password"

# Compared against when the user does not exist, so response time does not reveal it.
_DUMMY_HASH = hash_password("timing-equaliser-password")


def provision_tenant(session: Session, command: CreateTenant) -> tuple[Tenant, User]:
    """Create a tenant and its first admin. Used by the CLI, not exposed over HTTP."""
    if session.scalar(select(Tenant.id).where(Tenant.slug == command.slug)):
        raise ConflictError(f"Tenant '{command.slug}' already exists")

    tenant = Tenant(slug=command.slug, name=command.name)
    session.add(tenant)
    session.flush()
    bind_tenant(session, tenant.id)

    admin = User(
        tenant_id=tenant.id,
        email=command.admin_email.lower(),
        full_name=command.admin_full_name,
        password_hash=hash_password(command.admin_password),
        role=Role.ADMIN,
    )
    session.add(admin)
    session.flush()
    AuditLog(session, tenant.id, admin.id).record(
        "tenant.provisioned", "tenant", tenant.id, {"slug": tenant.slug, "admin": admin.email}
    )
    return tenant, admin


def reset_password_by_email(session: Session, tenant: str, email: str, password: str) -> User:
    """Set a user's password from the server console, e.g. when the only admin is locked out."""
    tenant_id = session.scalar(select(Tenant.id).where(Tenant.slug == tenant))
    if tenant_id is None:
        raise NotFoundError("Tenant", tenant)
    bind_tenant(session, tenant_id)
    user = session.scalar(select(User).where(User.email == email.lower()))
    if user is None:
        raise NotFoundError("User", email)
    user.password_hash = hash_password(ResetPassword(new_password=password).new_password)
    unlock(user)
    AuditLog(session, tenant_id, None).record(
        "user.password_reset", "user", user.id, {"email": user.email, "via": "console"}
    )
    return user


def login(session: Session, request: LoginRequest) -> str:
    tenant_id = session.scalar(select(Tenant.id).where(Tenant.slug == request.tenant))
    user = None
    if tenant_id is not None:
        bind_tenant(session, tenant_id)
        user = session.scalar(select(User).where(User.email == request.email.lower()))

    if user is None or not user.is_active:
        verify_password(request.password, _DUMMY_HASH)  # same timing as a real check
        raise LoginRejectedError(INVALID_LOGIN)
    check_password(
        user, request.password, "login", LoginRejectedError, INVALID_LOGIN, show_attempts_left=False
    )

    return create_access_token(
        TokenClaims(user_id=user.id, tenant_id=user.tenant_id, role=user.role)
    )


class UserService:
    def __init__(self, session: Session, actor: Actor) -> None:
        self._session = session
        self._actor = actor
        self._audit = AuditLog(session, actor.tenant_id, actor.user_id)

    def create(self, command: CreateUser) -> User:
        email = command.email.lower()
        if self._session.scalar(select(User.id).where(User.email == email)):
            raise ConflictError(f"User '{email}' already exists")
        user = User(
            tenant_id=self._actor.tenant_id,
            email=email,
            full_name=command.full_name,
            password_hash=hash_password(command.password),
            role=command.role,
            phone=command.phone,
        )
        self._session.add(user)
        self._session.flush()
        self._audit.record("user.created", "user", user.id, {"email": email, "role": user.role})
        return user

    def me(self) -> User:
        return self._get(self._actor.user_id)

    def list_users(self) -> list[User]:
        return list(self._session.scalars(select(User).order_by(User.email)))

    def people(self) -> list[User]:
        return list(
            self._session.scalars(select(User).where(User.is_active).order_by(User.full_name))
        )

    def change_own_password(self, command: ChangePassword) -> None:
        user = self._session.get(User, self._actor.user_id)
        assert user is not None  # the actor was loaded from this row
        check_password(
            user,
            command.current_password,
            "password_change",
            PasswordRejectedError,
            "Current password is incorrect",
        )
        if verify_password(command.new_password, user.password_hash):
            raise BusinessRuleError("The new password must differ from the current one")
        user.password_hash = hash_password(command.new_password)
        self._audit.record("user.password_changed", "user", user.id, {"email": user.email})

    def _get(self, user_id: UUID) -> User:
        user = self._session.get(User, user_id)  # row-level security limits this to the tenant
        if user is None:
            raise NotFoundError("User", user_id)
        return user

    def update(self, user_id: UUID, command: UpdateUser) -> User:
        user = self._get(user_id)
        if user.id == self._actor.user_id and (
            (command.role is not None and command.role != user.role) or command.is_active is False
        ):
            # Also keeps at least one admin: an admin can only be demoted by another admin.
            raise BusinessRuleError("You cannot change your own role or deactivate yourself")
        changes = {
            field: {"from": getattr(user, field), "to": value}
            for field, value in command.model_dump(exclude_unset=True).items()
            if getattr(user, field) != value
        }
        if not changes:
            raise BusinessRuleError("This does not change anything")
        for field, change in changes.items():
            setattr(user, field, change["to"])
        self._session.flush()
        self._audit.record("user.updated", "user", user.id, {"email": user.email, **changes})
        return user

    def unlock(self, user_id: UUID) -> User:
        user = self._get(user_id)
        if user.locked_at is None and not user.failed_password_attempts:
            raise ConflictError("This account is not locked")
        unlock(user)
        self._session.flush()
        self._audit.record("user.unlocked", "user", user.id, {"email": user.email})
        return user

    def reset_password(self, user_id: UUID, command: ResetPassword) -> User:
        user = self._get(user_id)
        user.password_hash = hash_password(command.new_password)
        unlock(user)
        self._session.flush()
        self._audit.record(
            "user.password_reset", "user", user.id, {"email": user.email, "via": "api"}
        )
        return user
