"""Document control: the controlled forms behind each report, and the issued-report register.

The default codes follow common HACCP practice (no regulator prescribes form numbers); each
factory sets its own codes, revision and effective date once, from its HACCP manual.
"""

import hashlib
from dataclasses import dataclass
from datetime import UTC, date, datetime
from typing import Any
from uuid import UUID, uuid4

from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.orm import Session

from compliance_engine.core.errors import BusinessRuleError, ConflictError, NotFoundError
from compliance_engine.models import DocumentForm, IssuedReport, User
from compliance_engine.schemas.documents import (
    DocumentFormView,
    IssuedReportView,
    ReportCheck,
    UpdateDocumentForm,
)
from compliance_engine.services.audit import AuditLog
from compliance_engine.services.context import Actor, factory_today
from compliance_engine.services.numbering import REPORT_SERIES, next_serial


@dataclass(frozen=True)
class FormDefault:
    code: str
    title_ar: str
    title_en: str
    reference: str
    retention_years: int = 2


DEFAULT_FORMS: dict[str, FormDefault] = {
    "ccp_log": FormDefault(
        "F-HACCP-01",
        "سجل مراقبة نقاط التحكم الحرجة",
        "CCP Monitoring Log",
        "Codex CXC 1-1969 (2022): Principle 4 / Step 9; ISO 22000:2018 8.5.4",
    ),
    "corrective_actions": FormDefault(
        "F-HACCP-02",
        "سجل الإجراءات التصحيحية",
        "Corrective Action Register",
        "Codex CXC 1-1969 (2022): Principle 5 / Step 10; ISO 22000:2018 8.9",
    ),
    "sanitation_log": FormDefault(
        "F-PRP-01",
        "سجل التنظيف والتطهير",
        "Cleaning and Sanitation Log",
        "Codex CXC 1-1969 (2022): GHP 7.1 Cleaning and disinfection; ISO 22000:2018 8.2",
    ),
    "supplier_list": FormDefault(
        "F-SUP-01",
        "قائمة الموردين المعتمدين",
        "Approved Supplier List",
        "ISO 22000:2018 7.1.6; FSSC 22000 v6 2.5.x; BRCGS Food Safety Issue 9: 3.5.1",
        3,
    ),
    "training_matrix": FormDefault(
        "F-TRN-01",
        "مصفوفة التدريب والكفاءة",
        "Training and Competence Matrix",
        "ISO 22000:2018 7.2; Codex CXC 1-1969 (2022): GHP 10; BRCGS Food Safety Issue 9: 7.1",
        3,
    ),
    "training_log": FormDefault(
        "F-TRN-02",
        "سجل التدريب",
        "Training Records Log",
        "ISO 22000:2018 7.2 (d); BRCGS Food Safety Issue 9: 7.1.3",
        3,
    ),
    "trace": FormDefault(
        "F-TR-01",
        "تقرير التتبع والاستدعاء التجريبي",
        "Traceability and Mock Recall Report",
        "ISO 22000:2018 8.3 and 8.9.5; Codex CXC 1-1969 (2022): GHP 5.3",
    ),
}


def ensure_forms(session: Session, tenant_id: UUID) -> dict[str, DocumentForm]:
    """The tenant's forms, creating any that do not exist yet with the default wording."""
    forms = {f.key: f for f in session.scalars(select(DocumentForm))}
    missing = [key for key in DEFAULT_FORMS if key not in forms]
    if missing:
        today = factory_today()
        session.execute(
            insert(DocumentForm)
            .values(
                [
                    {
                        "id": uuid4(),
                        "tenant_id": tenant_id,
                        "key": key,
                        "code": DEFAULT_FORMS[key].code,
                        "title_ar": DEFAULT_FORMS[key].title_ar,
                        "title_en": DEFAULT_FORMS[key].title_en,
                        "revision": "00",
                        "effective_date": today,
                        "reference": DEFAULT_FORMS[key].reference,
                        "retention_years": DEFAULT_FORMS[key].retention_years,
                    }
                    for key in missing
                ]
            )
            .on_conflict_do_nothing()  # another request created them first
        )
        forms = {f.key: f for f in session.scalars(select(DocumentForm))}
    return forms


def sha256(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


class DocumentService:
    def __init__(self, session: Session, actor: Actor) -> None:
        self._session = session
        self._actor = actor

    # ----- controlled forms ------------------------------------------------------------

    def list_forms(self) -> list[DocumentFormView]:
        forms = ensure_forms(self._session, self._actor.tenant_id)
        return [DocumentFormView.model_validate(forms[key]) for key in DEFAULT_FORMS]

    def update_form(self, key: str, command: UpdateDocumentForm) -> DocumentFormView:
        forms = ensure_forms(self._session, self._actor.tenant_id)
        form = forms.get(key)
        if form is None:
            raise NotFoundError("Form", key)
        wanted = command.model_dump(exclude={"reason"}, exclude_none=True)
        changes = {
            field: {"from": _plain(getattr(form, field)), "to": _plain(value)}
            for field, value in wanted.items()
            if getattr(form, field) != value
        }
        if not changes:
            raise BusinessRuleError("This does not change anything")
        content_fields = changes.keys() - {"revision", "effective_date", "approved_by_name"}
        if content_fields and "revision" not in changes:
            raise BusinessRuleError(
                "Changing a controlled form needs a new revision number (document control)"
            )
        if "code" in changes and any(
            other.code == wanted["code"] for other in forms.values() if other is not form
        ):
            raise ConflictError(f"Another form already uses the code '{wanted['code']}'")
        for field in changes:
            setattr(form, field, wanted[field])
        form.updated_at = datetime.now(UTC)
        self._session.flush()
        AuditLog(self._session, self._actor.tenant_id, self._actor.user_id).record(
            "document_form.updated",
            "document_form",
            form.id,
            {"key": key, "changes": changes, "reason": command.reason},
        )
        return DocumentFormView.model_validate(form)

    # ----- issued reports --------------------------------------------------------------

    def reserve_report_number(self) -> str:
        return next_serial(self._session, self._actor.tenant_id, REPORT_SERIES)

    def register_report(
        self,
        serial: str,
        form: DocumentForm,
        title: str,
        lang: str,
        parameters: dict[str, Any],
        filename: str,
        content: bytes,
    ) -> IssuedReport:
        user = self._session.get(User, self._actor.user_id)
        issued = IssuedReport(
            tenant_id=self._actor.tenant_id,
            serial=serial,
            form_key=form.key,
            form_code=form.code,
            form_revision=form.revision,
            title=title,
            lang=lang,
            parameters={k: _plain(v) for k, v in parameters.items() if v not in (None, "")},
            filename=filename,
            sha256=sha256(content),
            issued_at=datetime.now(UTC),
            issued_by=self._actor.user_id,
            issued_by_name=user.full_name if user else "",
        )
        self._session.add(issued)
        self._session.flush()
        return issued

    def list_reports(self, limit: int) -> list[IssuedReportView]:
        rows = self._session.scalars(
            select(IssuedReport).order_by(IssuedReport.issued_at.desc()).limit(limit)
        )
        return [IssuedReportView.model_validate(r) for r in rows]

    def get_report(self, serial: str) -> IssuedReportView:
        report = self._session.scalar(select(IssuedReport).where(IssuedReport.serial == serial))
        if report is None:
            raise NotFoundError("Report", serial)
        return IssuedReportView.model_validate(report)

    def check_file(self, content: bytes) -> ReportCheck:
        report = self._session.scalar(
            select(IssuedReport).where(IssuedReport.sha256 == sha256(content))
        )
        return ReportCheck(
            genuine=report is not None,
            report=IssuedReportView.model_validate(report) if report else None,
        )


def _plain(value: Any) -> Any:
    if isinstance(value, date | datetime):
        return value.isoformat()
    if isinstance(value, UUID):
        return str(value)
    return value
