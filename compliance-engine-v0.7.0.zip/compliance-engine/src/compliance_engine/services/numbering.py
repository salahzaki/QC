"""Sequential record numbers: CCP-2026-000123, SAN-2026-000045, CA-2026-000007, ...
(SAP supplier approval decisions, SEV supplier evaluations, TRN training records.)

Each tenant has its own series per record type and year (in the factory time zone). Numbers
come from `record_counters` inside the inserting transaction: the counter row stays locked
until commit, so concurrent inserts queue up and a rolled-back insert leaves no gap.
"""

from datetime import datetime
from typing import Any
from uuid import UUID
from zoneinfo import ZoneInfo

from sqlalchemy import event, text
from sqlalchemy.orm import Session

from compliance_engine.core.config import get_settings
from compliance_engine.models import (
    CcpReading,
    CorrectiveAction,
    RecordAmendment,
    SanitationRecord,
    SupplierApproval,
    SupplierEvaluation,
    TrainingRecord,
)

SERIES: dict[type, str] = {
    CcpReading: "CCP",
    SanitationRecord: "SAN",
    RecordAmendment: "AMD",
    CorrectiveAction: "CA",
    SupplierApproval: "SAP",
    SupplierEvaluation: "SEV",
    TrainingRecord: "TRN",
}
REPORT_SERIES = "RPT"

_NEXT = text(
    """
    INSERT INTO record_counters (tenant_id, series, year, last_number)
    VALUES (:tenant_id, :series, :year, 1)
    ON CONFLICT (tenant_id, series, year)
      DO UPDATE SET last_number = record_counters.last_number + 1
    RETURNING last_number
    """
)


def format_serial(series: str, year: int, number: int) -> str:
    return f"{series}-{year}-{number:06d}"


def next_serial(session: Session, tenant_id: UUID, series: str) -> str:
    year = datetime.now(ZoneInfo(get_settings().factory_timezone)).year
    number = (
        session.connection()
        .execute(_NEXT, {"tenant_id": tenant_id, "series": series, "year": year})
        .scalar_one()
    )
    return format_serial(series, year, number)


@event.listens_for(Session, "before_flush")
def _assign_serials(session: Session, _context: Any, _instances: Any) -> None:
    for obj in session.new:
        series = SERIES.get(type(obj))
        if series is not None and obj.serial is None:
            obj.serial = next_serial(session, obj.tenant_id, series)
