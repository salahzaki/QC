"""Alert notifications by e-mail and WhatsApp.

When an alert is raised, one delivery per matching recipient is queued in the same
transaction. A background task (every `CE_NOTIFY_SECONDS`) sends what is queued, outside the
request, so a slow mail server never holds up recording a reading. Failed sends are retried
with growing waits and given up after `MAX_ATTEMPTS`.
"""

import logging
from datetime import UTC, datetime, timedelta
from uuid import UUID
from zoneinfo import ZoneInfo

from sqlalchemy import select
from sqlalchemy.orm import Session, sessionmaker

from compliance_engine.core.config import get_settings
from compliance_engine.core.errors import BusinessRuleError, NotFoundError
from compliance_engine.db.session import bind_tenant
from compliance_engine.models import Alert, NotificationDelivery, NotificationRecipient, Tenant
from compliance_engine.models.enums import (
    AlertKind,
    AlertSeverity,
    DeliveryStatus,
)
from compliance_engine.notifications import senders
from compliance_engine.notifications.senders import DeliveryError, Message
from compliance_engine.reports.pdf import Lang, format_moment
from compliance_engine.schemas.notifications import (
    CreateRecipient,
    DispatchResult,
    TestResult,
    UpdateRecipient,
    check_address,
)
from compliance_engine.services.audit import AuditLog
from compliance_engine.services.context import Actor
from compliance_engine.services.settings import effective_settings

log = logging.getLogger(__name__)

MAX_ATTEMPTS = 5
RETRY_AFTER = (timedelta(minutes=1), timedelta(minutes=5), timedelta(minutes=15))
RETRY_AFTER_LAST = timedelta(hours=1)

KIND_AR = {
    AlertKind.CCP_DEVIATION: "انحراف في نقطة تحكم حرجة",
    AlertKind.SANITATION_FAILURE: "عدم مطابقة في فحص النظافة والتعقيم",
    AlertKind.MISSED_CHECK: "تأخر فحص نقطة تحكم حرجة",
    AlertKind.SUPPLIER_DOCUMENT_EXPIRING: "قرب انتهاء مستند مورد",
    AlertKind.SUPPLIER_DOCUMENT_EXPIRED: "انتهاء مستند مورد",
    AlertKind.SUPPLIER_REVIEW_DUE: "موعد إعادة تقييم مورد",
    AlertKind.TRAINING_EXPIRING: "قرب انتهاء صلاحية تدريب",
    AlertKind.TRAINING_EXPIRED: "انتهاء صلاحية تدريب",
}
SEVERITY_AR = {AlertSeverity.CRITICAL: "حرج", AlertSeverity.MAJOR: "مهم"}


def queue_for_alert(session: Session, alert: Alert) -> int:
    """Queue the alert for every active recipient who wants this severity."""
    wanted = (
        [AlertSeverity.MAJOR, AlertSeverity.CRITICAL]
        if alert.severity == AlertSeverity.CRITICAL
        else [AlertSeverity.MAJOR]
    )
    recipients = session.scalars(
        select(NotificationRecipient).where(
            NotificationRecipient.is_active, NotificationRecipient.min_severity.in_(wanted)
        )
    ).all()
    now = datetime.now(UTC)
    for recipient in recipients:
        session.add(
            NotificationDelivery(
                tenant_id=alert.tenant_id,
                alert_id=alert.id,
                recipient_id=recipient.id,
                channel=recipient.channel,
                address=recipient.address,
                status=DeliveryStatus.PENDING,
                attempts=0,
                next_attempt_at=now,
            )
        )
    session.flush()
    return len(recipients)


def alert_message(alert: Alert, factory: str) -> Message:
    settings = get_settings()
    when = format_moment(alert.raised_at, ZoneInfo(settings.factory_timezone), Lang.AR)
    kind = KIND_AR[alert.kind]
    severity = SEVERITY_AR[alert.severity]
    lines = [
        f"تنبيه {severity}: {kind}",
        alert.message,
        f"المنشأة: {factory}",
        f"الوقت: {when}",
    ]
    if settings.public_url:
        lines.append(f"{settings.public_url.rstrip('/')}/app/#/alerts")
    return Message(
        subject=f"[{severity}] {kind} - {factory}",
        text="\n".join(lines) + "\n",
        short=f"{kind} ({factory}، {when}): {alert.message}",
    )


def _retry_delay(attempts: int) -> timedelta:
    return RETRY_AFTER[attempts - 1] if attempts <= len(RETRY_AFTER) else RETRY_AFTER_LAST


def dispatch_pending(session: Session, tenant_id: UUID, limit: int = 100) -> DispatchResult:
    """Send what is due for one tenant (the session must be bound to it)."""
    now = datetime.now(UTC)
    due = session.scalars(
        select(NotificationDelivery)
        .where(
            NotificationDelivery.status == DeliveryStatus.PENDING,
            NotificationDelivery.next_attempt_at <= now,
        )
        .order_by(NotificationDelivery.created_at)
        .limit(limit)
        .with_for_update(skip_locked=True)
    ).all()
    if not due:
        return DispatchResult(sent=0, retrying=0, failed=0)
    tenant = session.get(Tenant, tenant_id)
    factory = tenant.name if tenant else ""
    channel_senders = senders.get_senders(effective_settings(session, tenant_id))
    sent = retrying = failed = 0
    for delivery in due:
        alert = session.get(Alert, delivery.alert_id)
        assert alert is not None
        delivery.attempts += 1
        try:
            channel_senders[delivery.channel].send(delivery.address, alert_message(alert, factory))
        except DeliveryError as exc:
            delivery.last_error = str(exc)[:500]
            if delivery.attempts >= MAX_ATTEMPTS:
                delivery.status = DeliveryStatus.FAILED
                failed += 1
            else:
                delivery.next_attempt_at = now + _retry_delay(delivery.attempts)
                retrying += 1
        else:
            delivery.status = DeliveryStatus.SENT
            delivery.sent_at = datetime.now(UTC)
            delivery.last_error = None
            sent += 1
    session.flush()
    return DispatchResult(sent=sent, retrying=retrying, failed=failed)


def dispatch_all_tenants(session_factory: sessionmaker[Session]) -> DispatchResult:
    """Send what is due for every tenant, one transaction each."""
    with session_factory() as session:
        tenant_ids = list(session.scalars(select(Tenant.id)))
    total = DispatchResult(sent=0, retrying=0, failed=0)
    for tenant_id in tenant_ids:
        try:
            with session_factory.begin() as session:
                bind_tenant(session, tenant_id)
                result = dispatch_pending(session, tenant_id)
        except Exception:  # one tenant's failure must not stop the others
            log.exception("Sending notifications failed for tenant %s", tenant_id)
            continue
        total = DispatchResult(
            sent=total.sent + result.sent,
            retrying=total.retrying + result.retrying,
            failed=total.failed + result.failed,
        )
    return total


class NotificationService:
    def __init__(self, session: Session, actor: Actor) -> None:
        self._session = session
        self._actor = actor
        self._audit = AuditLog(session, actor.tenant_id, actor.user_id)

    def list_recipients(self) -> list[NotificationRecipient]:
        return list(
            self._session.scalars(
                select(NotificationRecipient).order_by(
                    NotificationRecipient.channel, NotificationRecipient.name
                )
            )
        )

    def _get(self, recipient_id: UUID) -> NotificationRecipient:
        recipient = self._session.get(NotificationRecipient, recipient_id)
        if recipient is None:
            raise NotFoundError("Recipient", recipient_id)
        return recipient

    def create_recipient(self, command: CreateRecipient) -> NotificationRecipient:
        recipient = NotificationRecipient(
            tenant_id=self._actor.tenant_id,
            name=command.name,
            channel=command.channel,
            address=command.address,
            min_severity=command.min_severity,
            is_active=True,
        )
        self._session.add(recipient)
        self._session.flush()
        self._audit.record(
            "notification_recipient.created",
            "notification_recipient",
            recipient.id,
            command.model_dump(),
        )
        return recipient

    def update_recipient(
        self, recipient_id: UUID, command: UpdateRecipient
    ) -> NotificationRecipient:
        recipient = self._get(recipient_id)
        values = command.model_dump(exclude_unset=True)
        if "address" in values:
            try:
                values["address"] = check_address(recipient.channel, values["address"])
            except ValueError as exc:
                raise BusinessRuleError(str(exc)) from exc
        changes = {
            field: {"from": getattr(recipient, field), "to": value}
            for field, value in values.items()
            if getattr(recipient, field) != value
        }
        if not changes:
            raise BusinessRuleError("This does not change anything")
        for field, change in changes.items():
            setattr(recipient, field, change["to"])
        self._session.flush()
        self._audit.record(
            "notification_recipient.updated", "notification_recipient", recipient.id, changes
        )
        return recipient

    def send_test(self, recipient_id: UUID) -> TestResult:
        recipient = self._get(recipient_id)
        tenant = self._session.get(Tenant, self._actor.tenant_id)
        factory = tenant.name if tenant else ""
        message = Message(
            subject=f"رسالة تجريبية - {factory}",
            text=(
                f"هذه رسالة تجريبية من نظام الجودة ({factory}). ستصلك التنبيهات على هذا العنوان.\n"
            ),
            short=f"رسالة تجريبية من نظام الجودة ({factory}). ستصلك التنبيهات على هذا الرقم.",
        )
        try:
            settings = effective_settings(self._session, self._actor.tenant_id)
            senders.get_senders(settings)[recipient.channel].send(recipient.address, message)
        except DeliveryError as exc:
            return TestResult(sent=False, error=str(exc))
        return TestResult(sent=True, error=None)

    def list_deliveries(
        self, status: DeliveryStatus | None, alert_id: UUID | None, limit: int
    ) -> list[NotificationDelivery]:
        query = (
            select(NotificationDelivery)
            .order_by(NotificationDelivery.created_at.desc())
            .limit(limit)
        )
        if status is not None:
            query = query.where(NotificationDelivery.status == status)
        if alert_id is not None:
            query = query.where(NotificationDelivery.alert_id == alert_id)
        return list(self._session.scalars(query))

    def dispatch_now(self) -> DispatchResult:
        return dispatch_pending(self._session, self._actor.tenant_id)

    def retry_failed(self) -> int:
        """Put failed deliveries back in the queue, e.g. after fixing the mail settings."""
        failed = self._session.scalars(
            select(NotificationDelivery).where(NotificationDelivery.status == DeliveryStatus.FAILED)
        ).all()
        now = datetime.now(UTC)
        for delivery in failed:
            delivery.status = DeliveryStatus.PENDING
            delivery.attempts = 0
            delivery.next_attempt_at = now
        self._session.flush()
        return len(failed)
