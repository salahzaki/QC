from uuid import UUID

from sqlalchemy import select
from sqlalchemy.orm import Session

from compliance_engine.core.errors import ConflictError, NotFoundError
from compliance_engine.models import Customer, Item, Supplier
from compliance_engine.schemas.master_data import CreateCustomer, CreateItem, CreateSupplier
from compliance_engine.services.audit import AuditLog
from compliance_engine.services.context import Actor
from compliance_engine.services.suppliers import SupplierService


def get_or_raise[T: (Item, Supplier, Customer)](
    session: Session, model: type[T], entity_id: UUID
) -> T:
    entity = session.get(model, entity_id)
    if entity is None:
        raise NotFoundError(model.__name__, entity_id)
    return entity


class MasterDataService:
    """Items, suppliers and customers. In production these usually sync from the ERP."""

    def __init__(self, session: Session, actor: Actor) -> None:
        self._session = session
        self._actor = actor
        self._audit = AuditLog(session, actor.tenant_id, actor.user_id)

    def create_item(self, command: CreateItem) -> Item:
        return self._create(Item, command.model_dump())

    def create_supplier(self, command: CreateSupplier) -> Supplier:
        return SupplierService(self._session, self._actor).create(command)

    def create_customer(self, command: CreateCustomer) -> Customer:
        return self._create(Customer, command.model_dump())

    def list_all[T: (Item, Supplier, Customer)](self, model: type[T]) -> list[T]:
        return list(self._session.scalars(select(model).order_by(model.code)))

    def _create[T: (Item, Supplier, Customer)](
        self, model: type[T], fields: dict[str, object]
    ) -> T:
        code = fields["code"]
        if self._session.scalar(select(model.id).where(model.code == code)):
            raise ConflictError(f"{model.__name__} with code '{code}' already exists")
        entity = model(tenant_id=self._actor.tenant_id, **fields)
        self._session.add(entity)
        self._session.flush()
        self._audit.record(f"{model.__tablename__}.created", model.__tablename__, entity.id, fields)
        return entity
