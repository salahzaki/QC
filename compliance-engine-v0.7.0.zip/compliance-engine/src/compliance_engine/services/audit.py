"""Tamper-evident audit log.

Each event stores sha256(prev_hash + canonical JSON of the event). Changing or removing any
past event breaks every hash after it, which `verify_chain` detects.
"""

import hashlib
import json
from collections.abc import Mapping
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from sqlalchemy import select, text
from sqlalchemy.orm import Session

from compliance_engine.models import AuditEvent
from compliance_engine.schemas.traceability import ChainVerification

GENESIS_HASH = "0" * 64


def _to_json_safe(payload: Mapping[str, Any]) -> dict[str, Any]:
    """Decimals, UUIDs and dates become strings so the hash survives a JSONB round trip."""
    result: dict[str, Any] = json.loads(json.dumps(payload, default=str))
    return result


def compute_event_hash(
    *,
    prev_hash: str,
    tenant_id: UUID,
    seq: int,
    occurred_at: datetime,
    actor_id: UUID | None,
    action: str,
    entity_type: str,
    entity_id: UUID,
    payload: Mapping[str, Any],
) -> str:
    body = json.dumps(
        {
            "tenant_id": str(tenant_id),
            "seq": seq,
            "occurred_at": occurred_at.astimezone(UTC).isoformat(),
            "actor_id": str(actor_id) if actor_id else None,
            "action": action,
            "entity_type": entity_type,
            "entity_id": str(entity_id),
            "payload": payload,
        },
        sort_keys=True,
        separators=(",", ":"),
    )
    return hashlib.sha256((prev_hash + body).encode()).hexdigest()


class AuditLog:
    def __init__(self, session: Session, tenant_id: UUID, actor_id: UUID | None) -> None:
        self._session = session
        self._tenant_id = tenant_id
        self._actor_id = actor_id

    def record(
        self, action: str, entity_type: str, entity_id: UUID, payload: Mapping[str, Any]
    ) -> AuditEvent:
        # Serialize writers per tenant so two requests never claim the same sequence number.
        self._session.execute(
            text("SELECT pg_advisory_xact_lock(hashtextextended(:key, 0))"),
            {"key": f"audit:{self._tenant_id}"},
        )
        last = self._session.scalars(
            select(AuditEvent).order_by(AuditEvent.seq.desc()).limit(1)
        ).first()
        seq = last.seq + 1 if last else 1
        prev_hash = last.hash if last else GENESIS_HASH
        occurred_at = datetime.now(UTC)
        safe_payload = _to_json_safe(payload)

        event = AuditEvent(
            tenant_id=self._tenant_id,
            seq=seq,
            occurred_at=occurred_at,
            actor_id=self._actor_id,
            action=action,
            entity_type=entity_type,
            entity_id=entity_id,
            payload=safe_payload,
            prev_hash=prev_hash,
            hash=compute_event_hash(
                prev_hash=prev_hash,
                tenant_id=self._tenant_id,
                seq=seq,
                occurred_at=occurred_at,
                actor_id=self._actor_id,
                action=action,
                entity_type=entity_type,
                entity_id=entity_id,
                payload=safe_payload,
            ),
        )
        self._session.add(event)
        self._session.flush()
        return event


def list_events(session: Session, limit: int, before_seq: int | None) -> list[AuditEvent]:
    query = select(AuditEvent).order_by(AuditEvent.seq.desc()).limit(limit)
    if before_seq is not None:
        query = query.where(AuditEvent.seq < before_seq)
    return list(session.scalars(query))


def verify_chain(session: Session) -> ChainVerification:
    expected_prev = GENESIS_HASH
    checked = 0
    events = session.scalars(select(AuditEvent).order_by(AuditEvent.seq)).yield_per(1000)
    for expected_seq, event in enumerate(events, start=1):
        recomputed = compute_event_hash(
            prev_hash=expected_prev,
            tenant_id=event.tenant_id,
            seq=event.seq,
            occurred_at=event.occurred_at,
            actor_id=event.actor_id,
            action=event.action,
            entity_type=event.entity_type,
            entity_id=event.entity_id,
            payload=event.payload,
        )
        intact = (
            event.seq == expected_seq
            and event.prev_hash == expected_prev
            and event.hash == recomputed
        )
        if not intact:
            return ChainVerification(
                valid=False, events_checked=checked, first_invalid_seq=event.seq
            )
        expected_prev = event.hash
        checked += 1
    return ChainVerification(valid=True, events_checked=checked)
