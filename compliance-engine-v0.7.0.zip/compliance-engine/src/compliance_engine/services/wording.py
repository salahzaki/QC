"""Wording of texts the system writes into records itself (deviation descriptions, alert
messages), in the factory's record language (CE_RECORD_LANGUAGE)."""

from datetime import date, timedelta
from decimal import Decimal

from compliance_engine.core.config import get_settings
from compliance_engine.models.enums import SanitationActivity

ACTIVITY_AR = {
    SanitationActivity.PRE_OP_INSPECTION: "فحص ما قبل التشغيل",
    SanitationActivity.CLEANING: "تنظيف",
    SanitationActivity.SANITIZING: "تعقيم",
    SanitationActivity.DEEP_CLEAN: "تنظيف عميق",
    SanitationActivity.AFTER_USE: "تنظيف بعد الاستخدام",
}


def arabic() -> bool:
    return get_settings().record_language == "ar"


def num(value: Decimal | None) -> str:
    return "" if value is None else format(value.normalize(), "f")


def limits_text(low: Decimal | None, high: Decimal | None, unit: str) -> str:
    if arabic():
        if low is not None and high is not None:
            return f"من {num(low)} إلى {num(high)} {unit}"
        if low is not None:
            return f"حد أدنى {num(low)} {unit}"
        return f"حد أقصى {num(high)} {unit}"
    if low is not None and high is not None:
        return f"{num(low)} to {num(high)} {unit}"
    if low is not None:
        return f"min {num(low)} {unit}"
    return f"max {num(high)} {unit}"


def ccp_deviation(
    code: str, name: str, value: Decimal, unit: str, low: Decimal | None, high: Decimal | None
) -> str:
    limits = limits_text(low, high, unit)
    if arabic():
        return f"{code} ({name}): القيمة {num(value)} {unit} خارج الحدود الحرجة ({limits})"
    return f"{code} ({name}): {num(value)} {unit} is outside the critical limits ({limits})"


def sanitation_failure(activity: SanitationActivity, area: str) -> str:
    if arabic():
        return f"عدم مطابقة في فحص النظافة: {ACTIVITY_AR[activity]} - {area}"
    return f"Sanitation check failed: {activity.replace('_', ' ')} of {area}"


def minutes(delta: timedelta) -> str:
    count = int(delta.total_seconds() // 60)
    if arabic():
        if count == 1:
            return "دقيقة واحدة"
        if count == 2:
            return "دقيقتين"
        return f"{count} {'دقائق' if 3 <= count <= 10 else 'دقيقة'}"
    return "1 minute" if count == 1 else f"{count} minutes"


def missed_check(
    code: str, name: str, elapsed: timedelta, after_reading: bool, interval: timedelta
) -> str:
    if arabic():
        since = "آخر قراءة" if after_reading else "إعداد نقطة التحكم"
        return (
            f"{code} ({name}): لم تُسجَّل أي قراءة منذ {minutes(elapsed)} من {since}، "
            f"والمطلوب قراءة كل {minutes(interval)}"
        )
    since = "the last reading" if after_reading else "the control point was set up"
    return (
        f"{code} ({name}): no reading for {minutes(elapsed)} since {since}; "
        f"checks are due every {minutes(interval)}"
    )


def day(value: date) -> str:
    return value.strftime("%Y/%m/%d" if arabic() else "%Y-%m-%d")


def days(count: int) -> str:
    if arabic():
        if count == 1:
            return "يوم واحد"
        if count == 2:
            return "يومين"
        return f"{count} {'أيام' if 3 <= count <= 10 else 'يومًا'}"
    return "1 day" if count == 1 else f"{count} days"


def supplier_document(
    supplier_code: str, supplier_name: str, title: str, expires_on: date, today: date
) -> str:
    left = (expires_on - today).days
    if arabic():
        if left < 0:
            return (
                f"المورد {supplier_code} ({supplier_name}): انتهت صلاحية «{title}» "
                f"في {day(expires_on)}"
            )
        return (
            f"المورد {supplier_code} ({supplier_name}): تنتهي صلاحية «{title}» "
            f"في {day(expires_on)} (بعد {days(left)})"
        )
    if left < 0:
        return f"Supplier {supplier_code} ({supplier_name}): '{title}' expired on {day(expires_on)}"
    return (
        f"Supplier {supplier_code} ({supplier_name}): '{title}' expires on {day(expires_on)} "
        f"(in {days(left)})"
    )


def supplier_review(supplier_code: str, supplier_name: str, review: date) -> str:
    if arabic():
        return (
            f"المورد {supplier_code} ({supplier_name}): حان موعد إعادة تقييم الاعتماد "
            f"({day(review)})"
        )
    return f"Supplier {supplier_code} ({supplier_name}): approval review was due on {day(review)}"


def training(
    person: str, course_code: str, course_title: str, expires_on: date, today: date
) -> str:
    left = (expires_on - today).days
    if arabic():
        if left < 0:
            return (
                f"{person}: انتهت صلاحية تدريب {course_code} ({course_title}) في {day(expires_on)}"
            )
        return (
            f"{person}: تنتهي صلاحية تدريب {course_code} ({course_title}) "
            f"في {day(expires_on)} (بعد {days(left)})"
        )
    if left < 0:
        return f"{person}: training {course_code} ({course_title}) expired on {day(expires_on)}"
    return (
        f"{person}: training {course_code} ({course_title}) expires on {day(expires_on)} "
        f"(in {days(left)})"
    )
