from dataclasses import dataclass
from datetime import date, datetime
from uuid import UUID
from zoneinfo import ZoneInfo

from compliance_engine.core.config import get_settings
from compliance_engine.core.permissions import Role


@dataclass(frozen=True, slots=True)
class Actor:
    """The authenticated user on whose behalf a service acts."""

    user_id: UUID
    tenant_id: UUID
    role: Role


def factory_today() -> date:
    """Today's date in the factory's time zone (expiry checks depend on it)."""
    return datetime.now(ZoneInfo(get_settings().factory_timezone)).date()
