"""Settings a factory manages from the app: alert channels (mail server, WhatsApp number)
and quality rules (competence gate, expiry warnings).

Mail or WhatsApp set here replace the server's CE_SMTP_* / CE_WHATSAPP_* values for this
factory; when cleared, the server values apply again.
"""

from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from pydantic import SecretStr
from sqlalchemy.orm import Session

from compliance_engine.core import secrets
from compliance_engine.core.config import Settings, get_settings
from compliance_engine.core.errors import BusinessRuleError
from compliance_engine.models import TenantSettings, User
from compliance_engine.models.enums import NotificationChannel, SmtpSecurity
from compliance_engine.notifications.senders import configured_channels
from compliance_engine.schemas.settings import (
    ChannelState,
    NotificationSettingsView,
    QualitySettingsView,
    UpdateEmailSettings,
    UpdateQualitySettings,
    UpdateWhatsAppSettings,
)
from compliance_engine.services.audit import AuditLog
from compliance_engine.services.context import Actor

DEFAULT_WARNING_DAYS = 30


def tenant_settings(session: Session, tenant_id: UUID) -> TenantSettings | None:
    return session.get(TenantSettings, tenant_id)


def _secret(token: str | None) -> SecretStr | None:
    plain = secrets.decrypt(token) if token else None
    return SecretStr(plain) if plain else None


def _uses_app_email(row: TenantSettings | None) -> bool:
    return bool(row and row.smtp_host)


def _uses_app_whatsapp(row: TenantSettings | None) -> bool:
    return bool(row and row.whatsapp_phone_number_id)


def effective_settings(session: Session, tenant_id: UUID) -> Settings:
    """The server settings with this factory's own mail and WhatsApp settings applied."""
    base = get_settings()
    row = tenant_settings(session, tenant_id)
    update: dict[str, Any] = {}
    if row is not None and _uses_app_email(row):
        update |= {
            "smtp_host": row.smtp_host,
            "smtp_port": row.smtp_port or 587,
            "smtp_security": (row.smtp_security or SmtpSecurity.STARTTLS).value,
            "smtp_username": row.smtp_username,
            "smtp_password": _secret(row.smtp_password_enc),
            "smtp_from": row.smtp_from,
        }
    if row is not None and _uses_app_whatsapp(row):
        update |= {
            "whatsapp_phone_number_id": row.whatsapp_phone_number_id,
            "whatsapp_token": _secret(row.whatsapp_token_enc),
            "whatsapp_template": row.whatsapp_template,
            "whatsapp_template_language": row.whatsapp_template_language or "ar",
        }
    return base.model_copy(update=update) if update else base


def warning_days(session: Session, tenant_id: UUID) -> int:
    row = tenant_settings(session, tenant_id)
    return row.expiry_warning_days if row else DEFAULT_WARNING_DAYS


def training_enforced(session: Session, tenant_id: UUID) -> bool:
    row = tenant_settings(session, tenant_id)
    return bool(row and row.enforce_training)


class SettingsService:
    def __init__(self, session: Session, actor: Actor) -> None:
        self._session = session
        self._actor = actor
        self._audit = AuditLog(session, actor.tenant_id, actor.user_id)

    def _row(self) -> TenantSettings:
        row = tenant_settings(self._session, self._actor.tenant_id)
        if row is None:
            row = TenantSettings(
                tenant_id=self._actor.tenant_id,
                enforce_training=False,
                expiry_warning_days=DEFAULT_WARNING_DAYS,
            )
            self._session.add(row)
            self._session.flush()
        return row

    def _touch(self, row: TenantSettings) -> None:
        row.updated_at = datetime.now(UTC)
        row.updated_by = self._actor.user_id
        self._session.flush()

    # ----- notification channels -------------------------------------------------------

    def notifications(self) -> NotificationSettingsView:
        row = tenant_settings(self._session, self._actor.tenant_id)
        server = configured_channels(get_settings())
        effective = configured_channels(effective_settings(self._session, self._actor.tenant_id))

        def state(channel: NotificationChannel, in_app: bool) -> ChannelState:
            if in_app:
                return ChannelState(configured=effective[channel], source="app")
            return ChannelState(
                configured=effective[channel], source="server" if server[channel] else None
            )

        unreadable = bool(
            row
            and any(
                token and secrets.decrypt(token) is None
                for token in (row.smtp_password_enc, row.whatsapp_token_enc)
            )
        )
        updated_by = self._session.get(User, row.updated_by) if row and row.updated_by else None
        return NotificationSettingsView(
            email=state(NotificationChannel.EMAIL, _uses_app_email(row)),
            whatsapp=state(NotificationChannel.WHATSAPP, _uses_app_whatsapp(row)),
            smtp_host=row.smtp_host if row else None,
            smtp_port=row.smtp_port if row else None,
            smtp_security=row.smtp_security if row else None,
            smtp_username=row.smtp_username if row else None,
            smtp_from=row.smtp_from if row else None,
            smtp_password_set=bool(row and row.smtp_password_enc),
            whatsapp_phone_number_id=row.whatsapp_phone_number_id if row else None,
            whatsapp_template=row.whatsapp_template if row else None,
            whatsapp_template_language=row.whatsapp_template_language if row else None,
            whatsapp_token_set=bool(row and row.whatsapp_token_enc),
            secrets_unreadable=unreadable,
            updated_at=row.updated_at if row else None,
            updated_by_name=updated_by.full_name if updated_by else None,
        )

    def update_email(self, command: UpdateEmailSettings) -> NotificationSettingsView:
        row = self._row()
        if command.smtp_host is None:
            values: dict[str, Any] = dict.fromkeys(
                ("smtp_host", "smtp_port", "smtp_security", "smtp_username", "smtp_from")
            )
            password: str | None = None
            clear_password = True
        else:
            values = {
                "smtp_host": command.smtp_host,
                "smtp_port": command.smtp_port,
                "smtp_security": command.smtp_security,
                "smtp_username": command.smtp_username or None,
                "smtp_from": str(command.smtp_from).lower() if command.smtp_from else None,
            }
            password = command.smtp_password.get_secret_value() if command.smtp_password else None
            clear_password = False
            if command.smtp_username and not (password or row.smtp_password_enc):
                raise BusinessRuleError("Enter the password of the mail account")
        changes = {
            field: {"from": _plain(getattr(row, field)), "to": _plain(value)}
            for field, value in values.items()
            if getattr(row, field) != value
        }
        if password:
            row.smtp_password_enc = secrets.encrypt(password)
            changes["smtp_password"] = {"from": "***", "to": "*** (changed)"}
        elif clear_password and row.smtp_password_enc:
            row.smtp_password_enc = None
            changes["smtp_password"] = {"from": "***", "to": None}
        if not changes:
            raise BusinessRuleError("This does not change anything")
        for field, value in values.items():
            setattr(row, field, value)
        self._touch(row)
        self._audit.record(
            "settings.email_updated", "tenant_settings", self._actor.tenant_id, changes
        )
        return self.notifications()

    def update_whatsapp(self, command: UpdateWhatsAppSettings) -> NotificationSettingsView:
        row = self._row()
        if command.phone_number_id is None:
            values: dict[str, Any] = dict.fromkeys(
                ("whatsapp_phone_number_id", "whatsapp_template", "whatsapp_template_language")
            )
            token: str | None = None
            clear_token = True
        else:
            values = {
                "whatsapp_phone_number_id": command.phone_number_id,
                "whatsapp_template": command.template or None,
                "whatsapp_template_language": command.template_language,
            }
            token = command.token.get_secret_value() if command.token else None
            clear_token = False
            if not (token or row.whatsapp_token_enc):
                raise BusinessRuleError("Enter the WhatsApp access token")
        changes = {
            field: {"from": getattr(row, field), "to": value}
            for field, value in values.items()
            if getattr(row, field) != value
        }
        if token:
            row.whatsapp_token_enc = secrets.encrypt(token)
            changes["whatsapp_token"] = {"from": "***", "to": "*** (changed)"}
        elif clear_token and row.whatsapp_token_enc:
            row.whatsapp_token_enc = None
            changes["whatsapp_token"] = {"from": "***", "to": None}
        if not changes:
            raise BusinessRuleError("This does not change anything")
        for field, value in values.items():
            setattr(row, field, value)
        self._touch(row)
        self._audit.record(
            "settings.whatsapp_updated", "tenant_settings", self._actor.tenant_id, changes
        )
        return self.notifications()

    # ----- quality rules ---------------------------------------------------------------

    def quality(self) -> QualitySettingsView:
        row = tenant_settings(self._session, self._actor.tenant_id)
        return QualitySettingsView(
            enforce_training=bool(row and row.enforce_training),
            expiry_warning_days=row.expiry_warning_days if row else DEFAULT_WARNING_DAYS,
        )

    def update_quality(self, command: UpdateQualitySettings) -> QualitySettingsView:
        row = self._row()
        changes = {
            field: {"from": getattr(row, field), "to": value}
            for field, value in command.model_dump(exclude_none=True).items()
            if getattr(row, field) != value
        }
        if not changes:
            raise BusinessRuleError("This does not change anything")
        for field, change in changes.items():
            setattr(row, field, change["to"])
        self._touch(row)
        self._audit.record(
            "settings.quality_updated", "tenant_settings", self._actor.tenant_id, changes
        )
        return self.quality()


def _plain(value: object) -> object:
    return value.value if isinstance(value, SmtpSecurity) else value
