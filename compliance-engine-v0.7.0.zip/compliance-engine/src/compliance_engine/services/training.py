"""Training records and competence (ISO 22000:2018 7.2, FSSC 22000, BRCGS 7.1).

Courses list who must hold them (by role) and which CCPs they qualify a person to record.
Each attendance is a numbered, signed record that is never edited; its expiry is fixed when
recorded. The training matrix shows every active person against the courses their role
requires. With the competence gate on (settings), a CCP reading from someone without a
valid pass on the courses linked to that CCP is refused.
"""

from dataclasses import dataclass
from datetime import UTC, date, datetime
from typing import Any
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.orm import Session

from compliance_engine.core.errors import BusinessRuleError, ConflictError, NotFoundError
from compliance_engine.models import ControlPoint, TrainingCourse, TrainingRecord, User
from compliance_engine.models.enums import SignatureMeaning, TrainingResult
from compliance_engine.schemas.training import (
    Competence,
    CourseView,
    CreateCourse,
    MatrixCell,
    MatrixRow,
    RecordTraining,
    TrainingMatrix,
    TrainingRecordView,
    UpdateCourse,
)
from compliance_engine.services.audit import AuditLog
from compliance_engine.services.context import Actor, factory_today
from compliance_engine.services.settings import training_enforced, warning_days
from compliance_engine.services.signatures import SignatureService
from compliance_engine.services.suppliers import add_months

QUALIFYING = (TrainingResult.PASSED, TrainingResult.ATTENDED)


def record_state(record: TrainingRecord, today: date, warn_days: int) -> str:
    if record.result not in QUALIFYING:
        return "failed"
    if record.expires_on is None:
        return "valid"
    days_left = (record.expires_on - today).days
    if days_left < 0:
        return "expired"
    return "expiring" if days_left <= warn_days else "valid"


@dataclass(frozen=True)
class Standing:
    """Where one person stands on one course: their latest qualifying record, if any."""

    status: str  # valid, expiring, expired, failed, missing
    record: TrainingRecord | None


def standings(
    session: Session, tenant_id: UUID, user_ids: list[UUID] | None = None
) -> dict[tuple[UUID, UUID], Standing]:
    """(user, course) -> standing, from the latest qualifying record (a later failed attempt
    does not cancel a valid pass; a failure with no pass shows as "failed")."""
    query = select(TrainingRecord).order_by(TrainingRecord.trained_on, TrainingRecord.recorded_at)
    if user_ids is not None:
        query = query.where(TrainingRecord.user_id.in_(user_ids))
    today = factory_today()
    warn = warning_days(session, tenant_id)
    latest_pass: dict[tuple[UUID, UUID], TrainingRecord] = {}
    failed: dict[tuple[UUID, UUID], TrainingRecord] = {}
    for record in session.scalars(query):
        key = (record.user_id, record.course_id)
        if record.result in QUALIFYING:
            latest_pass[key] = record
        else:
            failed[key] = record
    result = {key: Standing(record_state(r, today, warn), r) for key, r in latest_pass.items()}
    for key, record in failed.items():
        result.setdefault(key, Standing("failed", record))
    return result


def competence(
    session: Session, tenant_id: UUID, user_id: UUID, control_point: ControlPoint
) -> Competence:
    courses = [
        c
        for c in session.scalars(select(TrainingCourse).where(TrainingCourse.is_active))
        if str(control_point.id) in c.control_point_ids
    ]
    mine = standings(session, tenant_id, [user_id])
    missing = [
        f"{c.code} {c.title}"
        for c in courses
        if mine.get((user_id, c.id), Standing("missing", None)).status not in ("valid", "expiring")
    ]
    return Competence(control_point_id=control_point.id, qualified=not missing, missing=missing)


def check_competence(session: Session, actor: Actor, control_point: ControlPoint) -> None:
    """Refuse the reading when the competence gate is on and the person is not qualified."""
    if not training_enforced(session, actor.tenant_id):
        return
    result = competence(session, actor.tenant_id, actor.user_id, control_point)
    if not result.qualified:
        raise BusinessRuleError(
            f"You are not qualified to record {control_point.code}: valid training is needed "
            f"in {'; '.join(result.missing)}"
        )


class TrainingService:
    def __init__(self, session: Session, actor: Actor) -> None:
        self._session = session
        self._actor = actor
        self._audit = AuditLog(session, actor.tenant_id, actor.user_id)
        self._signatures = SignatureService(session, actor)

    # ----- courses ---------------------------------------------------------------------

    def list_courses(self, include_inactive: bool = True) -> list[CourseView]:
        query = select(TrainingCourse).order_by(TrainingCourse.code)
        if not include_inactive:
            query = query.where(TrainingCourse.is_active)
        return [CourseView.model_validate(c) for c in self._session.scalars(query)]

    def create_course(self, command: CreateCourse) -> CourseView:
        if self._session.scalar(
            select(TrainingCourse.id).where(TrainingCourse.code == command.code)
        ):
            raise ConflictError(f"Course with code '{command.code}' already exists")
        self._check_control_points(command.control_point_ids)
        fields = command.model_dump(mode="json")
        course = TrainingCourse(tenant_id=self._actor.tenant_id, is_active=True, **fields)
        self._session.add(course)
        self._session.flush()
        self._audit.record("training_course.created", "training_course", course.id, fields)
        return CourseView.model_validate(course)

    def update_course(self, course_id: UUID, command: UpdateCourse) -> CourseView:
        course = self._course(course_id)
        if command.control_point_ids is not None:
            self._check_control_points(command.control_point_ids)
        wanted = command.model_dump(mode="json", exclude_unset=True)
        changes: dict[str, Any] = {
            field: {"from": getattr(course, field), "to": value}
            for field, value in wanted.items()
            if getattr(course, field) != value
        }
        if not changes:
            raise BusinessRuleError("This does not change anything")
        for field, change in changes.items():
            setattr(course, field, change["to"])
        course.updated_at = datetime.now(UTC)
        self._session.flush()
        self._audit.record(
            "training_course.updated",
            "training_course",
            course.id,
            {"code": course.code, **changes},
        )
        return CourseView.model_validate(course)

    # ----- records ---------------------------------------------------------------------

    def record(self, command: RecordTraining) -> list[TrainingRecordView]:
        course = self._course(command.course_id)
        if not course.is_active:
            raise BusinessRuleError(f"Course '{course.code}' is no longer active")
        if command.trained_on > factory_today():
            raise BusinessRuleError("Training cannot be dated in the future")
        users = {
            u.id: u
            for u in self._session.scalars(
                select(User).where(User.id.in_([a.user_id for a in command.attendees]))
            )
        }
        for attendee in command.attendees:
            if attendee.user_id not in users:
                raise NotFoundError("User", attendee.user_id)
        records = []
        now = datetime.now(UTC)
        for attendee in command.attendees:
            expires = (
                add_months(command.trained_on, course.validity_months)
                if course.validity_months and attendee.result in QUALIFYING
                else None
            )
            record = TrainingRecord(
                tenant_id=self._actor.tenant_id,
                user_id=attendee.user_id,
                course_id=course.id,
                trained_on=command.trained_on,
                expires_on=expires,
                trainer=command.trainer,
                method=command.method,
                duration_hours=command.duration_hours,
                result=attendee.result,
                score=attendee.score,
                certificate_ref=command.certificate_ref,
                notes=command.notes,
                recorded_at=now,
                recorded_by=self._actor.user_id,
            )
            self._session.add(record)
            self._session.flush()
            self._audit.record(
                "training.recorded",
                "training_record",
                record.id,
                {
                    "user": users[attendee.user_id].email,
                    "course": course.code,
                    "trained_on": command.trained_on,
                    "result": attendee.result,
                    "score": attendee.score,
                    "expires_on": expires,
                    "trainer": command.trainer,
                },
            )
            self._signatures.sign(
                record, SignatureMeaning.PERFORMED, command.password.get_secret_value()
            )
            records.append(record)
        return self._views(records)

    def list_records(
        self, user_id: UUID | None, course_id: UUID | None, limit: int
    ) -> list[TrainingRecordView]:
        query = (
            select(TrainingRecord)
            .order_by(TrainingRecord.trained_on.desc(), TrainingRecord.recorded_at.desc())
            .limit(limit)
        )
        if user_id is not None:
            query = query.where(TrainingRecord.user_id == user_id)
        if course_id is not None:
            query = query.where(TrainingRecord.course_id == course_id)
        return self._views(list(self._session.scalars(query)))

    def matrix(self) -> TrainingMatrix:
        courses = [
            c
            for c in self._session.scalars(
                select(TrainingCourse).where(TrainingCourse.is_active).order_by(TrainingCourse.code)
            )
        ]
        users = list(
            self._session.scalars(select(User).where(User.is_active).order_by(User.full_name))
        )
        known = standings(self._session, self._actor.tenant_id)
        rows = []
        totals = {"required": 0, "compliant": 0, "expiring": 0, "expired": 0, "missing": 0}
        for user in users:
            cells = []
            for course in courses:
                required = user.role.value in course.required_roles
                standing = known.get((user.id, course.id), Standing("missing", None))
                status = standing.status
                if not required and status == "missing":
                    status = "not_required"
                record = standing.record
                cells.append(
                    MatrixCell(
                        course_id=course.id,
                        required=required,
                        status=status,
                        trained_on=record.trained_on if record else None,
                        expires_on=record.expires_on if record else None,
                        record_id=record.id if record else None,
                    )
                )
                if required:
                    totals["required"] += 1
                    if status in ("valid", "expiring"):
                        totals["compliant"] += 1
                    if status in ("expiring", "expired"):
                        totals[status] += 1
                    if status in ("missing", "failed"):
                        totals["missing"] += 1
            rows.append(
                MatrixRow(
                    user_id=user.id,
                    full_name=user.full_name,
                    role=user.role,
                    cells=cells,
                    required=sum(c.required for c in cells),
                    compliant=sum(c.required and c.status in ("valid", "expiring") for c in cells),
                )
            )
        return TrainingMatrix(
            courses=[CourseView.model_validate(c) for c in courses],
            rows=rows,
            required=totals["required"],
            compliant=totals["compliant"],
            compliance_pct=round(100 * totals["compliant"] / totals["required"], 1)
            if totals["required"]
            else None,
            expiring=totals["expiring"],
            expired=totals["expired"],
            missing=totals["missing"],
        )

    def my_competence(self) -> list[Competence]:
        points = self._session.scalars(select(ControlPoint).order_by(ControlPoint.code))
        return [
            competence(self._session, self._actor.tenant_id, self._actor.user_id, cp)
            for cp in points
        ]

    # ----- helpers ---------------------------------------------------------------------

    def _views(self, records: list[TrainingRecord]) -> list[TrainingRecordView]:
        if not records:
            return []
        today, warn = factory_today(), warning_days(self._session, self._actor.tenant_id)
        rows = self._session.execute(
            select(User.id, User.full_name).where(User.id.in_({r.user_id for r in records}))
        )
        users = {row.id: row.full_name for row in rows}
        courses = {
            c.id: c
            for c in self._session.scalars(
                select(TrainingCourse).where(TrainingCourse.id.in_({r.course_id for r in records}))
            )
        }
        signatures = self._signatures.for_records(TrainingRecord, [r.id for r in records])
        views = []
        for record in records:
            course = courses[record.course_id]
            views.append(
                TrainingRecordView(
                    id=record.id,
                    serial=record.serial,
                    user_id=record.user_id,
                    user_name=users.get(record.user_id, ""),
                    course_id=course.id,
                    course_code=course.code,
                    course_title=course.title,
                    trained_on=record.trained_on,
                    expires_on=record.expires_on,
                    trainer=record.trainer,
                    method=record.method,
                    duration_hours=record.duration_hours,
                    result=record.result,
                    score=record.score,
                    certificate_ref=record.certificate_ref,
                    notes=record.notes,
                    recorded_at=record.recorded_at,
                    recorded_by=record.recorded_by,
                    state=record_state(record, today, warn),
                    signatures=self._signatures.views(record, signatures[record.id]),
                )
            )
        return views

    def _course(self, course_id: UUID) -> TrainingCourse:
        course = self._session.get(TrainingCourse, course_id)
        if course is None:
            raise NotFoundError("Course", course_id)
        return course

    def _check_control_points(self, ids: list[UUID]) -> None:
        if not ids:
            return
        found = set(self._session.scalars(select(ControlPoint.id).where(ControlPoint.id.in_(ids))))
        for control_point_id in ids:
            if control_point_id not in found:
                raise NotFoundError("Control point", control_point_id)
