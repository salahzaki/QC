"""Supplier approval: signed decisions, certificates and licences, periodic evaluations.

Goods are received only from suppliers that are approved or conditionally approved and whose
required documents have not expired (see `receiving_block`, used by lot receipt). Every
decision and evaluation is numbered, signed with the person's password and never edited, so
the history is the approved-supplier evidence asked for by ISO 22000:2018 7.1.6, FSSC 22000
and BRCGS 3.5.
"""

import calendar
import hashlib
from datetime import UTC, date, datetime
from decimal import ROUND_HALF_UP, Decimal
from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from compliance_engine.core.config import get_settings
from compliance_engine.core.errors import BusinessRuleError, ConflictError, NotFoundError
from compliance_engine.models import (
    Lot,
    Supplier,
    SupplierApproval,
    SupplierDocument,
    SupplierEvaluation,
    User,
)
from compliance_engine.models.enums import (
    RECEIVING_ALLOWED,
    LotStatus,
    RiskLevel,
    SignatureMeaning,
    SupplierStatus,
)
from compliance_engine.schemas.master_data import CreateSupplier, SupplierView, UpdateSupplier
from compliance_engine.schemas.suppliers import (
    AddSupplierDocument,
    ApprovalView,
    DecideApproval,
    EvaluateSupplier,
    EvaluationView,
    SupplierDetail,
    SupplierDocumentView,
    SupplierStats,
    SupplierSummary,
    WithdrawDocument,
)
from compliance_engine.services.audit import AuditLog
from compliance_engine.services.context import Actor, factory_today
from compliance_engine.services.settings import warning_days
from compliance_engine.services.signatures import SignatureService

# Months until the next approval review when none is given, by risk.
REVIEW_MONTHS = {RiskLevel.LOW: 24, RiskLevel.MEDIUM: 12, RiskLevel.HIGH: 6}
# Evaluation weights (percent) and the total that recommends each status.
WEIGHTS = {
    "quality_score": 40,
    "delivery_score": 25,
    "documentation_score": 20,
    "service_score": 15,
}
APPROVE_FROM = Decimal(80)
DOCUMENT_FIELDS = [f for f in SupplierDocumentView.model_fields if f not in ("state", "days_left")]
CONDITIONAL_FROM = Decimal(60)


def add_months(day: date, months: int) -> date:
    month_index = day.month - 1 + months
    year, month = day.year + month_index // 12, month_index % 12 + 1
    return date(year, month, min(day.day, calendar.monthrange(year, month)[1]))


def document_state(
    document: SupplierDocument, today: date, warn_days: int
) -> tuple[str, int | None]:
    if document.withdrawn_at is not None:
        return "withdrawn", None
    if document.expires_on is None:
        return "valid", None
    days_left = (document.expires_on - today).days
    if days_left < 0:
        return "expired", days_left
    if days_left <= warn_days:
        return "expiring", days_left
    return "valid", days_left


def expired_required(session: Session, supplier_id: UUID, today: date) -> list[SupplierDocument]:
    return list(
        session.scalars(
            select(SupplierDocument)
            .where(
                SupplierDocument.supplier_id == supplier_id,
                SupplierDocument.is_required,
                SupplierDocument.withdrawn_at.is_(None),
                SupplierDocument.expires_on < today,
            )
            .order_by(SupplierDocument.expires_on)
        )
    )


def receiving_block(session: Session, supplier: Supplier) -> str | None:
    """Why goods cannot be received from this supplier now, or None if they can."""
    if supplier.approval_status not in RECEIVING_ALLOWED:
        return f"Supplier '{supplier.code}' is not approved (status: {supplier.approval_status})"
    expired = expired_required(session, supplier.id, factory_today())
    if expired:
        document = expired[0]
        return (
            f"Supplier '{supplier.code}' has an expired required document: "
            f"{document.title} (expired {document.expires_on})"
        )
    return None


def recommendation_for(total: Decimal) -> SupplierStatus:
    if total >= APPROVE_FROM:
        return SupplierStatus.APPROVED
    if total >= CONDITIONAL_FROM:
        return SupplierStatus.CONDITIONAL
    return SupplierStatus.SUSPENDED


class SupplierService:
    def __init__(self, session: Session, actor: Actor) -> None:
        self._session = session
        self._actor = actor
        self._audit = AuditLog(session, actor.tenant_id, actor.user_id)
        self._signatures = SignatureService(session, actor)

    # ----- suppliers -------------------------------------------------------------------

    def create(self, command: CreateSupplier) -> Supplier:
        if self._session.scalar(select(Supplier.id).where(Supplier.code == command.code)):
            raise ConflictError(f"Supplier with code '{command.code}' already exists")
        fields = command.model_dump()
        status = SupplierStatus.APPROVED if command.is_approved else SupplierStatus.PENDING
        supplier = Supplier(tenant_id=self._actor.tenant_id, approval_status=status, **fields)
        self._session.add(supplier)
        self._session.flush()
        self._audit.record(
            "suppliers.created", "suppliers", supplier.id, {**fields, "approval_status": status}
        )
        return supplier

    def update(self, supplier_id: UUID, command: UpdateSupplier) -> Supplier:
        supplier = self._get(supplier_id)
        changes = {
            field: {"from": getattr(supplier, field), "to": value}
            for field, value in command.model_dump(exclude_unset=True).items()
            if getattr(supplier, field) != value
        }
        if not changes:
            raise BusinessRuleError("This does not change anything")
        for field, change in changes.items():
            setattr(supplier, field, change["to"])
        self._session.flush()
        self._audit.record(
            "supplier.updated", "suppliers", supplier.id, {"code": supplier.code, **changes}
        )
        return supplier

    def overview(self) -> list[SupplierSummary]:
        suppliers = list(self._session.scalars(select(Supplier).order_by(Supplier.code)))
        documents = self._documents([s.id for s in suppliers])
        lots = self._lot_stats([s.id for s in suppliers])
        scores = self._last_scores([s.id for s in suppliers])
        return [
            self._summary(s, documents.get(s.id, []), lots.get(s.id), scores.get(s.id))
            for s in suppliers
        ]

    def detail(self, supplier_id: UUID) -> SupplierDetail:
        supplier = self._get(supplier_id)
        documents = self._documents([supplier.id]).get(supplier.id, [])
        approvals = list(
            self._session.scalars(
                select(SupplierApproval)
                .where(SupplierApproval.supplier_id == supplier.id)
                .order_by(SupplierApproval.decided_at.desc())
            )
        )
        evaluations = list(
            self._session.scalars(
                select(SupplierEvaluation)
                .where(SupplierEvaluation.supplier_id == supplier.id)
                .order_by(
                    SupplierEvaluation.period_to.desc(), SupplierEvaluation.evaluated_at.desc()
                )
            )
        )
        summary = self._summary(
            supplier,
            documents,
            self._lot_stats([supplier.id]).get(supplier.id),
            evaluations[0].total_score if evaluations else None,
        )
        people = (
            {a.decided_by for a in approvals}
            | {e.evaluated_by for e in evaluations}
            | {d.uploaded_by for d in documents}
        )
        rows = self._session.execute(select(User.id, User.full_name).where(User.id.in_(people)))
        names = {row.id: row.full_name for row in rows}
        today, warn = factory_today(), warning_days(self._session, self._actor.tenant_id)
        return SupplierDetail(
            **summary.model_dump(),
            documents=[self._document_view(d, today, warn) for d in documents],
            approvals=[self.approval_view(a) for a in approvals],
            evaluations=[self.evaluation_view(e) for e in evaluations],
            names=names,
        )

    # ----- approval decisions ----------------------------------------------------------

    def decide(self, supplier_id: UUID, command: DecideApproval) -> ApprovalView:
        supplier = self._get(supplier_id, lock=True)
        today = factory_today()
        if command.to_status == SupplierStatus.APPROVED:
            expired = expired_required(self._session, supplier.id, today)
            if expired:
                raise BusinessRuleError(
                    f"Cannot approve: the required document '{expired[0].title}' expired on "
                    f"{expired[0].expires_on}; add the renewed document or approve with conditions"
                )
        risk = command.risk_level or supplier.risk_level
        review: date | None = None
        if command.to_status in RECEIVING_ALLOWED:
            review = command.next_review_date or add_months(today, REVIEW_MONTHS[risk])
            if review <= today:
                raise BusinessRuleError("The next review date must be in the future")
        decision = SupplierApproval(
            tenant_id=self._actor.tenant_id,
            supplier_id=supplier.id,
            from_status=supplier.approval_status,
            to_status=command.to_status,
            risk_level=risk,
            reason=command.reason,
            conditions=command.conditions,
            next_review_date=review,
            decided_at=datetime.now(UTC),
            decided_by=self._actor.user_id,
        )
        self._session.add(decision)
        self._session.flush()
        self._audit.record(
            "supplier.decision",
            "supplier_approval",
            decision.id,
            {
                "supplier": supplier.code,
                "from": supplier.approval_status,
                "to": command.to_status,
                "risk_level": risk,
                "reason": command.reason,
                "conditions": command.conditions,
                "next_review_date": review,
            },
        )
        self._signatures.sign(
            decision, SignatureMeaning.APPROVED, command.password.get_secret_value()
        )
        supplier.approval_status = command.to_status
        supplier.is_approved = command.to_status in RECEIVING_ALLOWED
        supplier.risk_level = risk
        supplier.next_review_date = review
        self._session.flush()
        return self.approval_view(decision)

    # ----- documents -------------------------------------------------------------------

    def add_document(self, supplier_id: UUID, command: AddSupplierDocument) -> SupplierDocumentView:
        supplier = self._get(supplier_id)
        try:
            content = command.file_bytes()
        except ValueError as exc:
            raise BusinessRuleError(str(exc)) from exc
        document = SupplierDocument(
            tenant_id=self._actor.tenant_id,
            supplier_id=supplier.id,
            doc_type=command.doc_type,
            title=command.title,
            number=command.number,
            issuer=command.issuer,
            issued_on=command.issued_on,
            expires_on=command.expires_on,
            is_required=command.is_required,
            file_name=command.file_name if content else None,
            content_type=command.content_type if content else None,
            file_size=len(content) if content else None,
            file_sha256=hashlib.sha256(content).hexdigest() if content else None,
            file_data=content,
            uploaded_at=datetime.now(UTC),
            uploaded_by=self._actor.user_id,
        )
        self._session.add(document)
        self._session.flush()
        self._audit.record(
            "supplier_document.added",
            "supplier_document",
            document.id,
            {
                **command.model_dump(exclude={"file_base64"}),
                "supplier": supplier.code,
                "file_sha256": document.file_sha256,
            },
        )
        return self._document_view(
            document, factory_today(), warning_days(self._session, self._actor.tenant_id)
        )

    def withdraw_document(
        self, document_id: UUID, command: WithdrawDocument
    ) -> SupplierDocumentView:
        document = self._session.get(SupplierDocument, document_id, with_for_update=True)
        if document is None:
            raise NotFoundError("Supplier document", document_id)
        if document.withdrawn_at is not None:
            raise ConflictError("This document is already withdrawn")
        document.withdrawn_at = datetime.now(UTC)
        document.withdrawn_by = self._actor.user_id
        document.withdrawn_reason = command.reason
        self._session.flush()
        self._audit.record(
            "supplier_document.withdrawn",
            "supplier_document",
            document.id,
            {"title": document.title, "reason": command.reason},
        )
        return self._document_view(
            document, factory_today(), warning_days(self._session, self._actor.tenant_id)
        )

    def document_file(self, document_id: UUID) -> tuple[str, str, bytes]:
        document = self._session.get(SupplierDocument, document_id)
        if document is None:
            raise NotFoundError("Supplier document", document_id)
        if document.file_data is None:
            raise NotFoundError("File of document", document_id)
        assert document.file_name is not None and document.content_type is not None
        return document.file_name, document.content_type, document.file_data

    # ----- evaluations -----------------------------------------------------------------

    def evaluate(self, supplier_id: UUID, command: EvaluateSupplier) -> EvaluationView:
        supplier = self._get(supplier_id)
        if command.period_to > factory_today():
            raise BusinessRuleError("The evaluation period cannot end in the future")
        total = sum(
            (Decimal(getattr(command, field)) * weight for field, weight in WEIGHTS.items()),
            Decimal(0),
        ) / Decimal(100)
        total = total.quantize(Decimal("0.1"), rounding=ROUND_HALF_UP)
        received, blocked = self._lots_in_period(
            supplier.id, command.period_from, command.period_to
        )
        evaluation = SupplierEvaluation(
            tenant_id=self._actor.tenant_id,
            supplier_id=supplier.id,
            period_from=command.period_from,
            period_to=command.period_to,
            quality_score=command.quality_score,
            delivery_score=command.delivery_score,
            documentation_score=command.documentation_score,
            service_score=command.service_score,
            total_score=total,
            recommendation=recommendation_for(total),
            lots_received=received,
            lots_blocked=blocked,
            comments=command.comments,
            evaluated_at=datetime.now(UTC),
            evaluated_by=self._actor.user_id,
        )
        self._session.add(evaluation)
        self._session.flush()
        self._audit.record(
            "supplier.evaluated",
            "supplier_evaluation",
            evaluation.id,
            {
                **command.model_dump(exclude={"password"}),
                "supplier": supplier.code,
                "total_score": total,
                "recommendation": evaluation.recommendation,
            },
        )
        self._signatures.sign(
            evaluation, SignatureMeaning.PERFORMED, command.password.get_secret_value()
        )
        return self.evaluation_view(evaluation)

    # ----- views -----------------------------------------------------------------------

    def approval_view(self, approval: SupplierApproval) -> ApprovalView:
        signatures = self._signatures.for_records(SupplierApproval, [approval.id])[approval.id]
        view = ApprovalView.model_validate(approval)
        view.signatures = self._signatures.views(approval, signatures)
        return view

    def evaluation_view(self, evaluation: SupplierEvaluation) -> EvaluationView:
        signatures = self._signatures.for_records(SupplierEvaluation, [evaluation.id])[
            evaluation.id
        ]
        view = EvaluationView.model_validate(evaluation)
        view.signatures = self._signatures.views(evaluation, signatures)
        return view

    def _document_view(
        self, document: SupplierDocument, today: date, warn: int
    ) -> SupplierDocumentView:
        state, days_left = document_state(document, today, warn)
        return SupplierDocumentView.model_validate(
            {
                **{
                    f: getattr(document, f)
                    for f in SupplierDocumentView.model_fields
                    if f not in ("state", "days_left")
                },
                "state": state,
                "days_left": days_left,
            }
        )

    def _summary(
        self,
        supplier: Supplier,
        documents: list[SupplierDocument],
        lots: tuple[int, int, datetime | None] | None,
        last_score: Decimal | None,
    ) -> SupplierSummary:
        today, warn = factory_today(), warning_days(self._session, self._actor.tenant_id)
        states = [document_state(d, today, warn)[0] for d in documents]
        required_expired = sum(
            1
            for d, state in zip(documents, states, strict=True)
            if d.is_required and state == "expired"
        )
        received, blocked, last = lots or (0, 0, None)
        reason = receiving_block(self._session, supplier)
        return SupplierSummary(
            supplier=SupplierView.model_validate(supplier),
            can_receive=reason is None,
            blocked_reason=reason,
            stats=SupplierStats(
                lots_received=received,
                lots_blocked=blocked,
                last_receipt_at=last,
                documents_valid=states.count("valid"),
                documents_expiring=states.count("expiring"),
                documents_expired=states.count("expired"),
                required_expired=required_expired,
                last_score=last_score,
            ),
            review_overdue=bool(
                supplier.next_review_date
                and supplier.next_review_date < today
                and supplier.approval_status in RECEIVING_ALLOWED
            ),
        )

    def _documents(self, supplier_ids: list[UUID]) -> dict[UUID, list[SupplierDocument]]:
        result: dict[UUID, list[SupplierDocument]] = {}
        if not supplier_ids:
            return result
        rows = self._session.scalars(
            select(SupplierDocument)
            .where(SupplierDocument.supplier_id.in_(supplier_ids))
            .order_by(SupplierDocument.withdrawn_at.is_not(None), SupplierDocument.expires_on)
        )
        for document in rows:
            result.setdefault(document.supplier_id, []).append(document)
        return result

    def _lot_stats(self, supplier_ids: list[UUID]) -> dict[UUID, tuple[int, int, datetime | None]]:
        if not supplier_ids:
            return {}
        rows = self._session.execute(
            select(
                Lot.supplier_id,
                func.count(),
                func.count().filter(Lot.status == LotStatus.BLOCKED),
                func.max(Lot.created_at),
            )
            .where(Lot.supplier_id.in_(supplier_ids))
            .group_by(Lot.supplier_id)
        )
        return {row[0]: (row[1], row[2], row[3]) for row in rows if row[0] is not None}

    def _last_scores(self, supplier_ids: list[UUID]) -> dict[UUID, Decimal]:
        if not supplier_ids:
            return {}
        rows = self._session.execute(
            select(SupplierEvaluation.supplier_id, SupplierEvaluation.total_score)
            .where(SupplierEvaluation.supplier_id.in_(supplier_ids))
            .order_by(SupplierEvaluation.period_to, SupplierEvaluation.evaluated_at)
        )
        return {supplier_id: score for supplier_id, score in rows}  # latest wins

    def _lots_in_period(self, supplier_id: UUID, first: date, last: date) -> tuple[int, int]:
        day = func.date(func.timezone(get_settings().factory_timezone, Lot.created_at))
        row = self._session.execute(
            select(func.count(), func.count().filter(Lot.status == LotStatus.BLOCKED)).where(
                Lot.supplier_id == supplier_id, day >= first, day <= last
            )
        ).one()
        return row[0], row[1]

    def _get(self, supplier_id: UUID, lock: bool = False) -> Supplier:
        supplier = self._session.get(Supplier, supplier_id, with_for_update=lock)
        if supplier is None:
            raise NotFoundError("Supplier", supplier_id)
        return supplier
