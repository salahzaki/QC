"""Electronic signatures on quality records.

A signature binds a person, a meaning ("performed", "verified") and a moment to the exact
content of a record. To sign, the user re-enters their password, so a token left open on a
shared tablet is not enough. The signature stores a SHA-256 fingerprint of the record; if the
record ever changes, the signature shows as no longer intact.
"""

import hashlib
import json
from collections.abc import Iterable
from datetime import UTC, date, datetime
from decimal import Decimal
from enum import Enum
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.orm import Session

from compliance_engine.core.errors import (
    AuthenticationError,
    BusinessRuleError,
    ConflictError,
    PasswordRejectedError,
)
from compliance_engine.models import (
    CcpReading,
    CorrectiveAction,
    RecordAmendment,
    RecordSignature,
    SanitationRecord,
    SupplierApproval,
    SupplierEvaluation,
    TrainingRecord,
    User,
)
from compliance_engine.models.enums import SignatureMeaning
from compliance_engine.schemas.records import SignatureView
from compliance_engine.services.audit import AuditLog
from compliance_engine.services.context import Actor
from compliance_engine.services.lockout import check_password

SignableRecord = (
    CcpReading
    | SanitationRecord
    | RecordAmendment
    | CorrectiveAction
    | SupplierApproval
    | SupplierEvaluation
    | TrainingRecord
)

RECORD_TYPES: dict[type[SignableRecord], str] = {
    CcpReading: "ccp_reading",
    SanitationRecord: "sanitation_record",
    RecordAmendment: "record_amendment",
    CorrectiveAction: "corrective_action",
    SupplierApproval: "supplier_approval",
    SupplierEvaluation: "supplier_evaluation",
    TrainingRecord: "training_record",
}


def canonical(value: object) -> object:
    """Same value, same text: a Decimal read back as 72.500 must hash like the 72.5 sent in."""
    if isinstance(value, Decimal):
        return format(value.normalize(), "f")
    if isinstance(value, datetime):
        return value.astimezone(UTC).isoformat()
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, UUID):
        return str(value)
    return value


# Not part of what is signed: the record number is assigned by the system (and was added
# in 0.5.0, after many records were already signed).
UNSIGNED_COLUMNS = frozenset({"serial"})


def record_fingerprint(record: SignableRecord) -> str:
    fields = {
        attr.key: canonical(getattr(record, attr.key))
        for attr in record.__mapper__.column_attrs
        if attr.key not in UNSIGNED_COLUMNS
    }
    body = json.dumps(
        {"type": RECORD_TYPES[type(record)], "fields": fields},
        sort_keys=True,
        separators=(",", ":"),
    )
    return hashlib.sha256(body.encode()).hexdigest()


def to_signature_view(signature: RecordSignature, current_hash: str) -> SignatureView:
    return SignatureView(
        meaning=signature.meaning,
        signer_id=signature.signer_id,
        signer_name=signature.signer_name,
        signer_role=signature.signer_role,
        signed_at=signature.signed_at,
        comment=signature.comment,
        intact=signature.record_hash == current_hash,
    )


class SignatureService:
    def __init__(self, session: Session, actor: Actor) -> None:
        self._session = session
        self._actor = actor
        self._audit = AuditLog(session, actor.tenant_id, actor.user_id)

    def sign(
        self,
        record: SignableRecord,
        meaning: SignatureMeaning,
        password: str,
        comment: str | None = None,
    ) -> RecordSignature:
        signer = self._session.get(User, self._actor.user_id)
        if signer is None or not signer.is_active:
            raise AuthenticationError("User is inactive or no longer exists")
        check_password(
            signer,
            password,
            "signature",
            PasswordRejectedError,
            "Signature rejected: the password is incorrect",
        )

        record_type = RECORD_TYPES[type(record)]
        existing = self.for_records(type(record), [record.id]).get(record.id, [])
        if any(s.meaning == meaning for s in existing):
            raise ConflictError(f"This {record_type} is already {meaning}")
        if meaning == SignatureMeaning.VERIFIED and any(s.signer_id == signer.id for s in existing):
            raise BusinessRuleError("A record must be verified by someone other than its author")

        # Re-read the record from the database so the fingerprint covers stored values.
        self._session.refresh(record)
        signature = RecordSignature(
            tenant_id=self._actor.tenant_id,
            record_type=record_type,
            record_id=record.id,
            meaning=meaning,
            signer_id=signer.id,
            signer_name=signer.full_name,
            signer_role=signer.role,
            signed_at=datetime.now(UTC),
            comment=comment,
            record_hash=record_fingerprint(record),
        )
        self._session.add(signature)
        self._session.flush()
        self._audit.record(
            "record.signed",
            record_type,
            record.id,
            {
                "meaning": meaning,
                "signer": signer.full_name,
                "role": signer.role,
                "record_hash": signature.record_hash,
            },
        )
        return signature

    def for_records(
        self, model: type[SignableRecord], record_ids: Iterable[UUID]
    ) -> dict[UUID, list[RecordSignature]]:
        ids = list(record_ids)
        rows = self._session.scalars(
            select(RecordSignature)
            .where(
                RecordSignature.record_type == RECORD_TYPES[model],
                RecordSignature.record_id.in_(ids),
            )
            .order_by(RecordSignature.signed_at)
        )
        result: dict[UUID, list[RecordSignature]] = {record_id: [] for record_id in ids}
        for signature in rows:
            result[signature.record_id].append(signature)
        return result

    def views(
        self, record: SignableRecord, signatures: list[RecordSignature]
    ) -> list[SignatureView]:
        current = record_fingerprint(record)
        return [to_signature_view(s, current) for s in signatures]
