"""Figures for the dashboard and the analytics page.

Everything is computed from the same views as the records pages and the PDF reports, so
amended values count as amended and the numbers always match what an inspector sees.
"""

import statistics
from collections import Counter, defaultdict
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from datetime import UTC, date, datetime, timedelta
from decimal import Decimal
from itertools import pairwise
from uuid import UUID
from zoneinfo import ZoneInfo

from sqlalchemy import select
from sqlalchemy.orm import Session

from compliance_engine.core.config import get_settings
from compliance_engine.core.permissions import Permission, has_permission
from compliance_engine.models import Alert, ControlPoint, User
from compliance_engine.models.enums import (
    AlertKind,
    CorrectiveActionStatus,
    SanitationResult,
    SignatureMeaning,
)
from compliance_engine.schemas.analytics import (
    ActivityItem,
    Analytics,
    AreaStats,
    CapaAging,
    ComplianceScore,
    ControlPointStats,
    DayPoint,
    HeatCell,
    Kpis,
    Live,
    LiveControlPoint,
    PersonStats,
    ScorePart,
    SpcPoint,
    SpcSeries,
)
from compliance_engine.schemas.capa import CorrectiveActionView
from compliance_engine.schemas.records import CcpReadingView, SanitationRecordView, SignatureView
from compliance_engine.services.capa import CapaService
from compliance_engine.services.context import Actor, factory_today
from compliance_engine.services.records import RecordsService
from compliance_engine.services.reports import Period, make_period

ALL = 1_000_000
SPC_POINTS = 300  # latest readings drawn on the control chart
CPK_MIN_READINGS = 10
ON_TIME_GRACE = 1.1  # a check up to 10% late still counts as on time
DUE_SOON = 0.8  # "due soon" once 80% of the interval has passed
AGE_BUCKETS = (("0-2", 2), ("3-7", 7), ("8-30", 30), ("31+", None))


def _pct(part: int | float, whole: int | float) -> float | None:
    return round(100 * part / whole, 1) if whole else None


def _f(value: Decimal | None) -> float | None:
    return None if value is None else float(value)


def _first_verification(signatures: Sequence[SignatureView]) -> datetime | None:
    return min(
        (s.signed_at for s in signatures if s.meaning == SignatureMeaning.VERIFIED), default=None
    )


def _on_time(times: Sequence[datetime], interval_minutes: int | None) -> tuple[int, int]:
    """(gaps on time, gaps) between consecutive readings, oldest first."""
    if not interval_minutes or len(times) < 2:
        return 0, 0
    limit = timedelta(minutes=interval_minutes * ON_TIME_GRACE)
    ordered = sorted(times)
    gaps = [b - a for a, b in pairwise(ordered)]
    return sum(g <= limit for g in gaps), len(gaps)


def _cpk(values: Sequence[float], low: float | None, high: float | None) -> float | None:
    if len(values) < CPK_MIN_READINGS or (low is None and high is None):
        return None
    sigma = statistics.stdev(values)
    if sigma == 0:
        return None
    mean = statistics.fmean(values)
    sides = [
        x
        for x in (
            (high - mean) if high is not None else None,
            (mean - low) if low is not None else None,
        )
        if x is not None
    ]
    return round(min(sides) / (3 * sigma), 2)


@dataclass
class _Data:
    readings: list[CcpReadingView]
    sanitation: list[SanitationRecordView]
    actions_opened: list[CorrectiveActionView]
    actions_closed: list[CorrectiveActionView]
    alerts: list[Alert]


class AnalyticsService:
    def __init__(self, session: Session, actor: Actor) -> None:
        self._session = session
        self._actor = actor
        self._records = RecordsService(session, actor)
        self._capa = CapaService(session, actor)
        settings = get_settings()
        self._tz = ZoneInfo(settings.factory_timezone)
        self._target_days = settings.capa_target_days

    # ----- analytics -------------------------------------------------------------------

    def overview(self, period: Period, control_point_id: UUID | None) -> Analytics:
        length = (period.last_day - period.first_day).days + 1
        previous = make_period(
            period.first_day - timedelta(days=length), period.first_day - timedelta(days=1)
        )
        all_actions = self._capa.list_actions(None, None, None, ALL)
        control_points = self._records.list_control_points()
        data = self._load(period, all_actions)
        before = self._load(previous, all_actions)
        kpis = self._kpis(data, control_points)
        previous_kpis = self._kpis(before, control_points)
        return Analytics(
            date_from=period.first_day,
            date_to=period.last_day,
            previous_from=previous.first_day,
            previous_to=previous.last_day,
            kpis=kpis,
            previous=previous_kpis,
            score=self._score(kpis),
            previous_score=self._score(previous_kpis),
            daily=self._daily(period, data),
            control_points=self._control_points(data.readings, control_points),
            spc=self._spc(data.readings, control_points, control_point_id),
            heatmap=self._heatmap(data),
            areas=self._areas(data.sanitation),
            capa=self._capa_aging(all_actions, data.actions_closed),
            people=self._people(data)
            if has_permission(self._actor.role, Permission.RECORDS_VERIFY)
            else None,
        )

    def _load(self, period: Period, actions: Sequence[CorrectiveActionView]) -> _Data:
        return _Data(
            readings=self._records.list_ccp_readings(
                None, False, False, ALL, period.start, period.end
            ),
            sanitation=self._records.list_sanitation(
                None, False, False, ALL, period.start, period.end
            ),
            actions_opened=[a for a in actions if period.start <= a.opened_at < period.end],
            actions_closed=[
                a
                for a in actions
                if a.closed_at is not None and period.start <= a.closed_at < period.end
            ],
            alerts=list(
                self._session.scalars(
                    select(Alert).where(
                        Alert.raised_at >= period.start, Alert.raised_at < period.end
                    )
                )
            ),
        )

    def _kpis(self, data: _Data, control_points: Sequence[ControlPoint]) -> Kpis:
        readings, sanitation = data.readings, data.sanitation
        records: list[CcpReadingView | SanitationRecordView] = [*readings, *sanitation]
        verify_hours = []
        for record in records:
            first = _first_verification(record.signatures)
            if first is not None:
                verify_hours.append((first - record.created_at).total_seconds() / 3600)

        on_time = gaps = 0
        by_point = defaultdict(list)
        for r in readings:
            by_point[r.control_point_id].append(r.measured_at)
        for cp in control_points:
            good, total = _on_time(by_point.get(cp.id, []), cp.check_interval_minutes)
            on_time, gaps = on_time + good, gaps + total

        target = timedelta(days=self._target_days)
        close_days = [
            (a.closed_at - a.opened_at).total_seconds() / 86400
            for a in data.actions_closed
            if a.closed_at is not None
        ]
        ack_minutes = [
            (a.acknowledged_at - a.raised_at).total_seconds() / 60
            for a in data.alerts
            if a.acknowledged_at is not None
        ]
        deviations = sum(not r.within_limits for r in readings)
        failures = sum(s.result == SanitationResult.FAIL for s in sanitation)
        return Kpis(
            ccp_readings=len(readings),
            ccp_deviations=deviations,
            ccp_compliance_pct=_pct(len(readings) - deviations, len(readings)),
            sanitation_checks=len(sanitation),
            sanitation_failures=failures,
            sanitation_pass_pct=_pct(len(sanitation) - failures, len(sanitation)),
            records=len(records),
            verified_pct=_pct(sum(r.verified for r in records), len(records)),
            median_verify_hours=round(statistics.median(verify_hours), 1) if verify_hours else None,
            on_time_pct=_pct(on_time, gaps),
            missed_checks=sum(a.kind == AlertKind.MISSED_CHECK for a in data.alerts),
            capa_opened=len(data.actions_opened),
            capa_closed=len(data.actions_closed),
            capa_closed_on_time_pct=_pct(
                sum(d <= target.total_seconds() / 86400 for d in close_days), len(close_days)
            ),
            capa_mean_close_days=round(statistics.fmean(close_days), 1) if close_days else None,
            alerts_raised=len(data.alerts),
            alerts_mean_ack_minutes=round(statistics.fmean(ack_minutes)) if ack_minutes else None,
        )

    @staticmethod
    def _score(kpis: Kpis) -> ComplianceScore:
        parts = [
            ScorePart(key=key, value=value)
            for key, value in (
                ("ccp_compliance", kpis.ccp_compliance_pct),
                ("sanitation_pass", kpis.sanitation_pass_pct),
                ("verified", kpis.verified_pct),
                ("on_time", kpis.on_time_pct),
                ("capa_on_time", kpis.capa_closed_on_time_pct),
            )
            if value is not None
        ]
        score = round(statistics.fmean(p.value for p in parts), 1) if parts else None
        return ComplianceScore(score=score, parts=parts)

    def _local_day(self, moment: datetime) -> date:
        return moment.astimezone(self._tz).date()

    def _daily(self, period: Period, data: _Data) -> list[DayPoint]:
        counts: dict[date, Counter[str]] = defaultdict(Counter)
        for r in data.readings:
            day = counts[self._local_day(r.measured_at)]
            day["ccp_readings"] += 1
            day["ccp_deviations"] += not r.within_limits
        for s in data.sanitation:
            day = counts[self._local_day(s.performed_at)]
            day["sanitation_checks"] += 1
            day["sanitation_failures"] += s.result == SanitationResult.FAIL
        for a in data.actions_opened:
            counts[self._local_day(a.opened_at)]["capa_opened"] += 1
        for a in data.actions_closed:
            assert a.closed_at is not None
            counts[self._local_day(a.closed_at)]["capa_closed"] += 1
        days = (period.last_day - period.first_day).days + 1
        return [
            DayPoint(
                day=day, **{key: counts[day][key] for key in DayPoint.model_fields if key != "day"}
            )
            for day in (period.first_day + timedelta(days=n) for n in range(days))
        ]

    def _control_points(
        self, readings: Sequence[CcpReadingView], control_points: Sequence[ControlPoint]
    ) -> list[ControlPointStats]:
        stats = []
        for cp in control_points:
            mine = [r for r in readings if r.control_point_id == cp.id]
            values = [float(r.value) for r in mine]
            low, high = _f(cp.critical_min), _f(cp.critical_max)
            good, gaps = _on_time([r.measured_at for r in mine], cp.check_interval_minutes)
            deviations = sum(not r.within_limits for r in mine)
            stats.append(
                ControlPointStats(
                    control_point_id=cp.id,
                    code=cp.code,
                    name=cp.name,
                    unit=cp.unit,
                    critical_min=low,
                    critical_max=high,
                    readings=len(mine),
                    deviations=deviations,
                    compliance_pct=_pct(len(mine) - deviations, len(mine)),
                    mean=round(statistics.fmean(values), 3) if values else None,
                    minimum=min(values, default=None),
                    maximum=max(values, default=None),
                    stdev=round(statistics.stdev(values), 3) if len(values) > 1 else None,
                    cpk=_cpk(values, low, high),
                    on_time_pct=_pct(good, gaps),
                    last_reading_at=max((r.measured_at for r in mine), default=None),
                )
            )
        stats.sort(key=lambda s: (-s.deviations, s.code))
        return stats

    def _spc(
        self,
        readings: Sequence[CcpReadingView],
        control_points: Sequence[ControlPoint],
        control_point_id: UUID | None,
    ) -> SpcSeries | None:
        if control_point_id is None:
            # Default to the point with the most readings, so the chart is never empty
            # when there is data.
            busiest = Counter(r.control_point_id for r in readings).most_common(1)
            control_point_id = busiest[0][0] if busiest else None
        cp = next((c for c in control_points if c.id == control_point_id), None)
        if cp is None:
            return None
        mine = sorted(
            (r for r in readings if r.control_point_id == cp.id), key=lambda r: r.measured_at
        )
        values = [float(r.value) for r in mine]
        mean = statistics.fmean(values) if values else None
        sigma = statistics.stdev(values) if len(values) > 1 else None
        shown = mine[-SPC_POINTS:]
        return SpcSeries(
            control_point_id=cp.id,
            code=cp.code,
            name=cp.name,
            unit=cp.unit,
            critical_min=_f(cp.critical_min),
            critical_max=_f(cp.critical_max),
            mean=None if mean is None else round(mean, 3),
            ucl=None if mean is None or sigma is None else round(mean + 3 * sigma, 3),
            lcl=None if mean is None or sigma is None else round(mean - 3 * sigma, 3),
            points=[
                SpcPoint(
                    measured_at=r.measured_at,
                    value=float(r.value),
                    within_limits=r.within_limits,
                    serial=r.serial,
                    record_id=r.id,
                )
                for r in shown
            ],
            truncated=len(shown) < len(mine),
        )

    def _heatmap(self, data: _Data) -> list[HeatCell]:
        records: Counter[tuple[int, int]] = Counter()
        problems: Counter[tuple[int, int]] = Counter()

        def add(moment: datetime, bad: bool) -> None:
            local = moment.astimezone(self._tz)
            key = (local.weekday(), local.hour)
            records[key] += 1
            problems[key] += bad

        for r in data.readings:
            add(r.measured_at, not r.within_limits)
        for s in data.sanitation:
            add(s.performed_at, s.result == SanitationResult.FAIL)
        return [
            HeatCell(weekday=w, hour=h, records=records[(w, h)], problems=problems[(w, h)])
            for (w, h) in sorted(records)
        ]

    @staticmethod
    def _areas(sanitation: Sequence[SanitationRecordView]) -> list[AreaStats]:
        grouped: dict[str, list[SanitationRecordView]] = defaultdict(list)
        for s in sanitation:
            grouped[s.area].append(s)
        stats = []
        for area, items in grouped.items():
            failures = sum(s.result == SanitationResult.FAIL for s in items)
            stats.append(
                AreaStats(
                    area=area,
                    checks=len(items),
                    failures=failures,
                    pass_pct=_pct(len(items) - failures, len(items)),
                    last_at=max(s.performed_at for s in items),
                )
            )
        stats.sort(key=lambda a: (-a.failures, a.area))
        return stats

    def _capa_aging(
        self, actions: Sequence[CorrectiveActionView], closed: Sequence[CorrectiveActionView]
    ) -> CapaAging:
        now = datetime.now(UTC)
        open_actions = [a for a in actions if a.status == CorrectiveActionStatus.OPEN]
        buckets = dict.fromkeys((name for name, _ in AGE_BUCKETS), 0)
        overdue = 0
        for a in open_actions:
            age = (now - a.opened_at).days
            overdue += age > self._target_days
            for name, limit in AGE_BUCKETS:
                if limit is None or age <= limit:
                    buckets[name] += 1
                    break
        dispositions = Counter(
            a.product_disposition.value for a in closed if a.product_disposition is not None
        )
        return CapaAging(
            open_now=len(open_actions),
            overdue_now=overdue,
            target_days=self._target_days,
            buckets=buckets,
            dispositions=dict(dispositions),
        )

    def _names(self, ids: Iterable[UUID]) -> dict[UUID, str]:
        wanted = set(ids)
        if not wanted:
            return {}
        rows = self._session.execute(select(User.id, User.full_name).where(User.id.in_(wanted)))
        return {user_id: name for user_id, name in rows}

    def _people(self, data: _Data) -> list[PersonStats]:
        records: Counter[UUID] = Counter()
        problems: Counter[UUID] = Counter()
        verifications: Counter[UUID] = Counter()
        for r in data.readings:
            records[r.recorded_by] += 1
            problems[r.recorded_by] += not r.within_limits
        for s in data.sanitation:
            records[s.recorded_by] += 1
            problems[s.recorded_by] += s.result == SanitationResult.FAIL
        records_all: list[CcpReadingView | SanitationRecordView] = [
            *data.readings,
            *data.sanitation,
        ]
        for record in records_all:
            for sig in record.signatures:
                if sig.meaning == SignatureMeaning.VERIFIED:
                    verifications[sig.signer_id] += 1
        names = self._names([*records, *verifications])
        people = [
            PersonStats(
                user_id=user_id,
                name=names.get(user_id, "?"),
                records=records[user_id],
                problems=problems[user_id],
                verifications=verifications[user_id],
            )
            for user_id in names
        ]
        people.sort(key=lambda p: (-(p.records + p.verifications), p.name))
        return people

    # ----- live status -----------------------------------------------------------------

    def live(self, now: datetime | None = None) -> Live:
        now = now or datetime.now(UTC)
        today = factory_today()
        period = make_period(today, today)
        readings = self._records.list_ccp_readings(
            None, False, False, ALL, period.start, period.end
        )
        sanitation = self._records.list_sanitation(
            None, False, False, ALL, period.start, period.end
        )
        points = []
        for cp in self._records.list_control_points():
            last = next(iter(self._records.list_ccp_readings(cp.id, False, False, 1)), None)
            mine = [r for r in readings if r.control_point_id == cp.id]
            next_due = status = None
            if cp.check_interval_minutes:
                since = last.measured_at if last else cp.created_at
                interval = timedelta(minutes=cp.check_interval_minutes)
                next_due = since + interval
                if now > next_due:
                    status = "overdue"
                elif now >= since + interval * DUE_SOON:
                    status = "due_soon"
            if last is not None and not last.within_limits:
                status = "deviation"
            points.append(
                LiveControlPoint(
                    control_point_id=cp.id,
                    code=cp.code,
                    name=cp.name,
                    unit=cp.unit,
                    critical_min=_f(cp.critical_min),
                    critical_max=_f(cp.critical_max),
                    check_interval_minutes=cp.check_interval_minutes,
                    last_value=None if last is None else float(last.value),
                    last_within_limits=None if last is None else last.within_limits,
                    last_reading_at=None if last is None else last.measured_at,
                    next_due_at=next_due,
                    status=status or ("ok" if cp.check_interval_minutes else "no_schedule"),
                    readings_today=len(mine),
                    deviations_today=sum(not r.within_limits for r in mine),
                )
            )
        order = {"deviation": 0, "overdue": 1, "due_soon": 2, "ok": 3, "no_schedule": 4}
        points.sort(key=lambda p: (order[p.status], p.code))
        return Live(
            now=now,
            today=today,
            control_points=points,
            activity=self._activity(),
            today_records=len(readings) + len(sanitation),
            today_problems=sum(not r.within_limits for r in readings)
            + sum(s.result == SanitationResult.FAIL for s in sanitation),
        )

    def _activity(self, limit: int = 12) -> list[ActivityItem]:
        readings = self._records.list_ccp_readings(None, False, False, limit)
        sanitation = self._records.list_sanitation(None, False, False, limit)
        actions = self._capa.list_actions(None, None, None, limit)
        names = self._names(
            [r.recorded_by for r in readings]
            + [s.recorded_by for s in sanitation]
            + [a.closed_by or a.opened_by for a in actions]
        )
        items = [
            ActivityItem(
                at=r.measured_at,
                kind="ccp_reading",
                record_id=r.id,
                serial=r.serial,
                title=f"{r.control_point_code}: {r.value.normalize():f} {r.unit}",
                ok=r.within_limits,
                by=names.get(r.recorded_by),
            )
            for r in readings
        ]
        items += [
            ActivityItem(
                at=s.performed_at,
                kind="sanitation_record",
                record_id=s.id,
                serial=s.serial,
                title=s.area,
                ok=s.result == SanitationResult.PASS,
                by=names.get(s.recorded_by),
            )
            for s in sanitation
        ]
        items += [
            ActivityItem(
                at=a.closed_at or a.opened_at,
                kind="corrective_action",
                record_id=a.id,
                serial=a.serial,
                title="closed" if a.status == CorrectiveActionStatus.CLOSED else "opened",
                ok=a.status == CorrectiveActionStatus.CLOSED,
                by=names.get(a.closed_by or a.opened_by),
            )
            for a in actions
        ]
        items.sort(key=lambda i: i.at, reverse=True)
        return items[:limit]
