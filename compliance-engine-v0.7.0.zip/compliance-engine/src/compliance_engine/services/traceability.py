"""Lot genealogy: walk lot_links backward (to ingredients and suppliers) or forward
(to products and customers) with one recursive query."""

import time
from uuid import UUID

from sqlalchemy import select, text
from sqlalchemy.orm import Session

from compliance_engine.core.errors import NotFoundError
from compliance_engine.models import Lot, LotLink, Shipment, ShipmentLine
from compliance_engine.schemas.traceability import (
    TraceDirection,
    TracedLink,
    TracedLot,
    TracedShipment,
    TraceReport,
)

# `path` stops the walk if bad data ever forms a cycle.
_WALK_SQL = {
    TraceDirection.BACKWARD: """
        WITH RECURSIVE walk(lot_id, depth, path) AS (
            SELECT CAST(:root AS uuid), 0, ARRAY[CAST(:root AS uuid)]
          UNION ALL
            SELECT link.parent_lot_id, walk.depth + 1, walk.path || link.parent_lot_id
            FROM lot_links AS link
            JOIN walk ON link.child_lot_id = walk.lot_id
            WHERE NOT link.parent_lot_id = ANY(walk.path)
        )
        SELECT lot_id, MIN(depth) AS depth FROM walk GROUP BY lot_id
    """,
    TraceDirection.FORWARD: """
        WITH RECURSIVE walk(lot_id, depth, path) AS (
            SELECT CAST(:root AS uuid), 0, ARRAY[CAST(:root AS uuid)]
          UNION ALL
            SELECT link.child_lot_id, walk.depth + 1, walk.path || link.child_lot_id
            FROM lot_links AS link
            JOIN walk ON link.parent_lot_id = walk.lot_id
            WHERE NOT link.child_lot_id = ANY(walk.path)
        )
        SELECT lot_id, MIN(depth) AS depth FROM walk GROUP BY lot_id
    """,
}


def trace_lot(session: Session, lot_id: UUID, direction: TraceDirection) -> TraceReport:
    started = time.perf_counter()
    if session.get(Lot, lot_id) is None:
        raise NotFoundError("Lot", lot_id)

    depths: dict[UUID, int] = {
        row.lot_id: row.depth
        for row in session.execute(text(_WALK_SQL[direction]), {"root": str(lot_id)})
    }
    lot_ids = list(depths)

    lots = session.scalars(select(Lot).where(Lot.id.in_(lot_ids))).unique().all()
    links = session.scalars(
        select(LotLink).where(LotLink.parent_lot_id.in_(lot_ids), LotLink.child_lot_id.in_(lot_ids))
    ).all()
    shipments = (
        session.execute(
            select(ShipmentLine, Shipment)
            .join(Shipment, Shipment.id == ShipmentLine.shipment_id)
            .where(ShipmentLine.lot_id.in_(lot_ids))
            .order_by(Shipment.shipped_at)
        ).all()
        if direction is TraceDirection.FORWARD
        else []
    )

    return TraceReport(
        root_lot_id=lot_id,
        direction=direction,
        lots=sorted(
            (
                TracedLot(
                    lot_id=lot.id,
                    lot_code=lot.lot_code,
                    depth=depths[lot.id],
                    item_code=lot.item.code,
                    item_name=lot.item.name,
                    status=lot.status,
                    expiry_date=lot.expiry_date,
                    supplier_code=lot.supplier.code if lot.supplier else None,
                    supplier_lot_code=lot.supplier_lot_code,
                )
                for lot in lots
            ),
            key=lambda traced: (traced.depth, traced.lot_code),
        ),
        links=[
            TracedLink(
                parent_lot_id=link.parent_lot_id,
                child_lot_id=link.child_lot_id,
                quantity=link.quantity,
                production_run_id=link.production_run_id,
            )
            for link in links
        ],
        shipments=[
            TracedShipment(
                shipment_id=shipment.id,
                reference=shipment.reference,
                customer_code=shipment.customer.code,
                customer_name=shipment.customer.name,
                lot_id=line.lot_id,
                quantity=line.quantity,
                shipped_at=shipment.shipped_at,
            )
            for line, shipment in shipments
        ],
        elapsed_ms=round((time.perf_counter() - started) * 1000, 2),
    )
