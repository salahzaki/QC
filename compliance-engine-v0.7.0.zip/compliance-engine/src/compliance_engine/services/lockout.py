"""Wrong passwords and account lockout.

Every wrong password typed by a known user (at login, when signing a record or when changing
the password) is counted and audited. After `CE_MAX_FAILED_PASSWORDS` in a row the account is
locked: it cannot log in, use the API or sign until an admin unlocks it or resets its password.
A correct password resets the count.

The request that typed the wrong password fails and its transaction is rolled back, so the
failure is recorded afterwards in a fresh transaction (see `api.deps.get_session`).
"""

import logging
from datetime import UTC, datetime

from sqlalchemy.orm import Session

from compliance_engine.core.config import get_settings
from compliance_engine.core.errors import (
    LoginRejectedError,
    PasswordFailure,
    PasswordRejectedError,
)
from compliance_engine.core.security import verify_password
from compliance_engine.db.session import bind_tenant
from compliance_engine.models import User
from compliance_engine.services.audit import AuditLog

log = logging.getLogger(__name__)


def locked_message() -> str:
    limit = get_settings().max_failed_passwords
    return (
        f"This account is locked after {limit} wrong passwords in a row; "
        "ask an administrator to unlock it"
    )


def check_password(
    user: User,
    password: str,
    context: str,
    error: type[LoginRejectedError | PasswordRejectedError],
    message: str,
    *,
    show_attempts_left: bool = True,
) -> None:
    """Raise `error` if the account is locked or the password is wrong; else reset the count."""
    if user.locked_at is not None:
        raise error(locked_message())
    if not verify_password(password, user.password_hash):
        if show_attempts_left:
            left = get_settings().max_failed_passwords - user.failed_password_attempts - 1
            message += (
                f" ({left} attempt{'s' if left != 1 else ''} left before the account is locked)"
                if left > 0
                else "; the account is now locked"
            )
        raise error(message, PasswordFailure(user.tenant_id, user.id, context))
    if user.failed_password_attempts:
        user.failed_password_attempts = 0


def record_password_failure(session: Session, failure: PasswordFailure) -> None:
    """Count a wrong password and lock the account at the limit. Commits its own transaction."""
    try:
        bind_tenant(session, failure.tenant_id)
        user = session.get(User, failure.user_id, with_for_update=True, populate_existing=True)
        if user is None:
            return
        user.failed_password_attempts += 1
        audit = AuditLog(session, failure.tenant_id, user.id)
        audit.record(
            "user.password_rejected",
            "user",
            user.id,
            {"context": failure.context, "attempts": user.failed_password_attempts},
        )
        limit = get_settings().max_failed_passwords
        if user.failed_password_attempts >= limit and user.locked_at is None:
            user.locked_at = datetime.now(UTC)
            audit.record("user.locked", "user", user.id, {"after_attempts": limit})
        session.commit()
    except Exception:
        session.rollback()
        log.exception("Could not record a wrong password for user %s", failure.user_id)


def unlock(user: User) -> None:
    user.locked_at = None
    user.failed_password_attempts = 0
