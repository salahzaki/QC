"""Audit-ready reports: CCP monitoring log, sanitation log, corrective action register and
traceability (mock recall), as PDF in Arabic or English, plus a JSON HACCP summary.

Reports read the same views as the API, so records appear with amendments applied and
with the names of the people who signed them.
"""

from collections.abc import Sequence
from dataclasses import dataclass
from datetime import UTC, date, datetime, time, timedelta
from decimal import Decimal
from typing import Any
from uuid import UUID
from zoneinfo import ZoneInfo

from sqlalchemy import select
from sqlalchemy.orm import Session

from compliance_engine.core.config import get_settings
from compliance_engine.core.errors import BusinessRuleError, NotFoundError
from compliance_engine.models import (
    ControlPoint,
    DocumentForm,
    Lot,
    SupplierApproval,
    Tenant,
    User,
)
from compliance_engine.models.enums import (
    RECEIVING_ALLOWED,
    CorrectiveActionStatus,
    SanitationResult,
    SignatureMeaning,
)
from compliance_engine.reports.pdf import Lang, ReportPdf, format_moment
from compliance_engine.reports.texts import t
from compliance_engine.schemas.capa import CorrectiveActionView
from compliance_engine.schemas.records import AmendmentView, SignatureView
from compliance_engine.schemas.reports import ControlPointSummary, HaccpSummary
from compliance_engine.schemas.suppliers import SupplierSummary
from compliance_engine.schemas.traceability import TraceDirection, TracedLot
from compliance_engine.services.alerts import AlertService
from compliance_engine.services.capa import CapaService
from compliance_engine.services.context import Actor, factory_today
from compliance_engine.services.documents import DocumentService, ensure_forms
from compliance_engine.services.records import RecordsService, limits_text
from compliance_engine.services.suppliers import SupplierService
from compliance_engine.services.traceability import trace_lot
from compliance_engine.services.training import TrainingService

MAX_RANGE_DAYS = 366
ALL = 1_000_000  # "no limit" for report queries


@dataclass(frozen=True)
class Period:
    first_day: date
    last_day: date
    start: datetime  # inclusive, UTC
    end: datetime  # exclusive, UTC

    def parameters(self) -> dict[str, Any]:
        return {"date_from": self.first_day, "date_to": self.last_day}


def make_period(date_from: date | None, date_to: date | None) -> Period:
    """Whole days in the factory's time zone; defaults to the last 7 days."""
    last_day = date_to or factory_today()
    first_day = date_from or last_day - timedelta(days=6)
    if first_day > last_day:
        raise BusinessRuleError("date_from must not be after date_to")
    if (last_day - first_day).days >= MAX_RANGE_DAYS:
        raise BusinessRuleError(f"A report can cover at most {MAX_RANGE_DAYS} days")
    tz = ZoneInfo(get_settings().factory_timezone)
    return Period(
        first_day=first_day,
        last_day=last_day,
        start=datetime.combine(first_day, time.min, tz).astimezone(UTC),
        end=datetime.combine(last_day + timedelta(days=1), time.min, tz).astimezone(UTC),
    )


@dataclass(frozen=True)
class RenderedReport:
    filename: str
    content: bytes
    serial: str


@dataclass(frozen=True)
class Issue:
    serial: str
    form: DocumentForm
    title: str
    lang: Lang


class ReportService:
    def __init__(self, session: Session, actor: Actor) -> None:
        self._session = session
        self._actor = actor
        self._records = RecordsService(session, actor)
        self._tz = ZoneInfo(get_settings().factory_timezone)

    # ----- JSON summary ----------------------------------------------------------------

    def haccp_summary(self, period: Period) -> HaccpSummary:
        readings = self._records.list_ccp_readings(
            None, False, False, ALL, period.start, period.end
        )
        sanitation = self._records.list_sanitation(
            None, False, False, ALL, period.start, period.end
        )
        actions = CapaService(self._session, self._actor).list_actions(
            None, period.start, period.end, ALL
        )
        points = []
        for control_point in self._records.list_control_points():
            mine = [r for r in readings if r.control_point_id == control_point.id]
            points.append(
                ControlPointSummary(
                    control_point_id=control_point.id,
                    code=control_point.code,
                    name=control_point.name,
                    readings=len(mine),
                    deviations=sum(not r.within_limits for r in mine),
                    unverified=sum(not r.verified for r in mine),
                    last_reading_at=max((r.measured_at for r in mine), default=None),
                )
            )
        alerts = AlertService.for_actor(self._session, self._actor).summary()
        return HaccpSummary(
            date_from=period.first_day,
            date_to=period.last_day,
            control_points=points,
            ccp_readings=len(readings),
            ccp_deviations=sum(not r.within_limits for r in readings),
            sanitation_checks=len(sanitation),
            sanitation_failures=sum(r.result == SanitationResult.FAIL for r in sanitation),
            unverified_records=sum(not r.verified for r in readings)
            + sum(not r.verified for r in sanitation),
            corrective_actions_opened=len(actions),
            corrective_actions_open_now=alerts.open_corrective_actions,
            open_alerts_now=alerts.open_alerts,
        )

    # ----- CCP log ---------------------------------------------------------------------

    def ccp_log(self, period: Period, control_point_id: UUID | None, lang: Lang) -> RenderedReport:
        control_points = self._records.list_control_points()
        if control_point_id is not None:
            control_points = [cp for cp in control_points if cp.id == control_point_id]
            if not control_points:
                raise NotFoundError("Control point", control_point_id)
        readings = self._records.list_ccp_readings(
            control_point_id, False, False, ALL, period.start, period.end
        )
        lot_codes = self._lot_codes({r.lot_id for r in readings if r.lot_id})
        pdf, issue = self._start(lang, "ccp_log", period)
        if not control_points:
            pdf.paragraph(t(lang, "no_control_points"), muted=True)
        for control_point in control_points:
            mine = sorted(
                (r for r in readings if r.control_point_id == control_point.id),
                key=lambda r: r.measured_at,
            )
            pdf.heading(f"{control_point.code} | {control_point.name}")
            pdf.key_values(
                [
                    (t(lang, "hazard"), control_point.hazard),
                    (t(lang, "parameter"), f"{control_point.parameter} ({control_point.unit})"),
                    (t(lang, "critical_limits"), self._limits(lang, control_point)),
                    (t(lang, "frequency"), control_point.monitoring_frequency or "-"),
                    (t(lang, "readings"), str(len(mine))),
                    (
                        f"{t(lang, 'deviations')} / {t(lang, 'unverified')}",
                        f"{sum(not r.within_limits for r in mine)} / "
                        f"{sum(not r.verified for r in mine)}",
                    ),
                ]
            )
            rows = [
                [
                    f"{r.serial or ''}\n{self._at(r.measured_at, lang)}",
                    f"{_num(r.value)} {r.unit}" + (" *" if r.amended else ""),
                    self._limits_of(lang, r.critical_min, r.critical_max, r.unit),
                    t(lang, "ok") if r.within_limits else t(lang, "deviation"),
                    r.corrective_action or "",
                    lot_codes.get(r.lot_id, "") if r.lot_id else "",
                    self._signer(lang, r.signatures, SignatureMeaning.PERFORMED),
                    self._verifier(lang, r.signatures, r.verified),
                    self._notes(lang, r.notes, r.amendments),
                ]
                for r in mine
            ]
            pdf.data_table(
                [
                    t(lang, "number_datetime"),
                    t(lang, "value"),
                    t(lang, "limits"),
                    t(lang, "status"),
                    t(lang, "corrective_action"),
                    t(lang, "lot"),
                    t(lang, "performed_by"),
                    t(lang, "verified_by"),
                    t(lang, "notes"),
                ],
                [28, 18, 20, 17, 42, 20, 32, 32, 52],
                rows,
                highlight=[not r.within_limits for r in mine],
                empty_text=t(lang, "none"),
            )
        return self._finish(
            pdf,
            issue,
            self._filename("ccp-log", period, lang),
            {**period.parameters(), "control_point_id": control_point_id},
        )

    # ----- sanitation log --------------------------------------------------------------

    def sanitation_log(self, period: Period, area: str | None, lang: Lang) -> RenderedReport:
        records = sorted(
            self._records.list_sanitation(area, False, False, ALL, period.start, period.end),
            key=lambda r: r.performed_at,
        )
        pdf, issue = self._start(lang, "sanitation_log", period)
        pdf.key_values(
            [
                (t(lang, "checks"), str(len(records))),
                (
                    t(lang, "failures"),
                    str(sum(r.result == SanitationResult.FAIL for r in records)),
                ),
                (t(lang, "unverified"), str(sum(not r.verified for r in records))),
                (t(lang, "area"), area or "-"),
            ]
        )
        rows = [
            [
                f"{r.serial or ''}\n{self._at(r.performed_at, lang)}",
                r.area,
                t(lang, r.activity.value),
                " ".join(x for x in (r.chemical, _num(r.concentration_ppm)) if x),
                t(lang, r.result.value) + (" *" if r.amended else ""),
                r.corrective_action or "",
                self._signer(lang, r.signatures, SignatureMeaning.PERFORMED),
                self._verifier(lang, r.signatures, r.verified),
                self._notes(lang, r.notes, r.amendments),
            ]
            for r in records
        ]
        pdf.data_table(
            [
                t(lang, "number_datetime"),
                t(lang, "area"),
                t(lang, "activity"),
                t(lang, "chemical"),
                t(lang, "result"),
                t(lang, "corrective_action"),
                t(lang, "performed_by"),
                t(lang, "verified_by"),
                t(lang, "notes"),
            ],
            [28, 24, 24, 24, 16, 44, 32, 32, 53],
            rows,
            highlight=[r.result == SanitationResult.FAIL for r in records],
            empty_text=t(lang, "none"),
        )
        return self._finish(
            pdf,
            issue,
            self._filename("sanitation-log", period, lang),
            {**period.parameters(), "area": area},
        )

    # ----- corrective action register --------------------------------------------------

    def corrective_actions(
        self, period: Period, status: CorrectiveActionStatus | None, lang: Lang
    ) -> RenderedReport:
        actions = sorted(
            CapaService(self._session, self._actor).list_actions(
                status, period.start, period.end, ALL
            ),
            key=lambda a: a.opened_at,
        )
        pdf, issue = self._start(lang, "corrective_actions", period)
        pdf.key_values(
            [
                (t(lang, "open_count"), str(sum(a.status == "open" for a in actions))),
                (t(lang, "closed_count"), str(sum(a.status == "closed" for a in actions))),
            ]
        )
        names = self._user_names({a.opened_by for a in actions})
        pdf.data_table(
            [
                t(lang, "number_opened"),
                t(lang, "deviation_desc"),
                t(lang, "immediate_action"),
                t(lang, "status"),
                t(lang, "root_cause"),
                t(lang, "preventive_action"),
                t(lang, "disposition"),
                t(lang, "closed_by"),
            ],
            [30, 50, 40, 15, 36, 36, 26, 40],
            [self._capa_row(lang, a, names) for a in actions],
            highlight=[a.status == CorrectiveActionStatus.OPEN for a in actions],
            empty_text=t(lang, "none"),
        )
        return self._finish(
            pdf,
            issue,
            self._filename("corrective-actions", period, lang),
            {**period.parameters(), "status": status},
        )

    def _capa_row(
        self, lang: Lang, action: CorrectiveActionView, names: dict[UUID, str]
    ) -> list[str]:
        return [
            f"{action.serial or ''}\n{self._at(action.opened_at, lang)}\n"
            f"{names.get(action.opened_by, '')}",
            action.description,
            action.immediate_action,
            t(lang, action.status.value),
            action.root_cause or "",
            action.preventive_action or "",
            t(lang, action.product_disposition.value) if action.product_disposition else "",
            self._signer(lang, action.signatures, SignatureMeaning.APPROVED),
        ]

    # ----- traceability / mock recall --------------------------------------------------

    def trace(self, lot_id: UUID, lang: Lang) -> RenderedReport:
        lot = self._session.get(Lot, lot_id)
        if lot is None:
            raise NotFoundError("Lot", lot_id)
        backward = trace_lot(self._session, lot_id, TraceDirection.BACKWARD)
        forward = trace_lot(self._session, lot_id, TraceDirection.FORWARD)

        pdf, issue = self._start(lang, "trace", None)
        customers = sorted({s.customer_name for s in forward.shipments})
        pdf.key_values(
            [
                (t(lang, "subject_lot"), lot.lot_code),
                (t(lang, "item"), f"{lot.item.code} | {lot.item.name}"),
                (t(lang, "lot_status"), t(lang, lot.status.value)),
                (t(lang, "expiry"), _day(lot.expiry_date, lang) or "-"),
                (
                    t(lang, "lots_affected"),
                    str(len({x.lot_id for x in backward.lots} | {x.lot_id for x in forward.lots})),
                ),
                (t(lang, "customers_affected"), ", ".join(customers) or "-"),
                (
                    t(lang, "trace_time"),
                    f"{backward.elapsed_ms + forward.elapsed_ms:.1f} {t(lang, 'ms')}",
                ),
            ]
        )
        lot_headers = [
            t(lang, "depth"),
            t(lang, "lot"),
            t(lang, "item"),
            t(lang, "supplier"),
            t(lang, "supplier_lot"),
            t(lang, "lot_status"),
            t(lang, "expiry"),
        ]
        lot_widths = [14, 38, 70, 36, 38, 30, 26]

        def lot_rows(lots: Sequence[TracedLot]) -> list[list[str]]:
            return [
                [
                    str(x.depth),
                    x.lot_code,
                    f"{x.item_code} | {x.item_name}",
                    x.supplier_code or "",
                    x.supplier_lot_code or "",
                    t(lang, x.status.value),
                    _day(x.expiry_date, lang),
                ]
                for x in lots
            ]

        pdf.heading(t(lang, "backward"))
        pdf.data_table(
            lot_headers, lot_widths, lot_rows(backward.lots), empty_text=t(lang, "no_links")
        )
        pdf.heading(t(lang, "forward"))
        pdf.data_table(
            lot_headers, lot_widths, lot_rows(forward.lots), empty_text=t(lang, "no_links")
        )

        codes = {x.lot_id: x.lot_code for x in [*backward.lots, *forward.lots]}
        pdf.heading(t(lang, "shipments"))
        pdf.data_table(
            [
                t(lang, "shipped_at"),
                t(lang, "customer"),
                t(lang, "reference"),
                t(lang, "lot"),
                t(lang, "quantity"),
            ],
            [36, 90, 50, 50, 26],
            [
                [
                    self._at(s.shipped_at, lang),
                    f"{s.customer_code} | {s.customer_name}",
                    s.reference,
                    codes.get(s.lot_id, ""),
                    _num(s.quantity),
                ]
                for s in forward.shipments
            ],
            empty_text=t(lang, "no_shipments"),
        )

        in_scope = set(codes)
        readings = [
            r
            for r in self._records.list_ccp_readings(None, False, False, ALL)
            if r.lot_id in in_scope
        ]
        readings.sort(key=lambda r: r.measured_at)
        pdf.heading(t(lang, "ccp_for_lots"))
        pdf.data_table(
            [
                t(lang, "datetime"),
                t(lang, "control_point"),
                t(lang, "lot"),
                t(lang, "value"),
                t(lang, "status"),
                t(lang, "corrective_action"),
                t(lang, "verified_by"),
            ],
            [28, 40, 34, 24, 22, 74, 30],
            [
                [
                    self._at(r.measured_at, lang),
                    r.control_point_code,
                    codes.get(r.lot_id, "") if r.lot_id else "",
                    f"{_num(r.value)} {r.unit}",
                    t(lang, "ok") if r.within_limits else t(lang, "deviation"),
                    r.corrective_action or "",
                    self._verifier(lang, r.signatures, r.verified),
                ]
                for r in readings
            ],
            highlight=[not r.within_limits for r in readings],
            empty_text=t(lang, "none"),
        )
        return self._finish(pdf, issue, f"trace-{lot.lot_code}-{lang}.pdf", {"lot": lot.lot_code})

    # ----- approved supplier list ------------------------------------------------------

    def supplier_list(self, lang: Lang) -> RenderedReport:
        service = SupplierService(self._session, self._actor)
        rows = service.overview()
        last = self._last_decisions([r.supplier.id for r in rows])
        pdf, issue = self._start(lang, "supplier_list", None)
        pdf.key_values(
            [
                (t(lang, "suppliers_count"), str(len(rows))),
                (
                    t(lang, "approved_count"),
                    str(sum(r.supplier.approval_status in RECEIVING_ALLOWED for r in rows)),
                ),
                (t(lang, "blocked_count"), str(sum(not r.can_receive for r in rows))),
            ]
        )

        def documents(row: SupplierSummary) -> str:
            s = row.stats
            parts = [f"{s.documents_valid} {t(lang, 'doc_valid')}"]
            if s.documents_expiring:
                parts.append(f"{s.documents_expiring} {t(lang, 'doc_expiring')}")
            if s.documents_expired:
                parts.append(f"{s.documents_expired} {t(lang, 'doc_expired')}")
            return "\n".join(parts)

        def decision(supplier_id: UUID) -> str:
            found = last.get(supplier_id)
            if found is None:
                return ""
            approval, signer = found
            return (
                f"{approval.serial or ''}\n{_day(approval.decided_at.date(), lang)}\n{signer}"
                + (f"\n{approval.conditions}" if approval.conditions else "")
            )

        pdf.data_table(
            [
                t(lang, "code_name"),
                t(lang, "category"),
                t(lang, "approval_status"),
                t(lang, "risk"),
                t(lang, "documents"),
                t(lang, "last_score"),
                t(lang, "next_review"),
                t(lang, "last_decision"),
                t(lang, "can_receive"),
            ],
            [44, 34, 22, 16, 28, 16, 22, 61, 34],
            [
                [
                    f"{r.supplier.code}\n{r.supplier.name}",
                    r.supplier.category or "",
                    t(lang, r.supplier.approval_status.value),
                    t(lang, r.supplier.risk_level.value),
                    documents(r),
                    _num(r.stats.last_score),
                    _day(r.supplier.next_review_date, lang),
                    decision(r.supplier.id),
                    t(lang, "allowed")
                    if r.can_receive
                    else f"{t(lang, 'stopped')}\n{r.blocked_reason or ''}",
                ]
                for r in rows
            ],
            highlight=[not r.can_receive or r.review_overdue for r in rows],
            empty_text=t(lang, "no_suppliers"),
        )
        return self._finish(pdf, issue, f"supplier-list_{factory_today()}_{lang}.pdf", {})

    def _last_decisions(self, supplier_ids: list[UUID]) -> dict[UUID, tuple[SupplierApproval, str]]:
        if not supplier_ids:
            return {}
        rows = self._session.execute(
            select(SupplierApproval, User.full_name)
            .join(User, User.id == SupplierApproval.decided_by)
            .where(SupplierApproval.supplier_id.in_(supplier_ids))
            .order_by(SupplierApproval.decided_at)
        )
        return {approval.supplier_id: (approval, name) for approval, name in rows}

    # ----- training ----------------------------------------------------------------------

    def training_matrix(self, lang: Lang) -> RenderedReport:
        matrix = TrainingService(self._session, self._actor).matrix()
        pdf, issue = self._start(lang, "training_matrix", None)
        pct = "-" if matrix.compliance_pct is None else f"{matrix.compliance_pct:g}%"
        pdf.key_values(
            [
                (t(lang, "compliance"), pct),
                (t(lang, "required_cells"), str(matrix.required)),
                (t(lang, "expiring"), str(matrix.expiring)),
                (t(lang, "expired"), str(matrix.expired)),
                (t(lang, "gaps"), str(matrix.missing)),
            ]
        )
        if not matrix.courses:
            pdf.paragraph(t(lang, "no_courses"), muted=True)
        per_table = 8
        for start in range(0, len(matrix.courses), per_table):
            courses = matrix.courses[start : start + per_table]
            name_width = 52.0
            width = (277 - name_width) / len(courses)

            def cell(status: str, expires: date | None) -> str:
                text = t(lang, status)
                if status in ("valid", "expiring", "expired") and expires:
                    text += f"\n{_day(expires, lang)}"
                return text

            pdf.data_table(
                [t(lang, "person"), *(f"{c.code}\n{c.title}" for c in courses)],
                [name_width, *([width] * len(courses))],
                [
                    [
                        f"{row.full_name}\n{_role(lang, row.role)}",
                        *(
                            cell(c.status, c.expires_on)
                            for c in row.cells[start : start + per_table]
                        ),
                    ]
                    for row in matrix.rows
                ],
                highlight=[
                    any(
                        c.required and c.status in ("expired", "failed", "missing")
                        for c in row.cells[start : start + per_table]
                    )
                    for row in matrix.rows
                ],
                empty_text=t(lang, "none"),
            )
        return self._finish(pdf, issue, f"training-matrix_{factory_today()}_{lang}.pdf", {})

    def training_log(self, period: Period, lang: Lang) -> RenderedReport:
        service = TrainingService(self._session, self._actor)
        records = [
            r
            for r in service.list_records(None, None, ALL)
            if period.first_day <= r.trained_on <= period.last_day
        ]
        records.sort(key=lambda r: (r.trained_on, r.serial or ""))
        pdf, issue = self._start(lang, "training_log", period)
        pdf.key_values(
            [
                (t(lang, "readings"), str(len(records))),
                (t(lang, "failed"), str(sum(r.result == "failed" for r in records))),
            ]
        )
        pdf.data_table(
            [
                t(lang, "number_datetime"),
                t(lang, "trainee"),
                t(lang, "course"),
                t(lang, "trainer"),
                t(lang, "hours"),
                t(lang, "result"),
                t(lang, "expires"),
                t(lang, "recorded_by"),
                t(lang, "notes"),
            ],
            [28, 34, 44, 34, 14, 22, 22, 36, 43],
            [
                [
                    f"{r.serial or ''}\n{_day(r.trained_on, lang)}",
                    r.user_name,
                    f"{r.course_code}\n{r.course_title}",
                    f"{r.trainer}\n{t(lang, r.method.value)}",
                    _num(r.duration_hours),
                    t(lang, r.result.value)
                    + (f" ({_num(r.score)})" if r.score is not None else ""),
                    _day(r.expires_on, lang),
                    self._signer(lang, r.signatures, SignatureMeaning.PERFORMED),
                    " ".join(x for x in (r.certificate_ref, r.notes) if x),
                ]
                for r in records
            ],
            highlight=[r.result == "failed" for r in records],
            empty_text=t(lang, "none"),
        )
        return self._finish(
            pdf, issue, self._filename("training-log", period, lang), period.parameters()
        )

    # ----- helpers ---------------------------------------------------------------------

    def _start(self, lang: Lang, form_key: str, period: Period | None) -> tuple[ReportPdf, Issue]:
        """A new PDF for one controlled form, numbered from the issued-report series."""
        documents = DocumentService(self._session, self._actor)
        form = ensure_forms(self._session, self._actor.tenant_id)[form_key]
        serial = documents.reserve_report_number()
        tenant = self._session.get(Tenant, self._actor.tenant_id)
        user = self._session.get(User, self._actor.user_id)
        title = form.title_ar if lang == Lang.AR else form.title_en
        meta = []
        if period is not None:
            meta.append(
                f"{t(lang, 'period')}: {_day(period.first_day, lang)} {t(lang, 'to')} "
                f"{_day(period.last_day, lang)}"
            )
        meta.append(
            f"{t(lang, 'generated')}: {self._at(datetime.now(UTC), lang)} "
            f"{t(lang, 'by')} {user.full_name if user else ''} | "
            f"{t(lang, 'timezone')} {self._tz.key}"
        )
        control = [
            (t(lang, "form_code"), form.code),
            (t(lang, "revision"), form.revision),
            (t(lang, "effective_date"), _day(form.effective_date, lang)),
            (t(lang, "report_no"), serial),
        ]
        pdf = ReportPdf(
            lang=lang,
            title=title,
            company=tenant.name if tenant else "",
            meta_lines=meta,
            footer_text=t(lang, "footer"),
            control=control,
        )
        return pdf, Issue(serial, form, title, lang)

    def _finish(
        self, pdf: ReportPdf, issue: "Issue", filename: str, parameters: dict[str, Any]
    ) -> RenderedReport:
        content = pdf.to_bytes()
        filename = f"{issue.serial}_{filename}"
        DocumentService(self._session, self._actor).register_report(
            issue.serial, issue.form, issue.title, issue.lang, parameters, filename, content
        )
        return RenderedReport(filename, content, issue.serial)

    def _at(self, moment: datetime | None, lang: Lang) -> str:
        return format_moment(moment, self._tz, lang)

    def _filename(self, name: str, period: Period, lang: Lang) -> str:
        return f"{name}_{period.first_day.isoformat()}_{period.last_day.isoformat()}_{lang}.pdf"

    def _limits(self, lang: Lang, control_point: ControlPoint) -> str:
        return self._limits_of(
            lang, control_point.critical_min, control_point.critical_max, control_point.unit
        )

    def _limits_of(self, lang: Lang, low: Decimal | None, high: Decimal | None, unit: str) -> str:
        if lang == Lang.EN:
            return limits_text(low, high, unit)
        if low is not None and high is not None:
            return f"{_num(low)} - {_num(high)} {unit}"
        if low is not None:
            return f"{_num(low)} {unit} ({t(lang, 'min')})"
        return f"{_num(high)} {unit} ({t(lang, 'max')})"

    def _signer(
        self, lang: Lang, signatures: Sequence[SignatureView], meaning: SignatureMeaning
    ) -> str:
        for signature in signatures:
            if signature.meaning == meaning:
                return f"{signature.signer_name}\n{self._at(signature.signed_at, lang)}"
        return ""

    def _verifier(self, lang: Lang, signatures: Sequence[SignatureView], verified: bool) -> str:
        signer = self._signer(lang, signatures, SignatureMeaning.VERIFIED)
        if not signer:
            return t(lang, "not_verified")
        if not verified:  # the record is verified but a later amendment is not
            return f"{signer}\n({t(lang, 'amended')}: {t(lang, 'not_verified')})"
        return signer

    def _notes(self, lang: Lang, notes: str | None, amendments: Sequence[AmendmentView]) -> str:
        parts = [notes] if notes else []
        for amendment in amendments:
            changes = ", ".join(
                f"{field}: {t(lang, 'from')} {_show(change['from'])} "
                f"{t(lang, 'to')} {_show(change['to'])}"
                for field, change in amendment.changes.items()
            )
            who = self._signer(lang, amendment.signatures, SignatureMeaning.PERFORMED).split("\n")[
                0
            ]
            parts.append(
                f"* {t(lang, 'amended')} {self._at(amendment.amended_at, lang)} "
                f"{who}: {changes} ({t(lang, 'reason')}: {amendment.reason})"
            )
        return "\n".join(parts)

    def _lot_codes(self, lot_ids: set[UUID]) -> dict[UUID, str]:
        if not lot_ids:
            return {}
        rows = self._session.execute(select(Lot.id, Lot.lot_code).where(Lot.id.in_(lot_ids)))
        return {row.id: row.lot_code for row in rows}

    def _user_names(self, user_ids: set[UUID]) -> dict[UUID, str]:
        if not user_ids:
            return {}
        rows = self._session.execute(select(User.id, User.full_name).where(User.id.in_(user_ids)))
        return {row.id: row.full_name for row in rows}


def _num(value: Decimal | None) -> str:
    return "" if value is None else format(value.normalize(), "f")


def _day(day: date | None, lang: Lang) -> str:
    """Arabic text turns 2026-10-08 into 08-10-2026 (bidi rules); slashes keep the order."""
    if day is None:
        return ""
    return day.strftime("%Y/%m/%d" if lang == Lang.AR else "%Y-%m-%d")


ROLE_NAMES = {
    "admin": ("Administrator", "مدير النظام"),
    "quality_manager": ("Quality manager", "مدير الجودة"),
    "supervisor": ("Supervisor", "مشرف"),
    "operator": ("Operator", "عامل تشغيل"),
    "auditor": ("Auditor", "مدقق"),
}


def _role(lang: Lang, role: str) -> str:
    en, ar = ROLE_NAMES.get(role, (role, role))
    return ar if lang == Lang.AR else en


def _show(value: object) -> str:
    return "-" if value is None else str(value)[:40]
