"""Lot lifecycle: receive, release/block, consume in production, dispatch.

Quantities are never stored on the lot. Each movement writes a signed row to the
lot_transactions ledger, and a lot's balance is the sum of its rows.
"""

import secrets
from collections.abc import Iterable, Sequence
from datetime import UTC, date, datetime, timedelta
from decimal import Decimal
from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from compliance_engine.core.errors import BusinessRuleError, NotFoundError
from compliance_engine.models import (
    Customer,
    Item,
    Lot,
    LotLink,
    LotTransaction,
    ProductionRun,
    Shipment,
    ShipmentLine,
    Supplier,
)
from compliance_engine.models.enums import ItemType, LotOrigin, LotStatus, TransactionType
from compliance_engine.schemas.inventory import (
    ChangeLotStatus,
    LotQuantity,
    LotView,
    ProductionView,
    ReceiveLot,
    RecordProduction,
    RecordShipment,
    ShipmentLineView,
    ShipmentView,
)
from compliance_engine.services.audit import AuditLog
from compliance_engine.services.context import Actor, factory_today
from compliance_engine.services.master_data import get_or_raise
from compliance_engine.services.suppliers import receiving_block

LOT_CODE_PREFIX = {
    ItemType.RAW_MATERIAL: "RM",
    ItemType.PACKAGING: "PK",
    ItemType.WORK_IN_PROGRESS: "WIP",
    ItemType.FINISHED_GOOD: "FG",
}

PRODUCIBLE_TYPES = {ItemType.WORK_IN_PROGRESS, ItemType.FINISHED_GOOD}

ALLOWED_STATUS_CHANGES = {
    LotStatus.QUARANTINE: {LotStatus.RELEASED, LotStatus.BLOCKED},
    LotStatus.RELEASED: {LotStatus.BLOCKED},
    LotStatus.BLOCKED: {LotStatus.RELEASED},
}


def generate_lot_code(item_type: ItemType, on: date) -> str:
    return f"{LOT_CODE_PREFIX[item_type]}-{on:%Y%m%d}-{secrets.token_hex(3).upper()}"


def to_lot_view(lot: Lot, balance: Decimal) -> LotView:
    return LotView(
        id=lot.id,
        lot_code=lot.lot_code,
        item_id=lot.item_id,
        item_code=lot.item.code,
        item_name=lot.item.name,
        origin=lot.origin,
        status=lot.status,
        expiry_date=lot.expiry_date,
        supplier_id=lot.supplier_id,
        supplier_lot_code=lot.supplier_lot_code,
        production_run_id=lot.production_run_id,
        balance=balance,
        created_at=lot.created_at,
    )


class InventoryService:
    def __init__(self, session: Session, actor: Actor) -> None:
        self._session = session
        self._actor = actor
        self._audit = AuditLog(session, actor.tenant_id, actor.user_id)

    # ----- queries -------------------------------------------------------------------

    def get_lot(self, lot_id: UUID) -> LotView:
        lot = self._session.get(Lot, lot_id)
        if lot is None:
            raise NotFoundError("Lot", lot_id)
        return to_lot_view(lot, self._balances([lot.id])[lot.id])

    def list_lots(self, item_id: UUID | None, status: LotStatus | None) -> list[LotView]:
        query = select(Lot).order_by(Lot.created_at.desc())
        if item_id is not None:
            query = query.where(Lot.item_id == item_id)
        if status is not None:
            query = query.where(Lot.status == status)
        lots = list(self._session.scalars(query))
        balances = self._balances(lot.id for lot in lots)
        return [to_lot_view(lot, balances[lot.id]) for lot in lots]

    def fefo_candidates(self, item_id: UUID) -> list[LotView]:
        """Released, unexpired lots with stock, earliest expiry first (First Expired, First Out)."""
        lots = self._session.scalars(
            select(Lot)
            .where(Lot.item_id == item_id, Lot.status == LotStatus.RELEASED)
            .where((Lot.expiry_date.is_(None)) | (Lot.expiry_date >= factory_today()))
            .order_by(Lot.expiry_date.asc().nulls_last(), Lot.created_at)
        ).all()
        balances = self._balances(lot.id for lot in lots)
        return [to_lot_view(lot, balances[lot.id]) for lot in lots if balances[lot.id] > 0]

    # ----- commands ------------------------------------------------------------------

    def receive(self, command: ReceiveLot) -> LotView:
        item = get_or_raise(self._session, Item, command.item_id)
        supplier = get_or_raise(self._session, Supplier, command.supplier_id)
        blocked = receiving_block(self._session, supplier)
        if blocked:
            raise BusinessRuleError(blocked)
        if command.expiry_date is not None and command.expiry_date < factory_today():
            raise BusinessRuleError("Cannot receive a lot that has already expired")

        lot = self._new_lot(
            item,
            origin=LotOrigin.RECEIVED,
            expiry_date=command.expiry_date,
            supplier_id=supplier.id,
            supplier_lot_code=command.supplier_lot_code,
        )
        self._post(lot.id, TransactionType.RECEIPT, command.quantity, reference_id=None)
        self._audit.record("lot.received", "lot", lot.id, command.model_dump())
        return to_lot_view(lot, command.quantity)

    def change_status(self, lot_id: UUID, command: ChangeLotStatus) -> LotView:
        lot = self._lock_lots([lot_id])[0]
        if command.status not in ALLOWED_STATUS_CHANGES[lot.status]:
            raise BusinessRuleError(
                f"Lot {lot.lot_code} cannot change from {lot.status} to {command.status}"
            )
        previous = lot.status
        lot.status = command.status
        self._session.flush()
        self._audit.record(
            "lot.status_changed",
            "lot",
            lot.id,
            {"from": previous, "to": command.status, "reason": command.reason},
        )
        return self.get_lot(lot.id)

    def record_production(self, command: RecordProduction) -> ProductionView:
        output_item = get_or_raise(self._session, Item, command.output_item_id)
        if output_item.item_type not in PRODUCIBLE_TYPES:
            raise BusinessRuleError(f"Item '{output_item.code}' cannot be a production output")

        inputs = self._lock_and_check_available(command.inputs)

        run = ProductionRun(
            tenant_id=self._actor.tenant_id,
            reference=command.reference,
            recorded_at=datetime.now(UTC),
            recorded_by=self._actor.user_id,
        )
        self._session.add(run)
        self._session.flush()

        output_lot = self._new_lot(
            output_item,
            origin=LotOrigin.PRODUCED,
            expiry_date=command.output_expiry_date or self._default_expiry(output_item),
            production_run_id=run.id,
        )
        self._post(
            output_lot.id, TransactionType.PRODUCTION_OUTPUT, command.output_quantity, run.id
        )
        for line in command.inputs:
            self._post(line.lot_id, TransactionType.CONSUMPTION, -line.quantity, run.id)
            self._session.add(
                LotLink(
                    tenant_id=self._actor.tenant_id,
                    production_run_id=run.id,
                    parent_lot_id=inputs[line.lot_id].id,
                    child_lot_id=output_lot.id,
                    quantity=line.quantity,
                )
            )
        self._session.flush()
        self._audit.record("production.recorded", "production_run", run.id, command.model_dump())
        return ProductionView(
            production_run_id=run.id,
            reference=run.reference,
            output_lot=to_lot_view(output_lot, command.output_quantity),
        )

    def record_shipment(self, command: RecordShipment) -> ShipmentView:
        customer = get_or_raise(self._session, Customer, command.customer_id)
        lots = self._lock_and_check_available(command.lines)
        for lot in lots.values():
            if lot.item.item_type != ItemType.FINISHED_GOOD:
                raise BusinessRuleError(f"Lot {lot.lot_code} is not a finished good")

        shipment = Shipment(
            tenant_id=self._actor.tenant_id,
            customer_id=customer.id,
            reference=command.reference,
            shipped_at=datetime.now(UTC),
            recorded_by=self._actor.user_id,
        )
        self._session.add(shipment)
        self._session.flush()
        for line in command.lines:
            self._session.add(
                ShipmentLine(
                    tenant_id=self._actor.tenant_id,
                    shipment_id=shipment.id,
                    lot_id=line.lot_id,
                    quantity=line.quantity,
                )
            )
            self._post(line.lot_id, TransactionType.DISPATCH, -line.quantity, shipment.id)
        self._session.flush()
        self._audit.record("shipment.recorded", "shipment", shipment.id, command.model_dump())
        return ShipmentView(
            id=shipment.id,
            reference=shipment.reference,
            customer_id=customer.id,
            shipped_at=shipment.shipped_at,
            lines=[ShipmentLineView(lot_id=x.lot_id, quantity=x.quantity) for x in command.lines],
        )

    # ----- helpers -------------------------------------------------------------------

    def _new_lot(
        self,
        item: Item,
        *,
        origin: LotOrigin,
        expiry_date: date | None,
        supplier_id: UUID | None = None,
        supplier_lot_code: str | None = None,
        production_run_id: UUID | None = None,
    ) -> Lot:
        lot = Lot(
            tenant_id=self._actor.tenant_id,
            lot_code=generate_lot_code(item.item_type, factory_today()),
            item_id=item.id,
            item=item,
            origin=origin,
            status=LotStatus.QUARANTINE,  # every new lot needs a quality release
            expiry_date=expiry_date,
            supplier_id=supplier_id,
            supplier_lot_code=supplier_lot_code,
            production_run_id=production_run_id,
            created_by=self._actor.user_id,
        )
        self._session.add(lot)
        self._session.flush()
        return lot

    def _post(
        self,
        lot_id: UUID,
        transaction_type: TransactionType,
        quantity: Decimal,
        reference_id: UUID | None,
    ) -> None:
        self._session.add(
            LotTransaction(
                tenant_id=self._actor.tenant_id,
                lot_id=lot_id,
                transaction_type=transaction_type,
                quantity=quantity,
                reference_id=reference_id,
                created_by=self._actor.user_id,
            )
        )

    def _lock_lots(self, lot_ids: Sequence[UUID]) -> list[Lot]:
        # Lock in a fixed order so concurrent requests cannot deadlock.
        lots = list(
            self._session.scalars(
                select(Lot).where(Lot.id.in_(lot_ids)).order_by(Lot.id).with_for_update(of=Lot)
            ).unique()
        )
        missing = set(lot_ids) - {lot.id for lot in lots}
        if missing:
            raise NotFoundError("Lot", sorted(missing)[0])
        return lots

    def _lock_and_check_available(self, lines: Sequence[LotQuantity]) -> dict[UUID, Lot]:
        lots = {lot.id: lot for lot in self._lock_lots([line.lot_id for line in lines])}
        balances = self._balances(lots)
        today = factory_today()
        for line in lines:
            lot = lots[line.lot_id]
            if lot.status != LotStatus.RELEASED:
                raise BusinessRuleError(f"Lot {lot.lot_code} is {lot.status}, not released")
            if lot.expiry_date is not None and lot.expiry_date < today:
                raise BusinessRuleError(f"Lot {lot.lot_code} expired on {lot.expiry_date}")
            if balances[lot.id] < line.quantity:
                raise BusinessRuleError(
                    f"Lot {lot.lot_code} has {balances[lot.id]} {lot.item.uom}, "
                    f"{line.quantity} requested"
                )
        return lots

    def _balances(self, lot_ids: Iterable[UUID]) -> dict[UUID, Decimal]:
        ids = list(lot_ids)
        rows = self._session.execute(
            select(LotTransaction.lot_id, func.sum(LotTransaction.quantity))
            .where(LotTransaction.lot_id.in_(ids))
            .group_by(LotTransaction.lot_id)
        ).all()
        totals: dict[UUID, Decimal] = {lot_id: Decimal("0") for lot_id in ids}
        totals.update({lot_id: total for lot_id, total in rows})
        return totals

    @staticmethod
    def _default_expiry(item: Item) -> date | None:
        if item.shelf_life_days is None:
            return None
        return factory_today() + timedelta(days=item.shelf_life_days)
