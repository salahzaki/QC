"""Corrective actions (CAPA) for deviations.

Every CCP reading outside its critical limits and every failed sanitation check opens one
corrective action and raises an alert. The immediate action is the one written on the
record. A quality manager closes the corrective action once, with the root cause, the
preventive action and what happened to affected product, and signs it "approved".
"""

from collections.abc import Iterable
from datetime import UTC, datetime
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.orm import Session

from compliance_engine.core.errors import BusinessRuleError, ConflictError, NotFoundError
from compliance_engine.models import CorrectiveAction, RecordSignature
from compliance_engine.models.enums import AlertKind, CorrectiveActionStatus, SignatureMeaning
from compliance_engine.schemas.capa import CloseCorrectiveAction, CorrectiveActionView
from compliance_engine.services import numbering  # noqa: F401  (assigns record numbers)
from compliance_engine.services.alerts import AlertService
from compliance_engine.services.audit import AuditLog
from compliance_engine.services.context import Actor
from compliance_engine.services.signatures import SignatureService


class CapaService:
    def __init__(self, session: Session, actor: Actor) -> None:
        self._session = session
        self._actor = actor
        self._audit = AuditLog(session, actor.tenant_id, actor.user_id)
        self._signatures = SignatureService(session, actor)

    def open_for_deviation(
        self,
        *,
        record_type: str,
        record_id: UUID,
        description: str,
        immediate_action: str,
        alert_kind: AlertKind,
        control_point_id: UUID | None = None,
        lot_id: UUID | None = None,
    ) -> CorrectiveAction:
        action = CorrectiveAction(
            tenant_id=self._actor.tenant_id,
            record_type=record_type,
            record_id=record_id,
            control_point_id=control_point_id,
            lot_id=lot_id,
            description=description,
            immediate_action=immediate_action,
            opened_at=datetime.now(UTC),
            opened_by=self._actor.user_id,
            status=CorrectiveActionStatus.OPEN,
        )
        self._session.add(action)
        self._session.flush()
        self._audit.record(
            "corrective_action.opened",
            "corrective_action",
            action.id,
            {"record_type": record_type, "record_id": record_id, "description": description},
        )
        AlertService.for_actor(self._session, self._actor).raise_alert(
            alert_kind,
            description,
            record_type=record_type,
            record_id=record_id,
            control_point_id=control_point_id,
        )
        return action

    def for_records(self, record_ids: Iterable[UUID]) -> dict[UUID, CorrectiveAction]:
        ids = list(record_ids)
        if not ids:
            return {}
        actions = self._session.scalars(
            select(CorrectiveAction).where(CorrectiveAction.record_id.in_(ids))
        )
        return {action.record_id: action for action in actions}

    def list_actions(
        self,
        status: CorrectiveActionStatus | None,
        opened_from: datetime | None = None,
        opened_to: datetime | None = None,
        limit: int = 500,
    ) -> list[CorrectiveActionView]:
        query = select(CorrectiveAction).order_by(CorrectiveAction.opened_at.desc()).limit(limit)
        if status is not None:
            query = query.where(CorrectiveAction.status == status)
        if opened_from is not None:
            query = query.where(CorrectiveAction.opened_at >= opened_from)
        if opened_to is not None:
            query = query.where(CorrectiveAction.opened_at < opened_to)
        actions = list(self._session.scalars(query))
        signatures = self._signatures.for_records(CorrectiveAction, (a.id for a in actions))
        return [self._view(a, signatures[a.id]) for a in actions]

    def get(self, action_id: UUID) -> CorrectiveActionView:
        return self._view(self._get(action_id))

    def close(self, action_id: UUID, command: CloseCorrectiveAction) -> CorrectiveActionView:
        action = self._get(action_id, lock=True)
        if action.status == CorrectiveActionStatus.CLOSED:
            raise ConflictError("This corrective action is already closed")
        if action.opened_by == self._actor.user_id:
            raise BusinessRuleError(
                "A corrective action must be closed by someone other than the person who "
                "recorded the deviation"
            )
        action.status = CorrectiveActionStatus.CLOSED
        action.root_cause = command.root_cause
        action.preventive_action = command.preventive_action
        action.product_disposition = command.product_disposition
        action.closed_at = datetime.now(UTC)
        action.closed_by = self._actor.user_id
        self._session.flush()
        self._audit.record(
            "corrective_action.closed",
            "corrective_action",
            action.id,
            command.model_dump(exclude={"password"}),
        )
        self._signatures.sign(
            action, SignatureMeaning.APPROVED, command.password.get_secret_value(), command.comment
        )
        return self._view(action)

    def _get(self, action_id: UUID, lock: bool = False) -> CorrectiveAction:
        action = self._session.get(CorrectiveAction, action_id, with_for_update=lock)
        if action is None:
            raise NotFoundError("Corrective action", action_id)
        return action

    def _view(
        self, action: CorrectiveAction, signatures: list[RecordSignature] | None = None
    ) -> CorrectiveActionView:
        signed = (
            signatures
            if signatures is not None
            else self._signatures.for_records(CorrectiveAction, [action.id])[action.id]
        )
        return CorrectiveActionView(
            id=action.id,
            serial=action.serial,
            record_type=action.record_type,
            record_id=action.record_id,
            control_point_id=action.control_point_id,
            lot_id=action.lot_id,
            description=action.description,
            immediate_action=action.immediate_action,
            opened_at=action.opened_at,
            opened_by=action.opened_by,
            status=action.status,
            root_cause=action.root_cause,
            preventive_action=action.preventive_action,
            product_disposition=action.product_disposition,
            closed_at=action.closed_at,
            closed_by=action.closed_by,
            signatures=self._signatures.views(action, signed),
        )
