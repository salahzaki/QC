from uuid import UUID

from fastapi import APIRouter, Depends, status

from compliance_engine.api.deps import DbSession, require
from compliance_engine.core.permissions import Permission
from compliance_engine.models.enums import LotStatus
from compliance_engine.schemas.inventory import (
    ChangeLotStatus,
    LotView,
    ProductionView,
    ReceiveLot,
    RecordProduction,
    RecordShipment,
    ShipmentView,
)
from compliance_engine.services.context import Actor
from compliance_engine.services.inventory import InventoryService

router = APIRouter(tags=["inventory"])

can_read = require(Permission.LOTS_READ)


@router.post("/lots/receipts", status_code=status.HTTP_201_CREATED)
def receive_lot(
    command: ReceiveLot,
    session: DbSession,
    actor: Actor = Depends(require(Permission.LOTS_RECEIVE)),
) -> LotView:
    return InventoryService(session, actor).receive(command)


@router.get("/lots")
def list_lots(
    session: DbSession,
    item_id: UUID | None = None,
    lot_status: LotStatus | None = None,
    actor: Actor = Depends(can_read),
) -> list[LotView]:
    return InventoryService(session, actor).list_lots(item_id, lot_status)


@router.get("/lots/{lot_id}")
def get_lot(lot_id: UUID, session: DbSession, actor: Actor = Depends(can_read)) -> LotView:
    return InventoryService(session, actor).get_lot(lot_id)


@router.post("/lots/{lot_id}/status")
def change_lot_status(
    lot_id: UUID,
    command: ChangeLotStatus,
    session: DbSession,
    actor: Actor = Depends(require(Permission.LOTS_RELEASE)),
) -> LotView:
    return InventoryService(session, actor).change_status(lot_id, command)


@router.get("/items/{item_id}/fefo")
def fefo_candidates(
    item_id: UUID, session: DbSession, actor: Actor = Depends(can_read)
) -> list[LotView]:
    return InventoryService(session, actor).fefo_candidates(item_id)


@router.post("/production-runs", status_code=status.HTTP_201_CREATED)
def record_production(
    command: RecordProduction,
    session: DbSession,
    actor: Actor = Depends(require(Permission.PRODUCTION_RECORD)),
) -> ProductionView:
    return InventoryService(session, actor).record_production(command)


@router.post("/shipments", status_code=status.HTTP_201_CREATED)
def record_shipment(
    command: RecordShipment,
    session: DbSession,
    actor: Actor = Depends(require(Permission.SHIPMENTS_RECORD)),
) -> ShipmentView:
    return InventoryService(session, actor).record_shipment(command)
