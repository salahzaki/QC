from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Depends, Query, status

from compliance_engine.api.deps import DbSession, require
from compliance_engine.core.permissions import Permission
from compliance_engine.schemas.training import (
    Competence,
    CourseView,
    CreateCourse,
    RecordTraining,
    TrainingMatrix,
    TrainingRecordView,
    UpdateCourse,
)
from compliance_engine.services.context import Actor
from compliance_engine.services.training import TrainingService

router = APIRouter(prefix="/training", tags=["training"])
reader = Depends(require(Permission.RECORDS_READ))
manager = Depends(require(Permission.TRAINING_MANAGE))


@router.get("/courses")
def list_courses(session: DbSession, actor: Actor = reader) -> list[CourseView]:
    return TrainingService(session, actor).list_courses()


@router.post("/courses", status_code=status.HTTP_201_CREATED)
def create_course(command: CreateCourse, session: DbSession, actor: Actor = manager) -> CourseView:
    return TrainingService(session, actor).create_course(command)


@router.patch("/courses/{course_id}")
def update_course(
    course_id: UUID, command: UpdateCourse, session: DbSession, actor: Actor = manager
) -> CourseView:
    return TrainingService(session, actor).update_course(course_id, command)


@router.post("/records", status_code=status.HTTP_201_CREATED)
def record_training(
    command: RecordTraining, session: DbSession, actor: Actor = manager
) -> list[TrainingRecordView]:
    """Record a training session: one numbered record per attendee, signed with your password."""
    return TrainingService(session, actor).record(command)


@router.get("/records")
def list_records(
    session: DbSession,
    user_id: UUID | None = None,
    course_id: UUID | None = None,
    limit: Annotated[int, Query(ge=1, le=1000)] = 200,
    actor: Actor = reader,
) -> list[TrainingRecordView]:
    return TrainingService(session, actor).list_records(user_id, course_id, limit)


@router.get("/matrix")
def matrix(session: DbSession, actor: Actor = reader) -> TrainingMatrix:
    """Every active person against the courses their role requires."""
    return TrainingService(session, actor).matrix()


@router.get("/my-competence")
def my_competence(session: DbSession, actor: Actor = reader) -> list[Competence]:
    """For each control point: may I record it (valid training on its linked courses)?"""
    return TrainingService(session, actor).my_competence()
