from urllib.parse import quote
from uuid import UUID

from fastapi import APIRouter, Depends, Response, status

from compliance_engine.api.deps import DbSession, require
from compliance_engine.core.permissions import Permission
from compliance_engine.schemas.master_data import SupplierView, UpdateSupplier
from compliance_engine.schemas.suppliers import (
    AddSupplierDocument,
    ApprovalView,
    DecideApproval,
    EvaluateSupplier,
    EvaluationView,
    SupplierDetail,
    SupplierDocumentView,
    SupplierSummary,
    WithdrawDocument,
)
from compliance_engine.services.context import Actor
from compliance_engine.services.suppliers import SupplierService

router = APIRouter(tags=["supplier approval"])
reader = Depends(require(Permission.MASTER_DATA_READ))
manager = Depends(require(Permission.SUPPLIERS_MANAGE))


@router.get("/suppliers/overview")
def overview(session: DbSession, actor: Actor = reader) -> list[SupplierSummary]:
    """Every supplier with its approval status, documents, last score and whether goods can
    be received from it now (the approved supplier list)."""
    return SupplierService(session, actor).overview()


@router.get("/suppliers/{supplier_id}")
def detail(supplier_id: UUID, session: DbSession, actor: Actor = reader) -> SupplierDetail:
    """A supplier with its documents, signed approval decisions and evaluations."""
    return SupplierService(session, actor).detail(supplier_id)


@router.patch("/suppliers/{supplier_id}")
def update(
    supplier_id: UUID, command: UpdateSupplier, session: DbSession, actor: Actor = manager
) -> SupplierView:
    return SupplierView.model_validate(SupplierService(session, actor).update(supplier_id, command))


@router.post("/suppliers/{supplier_id}/decisions", status_code=status.HTTP_201_CREATED)
def decide(
    supplier_id: UUID, command: DecideApproval, session: DbSession, actor: Actor = manager
) -> ApprovalView:
    """Approve, approve with conditions, suspend or reject; signed with your password."""
    return SupplierService(session, actor).decide(supplier_id, command)


@router.post("/suppliers/{supplier_id}/documents", status_code=status.HTTP_201_CREATED)
def add_document(
    supplier_id: UUID, command: AddSupplierDocument, session: DbSession, actor: Actor = manager
) -> SupplierDocumentView:
    return SupplierService(session, actor).add_document(supplier_id, command)


@router.post("/supplier-documents/{document_id}/withdraw")
def withdraw_document(
    document_id: UUID, command: WithdrawDocument, session: DbSession, actor: Actor = manager
) -> SupplierDocumentView:
    """Mark a document as no longer in force (e.g. replaced by a renewed certificate)."""
    return SupplierService(session, actor).withdraw_document(document_id, command)


@router.get(
    "/supplier-documents/{document_id}/file",
    response_class=Response,
    responses={200: {"content": {"application/pdf": {}, "image/*": {}}}},
)
def document_file(document_id: UUID, session: DbSession, actor: Actor = reader) -> Response:
    name, content_type, content = SupplierService(session, actor).document_file(document_id)
    return Response(
        content=content,
        media_type=content_type,
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(name)}"},
    )


@router.post("/suppliers/{supplier_id}/evaluations", status_code=status.HTTP_201_CREATED)
def evaluate(
    supplier_id: UUID, command: EvaluateSupplier, session: DbSession, actor: Actor = manager
) -> EvaluationView:
    """Score the supplier for a period; signed with your password."""
    return SupplierService(session, actor).evaluate(supplier_id, command)
