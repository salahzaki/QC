from typing import Annotated

from fastapi import APIRouter, Depends, Query, Request

from compliance_engine.api.deps import DbSession, require
from compliance_engine.core.errors import BusinessRuleError
from compliance_engine.core.permissions import Permission
from compliance_engine.schemas.documents import (
    DocumentFormView,
    IssuedReportView,
    ReportCheck,
    UpdateDocumentForm,
)
from compliance_engine.services.context import Actor
from compliance_engine.services.documents import DocumentService

router = APIRouter(tags=["document control"])
reader = Depends(require(Permission.RECORDS_READ))
MAX_PDF_BYTES = 20 * 1024 * 1024


@router.get("/document-forms")
def list_forms(session: DbSession, actor: Actor = reader) -> list[DocumentFormView]:
    """The controlled forms behind each report: code, revision and effective date are printed
    on every page of the report."""
    return DocumentService(session, actor).list_forms()


@router.patch("/document-forms/{key}")
def update_form(
    key: str,
    command: UpdateDocumentForm,
    session: DbSession,
    actor: Actor = Depends(require(Permission.DOCUMENTS_MANAGE)),
) -> DocumentFormView:
    """Change a form's code, titles or reference; content changes need a new revision."""
    return DocumentService(session, actor).update_form(key, command)


@router.get("/issued-reports")
def list_issued_reports(
    session: DbSession, limit: Annotated[int, Query(ge=1, le=500)] = 100, actor: Actor = reader
) -> list[IssuedReportView]:
    """Every report PDF the system produced, newest first."""
    return DocumentService(session, actor).list_reports(limit)


@router.get("/issued-reports/{serial}")
def get_issued_report(serial: str, session: DbSession, actor: Actor = reader) -> IssuedReportView:
    return DocumentService(session, actor).get_report(serial)


@router.post(
    "/issued-reports/check",
    openapi_extra={
        "requestBody": {
            "required": True,
            "content": {"application/pdf": {"schema": {"type": "string", "format": "binary"}}},
        }
    },
)
async def check_report_file(
    request: Request, session: DbSession, actor: Actor = reader
) -> ReportCheck:
    """Send a report PDF as the request body: is it exactly a file this system issued?"""
    content = await request.body()
    if not content or len(content) > MAX_PDF_BYTES:
        raise BusinessRuleError("Send the PDF file (at most 20 MB) as the request body")
    return DocumentService(session, actor).check_file(content)
