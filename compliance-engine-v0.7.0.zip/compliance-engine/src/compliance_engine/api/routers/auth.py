from uuid import UUID

from fastapi import APIRouter, Depends, status

from compliance_engine.api.deps import DbSession, get_actor, require
from compliance_engine.core.errors import PermissionDeniedError
from compliance_engine.core.permissions import Permission, has_permission
from compliance_engine.schemas.identity import (
    ChangePassword,
    CreateUser,
    LoginRequest,
    PersonView,
    ResetPassword,
    TokenResponse,
    UpdateUser,
    UserView,
)
from compliance_engine.services import identity
from compliance_engine.services.context import Actor
from compliance_engine.services.identity import UserService

router = APIRouter(tags=["identity"])


@router.post("/auth/token")
def login(request: LoginRequest, session: DbSession) -> TokenResponse:
    return TokenResponse(access_token=identity.login(session, request))


@router.post("/auth/change-password", status_code=status.HTTP_204_NO_CONTENT)
def change_password(
    command: ChangePassword, session: DbSession, actor: Actor = Depends(get_actor)
) -> None:
    """Change your own password. You need the current one."""
    UserService(session, actor).change_own_password(command)


@router.post("/users", status_code=status.HTTP_201_CREATED)
def create_user(
    command: CreateUser,
    session: DbSession,
    actor: Actor = Depends(require(Permission.USERS_MANAGE)),
) -> UserView:
    return UserView.model_validate(UserService(session, actor).create(command))


@router.get("/users")
def list_users(
    session: DbSession, actor: Actor = Depends(require(Permission.USERS_MANAGE))
) -> list[UserView]:
    return [UserView.model_validate(u) for u in UserService(session, actor).list_users()]


@router.get("/people")
def list_people(
    session: DbSession, actor: Actor = Depends(require(Permission.RECORDS_READ))
) -> list[PersonView]:
    """Active users with their role and contact, for choosing trainees and alert recipients."""
    if not (
        has_permission(actor.role, Permission.TRAINING_MANAGE)
        or has_permission(actor.role, Permission.NOTIFICATIONS_MANAGE)
    ):
        raise PermissionDeniedError(f"Role '{actor.role}' lacks permission 'training:manage'")
    return [PersonView.model_validate(u) for u in UserService(session, actor).people()]


@router.post("/users/{user_id}/reset-password")
def reset_password(
    user_id: UUID,
    command: ResetPassword,
    session: DbSession,
    actor: Actor = Depends(require(Permission.USERS_MANAGE)),
) -> UserView:
    """Set a new password for a user who forgot theirs (admin only)."""
    return UserView.model_validate(UserService(session, actor).reset_password(user_id, command))


@router.patch("/users/{user_id}")
def update_user(
    user_id: UUID,
    command: UpdateUser,
    session: DbSession,
    actor: Actor = Depends(require(Permission.USERS_MANAGE)),
) -> UserView:
    """Change a user's name or role, or deactivate them (admin only)."""
    return UserView.model_validate(UserService(session, actor).update(user_id, command))


@router.post("/users/{user_id}/unlock")
def unlock_user(
    user_id: UUID,
    session: DbSession,
    actor: Actor = Depends(require(Permission.USERS_MANAGE)),
) -> UserView:
    """Unlock an account locked after too many wrong passwords (admin only)."""
    return UserView.model_validate(UserService(session, actor).unlock(user_id))


@router.get("/auth/me")
def me(session: DbSession, actor: Actor = Depends(get_actor)) -> UserView:
    """The signed-in user."""
    return UserView.model_validate(UserService(session, actor).me())
