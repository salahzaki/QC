from fastapi import APIRouter, Depends

from compliance_engine.api.deps import DbSession, require
from compliance_engine.core.permissions import Permission
from compliance_engine.schemas.settings import (
    NotificationSettingsView,
    QualitySettingsView,
    UpdateEmailSettings,
    UpdateQualitySettings,
    UpdateWhatsAppSettings,
)
from compliance_engine.services.context import Actor
from compliance_engine.services.settings import SettingsService

router = APIRouter(prefix="/settings", tags=["settings"])
notifications_manager = Depends(require(Permission.NOTIFICATIONS_MANAGE))


@router.get("/notifications")
def notification_settings(
    session: DbSession, actor: Actor = notifications_manager
) -> NotificationSettingsView:
    """The mail server and WhatsApp number alerts are sent from. Secrets are never returned."""
    return SettingsService(session, actor).notifications()


@router.put("/notifications/email")
def update_email(
    command: UpdateEmailSettings, session: DbSession, actor: Actor = notifications_manager
) -> NotificationSettingsView:
    """Set the mail server for this factory (replaces CE_SMTP_* from .env)."""
    return SettingsService(session, actor).update_email(command)


@router.put("/notifications/whatsapp")
def update_whatsapp(
    command: UpdateWhatsAppSettings, session: DbSession, actor: Actor = notifications_manager
) -> NotificationSettingsView:
    """Set the WhatsApp Business number for this factory (replaces CE_WHATSAPP_* from .env)."""
    return SettingsService(session, actor).update_whatsapp(command)


@router.get("/quality")
def quality_settings(
    session: DbSession, actor: Actor = Depends(require(Permission.RECORDS_READ))
) -> QualitySettingsView:
    return SettingsService(session, actor).quality()


@router.patch("/quality")
def update_quality_settings(
    command: UpdateQualitySettings,
    session: DbSession,
    actor: Actor = Depends(require(Permission.TRAINING_MANAGE)),
) -> QualitySettingsView:
    """Turn the competence gate on or off, and set how early expiries are warned about."""
    return SettingsService(session, actor).update_quality(command)
