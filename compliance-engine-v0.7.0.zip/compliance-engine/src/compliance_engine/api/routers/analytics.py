from datetime import date
from uuid import UUID

from fastapi import APIRouter, Depends

from compliance_engine.api.deps import DbSession, require
from compliance_engine.core.permissions import Permission
from compliance_engine.schemas.analytics import Analytics, Live
from compliance_engine.services.analytics import AnalyticsService
from compliance_engine.services.context import Actor
from compliance_engine.services.reports import make_period

router = APIRouter(prefix="/analytics", tags=["dashboard & analytics"])

can_read = require(Permission.RECORDS_READ)


@router.get(
    "",
    description="KPIs, trends, control charts and breakdowns for a period, with the same "
    "figures for the period just before it. Days are in the factory time zone; the default "
    "is the last 7 days.",
)
def analytics(
    session: DbSession,
    date_from: date | None = None,
    date_to: date | None = None,
    control_point_id: UUID | None = None,
    actor: Actor = Depends(can_read),
) -> Analytics:
    period = make_period(date_from, date_to)
    return AnalyticsService(session, actor).overview(period, control_point_id)


@router.get("/live", description="Status of every control point now, and the latest activity.")
def live(session: DbSession, actor: Actor = Depends(can_read)) -> Live:
    return AnalyticsService(session, actor).live()
