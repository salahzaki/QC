from uuid import UUID

from fastapi import APIRouter, Depends, Query, status
from pydantic import AwareDatetime

from compliance_engine.api.deps import DbSession, require
from compliance_engine.core.permissions import Permission
from compliance_engine.schemas.records import (
    AmendCcpReading,
    AmendmentView,
    AmendSanitation,
    CcpReadingView,
    ControlPointView,
    CreateControlPoint,
    RecordCcpReading,
    RecordSanitation,
    SanitationRecordView,
    SignRecord,
    UpdateControlPoint,
)
from compliance_engine.services.context import Actor
from compliance_engine.services.records import RecordsService

router = APIRouter(tags=["CCP & sanitation"])

can_read = require(Permission.RECORDS_READ)
can_write = require(Permission.RECORDS_WRITE)
can_verify = require(Permission.RECORDS_VERIFY)
Limit = Query(default=100, ge=1, le=500)


@router.post("/control-points", status_code=status.HTTP_201_CREATED)
def create_control_point(
    command: CreateControlPoint,
    session: DbSession,
    actor: Actor = Depends(require(Permission.CCP_MANAGE)),
) -> ControlPointView:
    control_point = RecordsService(session, actor).create_control_point(command)
    return ControlPointView.model_validate(control_point)


@router.patch("/control-points/{control_point_id}")
def update_control_point(
    control_point_id: UUID,
    command: UpdateControlPoint,
    session: DbSession,
    actor: Actor = Depends(require(Permission.CCP_MANAGE)),
) -> ControlPointView:
    control_point = RecordsService(session, actor).update_control_point(control_point_id, command)
    return ControlPointView.model_validate(control_point)


@router.get("/control-points")
def list_control_points(
    session: DbSession, actor: Actor = Depends(can_read)
) -> list[ControlPointView]:
    service = RecordsService(session, actor)
    return [ControlPointView.model_validate(x) for x in service.list_control_points()]


@router.post("/ccp-readings", status_code=status.HTTP_201_CREATED)
def record_ccp_reading(
    command: RecordCcpReading, session: DbSession, actor: Actor = Depends(can_write)
) -> CcpReadingView:
    return RecordsService(session, actor).record_ccp_reading(command)


@router.get("/ccp-readings")
def list_ccp_readings(
    session: DbSession,
    control_point_id: UUID | None = None,
    deviations_only: bool = False,
    unverified_only: bool = False,
    measured_from: AwareDatetime | None = None,
    measured_to: AwareDatetime | None = None,
    limit: int = Limit,
    actor: Actor = Depends(can_read),
) -> list[CcpReadingView]:
    return RecordsService(session, actor).list_ccp_readings(
        control_point_id, deviations_only, unverified_only, limit, measured_from, measured_to
    )


@router.get("/ccp-readings/{reading_id}")
def get_ccp_reading(
    reading_id: UUID, session: DbSession, actor: Actor = Depends(can_read)
) -> CcpReadingView:
    return RecordsService(session, actor).get_ccp_reading(reading_id)


@router.post("/ccp-readings/{reading_id}/verify")
def verify_ccp_reading(
    reading_id: UUID, command: SignRecord, session: DbSession, actor: Actor = Depends(can_verify)
) -> CcpReadingView:
    return RecordsService(session, actor).verify_ccp_reading(reading_id, command)


@router.post("/sanitation-records", status_code=status.HTTP_201_CREATED)
def record_sanitation(
    command: RecordSanitation, session: DbSession, actor: Actor = Depends(can_write)
) -> SanitationRecordView:
    return RecordsService(session, actor).record_sanitation(command)


@router.get("/sanitation-records")
def list_sanitation_records(
    session: DbSession,
    area: str | None = None,
    failures_only: bool = False,
    unverified_only: bool = False,
    performed_from: AwareDatetime | None = None,
    performed_to: AwareDatetime | None = None,
    limit: int = Limit,
    actor: Actor = Depends(can_read),
) -> list[SanitationRecordView]:
    return RecordsService(session, actor).list_sanitation(
        area, failures_only, unverified_only, limit, performed_from, performed_to
    )


@router.get("/sanitation-records/{record_id}")
def get_sanitation_record(
    record_id: UUID, session: DbSession, actor: Actor = Depends(can_read)
) -> SanitationRecordView:
    return RecordsService(session, actor).get_sanitation(record_id)


@router.post("/sanitation-records/{record_id}/verify")
def verify_sanitation_record(
    record_id: UUID, command: SignRecord, session: DbSession, actor: Actor = Depends(can_verify)
) -> SanitationRecordView:
    return RecordsService(session, actor).verify_sanitation(record_id, command)


@router.post("/ccp-readings/{reading_id}/amendments", status_code=status.HTTP_201_CREATED)
def amend_ccp_reading(
    reading_id: UUID,
    command: AmendCcpReading,
    session: DbSession,
    actor: Actor = Depends(can_write),
) -> CcpReadingView:
    """Correct a CCP reading. The original stays; the correction is signed and needs
    verification by a second person."""
    return RecordsService(session, actor).amend_ccp_reading(reading_id, command)


@router.post("/sanitation-records/{record_id}/amendments", status_code=status.HTTP_201_CREATED)
def amend_sanitation_record(
    record_id: UUID, command: AmendSanitation, session: DbSession, actor: Actor = Depends(can_write)
) -> SanitationRecordView:
    """Correct a sanitation record. The original stays; the correction is signed and needs
    verification by a second person."""
    return RecordsService(session, actor).amend_sanitation(record_id, command)


@router.get("/amendments")
def list_amendments(
    session: DbSession,
    unverified_only: bool = False,
    limit: int = Limit,
    actor: Actor = Depends(can_read),
) -> list[AmendmentView]:
    return RecordsService(session, actor).list_amendments(unverified_only, limit)


@router.post("/amendments/{amendment_id}/verify")
def verify_amendment(
    amendment_id: UUID, command: SignRecord, session: DbSession, actor: Actor = Depends(can_verify)
) -> AmendmentView:
    return RecordsService(session, actor).verify_amendment(amendment_id, command)
