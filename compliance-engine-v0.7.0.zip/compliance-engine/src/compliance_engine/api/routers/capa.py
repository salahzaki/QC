from uuid import UUID

from fastapi import APIRouter, Depends, Query

from compliance_engine.api.deps import DbSession, require
from compliance_engine.core.permissions import Permission
from compliance_engine.models.enums import AlertKind, CorrectiveActionStatus
from compliance_engine.schemas.capa import (
    AcknowledgeAlert,
    AlertSummary,
    AlertView,
    CloseCorrectiveAction,
    CorrectiveActionView,
    ScanResult,
)
from compliance_engine.services.alerts import AlertService
from compliance_engine.services.capa import CapaService
from compliance_engine.services.context import Actor

router = APIRouter(tags=["corrective actions & alerts"])

can_read = require(Permission.RECORDS_READ)
Limit = Query(default=100, ge=1, le=500)


@router.get("/corrective-actions")
def list_corrective_actions(
    session: DbSession,
    status: CorrectiveActionStatus | None = None,
    limit: int = Limit,
    actor: Actor = Depends(can_read),
) -> list[CorrectiveActionView]:
    return CapaService(session, actor).list_actions(status, limit=limit)


@router.get("/corrective-actions/{action_id}")
def get_corrective_action(
    action_id: UUID, session: DbSession, actor: Actor = Depends(can_read)
) -> CorrectiveActionView:
    return CapaService(session, actor).get(action_id)


@router.post("/corrective-actions/{action_id}/close")
def close_corrective_action(
    action_id: UUID,
    command: CloseCorrectiveAction,
    session: DbSession,
    actor: Actor = Depends(require(Permission.CAPA_CLOSE)),
) -> CorrectiveActionView:
    """Close with root cause, preventive action and product disposition; signed "approved"."""
    return CapaService(session, actor).close(action_id, command)


@router.get("/alerts")
def list_alerts(
    session: DbSession,
    open_only: bool = True,
    kind: AlertKind | None = None,
    limit: int = Limit,
    actor: Actor = Depends(can_read),
) -> list[AlertView]:
    alerts = AlertService.for_actor(session, actor).list_alerts(open_only, kind, limit)
    return [AlertView.model_validate(a) for a in alerts]


@router.get("/alerts/summary")
def alert_summary(session: DbSession, actor: Actor = Depends(can_read)) -> AlertSummary:
    """Counts for a dashboard badge: open alerts, open corrective actions, unsigned records."""
    return AlertService.for_actor(session, actor).summary()


@router.post("/alerts/{alert_id}/acknowledge")
def acknowledge_alert(
    alert_id: UUID,
    command: AcknowledgeAlert,
    session: DbSession,
    actor: Actor = Depends(require(Permission.RECORDS_VERIFY)),
) -> AlertView:
    alert = AlertService.for_actor(session, actor).acknowledge(alert_id, command)
    return AlertView.model_validate(alert)


@router.post("/alerts/scan-missed-checks")
def scan_missed_checks(
    session: DbSession, actor: Actor = Depends(require(Permission.RECORDS_VERIFY))
) -> ScanResult:
    """Check now for overdue CCP checks. The server also does this by itself every few
    minutes (CE_ALERT_SCAN_SECONDS)."""
    alerts = AlertService.for_actor(session, actor).scan_missed_checks()
    return ScanResult(alerts_raised=[AlertView.model_validate(a) for a in alerts])
