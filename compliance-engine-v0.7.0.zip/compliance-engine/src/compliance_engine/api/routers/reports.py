from datetime import date
from typing import Any
from urllib.parse import quote
from uuid import UUID

from fastapi import APIRouter, Depends, Response

from compliance_engine.api.deps import DbSession, require
from compliance_engine.core.permissions import Permission
from compliance_engine.models.enums import CorrectiveActionStatus
from compliance_engine.reports.pdf import Lang
from compliance_engine.schemas.reports import HaccpSummary
from compliance_engine.services.context import Actor
from compliance_engine.services.reports import RenderedReport, ReportService, make_period

router = APIRouter(prefix="/reports", tags=["reports"])

can_read = require(Permission.RECORDS_READ)
PDF: dict[int | str, dict[str, Any]] = {
    200: {"content": {"application/pdf": {}}, "description": "The report as a PDF file"}
}
PERIOD_HELP = "Days are in the factory time zone; the default is the last 7 days."


def _pdf(report: RenderedReport) -> Response:
    return Response(
        content=report.content,
        media_type="application/pdf",
        # "attachment" makes browsers save the file and Swagger UI show a Download link;
        # with "inline" Swagger prints the raw PDF bytes as text.
        headers={
            "Content-Disposition": f"attachment; filename*=UTF-8''{quote(report.filename)}",
            "X-Report-Number": report.serial,
            "Access-Control-Expose-Headers": "X-Report-Number",
        },
    )


@router.get("/haccp-summary", description=PERIOD_HELP)
def haccp_summary(
    session: DbSession,
    date_from: date | None = None,
    date_to: date | None = None,
    actor: Actor = Depends(can_read),
) -> HaccpSummary:
    return ReportService(session, actor).haccp_summary(make_period(date_from, date_to))


@router.get("/ccp-log", response_class=Response, responses=PDF, description=PERIOD_HELP)
def ccp_log(
    session: DbSession,
    date_from: date | None = None,
    date_to: date | None = None,
    control_point_id: UUID | None = None,
    lang: Lang = Lang.AR,
    actor: Actor = Depends(can_read),
) -> Response:
    period = make_period(date_from, date_to)
    return _pdf(ReportService(session, actor).ccp_log(period, control_point_id, lang))


@router.get("/sanitation-log", response_class=Response, responses=PDF, description=PERIOD_HELP)
def sanitation_log(
    session: DbSession,
    date_from: date | None = None,
    date_to: date | None = None,
    area: str | None = None,
    lang: Lang = Lang.AR,
    actor: Actor = Depends(can_read),
) -> Response:
    period = make_period(date_from, date_to)
    return _pdf(ReportService(session, actor).sanitation_log(period, area, lang))


@router.get("/corrective-actions", response_class=Response, responses=PDF, description=PERIOD_HELP)
def corrective_actions(
    session: DbSession,
    date_from: date | None = None,
    date_to: date | None = None,
    status: CorrectiveActionStatus | None = None,
    lang: Lang = Lang.AR,
    actor: Actor = Depends(can_read),
) -> Response:
    period = make_period(date_from, date_to)
    return _pdf(ReportService(session, actor).corrective_actions(period, status, lang))


@router.get("/trace/{lot_id}", response_class=Response, responses=PDF)
def trace_report(
    lot_id: UUID,
    session: DbSession,
    lang: Lang = Lang.AR,
    actor: Actor = Depends(require(Permission.TRACE_READ)),
) -> Response:
    """Mock recall: ingredients and suppliers behind a lot, products and customers after it,
    and the CCP readings recorded on those lots."""
    return _pdf(ReportService(session, actor).trace(lot_id, lang))


@router.get("/supplier-list", response_class=Response, responses=PDF)
def supplier_list(
    session: DbSession,
    lang: Lang = Lang.AR,
    actor: Actor = Depends(require(Permission.MASTER_DATA_READ)),
) -> Response:
    """Approved supplier list: status, risk, documents, last score and next review."""
    return _pdf(ReportService(session, actor).supplier_list(lang))


@router.get("/training-matrix", response_class=Response, responses=PDF)
def training_matrix(
    session: DbSession, lang: Lang = Lang.AR, actor: Actor = Depends(can_read)
) -> Response:
    """Every active person against the courses their role requires."""
    return _pdf(ReportService(session, actor).training_matrix(lang))


@router.get("/training-log", response_class=Response, responses=PDF, description=PERIOD_HELP)
def training_log(
    session: DbSession,
    date_from: date | None = None,
    date_to: date | None = None,
    lang: Lang = Lang.AR,
    actor: Actor = Depends(can_read),
) -> Response:
    period = make_period(date_from, date_to)
    return _pdf(ReportService(session, actor).training_log(period, lang))
