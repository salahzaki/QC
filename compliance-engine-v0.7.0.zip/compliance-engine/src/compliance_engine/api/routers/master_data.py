from fastapi import APIRouter, Depends, status

from compliance_engine.api.deps import DbSession, require
from compliance_engine.core.permissions import Permission
from compliance_engine.models import Customer, Item, Supplier
from compliance_engine.schemas.master_data import (
    CreateCustomer,
    CreateItem,
    CreateSupplier,
    CustomerView,
    ItemView,
    SupplierView,
)
from compliance_engine.services.context import Actor
from compliance_engine.services.master_data import MasterDataService

router = APIRouter(tags=["master data"])

can_read = require(Permission.MASTER_DATA_READ)
can_write = require(Permission.MASTER_DATA_WRITE)


@router.post("/items", status_code=status.HTTP_201_CREATED)
def create_item(
    command: CreateItem, session: DbSession, actor: Actor = Depends(can_write)
) -> ItemView:
    return ItemView.model_validate(MasterDataService(session, actor).create_item(command))


@router.get("/items")
def list_items(session: DbSession, actor: Actor = Depends(can_read)) -> list[ItemView]:
    return [ItemView.model_validate(x) for x in MasterDataService(session, actor).list_all(Item)]


@router.post("/suppliers", status_code=status.HTTP_201_CREATED)
def create_supplier(
    command: CreateSupplier, session: DbSession, actor: Actor = Depends(can_write)
) -> SupplierView:
    return SupplierView.model_validate(MasterDataService(session, actor).create_supplier(command))


@router.get("/suppliers")
def list_suppliers(session: DbSession, actor: Actor = Depends(can_read)) -> list[SupplierView]:
    service = MasterDataService(session, actor)
    return [SupplierView.model_validate(x) for x in service.list_all(Supplier)]


@router.post("/customers", status_code=status.HTTP_201_CREATED)
def create_customer(
    command: CreateCustomer, session: DbSession, actor: Actor = Depends(can_write)
) -> CustomerView:
    return CustomerView.model_validate(MasterDataService(session, actor).create_customer(command))


@router.get("/customers")
def list_customers(session: DbSession, actor: Actor = Depends(can_read)) -> list[CustomerView]:
    service = MasterDataService(session, actor)
    return [CustomerView.model_validate(x) for x in service.list_all(Customer)]
