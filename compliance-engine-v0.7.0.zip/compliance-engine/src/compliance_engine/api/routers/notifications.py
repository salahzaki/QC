from uuid import UUID

from fastapi import APIRouter, Depends, Query, status

from compliance_engine.api.deps import DbSession, require
from compliance_engine.core.permissions import Permission
from compliance_engine.models.enums import DeliveryStatus, NotificationChannel
from compliance_engine.notifications.senders import configured_channels
from compliance_engine.schemas.notifications import (
    ChannelStatus,
    CreateRecipient,
    DeliveryView,
    DispatchResult,
    RecipientView,
    TestResult,
    UpdateRecipient,
)
from compliance_engine.services.context import Actor
from compliance_engine.services.notifications import NotificationService
from compliance_engine.services.settings import effective_settings

router = APIRouter(tags=["notifications"])
manager = Depends(require(Permission.NOTIFICATIONS_MANAGE))


@router.get("/notifications/channels")
def channels(session: DbSession, actor: Actor = manager) -> ChannelStatus:
    """Which channels can send: set up on the settings page, or on the server (.env)."""
    ready = configured_channels(effective_settings(session, actor.tenant_id))
    return ChannelStatus(
        email=ready[NotificationChannel.EMAIL], whatsapp=ready[NotificationChannel.WHATSAPP]
    )


@router.get("/notification-recipients")
def list_recipients(session: DbSession, actor: Actor = manager) -> list[RecipientView]:
    return [
        RecipientView.model_validate(r)
        for r in NotificationService(session, actor).list_recipients()
    ]


@router.post("/notification-recipients", status_code=status.HTTP_201_CREATED)
def create_recipient(
    command: CreateRecipient, session: DbSession, actor: Actor = manager
) -> RecipientView:
    """Add someone who gets alerts. They get alerts raised from now on."""
    return RecipientView.model_validate(
        NotificationService(session, actor).create_recipient(command)
    )


@router.patch("/notification-recipients/{recipient_id}")
def update_recipient(
    recipient_id: UUID, command: UpdateRecipient, session: DbSession, actor: Actor = manager
) -> RecipientView:
    """Change a recipient; `is_active: false` stops their alerts."""
    return RecipientView.model_validate(
        NotificationService(session, actor).update_recipient(recipient_id, command)
    )


@router.post("/notification-recipients/{recipient_id}/test")
def test_recipient(recipient_id: UUID, session: DbSession, actor: Actor = manager) -> TestResult:
    """Send a test message now and say whether it went out."""
    return NotificationService(session, actor).send_test(recipient_id)


@router.get("/notification-deliveries")
def list_deliveries(
    session: DbSession,
    actor: Actor = manager,
    delivery_status: DeliveryStatus | None = Query(default=None, alias="status"),
    alert_id: UUID | None = None,
    limit: int = Query(default=100, ge=1, le=500),
) -> list[DeliveryView]:
    return [
        DeliveryView.model_validate(d)
        for d in NotificationService(session, actor).list_deliveries(
            delivery_status, alert_id, limit
        )
    ]


@router.post("/notifications/dispatch")
def dispatch(session: DbSession, actor: Actor = manager) -> DispatchResult:
    """Send what is queued now, instead of waiting for the background task."""
    return NotificationService(session, actor).dispatch_now()


@router.post("/notifications/retry-failed")
def retry_failed(session: DbSession, actor: Actor = manager) -> dict[str, int]:
    """Queue failed deliveries again (e.g. after fixing the mail settings)."""
    return {"requeued": NotificationService(session, actor).retry_failed()}
