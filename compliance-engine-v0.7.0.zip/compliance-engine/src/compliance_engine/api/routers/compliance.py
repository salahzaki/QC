from uuid import UUID

from fastapi import APIRouter, Depends, Query

from compliance_engine.api.deps import DbSession, require
from compliance_engine.core.permissions import Permission
from compliance_engine.schemas.traceability import (
    AuditEventView,
    ChainVerification,
    TraceDirection,
    TraceReport,
)
from compliance_engine.services import audit
from compliance_engine.services.context import Actor
from compliance_engine.services.traceability import trace_lot

router = APIRouter(tags=["traceability & audit"])


@router.get("/trace/lots/{lot_id}")
def trace(
    lot_id: UUID,
    session: DbSession,
    direction: TraceDirection = TraceDirection.BACKWARD,
    _: Actor = Depends(require(Permission.TRACE_READ)),
) -> TraceReport:
    return trace_lot(session, lot_id, direction)


@router.get("/audit/events")
def list_audit_events(
    session: DbSession,
    limit: int = Query(default=100, ge=1, le=500),
    before_seq: int | None = Query(default=None, ge=1),
    _: Actor = Depends(require(Permission.AUDIT_READ)),
) -> list[AuditEventView]:
    events = audit.list_events(session, limit, before_seq)
    return [AuditEventView.model_validate(e) for e in events]


@router.get("/audit/verify")
def verify_audit_chain(
    session: DbSession, _: Actor = Depends(require(Permission.AUDIT_READ))
) -> ChainVerification:
    return audit.verify_chain(session)
