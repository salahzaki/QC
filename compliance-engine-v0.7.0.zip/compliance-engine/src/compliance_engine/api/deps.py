from collections.abc import Callable, Iterator
from typing import Annotated

from fastapi import Depends
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from compliance_engine.core.errors import (
    AuthenticationError,
    LoginRejectedError,
    PasswordRejectedError,
    PermissionDeniedError,
)
from compliance_engine.core.permissions import Permission, has_permission
from compliance_engine.core.security import decode_access_token
from compliance_engine.db.session import bind_tenant, get_session_factory
from compliance_engine.models import User
from compliance_engine.services.context import Actor
from compliance_engine.services.lockout import locked_message, record_password_failure

_bearer = HTTPBearer(auto_error=False)


def get_session() -> Iterator[Session]:
    """One transaction per request: committed on success, rolled back on any error."""
    session = get_session_factory()()
    try:
        yield session
        session.commit()
    except Exception as exc:
        session.rollback()
        if isinstance(exc, LoginRejectedError | PasswordRejectedError) and exc.failure:
            # Counted after the rollback, so the wrong password is remembered.
            record_password_failure(session, exc.failure)
        raise
    finally:
        session.close()


DbSession = Annotated[Session, Depends(get_session)]


def get_actor(
    session: DbSession,
    credentials: HTTPAuthorizationCredentials | None = Depends(_bearer),
) -> Actor:
    if credentials is None:
        raise AuthenticationError("Missing bearer token")
    claims = decode_access_token(credentials.credentials)
    bind_tenant(session, claims.tenant_id)

    user = session.get(User, claims.user_id)  # row-level security limits this to the tenant
    if user is None or not user.is_active:
        raise AuthenticationError("User is inactive or no longer exists")
    if user.locked_at is not None:
        raise AuthenticationError(locked_message())
    # The role is read from the database, so a role change applies before the token expires.
    return Actor(user_id=user.id, tenant_id=user.tenant_id, role=user.role)


def require(permission: Permission) -> Callable[..., Actor]:
    """Dependency factory: `actor: Actor = Depends(require(Permission.LOTS_RECEIVE))`."""

    def dependency(actor: Actor = Depends(get_actor)) -> Actor:
        if not has_permission(actor.role, permission):
            raise PermissionDeniedError(f"Role '{actor.role}' lacks permission '{permission}'")
        return actor

    return dependency
