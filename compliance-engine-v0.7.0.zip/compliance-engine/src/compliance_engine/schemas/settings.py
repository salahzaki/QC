from datetime import datetime
from typing import Self

from pydantic import EmailStr, Field, SecretStr, model_validator

from compliance_engine.models.enums import SmtpSecurity
from compliance_engine.schemas.common import Command, View


class ChannelState(View):
    """Whether a channel can send, and where its settings come from: "app" (set from the
    settings page), "server" (CE_* values in .env) or null (not set up)."""

    configured: bool
    source: str | None


class NotificationSettingsView(View):
    email: ChannelState
    whatsapp: ChannelState
    smtp_host: str | None
    smtp_port: int | None
    smtp_security: SmtpSecurity | None
    smtp_username: str | None
    smtp_from: str | None
    # Secrets are never sent back; these say whether one is stored and still readable.
    smtp_password_set: bool
    whatsapp_phone_number_id: str | None
    whatsapp_template: str | None
    whatsapp_template_language: str | None
    whatsapp_token_set: bool
    secrets_unreadable: bool
    updated_at: datetime | None
    updated_by_name: str | None


class UpdateEmailSettings(Command):
    """Mail server for alert e-mails. Send `smtp_host: null` to go back to the server's
    .env settings. Leave `smtp_password` out to keep the stored one."""

    smtp_host: str | None = Field(default=None, max_length=200)
    smtp_port: int = Field(default=587, ge=1, le=65535)
    smtp_security: SmtpSecurity = SmtpSecurity.STARTTLS
    smtp_username: str | None = Field(default=None, max_length=254)
    smtp_password: SecretStr | None = Field(default=None, max_length=200)
    smtp_from: EmailStr | None = None

    @model_validator(mode="after")
    def _host(self) -> Self:
        if self.smtp_host is not None and not self.smtp_host.strip():
            self.smtp_host = None
        return self


class UpdateWhatsAppSettings(Command):
    """WhatsApp Business Cloud API (Meta). Send `phone_number_id: null` to go back to the
    server's .env settings. Leave `token` out to keep the stored one."""

    phone_number_id: str | None = Field(default=None, max_length=64, pattern=r"^\d{5,64}$")
    token: SecretStr | None = Field(default=None, max_length=1000)
    template: str | None = Field(default=None, max_length=100, pattern=r"^[a-z0-9_]+$")
    template_language: str = Field(default="ar", max_length=16, pattern=r"^[a-zA-Z_]+$")


class QualitySettingsView(View):
    enforce_training: bool
    expiry_warning_days: int


class UpdateQualitySettings(Command):
    enforce_training: bool | None = Field(
        default=None,
        description="Refuse CCP readings from people without a valid pass on the courses "
        "linked to that control point",
    )
    expiry_warning_days: int | None = Field(default=None, ge=1, le=180)
