from datetime import date, datetime
from decimal import Decimal
from uuid import UUID

from pydantic import Field, field_validator

from compliance_engine.models.enums import LotOrigin, LotStatus
from compliance_engine.schemas.common import Code, Command, PositiveQuantity, View


class ReceiveLot(Command):
    item_id: UUID
    supplier_id: UUID
    supplier_lot_code: Code
    quantity: PositiveQuantity
    expiry_date: date | None = None


class ChangeLotStatus(Command):
    status: LotStatus
    reason: str = Field(min_length=3, max_length=500)


class LotQuantity(Command):
    lot_id: UUID
    quantity: PositiveQuantity


def _require_unique_lots(lines: list[LotQuantity]) -> list[LotQuantity]:
    lot_ids = [line.lot_id for line in lines]
    if len(lot_ids) != len(set(lot_ids)):
        raise ValueError("each lot may appear only once; combine the quantities")
    return lines


class RecordProduction(Command):
    reference: Code
    output_item_id: UUID
    output_quantity: PositiveQuantity
    output_expiry_date: date | None = None
    inputs: list[LotQuantity] = Field(min_length=1)

    _unique_inputs = field_validator("inputs")(_require_unique_lots)


class RecordShipment(Command):
    reference: Code
    customer_id: UUID
    lines: list[LotQuantity] = Field(min_length=1)

    _unique_lines = field_validator("lines")(_require_unique_lots)


class LotView(View):
    id: UUID
    lot_code: str
    item_id: UUID
    item_code: str
    item_name: str
    origin: LotOrigin
    status: LotStatus
    expiry_date: date | None
    supplier_id: UUID | None
    supplier_lot_code: str | None
    production_run_id: UUID | None
    balance: Decimal
    created_at: datetime


class ProductionView(View):
    production_run_id: UUID
    reference: str
    output_lot: LotView


class ShipmentLineView(View):
    lot_id: UUID
    quantity: Decimal


class ShipmentView(View):
    id: UUID
    reference: str
    customer_id: UUID
    shipped_at: datetime
    lines: list[ShipmentLineView]
