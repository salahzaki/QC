from datetime import date, datetime
from decimal import Decimal
from enum import StrEnum
from typing import Any
from uuid import UUID

from compliance_engine.models.enums import LotStatus
from compliance_engine.schemas.common import View


class TraceDirection(StrEnum):
    BACKWARD = "backward"  # finished lot -> ingredients -> suppliers
    FORWARD = "forward"  # supplier lot -> products -> customers


class TracedLot(View):
    lot_id: UUID
    lot_code: str
    depth: int
    item_code: str
    item_name: str
    status: LotStatus
    expiry_date: date | None
    supplier_code: str | None
    supplier_lot_code: str | None


class TracedLink(View):
    parent_lot_id: UUID
    child_lot_id: UUID
    quantity: Decimal
    production_run_id: UUID


class TracedShipment(View):
    shipment_id: UUID
    reference: str
    customer_code: str
    customer_name: str
    lot_id: UUID
    quantity: Decimal
    shipped_at: datetime


class TraceReport(View):
    root_lot_id: UUID
    direction: TraceDirection
    lots: list[TracedLot]
    links: list[TracedLink]
    shipments: list[TracedShipment]
    elapsed_ms: float


class AuditEventView(View):
    seq: int
    occurred_at: datetime
    actor_id: UUID | None
    action: str
    entity_type: str
    entity_id: UUID
    payload: dict[str, Any]
    hash: str


class ChainVerification(View):
    valid: bool
    events_checked: int
    first_invalid_seq: int | None = None
