"""Dashboard and analytics read models. Percentages are 0-100 and None when there is
nothing to measure (no readings, no checks), so the UI never shows a misleading 0% or 100%."""

from datetime import date, datetime
from uuid import UUID

from pydantic import Field

from compliance_engine.schemas.common import View


class Kpis(View):
    ccp_readings: int
    ccp_deviations: int
    ccp_compliance_pct: float | None = Field(description="Readings within critical limits")
    sanitation_checks: int
    sanitation_failures: int
    sanitation_pass_pct: float | None
    records: int = Field(description="CCP readings plus sanitation checks")
    verified_pct: float | None = Field(description="Records with a second-person signature")
    median_verify_hours: float | None = Field(
        description="Median time from recording to the second-person signature"
    )
    on_time_pct: float | None = Field(
        description="Gaps between readings no longer than the control point's check interval"
    )
    missed_checks: int = Field(description="Overdue-check alerts raised in the period")
    capa_opened: int
    capa_closed: int
    capa_closed_on_time_pct: float | None = Field(
        description="Corrective actions closed within the target number of days"
    )
    capa_mean_close_days: float | None
    alerts_raised: int
    alerts_mean_ack_minutes: float | None


class ScorePart(View):
    key: str = Field(examples=["ccp_compliance"])
    value: float


class ComplianceScore(View):
    score: float | None = Field(description="Average of the parts that have data, 0-100")
    parts: list[ScorePart]


class DayPoint(View):
    day: date
    ccp_readings: int
    ccp_deviations: int
    sanitation_checks: int
    sanitation_failures: int
    capa_opened: int
    capa_closed: int


class ControlPointStats(View):
    control_point_id: UUID
    code: str
    name: str
    unit: str
    critical_min: float | None
    critical_max: float | None
    readings: int
    deviations: int
    compliance_pct: float | None
    mean: float | None
    minimum: float | None
    maximum: float | None
    stdev: float | None
    cpk: float | None = Field(
        description="Process capability against the critical limits; shown from 10 readings"
    )
    on_time_pct: float | None
    last_reading_at: datetime | None


class SpcPoint(View):
    measured_at: datetime
    value: float
    within_limits: bool
    serial: str | None
    record_id: UUID


class SpcSeries(View):
    control_point_id: UUID
    code: str
    name: str
    unit: str
    critical_min: float | None
    critical_max: float | None
    mean: float | None
    ucl: float | None = Field(description="Mean + 3 standard deviations")
    lcl: float | None = Field(description="Mean - 3 standard deviations")
    points: list[SpcPoint]
    truncated: bool = Field(description="True when only the latest points are returned")


class HeatCell(View):
    weekday: int = Field(description="0 = Monday ... 6 = Sunday, in the factory time zone")
    hour: int
    records: int
    problems: int = Field(description="CCP deviations plus failed sanitation checks")


class AreaStats(View):
    area: str
    checks: int
    failures: int
    pass_pct: float | None
    last_at: datetime | None


class CapaAging(View):
    open_now: int
    overdue_now: int = Field(description="Open for longer than the target number of days")
    target_days: int
    buckets: dict[str, int] = Field(
        description="Open corrective actions by age: 0-2, 3-7, 8-30 and 31+ days"
    )
    dispositions: dict[str, int] = Field(description="Closed in the period, by product disposition")


class PersonStats(View):
    user_id: UUID
    name: str
    records: int
    problems: int
    verifications: int


class Analytics(View):
    date_from: date
    date_to: date
    previous_from: date
    previous_to: date
    kpis: Kpis
    previous: Kpis = Field(description="The same figures for the period just before")
    score: ComplianceScore
    previous_score: ComplianceScore
    daily: list[DayPoint]
    control_points: list[ControlPointStats]
    spc: SpcSeries | None
    heatmap: list[HeatCell]
    areas: list[AreaStats]
    capa: CapaAging
    people: list[PersonStats] | None = Field(
        description="Only for roles that review records (supervisor and above)"
    )


class LiveControlPoint(View):
    control_point_id: UUID
    code: str
    name: str
    unit: str
    critical_min: float | None
    critical_max: float | None
    check_interval_minutes: int | None
    last_value: float | None
    last_within_limits: bool | None
    last_reading_at: datetime | None
    next_due_at: datetime | None
    status: str = Field(description="ok, due_soon, overdue, deviation or no_schedule")
    readings_today: int
    deviations_today: int


class ActivityItem(View):
    at: datetime
    kind: str = Field(description="ccp_reading, sanitation_record or corrective_action")
    record_id: UUID
    serial: str | None
    title: str
    ok: bool
    by: str | None


class Live(View):
    now: datetime
    today: date
    control_points: list[LiveControlPoint]
    activity: list[ActivityItem]
    today_records: int
    today_problems: int
