from datetime import date, datetime
from uuid import UUID

from compliance_engine.schemas.common import View


class ControlPointSummary(View):
    control_point_id: UUID
    code: str
    name: str
    readings: int
    deviations: int
    unverified: int
    last_reading_at: datetime | None


class HaccpSummary(View):
    date_from: date
    date_to: date
    control_points: list[ControlPointSummary]
    ccp_readings: int
    ccp_deviations: int
    sanitation_checks: int
    sanitation_failures: int
    unverified_records: int
    corrective_actions_opened: int
    corrective_actions_open_now: int
    open_alerts_now: int
