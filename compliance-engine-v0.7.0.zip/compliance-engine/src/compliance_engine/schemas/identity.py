from datetime import datetime
from typing import Annotated, Self
from uuid import UUID

from pydantic import AfterValidator, EmailStr, Field, model_validator

from compliance_engine.core.permissions import Role
from compliance_engine.models.enums import NotificationChannel
from compliance_engine.schemas.common import Command, Name, View
from compliance_engine.schemas.notifications import check_address

Password = Field(min_length=10, max_length=128)


def _phone(value: str | None) -> str | None:
    if value is None or not value.strip():
        return None
    return check_address(NotificationChannel.WHATSAPP, value)


Phone = Annotated[
    str | None,
    Field(
        default=None,
        max_length=24,
        description="Mobile in international format, e.g. +966501234567 (for WhatsApp alerts)",
    ),
    AfterValidator(_phone),
]


class LoginRequest(Command):
    tenant: str = Field(min_length=1, max_length=64)
    email: EmailStr
    password: str = Field(min_length=1, max_length=128)


class TokenResponse(View):
    access_token: str
    token_type: str = "bearer"


class CreateTenant(Command):
    slug: str = Field(min_length=2, max_length=64, pattern=r"^[a-z0-9-]+$")
    name: Name
    admin_email: EmailStr
    admin_full_name: Name
    admin_password: str = Password


class CreateUser(Command):
    email: EmailStr
    full_name: Name
    role: Role
    password: str = Password
    phone: Phone = None


class ChangePassword(Command):
    current_password: str = Field(min_length=1, max_length=128)
    new_password: str = Password


class ResetPassword(Command):
    """Set a new password for a user who forgot theirs. Tell them the new password in person."""

    new_password: str = Password


class UpdateUser(Command):
    """Change a user. Only the fields you send change. Old signatures keep the name and role
    the signer had when signing."""

    full_name: Name | None = None
    role: Role | None = None
    is_active: bool | None = Field(default=None, description="false = can no longer log in")
    phone: Phone = None

    @model_validator(mode="after")
    def _something(self) -> Self:
        if not self.model_fields_set:
            raise ValueError("send at least one of full_name, role, is_active, phone")
        for field in self.model_fields_set - {"phone"}:
            if getattr(self, field) is None:
                raise ValueError(f"{field} cannot be empty")
        return self


class PersonView(View):
    """Active colleague, as quality managers see them (choosing trainees and recipients)."""

    id: UUID
    full_name: str
    role: Role
    email: str
    phone: str | None


class UserView(View):
    id: UUID
    email: str
    full_name: str
    role: Role
    is_active: bool
    failed_password_attempts: int
    locked_at: datetime | None
    phone: str | None = None
    created_at: datetime
