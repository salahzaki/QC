from datetime import datetime
from uuid import UUID

from pydantic import Field

from compliance_engine.models.enums import (
    AlertKind,
    AlertSeverity,
    CorrectiveActionStatus,
    ProductDisposition,
)
from compliance_engine.schemas.common import Command, View
from compliance_engine.schemas.records import LongText, SignaturePassword, SignatureView


class CloseCorrectiveAction(Command):
    """Close a corrective action. Signed "approved" by a quality manager or admin."""

    root_cause: LongText
    preventive_action: LongText = Field(description="What stops this from happening again")
    product_disposition: ProductDisposition = Field(
        description="What happened to product affected by the deviation"
    )
    password: SignaturePassword
    comment: str | None = Field(default=None, max_length=500)


class CorrectiveActionView(View):
    id: UUID
    serial: str | None = Field(description="Record number, e.g. CA-2026-000123")
    record_type: str
    record_id: UUID
    control_point_id: UUID | None
    lot_id: UUID | None
    description: str
    immediate_action: str
    opened_at: datetime
    opened_by: UUID
    status: CorrectiveActionStatus
    root_cause: str | None
    preventive_action: str | None
    product_disposition: ProductDisposition | None
    closed_at: datetime | None
    closed_by: UUID | None
    signatures: list[SignatureView]


class AcknowledgeAlert(Command):
    comment: str | None = Field(
        default=None, max_length=500, examples=["Line stopped, QA informed"]
    )


class AlertView(View):
    id: UUID
    kind: AlertKind
    severity: AlertSeverity
    message: str
    record_type: str | None
    record_id: UUID | None
    control_point_id: UUID | None
    raised_at: datetime
    acknowledged_at: datetime | None
    acknowledged_by: UUID | None
    acknowledgement: str | None


class AlertSummary(View):
    open_alerts: int
    open_critical: int
    open_corrective_actions: int
    unverified_records: int = Field(
        description="CCP readings, sanitation records and amendments still waiting for a "
        "second signature"
    )


class ScanResult(View):
    alerts_raised: list[AlertView]
