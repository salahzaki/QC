from datetime import datetime
from decimal import Decimal
from typing import Annotated, Any, ClassVar, Self
from uuid import UUID

from pydantic import AwareDatetime, Field, SecretStr, model_validator

from compliance_engine.core.permissions import Role
from compliance_engine.models.enums import (
    CorrectiveActionStatus,
    SanitationActivity,
    SanitationResult,
    SignatureMeaning,
)
from compliance_engine.schemas.common import Code, Command, Name, View

Measurement = Annotated[Decimal, Field(max_digits=12, decimal_places=3)]
LongText = Annotated[str, Field(min_length=3, max_length=2000)]
CheckInterval = Annotated[int, Field(gt=0, le=60 * 24 * 31)]
SignaturePassword = Annotated[
    SecretStr, Field(min_length=1, description="Your login password, re-entered to sign")
]


class CreateControlPoint(Command):
    code: Code
    name: Name
    hazard: str = Field(min_length=3, max_length=500)
    parameter: str = Field(min_length=1, max_length=100, examples=["Core temperature"])
    unit: str = Field(min_length=1, max_length=16, examples=["°C"])
    critical_min: Measurement | None = None
    critical_max: Measurement | None = None
    monitoring_frequency: str | None = Field(default=None, max_length=100)
    check_interval_minutes: CheckInterval | None = None

    @model_validator(mode="after")
    def _limits(self) -> Self:
        check_limits(self.critical_min, self.critical_max)
        return self


def check_limits(low: Decimal | None, high: Decimal | None) -> None:
    if low is None and high is None:
        raise ValueError("set critical_min, critical_max or both")
    if low is not None and high is not None and low > high:
        raise ValueError("critical_min must not be greater than critical_max")


class UpdateControlPoint(Command):
    """Change a control point. Only the fields you send change; send null to clear one.

    Readings already taken keep the limits that were in force when they were recorded."""

    name: Name | None = None
    hazard: str | None = Field(default=None, min_length=3, max_length=500)
    critical_min: Measurement | None = None
    critical_max: Measurement | None = None
    monitoring_frequency: str | None = Field(default=None, max_length=100)
    check_interval_minutes: CheckInterval | None = Field(
        default=None, description="Raise a missed-check alert after this many minutes"
    )
    reason: LongText = Field(description="Why the HACCP plan changed (kept in the audit log)")

    @model_validator(mode="after")
    def _required_fields_not_cleared(self) -> Self:
        for name in ("name", "hazard"):
            if name in self.model_fields_set and getattr(self, name) is None:
                raise ValueError(f"{name} cannot be cleared")
        return self


class ControlPointView(View):
    id: UUID
    code: str
    name: str
    hazard: str
    parameter: str
    unit: str
    critical_min: Decimal | None
    critical_max: Decimal | None
    monitoring_frequency: str | None
    check_interval_minutes: int | None


class SignRecord(Command):
    """Verification signature by a second person (supervisor or quality manager)."""

    password: SignaturePassword
    comment: str | None = Field(default=None, max_length=500)


class SignatureView(View):
    meaning: SignatureMeaning
    signer_id: UUID
    signer_name: str
    signer_role: Role
    signed_at: datetime
    comment: str | None
    intact: bool = Field(description="False if the record no longer matches what was signed")


class RecordCcpReading(Command):
    control_point_id: UUID
    value: Measurement
    measured_at: AwareDatetime | None = Field(
        default=None, description="When the check was made; defaults to now"
    )
    corrective_action: LongText | None = Field(
        default=None, description="Required when the value is outside the critical limits"
    )
    notes: str | None = Field(default=None, max_length=2000)
    lot_id: UUID | None = None
    production_run_id: UUID | None = None
    password: SignaturePassword


class CcpReadingView(View):
    id: UUID
    serial: str | None = Field(description="Record number, e.g. CCP-2026-000123")
    control_point_id: UUID
    control_point_code: str
    control_point_name: str
    value: Decimal
    unit: str
    critical_min: Decimal | None
    critical_max: Decimal | None
    within_limits: bool
    corrective_action: str | None
    notes: str | None
    lot_id: UUID | None
    production_run_id: UUID | None
    measured_at: datetime
    recorded_by: UUID
    created_at: datetime
    verified: bool = Field(
        description="True when the record and every amendment have a second-person signature"
    )
    signatures: list[SignatureView]
    amended: bool
    amendments: list["AmendmentView"]
    corrective_action_id: UUID | None
    corrective_action_status: CorrectiveActionStatus | None


class RecordSanitation(Command):
    area: Code = Field(examples=["MIXER-1"])
    activity: SanitationActivity
    chemical: str | None = Field(default=None, max_length=100)
    concentration_ppm: Annotated[Decimal, Field(ge=0, max_digits=10, decimal_places=2)] | None = (
        None
    )
    result: SanitationResult
    performed_at: AwareDatetime | None = Field(
        default=None, description="When the task was done; defaults to now"
    )
    corrective_action: LongText | None = Field(
        default=None, description="Required when the result is 'fail'"
    )
    notes: str | None = Field(default=None, max_length=2000)
    password: SignaturePassword

    @model_validator(mode="after")
    def _failure_needs_action(self) -> Self:
        if self.result == SanitationResult.FAIL and self.corrective_action is None:
            raise ValueError("a failed check needs a corrective_action")
        return self


class SanitationRecordView(View):
    id: UUID
    serial: str | None = Field(description="Record number, e.g. SAN-2026-000123")
    area: str
    activity: SanitationActivity
    chemical: str | None
    concentration_ppm: Decimal | None
    result: SanitationResult
    corrective_action: str | None
    notes: str | None
    performed_at: datetime
    recorded_by: UUID
    created_at: datetime
    verified: bool = Field(
        description="True when the record and every amendment have a second-person signature"
    )
    signatures: list[SignatureView]
    amended: bool
    amendments: list["AmendmentView"]
    corrective_action_id: UUID | None
    corrective_action_status: CorrectiveActionStatus | None


# ----- amendments ------------------------------------------------------------------------


class Amendment(Command):
    """Fields shared by every amendment. Send only the fields you correct."""

    REQUIRED_FIELDS: ClassVar[tuple[str, ...]] = ()

    reason: LongText = Field(description="Why the record is being corrected")
    corrective_action: LongText | None = Field(
        default=None,
        description="Required when the correction turns the record into a deviation",
    )
    password: SignaturePassword

    def corrections(self) -> dict[str, Any]:
        """The fields this amendment sets, with their new values."""
        meta = {"reason", "corrective_action", "password"}
        return {name: getattr(self, name) for name in self.model_fields_set - meta}

    @model_validator(mode="after")
    def _check_corrections(self) -> Self:
        corrections = self.corrections()
        if not corrections:
            raise ValueError("send at least one field to correct")
        for name in self.REQUIRED_FIELDS:
            if name in corrections and corrections[name] is None:
                raise ValueError(f"{name} cannot be cleared")
        return self


class AmendCcpReading(Amendment):
    REQUIRED_FIELDS: ClassVar[tuple[str, ...]] = ("value", "measured_at")

    value: Measurement | None = None
    measured_at: AwareDatetime | None = None
    notes: str | None = Field(default=None, max_length=2000)
    lot_id: UUID | None = None
    production_run_id: UUID | None = None


class AmendSanitation(Amendment):
    REQUIRED_FIELDS: ClassVar[tuple[str, ...]] = ("area", "activity", "result", "performed_at")

    area: Code | None = None
    activity: SanitationActivity | None = None
    chemical: str | None = Field(default=None, max_length=100)
    concentration_ppm: Annotated[Decimal, Field(ge=0, max_digits=10, decimal_places=2)] | None = (
        None
    )
    result: SanitationResult | None = None
    performed_at: AwareDatetime | None = None
    notes: str | None = Field(default=None, max_length=2000)


class AmendmentView(View):
    id: UUID
    serial: str | None = Field(description="Record number, e.g. AMD-2026-000123")
    record_type: str
    record_id: UUID
    changes: dict[str, dict[str, Any]] = Field(
        description='Each corrected field with its old and new value: {"from": ..., "to": ...}'
    )
    reason: str
    amended_at: datetime
    amended_by: UUID
    verified: bool
    signatures: list[SignatureView]


CcpReadingView.model_rebuild()
SanitationRecordView.model_rebuild()
