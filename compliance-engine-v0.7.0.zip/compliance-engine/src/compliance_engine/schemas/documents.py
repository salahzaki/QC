from datetime import date, datetime
from typing import Annotated, Any, Self
from uuid import UUID

from pydantic import Field, model_validator

from compliance_engine.schemas.common import Command, View

FormCode = Annotated[
    str, Field(min_length=2, max_length=32, pattern=r"^[A-Za-z0-9][A-Za-z0-9._/-]*$")
]


class DocumentFormView(View):
    key: str = Field(description="Which report this form is: ccp_log, sanitation_log, ...")
    code: str
    title_ar: str
    title_en: str
    revision: str
    effective_date: date
    reference: str | None
    retention_years: int
    approved_by_name: str | None
    updated_at: datetime | None


class UpdateDocumentForm(Command):
    code: FormCode | None = None
    title_ar: str | None = Field(default=None, min_length=2, max_length=200)
    title_en: str | None = Field(default=None, min_length=2, max_length=200)
    revision: str | None = Field(default=None, min_length=1, max_length=8, examples=["02"])
    effective_date: date | None = None
    reference: str | None = Field(default=None, max_length=300)
    retention_years: int | None = Field(default=None, ge=1, le=50)
    approved_by_name: str | None = Field(default=None, max_length=200)
    reason: str = Field(min_length=3, max_length=500, examples=["Annual HACCP review"])

    @model_validator(mode="after")
    def _something_to_change(self) -> Self:
        if not self.model_dump(exclude={"reason"}, exclude_none=True):
            raise ValueError("send at least one field to change")
        return self


class IssuedReportView(View):
    serial: str
    form_key: str
    form_code: str
    form_revision: str
    title: str
    lang: str
    parameters: dict[str, Any]
    filename: str
    sha256: str
    issued_at: datetime
    issued_by: UUID
    issued_by_name: str


class ReportCheck(View):
    genuine: bool = Field(description="True when the file is exactly a report this system issued")
    report: IssuedReportView | None
