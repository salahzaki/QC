import base64
import binascii
from datetime import date, datetime
from decimal import Decimal
from typing import Annotated, Self
from uuid import UUID

from pydantic import Field, model_validator

from compliance_engine.models.enums import (
    RiskLevel,
    SupplierDocumentType,
    SupplierStatus,
)
from compliance_engine.schemas.common import Command, View
from compliance_engine.schemas.master_data import SupplierView
from compliance_engine.schemas.records import LongText, SignaturePassword, SignatureView

MAX_FILE_BYTES = 10 * 1024 * 1024
ALLOWED_FILE_TYPES = frozenset(
    {"application/pdf", "image/jpeg", "image/png", "image/webp", "image/heic"}
)
Score = Annotated[int, Field(ge=0, le=100)]


class DecideApproval(Command):
    """Approve, conditionally approve, suspend or reject a supplier; signed with your password.

    Approval needs every required document to be valid. Conditional approval needs the
    conditions. Without `next_review_date`, approval is reviewed again after 24 months (low
    risk), 12 months (medium) or 6 months (high)."""

    to_status: SupplierStatus
    reason: LongText = Field(description="Basis of the decision, e.g. audit, certificate, history")
    conditions: str | None = Field(default=None, min_length=3, max_length=2000)
    next_review_date: date | None = None
    risk_level: RiskLevel | None = None
    password: SignaturePassword

    @model_validator(mode="after")
    def _conditions(self) -> Self:
        if self.to_status == SupplierStatus.CONDITIONAL and not self.conditions:
            raise ValueError("a conditional approval needs the conditions")
        if self.to_status == SupplierStatus.PENDING:
            raise ValueError("a decision cannot set a supplier back to pending")
        return self


class ApprovalView(View):
    id: UUID
    serial: str | None
    supplier_id: UUID
    from_status: SupplierStatus
    to_status: SupplierStatus
    risk_level: RiskLevel
    reason: str
    conditions: str | None
    next_review_date: date | None
    decided_at: datetime
    decided_by: UUID
    signatures: list[SignatureView] = Field(default_factory=list)


class AddSupplierDocument(Command):
    """A certificate or licence. Attach the scanned file as base64 (PDF or image, at most
    10 MB). A renewed certificate is added as a new document; withdraw the old one."""

    doc_type: SupplierDocumentType
    title: str = Field(min_length=2, max_length=200, examples=["FSSC 22000 certificate"])
    number: str | None = Field(default=None, max_length=100)
    issuer: str | None = Field(default=None, max_length=200)
    issued_on: date | None = None
    expires_on: date | None = None
    is_required: bool = Field(
        default=True, description="Required documents must be valid to receive from the supplier"
    )
    file_name: str | None = Field(default=None, max_length=200)
    content_type: str | None = Field(default=None, max_length=100)
    file_base64: str | None = Field(default=None, max_length=MAX_FILE_BYTES * 4 // 3 + 8)

    @model_validator(mode="after")
    def _check(self) -> Self:
        if self.issued_on and self.expires_on and self.expires_on < self.issued_on:
            raise ValueError("expires_on must not be before issued_on")
        if self.file_base64 is not None and not (self.file_name and self.content_type):
            raise ValueError("send file_name and content_type with the file")
        if self.content_type is not None and self.content_type not in ALLOWED_FILE_TYPES:
            raise ValueError("the file must be a PDF or an image (JPEG, PNG, WebP, HEIC)")
        return self

    def file_bytes(self) -> bytes | None:
        if self.file_base64 is None:
            return None
        try:
            data = base64.b64decode(self.file_base64, validate=True)
        except (binascii.Error, ValueError) as exc:
            raise ValueError("the file is not valid base64") from exc
        if not data or len(data) > MAX_FILE_BYTES:
            raise ValueError("the file must be between 1 byte and 10 MB")
        return data


class WithdrawDocument(Command):
    reason: str = Field(min_length=3, max_length=500)


class SupplierDocumentView(View):
    id: UUID
    supplier_id: UUID
    doc_type: SupplierDocumentType
    title: str
    number: str | None
    issuer: str | None
    issued_on: date | None
    expires_on: date | None
    is_required: bool
    file_name: str | None
    content_type: str | None
    file_size: int | None
    file_sha256: str | None
    uploaded_at: datetime
    uploaded_by: UUID
    withdrawn_at: datetime | None
    withdrawn_reason: str | None
    state: str = Field(
        description='"valid", "expiring" (within the warning days), "expired", "withdrawn"'
    )
    days_left: int | None


class EvaluateSupplier(Command):
    """Score the supplier 0-100 on each criterion for the period; signed with your password.

    Weights: quality 40%, delivery 25%, documentation 20%, service 15%. A total of 80 or more
    recommends approval, 60-79 conditional approval, below 60 suspension."""

    period_from: date
    period_to: date
    quality_score: Score = Field(description="Conformity of goods: rejects, blocked lots, COAs")
    delivery_score: Score = Field(description="On time, complete, correct transport conditions")
    documentation_score: Score = Field(description="Certificates and documents valid and on time")
    service_score: Score = Field(description="Response to complaints and corrective actions")
    comments: str | None = Field(default=None, max_length=2000)
    password: SignaturePassword

    @model_validator(mode="after")
    def _period(self) -> Self:
        if self.period_from > self.period_to:
            raise ValueError("period_from must not be after period_to")
        return self


class EvaluationView(View):
    id: UUID
    serial: str | None
    supplier_id: UUID
    period_from: date
    period_to: date
    quality_score: int
    delivery_score: int
    documentation_score: int
    service_score: int
    total_score: Decimal
    recommendation: SupplierStatus
    lots_received: int
    lots_blocked: int
    comments: str | None
    evaluated_at: datetime
    evaluated_by: UUID
    signatures: list[SignatureView] = Field(default_factory=list)


class SupplierStats(View):
    lots_received: int
    lots_blocked: int
    last_receipt_at: datetime | None
    documents_valid: int
    documents_expiring: int
    documents_expired: int
    required_expired: int
    last_score: Decimal | None


class SupplierSummary(View):
    """One row of the supplier list, with what decides whether goods can be received."""

    supplier: SupplierView
    can_receive: bool
    blocked_reason: str | None
    stats: SupplierStats
    review_overdue: bool


class SupplierDetail(SupplierSummary):
    documents: list[SupplierDocumentView]
    approvals: list[ApprovalView]
    evaluations: list[EvaluationView]
    names: dict[UUID, str] = Field(description="Names of the people in the history, by id")
