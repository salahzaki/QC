import re
from datetime import datetime
from typing import Self
from uuid import UUID

from pydantic import EmailStr as _EmailStr
from pydantic import Field, TypeAdapter, model_validator

from compliance_engine.models.enums import AlertSeverity, DeliveryStatus, NotificationChannel
from compliance_engine.schemas.common import Command, Name, View

_email = TypeAdapter(_EmailStr)
_PHONE = re.compile(r"^\+?[1-9][0-9 \-]{7,18}$")


def check_address(channel: NotificationChannel, address: str) -> str:
    if channel == NotificationChannel.EMAIL:
        return _email.validate_python(address).lower()
    if not _PHONE.match(address) or not 8 <= len(re.sub(r"\D", "", address)) <= 15:
        raise ValueError(
            "a WhatsApp number must be in international format with the country code, "
            "e.g. +966501234567"
        )
    return "+" + re.sub(r"\D", "", address)


class CreateRecipient(Command):
    name: Name
    channel: NotificationChannel
    address: str = Field(
        min_length=3,
        max_length=254,
        description="E-mail address, or WhatsApp number with country code (+966501234567)",
    )
    min_severity: AlertSeverity = Field(
        default=AlertSeverity.MAJOR,
        description='"major" gets every alert, "critical" only critical ones',
    )

    @model_validator(mode="after")
    def _address(self) -> Self:
        self.address = check_address(self.channel, self.address)
        return self


class UpdateRecipient(Command):
    name: Name | None = None
    address: str | None = Field(default=None, min_length=3, max_length=254)
    min_severity: AlertSeverity | None = None
    is_active: bool | None = None

    @model_validator(mode="after")
    def _something(self) -> Self:
        if not self.model_fields_set:
            raise ValueError("send at least one field to change")
        for field in self.model_fields_set:
            if getattr(self, field) is None:
                raise ValueError(f"{field} cannot be empty")
        return self


class RecipientView(View):
    id: UUID
    name: str
    channel: NotificationChannel
    address: str
    min_severity: AlertSeverity
    is_active: bool
    created_at: datetime


class DeliveryView(View):
    id: UUID
    alert_id: UUID
    recipient_id: UUID
    channel: NotificationChannel
    address: str
    status: DeliveryStatus
    attempts: int
    next_attempt_at: datetime
    sent_at: datetime | None
    last_error: str | None
    created_at: datetime


class TestResult(View):
    sent: bool
    error: str | None


class DispatchResult(View):
    sent: int
    retrying: int
    failed: int


class ChannelStatus(View):
    email: bool
    whatsapp: bool
