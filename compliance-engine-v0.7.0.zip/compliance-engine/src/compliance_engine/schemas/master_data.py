from datetime import date, datetime
from typing import Self
from uuid import UUID

from pydantic import EmailStr, Field, model_validator

from compliance_engine.models.enums import ItemType, RiskLevel, SupplierStatus, UnitOfMeasure
from compliance_engine.schemas.common import Code, Command, Name, View


class CreateItem(Command):
    code: Code
    name: Name
    item_type: ItemType
    uom: UnitOfMeasure
    shelf_life_days: int | None = Field(default=None, gt=0)


class ItemView(View):
    id: UUID
    code: str
    name: str
    item_type: ItemType
    uom: UnitOfMeasure
    shelf_life_days: int | None


class CreateSupplier(Command):
    """A new supplier starts as "pending" until an approval decision is signed.
    `is_approved: true` (for suppliers synced from an ERP) starts it as "approved"."""

    code: Code
    name: Name
    is_approved: bool = False
    erp_ref: str | None = Field(default=None, max_length=128)
    category: str | None = Field(default=None, max_length=200, examples=["Flour, sugar"])
    risk_level: RiskLevel = RiskLevel.MEDIUM
    contact_name: str | None = Field(default=None, max_length=200)
    contact_phone: str | None = Field(default=None, max_length=32)
    contact_email: EmailStr | None = None
    notes: str | None = Field(default=None, max_length=2000)


class UpdateSupplier(Command):
    """Change a supplier's details. The approval status changes only by a signed decision."""

    name: Name | None = None
    erp_ref: str | None = Field(default=None, max_length=128)
    category: str | None = Field(default=None, max_length=200)
    risk_level: RiskLevel | None = None
    contact_name: str | None = Field(default=None, max_length=200)
    contact_phone: str | None = Field(default=None, max_length=32)
    contact_email: EmailStr | None = None
    notes: str | None = Field(default=None, max_length=2000)

    @model_validator(mode="after")
    def _something(self) -> Self:
        if not self.model_fields_set:
            raise ValueError("send at least one field to change")
        for field in ("name", "risk_level"):
            if field in self.model_fields_set and getattr(self, field) is None:
                raise ValueError(f"{field} cannot be empty")
        return self


class SupplierView(View):
    id: UUID
    code: str
    name: str
    is_approved: bool
    erp_ref: str | None
    approval_status: SupplierStatus
    risk_level: RiskLevel
    category: str | None
    contact_name: str | None
    contact_phone: str | None
    contact_email: str | None
    next_review_date: date | None
    notes: str | None
    created_at: datetime


class CreateCustomer(Command):
    code: Code
    name: Name
    erp_ref: str | None = Field(default=None, max_length=128)


class CustomerView(View):
    id: UUID
    code: str
    name: str
    erp_ref: str | None
