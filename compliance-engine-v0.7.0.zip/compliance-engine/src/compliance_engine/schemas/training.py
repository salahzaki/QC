from datetime import date, datetime
from decimal import Decimal
from typing import Annotated, Self
from uuid import UUID

from pydantic import Field, model_validator

from compliance_engine.core.permissions import Role
from compliance_engine.models.enums import TrainingMethod, TrainingResult
from compliance_engine.schemas.common import Code, Command, View
from compliance_engine.schemas.records import SignaturePassword, SignatureView

Validity = Annotated[int, Field(gt=0, le=120, description="Months a pass stays valid")]


class CreateCourse(Command):
    code: Code
    title: str = Field(min_length=2, max_length=200, examples=["Basic food hygiene"])
    category: str | None = Field(default=None, max_length=100, examples=["Hygiene"])
    description: str | None = Field(default=None, max_length=2000)
    validity_months: Validity | None = None
    required_roles: list[Role] = Field(
        default_factory=list, description="Roles that must hold this training (training matrix)"
    )
    control_point_ids: list[UUID] = Field(
        default_factory=list,
        description="CCPs a person may only record after passing this course "
        "(when the competence gate is on)",
    )


class UpdateCourse(Command):
    """Change a course. Training already recorded keeps the expiry it was given."""

    title: str | None = Field(default=None, min_length=2, max_length=200)
    category: str | None = Field(default=None, max_length=100)
    description: str | None = Field(default=None, max_length=2000)
    validity_months: Validity | None = None
    required_roles: list[Role] | None = None
    control_point_ids: list[UUID] | None = None
    is_active: bool | None = None

    @model_validator(mode="after")
    def _something(self) -> Self:
        if not self.model_fields_set:
            raise ValueError("send at least one field to change")
        for field in ("title", "required_roles", "control_point_ids", "is_active"):
            if field in self.model_fields_set and getattr(self, field) is None:
                raise ValueError(f"{field} cannot be empty")
        return self


class CourseView(View):
    id: UUID
    code: str
    title: str
    category: str | None
    description: str | None
    validity_months: int | None
    required_roles: list[Role]
    control_point_ids: list[UUID]
    is_active: bool
    created_at: datetime


class Attendee(Command):
    user_id: UUID
    result: TrainingResult = TrainingResult.PASSED
    score: Decimal | None = Field(default=None, ge=0, le=100, max_digits=5, decimal_places=1)


class RecordTraining(Command):
    """One training session: one numbered record per attendee, each signed by you."""

    course_id: UUID
    trained_on: date
    trainer: str = Field(min_length=2, max_length=200)
    method: TrainingMethod = TrainingMethod.CLASSROOM
    duration_hours: Decimal | None = Field(
        default=None, gt=0, le=1000, max_digits=5, decimal_places=1
    )
    certificate_ref: str | None = Field(default=None, max_length=100)
    notes: str | None = Field(default=None, max_length=2000)
    attendees: list[Attendee] = Field(min_length=1, max_length=200)
    password: SignaturePassword

    @model_validator(mode="after")
    def _unique(self) -> Self:
        ids = [a.user_id for a in self.attendees]
        if len(ids) != len(set(ids)):
            raise ValueError("each attendee may be listed once")
        return self


class TrainingRecordView(View):
    id: UUID
    serial: str | None
    user_id: UUID
    user_name: str
    course_id: UUID
    course_code: str
    course_title: str
    trained_on: date
    expires_on: date | None
    trainer: str
    method: TrainingMethod
    duration_hours: Decimal | None
    result: TrainingResult
    score: Decimal | None
    certificate_ref: str | None
    notes: str | None
    recorded_at: datetime
    recorded_by: UUID
    state: str = Field(description='"valid", "expiring", "expired" or "failed"')
    signatures: list[SignatureView] = Field(default_factory=list)


class MatrixCell(View):
    course_id: UUID
    required: bool
    status: str = Field(
        description='"valid", "expiring", "expired", "failed", "missing" or "not_required"'
    )
    trained_on: date | None
    expires_on: date | None
    record_id: UUID | None


class MatrixRow(View):
    user_id: UUID
    full_name: str
    role: Role
    cells: list[MatrixCell]
    required: int
    compliant: int


class TrainingMatrix(View):
    courses: list[CourseView]
    rows: list[MatrixRow]
    required: int
    compliant: int
    compliance_pct: float | None
    expiring: int
    expired: int
    missing: int


class Competence(View):
    """Whether a person may record a control point (the courses linked to it)."""

    control_point_id: UUID
    qualified: bool
    missing: list[str]
