from decimal import Decimal
from typing import Annotated

from pydantic import BaseModel, ConfigDict, Field

Code = Annotated[str, Field(min_length=1, max_length=64, pattern=r"^[A-Za-z0-9._-]+$")]
Name = Annotated[str, Field(min_length=1, max_length=200)]
PositiveQuantity = Annotated[Decimal, Field(gt=0, max_digits=14, decimal_places=3)]


class Command(BaseModel):
    """Input model: unknown fields are rejected so typos never pass silently."""

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class View(BaseModel):
    """Output model built from ORM objects."""

    model_config = ConfigDict(from_attributes=True)
