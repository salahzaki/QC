"""ORM models.

Ledger-style tables (transactions, links, shipments, production runs, audit events) are
append-only: database triggers reject UPDATE and DELETE. Corrections are new rows.
"""

import uuid
from datetime import date, datetime
from decimal import Decimal
from typing import Any

from sqlalchemy import (
    BigInteger,
    Boolean,
    CheckConstraint,
    Date,
    DateTime,
    ForeignKey,
    Integer,
    LargeBinary,
    Numeric,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, deferred, mapped_column, relationship

from compliance_engine.core.permissions import Role
from compliance_engine.models.base import (
    Base,
    CreatedAtMixin,
    IdMixin,
    Quantity,
    TenantMixin,
    text_enum,
)
from compliance_engine.models.enums import (
    AlertKind,
    AlertSeverity,
    CorrectiveActionStatus,
    DeliveryStatus,
    ItemType,
    LotOrigin,
    LotStatus,
    NotificationChannel,
    ProductDisposition,
    RiskLevel,
    SanitationActivity,
    SanitationResult,
    SignatureMeaning,
    SmtpSecurity,
    SupplierDocumentType,
    SupplierStatus,
    TrainingMethod,
    TrainingResult,
    TransactionType,
    UnitOfMeasure,
)


class Tenant(IdMixin, CreatedAtMixin, Base):
    __tablename__ = "tenants"

    slug: Mapped[str] = mapped_column(String(64), unique=True)
    name: Mapped[str] = mapped_column(String(200))


class User(IdMixin, TenantMixin, CreatedAtMixin, Base):
    __tablename__ = "users"
    __table_args__ = (UniqueConstraint("tenant_id", "email"),)

    email: Mapped[str] = mapped_column(String(254))
    full_name: Mapped[str] = mapped_column(String(200))
    password_hash: Mapped[str] = mapped_column(String(100))
    role: Mapped[Role] = mapped_column(text_enum(Role))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    # Consecutive wrong passwords (login, signature or password change); reset on success.
    failed_password_attempts: Mapped[int] = mapped_column(Integer, default=0, server_default="0")
    # Set when the account is locked after too many wrong passwords; an admin unlocks it.
    locked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    # Mobile number in international format, used to add the user as a WhatsApp recipient.
    phone: Mapped[str | None] = mapped_column(String(20))


class Supplier(IdMixin, TenantMixin, CreatedAtMixin, Base):
    """A supplier of materials or packaging. `approval_status` changes only through signed
    approval decisions (SupplierApproval); `is_approved` mirrors it for older clients."""

    __tablename__ = "suppliers"
    __table_args__ = (UniqueConstraint("tenant_id", "code"),)

    code: Mapped[str] = mapped_column(String(64))
    name: Mapped[str] = mapped_column(String(200))
    is_approved: Mapped[bool] = mapped_column(Boolean, default=False)
    erp_ref: Mapped[str | None] = mapped_column(String(128))
    approval_status: Mapped[SupplierStatus] = mapped_column(
        text_enum(SupplierStatus), default=SupplierStatus.PENDING
    )
    risk_level: Mapped[RiskLevel] = mapped_column(text_enum(RiskLevel), default=RiskLevel.MEDIUM)
    category: Mapped[str | None] = mapped_column(String(200))  # what they supply
    contact_name: Mapped[str | None] = mapped_column(String(200))
    contact_phone: Mapped[str | None] = mapped_column(String(32))
    contact_email: Mapped[str | None] = mapped_column(String(254))
    next_review_date: Mapped[date | None] = mapped_column(Date)
    notes: Mapped[str | None] = mapped_column(Text)


class Customer(IdMixin, TenantMixin, CreatedAtMixin, Base):
    __tablename__ = "customers"
    __table_args__ = (UniqueConstraint("tenant_id", "code"),)

    code: Mapped[str] = mapped_column(String(64))
    name: Mapped[str] = mapped_column(String(200))
    erp_ref: Mapped[str | None] = mapped_column(String(128))


class Item(IdMixin, TenantMixin, CreatedAtMixin, Base):
    __tablename__ = "items"
    __table_args__ = (
        UniqueConstraint("tenant_id", "code"),
        CheckConstraint("shelf_life_days IS NULL OR shelf_life_days > 0", name="shelf_life"),
    )

    code: Mapped[str] = mapped_column(String(64))
    name: Mapped[str] = mapped_column(String(200))
    item_type: Mapped[ItemType] = mapped_column(text_enum(ItemType))
    uom: Mapped[UnitOfMeasure] = mapped_column(text_enum(UnitOfMeasure))
    shelf_life_days: Mapped[int | None] = mapped_column(Integer)


class ProductionRun(IdMixin, TenantMixin, Base):
    __tablename__ = "production_runs"

    reference: Mapped[str] = mapped_column(String(64))
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    recorded_by: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id"))


class Lot(IdMixin, TenantMixin, CreatedAtMixin, Base):
    """A physical lot. Only `status` may change after creation (enforced by trigger)."""

    __tablename__ = "lots"
    __table_args__ = (UniqueConstraint("tenant_id", "lot_code"),)

    lot_code: Mapped[str] = mapped_column(String(64))
    item_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("items.id"), index=True)
    origin: Mapped[LotOrigin] = mapped_column(text_enum(LotOrigin))
    status: Mapped[LotStatus] = mapped_column(text_enum(LotStatus))
    expiry_date: Mapped[date | None] = mapped_column(Date)
    supplier_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("suppliers.id"))
    supplier_lot_code: Mapped[str | None] = mapped_column(String(64))
    production_run_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("production_runs.id"))
    created_by: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id"))

    item: Mapped[Item] = relationship(lazy="joined")
    supplier: Mapped[Supplier | None] = relationship(lazy="joined")


class LotTransaction(IdMixin, TenantMixin, CreatedAtMixin, Base):
    """Signed quantity ledger. A lot's balance is the sum of its transactions."""

    __tablename__ = "lot_transactions"
    __table_args__ = (CheckConstraint("quantity <> 0", name="non_zero"),)

    lot_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("lots.id"), index=True)
    transaction_type: Mapped[TransactionType] = mapped_column(text_enum(TransactionType))
    quantity: Mapped[Quantity]
    reference_id: Mapped[uuid.UUID | None]
    created_by: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id"))


class LotLink(IdMixin, TenantMixin, Base):
    """Genealogy edge: `quantity` of the parent lot went into the child lot."""

    __tablename__ = "lot_links"
    __table_args__ = (
        CheckConstraint("quantity > 0", name="positive"),
        CheckConstraint("parent_lot_id <> child_lot_id", name="no_self_link"),
    )

    production_run_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("production_runs.id"))
    parent_lot_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("lots.id"), index=True)
    child_lot_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("lots.id"), index=True)
    quantity: Mapped[Quantity]


class Shipment(IdMixin, TenantMixin, Base):
    __tablename__ = "shipments"

    customer_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("customers.id"))
    reference: Mapped[str] = mapped_column(String(64))
    shipped_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    recorded_by: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id"))

    customer: Mapped[Customer] = relationship(lazy="joined")


class ShipmentLine(IdMixin, TenantMixin, Base):
    __tablename__ = "shipment_lines"
    __table_args__ = (CheckConstraint("quantity > 0", name="positive"),)

    shipment_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("shipments.id"), index=True)
    lot_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("lots.id"), index=True)
    quantity: Mapped[Quantity]


class AuditEvent(IdMixin, TenantMixin, Base):
    """Tamper-evident log. Each event's hash covers its content and the previous hash."""

    __tablename__ = "audit_events"
    __table_args__ = (UniqueConstraint("tenant_id", "seq"),)

    seq: Mapped[int] = mapped_column(BigInteger)
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    actor_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id"))
    action: Mapped[str] = mapped_column(String(64))
    entity_type: Mapped[str] = mapped_column(String(64))
    entity_id: Mapped[uuid.UUID]
    payload: Mapped[dict[str, Any]] = mapped_column(JSONB)
    prev_hash: Mapped[str] = mapped_column(String(64))
    hash: Mapped[str] = mapped_column(String(64))


class ControlPoint(IdMixin, TenantMixin, CreatedAtMixin, Base):
    """A critical control point from the HACCP plan, with its critical limits."""

    __tablename__ = "control_points"
    __table_args__ = (
        UniqueConstraint("tenant_id", "code"),
        CheckConstraint("critical_min IS NOT NULL OR critical_max IS NOT NULL", name="has_a_limit"),
        CheckConstraint(
            "critical_min IS NULL OR critical_max IS NULL OR critical_min <= critical_max",
            name="limits_ordered",
        ),
        CheckConstraint(
            "check_interval_minutes IS NULL OR check_interval_minutes > 0",
            name="positive_interval",
        ),
    )

    code: Mapped[str] = mapped_column(String(64))
    name: Mapped[str] = mapped_column(String(200))
    hazard: Mapped[str] = mapped_column(String(500))
    parameter: Mapped[str] = mapped_column(String(100))
    unit: Mapped[str] = mapped_column(String(16))
    critical_min: Mapped[Decimal | None] = mapped_column(Numeric(12, 3))
    critical_max: Mapped[Decimal | None] = mapped_column(Numeric(12, 3))
    monitoring_frequency: Mapped[str | None] = mapped_column(String(100))
    # When set, a "missed check" alert is raised if no reading arrives within this window.
    check_interval_minutes: Mapped[int | None] = mapped_column(Integer)


class CcpReading(IdMixin, TenantMixin, CreatedAtMixin, Base):
    """One monitoring check of a CCP. The limits in force are copied onto the reading,
    so later changes to the HACCP plan never rewrite what was true at the time."""

    __tablename__ = "ccp_readings"
    __table_args__ = (
        CheckConstraint(
            "within_limits OR corrective_action IS NOT NULL", name="deviation_has_action"
        ),
        UniqueConstraint("tenant_id", "serial"),
    )

    # Human-readable number, e.g. CCP-2026-000123; assigned on insert (services/numbering.py).
    serial: Mapped[str | None] = mapped_column(String(32))

    control_point_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("control_points.id"), index=True)
    value: Mapped[Decimal] = mapped_column(Numeric(12, 3))
    unit: Mapped[str] = mapped_column(String(16))
    critical_min: Mapped[Decimal | None] = mapped_column(Numeric(12, 3))
    critical_max: Mapped[Decimal | None] = mapped_column(Numeric(12, 3))
    within_limits: Mapped[bool] = mapped_column(Boolean)
    corrective_action: Mapped[str | None] = mapped_column(Text)
    notes: Mapped[str | None] = mapped_column(Text)
    lot_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("lots.id"), index=True)
    production_run_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("production_runs.id"))
    measured_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    recorded_by: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id"))

    control_point: Mapped[ControlPoint] = relationship(lazy="joined")


class SanitationRecord(IdMixin, TenantMixin, CreatedAtMixin, Base):
    """A cleaning, sanitizing or pre-operation inspection of one area or piece of equipment."""

    __tablename__ = "sanitation_records"
    __table_args__ = (
        CheckConstraint(
            "result = 'pass' OR corrective_action IS NOT NULL", name="failure_has_action"
        ),
        UniqueConstraint("tenant_id", "serial"),
    )

    # Human-readable number, e.g. CCP-2026-000123; assigned on insert (services/numbering.py).
    serial: Mapped[str | None] = mapped_column(String(32))

    area: Mapped[str] = mapped_column(String(64), index=True)
    activity: Mapped[SanitationActivity] = mapped_column(text_enum(SanitationActivity))
    chemical: Mapped[str | None] = mapped_column(String(100))
    concentration_ppm: Mapped[Decimal | None] = mapped_column(Numeric(10, 2))
    result: Mapped[SanitationResult] = mapped_column(text_enum(SanitationResult))
    corrective_action: Mapped[str | None] = mapped_column(Text)
    notes: Mapped[str | None] = mapped_column(Text)
    performed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    recorded_by: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id"))


class RecordSignature(IdMixin, TenantMixin, Base):
    """Electronic signature on a quality record.

    The signer re-enters their password to sign. Name, role and meaning are stored with the
    signature, and `record_hash` fingerprints the record as it was when signed.
    """

    __tablename__ = "record_signatures"
    __table_args__ = (UniqueConstraint("tenant_id", "record_type", "record_id", "meaning"),)

    record_type: Mapped[str] = mapped_column(String(32))
    record_id: Mapped[uuid.UUID] = mapped_column(index=True)
    meaning: Mapped[SignatureMeaning] = mapped_column(text_enum(SignatureMeaning))
    signer_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id"))
    signer_name: Mapped[str] = mapped_column(String(200))
    signer_role: Mapped[Role] = mapped_column(text_enum(Role))
    signed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    comment: Mapped[str | None] = mapped_column(String(500))
    record_hash: Mapped[str] = mapped_column(String(64))


class RecordAmendment(IdMixin, TenantMixin, CreatedAtMixin, Base):
    """A signed correction to a monitoring record.

    The original record is never changed. Each amendment stores the fields it corrects
    (old and new value) and why; the record is shown with all amendments applied, and every
    amendment needs its own verification by a second person.
    """

    __tablename__ = "record_amendments"
    __table_args__ = (UniqueConstraint("tenant_id", "serial"),)

    # Human-readable number, e.g. CCP-2026-000123; assigned on insert (services/numbering.py).
    serial: Mapped[str | None] = mapped_column(String(32))

    record_type: Mapped[str] = mapped_column(String(32))
    record_id: Mapped[uuid.UUID] = mapped_column(index=True)
    changes: Mapped[dict[str, Any]] = mapped_column(JSONB)
    reason: Mapped[str] = mapped_column(Text)
    amended_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    amended_by: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id"))


class CorrectiveAction(IdMixin, TenantMixin, CreatedAtMixin, Base):
    """Follow-up of one deviation (CCP out of limits, failed sanitation check).

    Opened automatically with the immediate action written on the record. Closed once by a
    quality manager with root cause, preventive action and product disposition, signed
    "approved". After closing, the row can never change (enforced by trigger).
    """

    __tablename__ = "corrective_actions"
    __table_args__ = (
        UniqueConstraint("tenant_id", "record_type", "record_id"),
        CheckConstraint(
            "status = 'open' OR (root_cause IS NOT NULL AND preventive_action IS NOT NULL "
            "AND product_disposition IS NOT NULL AND closed_at IS NOT NULL "
            "AND closed_by IS NOT NULL)",
            name="closed_is_complete",
        ),
        UniqueConstraint("tenant_id", "serial"),
    )

    # Human-readable number, e.g. CCP-2026-000123; assigned on insert (services/numbering.py).
    serial: Mapped[str | None] = mapped_column(String(32))

    record_type: Mapped[str] = mapped_column(String(32))
    record_id: Mapped[uuid.UUID] = mapped_column(index=True)
    control_point_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("control_points.id"))
    lot_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("lots.id"))
    description: Mapped[str] = mapped_column(Text)
    immediate_action: Mapped[str] = mapped_column(Text)
    opened_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    opened_by: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id"))
    status: Mapped[CorrectiveActionStatus] = mapped_column(text_enum(CorrectiveActionStatus))
    root_cause: Mapped[str | None] = mapped_column(Text)
    preventive_action: Mapped[str | None] = mapped_column(Text)
    product_disposition: Mapped[ProductDisposition | None] = mapped_column(
        text_enum(ProductDisposition)
    )
    closed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    closed_by: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id"))


class Alert(IdMixin, TenantMixin, CreatedAtMixin, Base):
    """Something a supervisor must look at now. Only the acknowledgement may be added later."""

    __tablename__ = "alerts"

    kind: Mapped[AlertKind] = mapped_column(text_enum(AlertKind))
    severity: Mapped[AlertSeverity] = mapped_column(text_enum(AlertSeverity))
    message: Mapped[str] = mapped_column(String(500))
    record_type: Mapped[str | None] = mapped_column(String(32))
    record_id: Mapped[uuid.UUID | None]
    control_point_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("control_points.id"), index=True
    )
    raised_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    acknowledged_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    acknowledged_by: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id"))
    acknowledgement: Mapped[str | None] = mapped_column(String(500))


class NotificationRecipient(IdMixin, TenantMixin, CreatedAtMixin, Base):
    """Someone who gets alerts by e-mail or WhatsApp."""

    __tablename__ = "notification_recipients"
    __table_args__ = (UniqueConstraint("tenant_id", "channel", "address"),)

    name: Mapped[str] = mapped_column(String(200))
    channel: Mapped[NotificationChannel] = mapped_column(text_enum(NotificationChannel))
    address: Mapped[str] = mapped_column(String(254))
    # "major" gets every alert; "critical" only critical ones.
    min_severity: Mapped[AlertSeverity] = mapped_column(text_enum(AlertSeverity))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


class NotificationDelivery(IdMixin, TenantMixin, CreatedAtMixin, Base):
    """One alert sent (or being sent) to one recipient. Failed sends are retried."""

    __tablename__ = "notification_deliveries"

    alert_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("alerts.id"), index=True)
    recipient_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("notification_recipients.id"))
    channel: Mapped[NotificationChannel] = mapped_column(text_enum(NotificationChannel))
    address: Mapped[str] = mapped_column(String(254))
    status: Mapped[DeliveryStatus] = mapped_column(text_enum(DeliveryStatus), index=True)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    next_attempt_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    sent_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_error: Mapped[str | None] = mapped_column(String(500))


class RecordCounter(Base):
    """Last number handed out per tenant, series (CCP, SAN, ...) and year. Numbers are taken
    inside the inserting transaction, so a rolled-back insert leaves no gap."""

    __tablename__ = "record_counters"

    tenant_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("tenants.id"), primary_key=True)
    series: Mapped[str] = mapped_column(String(16), primary_key=True)
    year: Mapped[int] = mapped_column(Integer, primary_key=True)
    last_number: Mapped[int] = mapped_column(Integer)


class DocumentForm(IdMixin, TenantMixin, CreatedAtMixin, Base):
    """A controlled form of the food safety system (document control).

    Each report the system prints is one of these forms. Its code, revision and effective
    date are printed in the header of every page, as document control in ISO 22000 / FSSC
    22000 / BRCGS expects. Changes are written to the audit log with old and new values.
    """

    __tablename__ = "document_forms"
    __table_args__ = (UniqueConstraint("tenant_id", "key"), UniqueConstraint("tenant_id", "code"))

    key: Mapped[str] = mapped_column(String(32))
    code: Mapped[str] = mapped_column(String(32))
    title_ar: Mapped[str] = mapped_column(String(200))
    title_en: Mapped[str] = mapped_column(String(200))
    revision: Mapped[str] = mapped_column(String(8))
    effective_date: Mapped[date] = mapped_column(Date)
    reference: Mapped[str | None] = mapped_column(String(300))
    retention_years: Mapped[int] = mapped_column(Integer)
    approved_by_name: Mapped[str | None] = mapped_column(String(200))
    updated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class IssuedReport(IdMixin, TenantMixin, CreatedAtMixin, Base):
    """Register of every report PDF the system produced, with its number and SHA-256, so a
    printed or e-mailed copy can be checked later. Append-only."""

    __tablename__ = "issued_reports"
    __table_args__ = (UniqueConstraint("tenant_id", "serial"),)

    serial: Mapped[str] = mapped_column(String(32))
    form_key: Mapped[str] = mapped_column(String(32))
    form_code: Mapped[str] = mapped_column(String(32))
    form_revision: Mapped[str] = mapped_column(String(8))
    title: Mapped[str] = mapped_column(String(200))
    lang: Mapped[str] = mapped_column(String(2))
    parameters: Mapped[dict[str, Any]] = mapped_column(JSONB)
    filename: Mapped[str] = mapped_column(String(200))
    sha256: Mapped[str] = mapped_column(String(64), index=True)
    issued_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    issued_by: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id"))
    issued_by_name: Mapped[str] = mapped_column(String(200))


class SupplierApproval(IdMixin, TenantMixin, CreatedAtMixin, Base):
    """One decision on a supplier's approval status, signed "approved" by the person who
    took it. The history of decisions is the approved-supplier evidence auditors ask for."""

    __tablename__ = "supplier_approvals"
    __table_args__ = (UniqueConstraint("tenant_id", "serial"),)

    serial: Mapped[str | None] = mapped_column(String(32))
    supplier_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("suppliers.id"), index=True)
    from_status: Mapped[SupplierStatus] = mapped_column(text_enum(SupplierStatus, "from_status"))
    to_status: Mapped[SupplierStatus] = mapped_column(text_enum(SupplierStatus, "to_status"))
    risk_level: Mapped[RiskLevel] = mapped_column(text_enum(RiskLevel))
    reason: Mapped[str] = mapped_column(Text)
    conditions: Mapped[str | None] = mapped_column(Text)
    next_review_date: Mapped[date | None] = mapped_column(Date)
    decided_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    decided_by: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id"))


class SupplierDocument(IdMixin, TenantMixin, CreatedAtMixin, Base):
    """A certificate, licence or other document held for a supplier, optionally with the
    scanned file. Never edited: a renewed certificate is a new document, and an old one is
    withdrawn (only the withdrawal fields may be set later, enforced by trigger)."""

    __tablename__ = "supplier_documents"

    supplier_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("suppliers.id"), index=True)
    doc_type: Mapped[SupplierDocumentType] = mapped_column(text_enum(SupplierDocumentType))
    title: Mapped[str] = mapped_column(String(200))
    number: Mapped[str | None] = mapped_column(String(100))
    issuer: Mapped[str | None] = mapped_column(String(200))
    issued_on: Mapped[date | None] = mapped_column(Date)
    expires_on: Mapped[date | None] = mapped_column(Date, index=True)
    # Required documents must be valid to receive goods from the supplier.
    is_required: Mapped[bool] = mapped_column(Boolean)
    file_name: Mapped[str | None] = mapped_column(String(200))
    content_type: Mapped[str | None] = mapped_column(String(100))
    file_size: Mapped[int | None] = mapped_column(Integer)
    file_sha256: Mapped[str | None] = mapped_column(String(64))
    file_data: Mapped[bytes | None] = deferred(mapped_column(LargeBinary))
    uploaded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    uploaded_by: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id"))
    withdrawn_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    withdrawn_by: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id"))
    withdrawn_reason: Mapped[str | None] = mapped_column(String(500))


class SupplierEvaluation(IdMixin, TenantMixin, CreatedAtMixin, Base):
    """Periodic performance evaluation of a supplier, signed by the evaluator. The lots
    received and blocked in the period are copied in from the system when it is saved."""

    __tablename__ = "supplier_evaluations"
    __table_args__ = (
        UniqueConstraint("tenant_id", "serial"),
        CheckConstraint("period_from <= period_to", name="period_ordered"),
    )

    serial: Mapped[str | None] = mapped_column(String(32))
    supplier_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("suppliers.id"), index=True)
    period_from: Mapped[date] = mapped_column(Date)
    period_to: Mapped[date] = mapped_column(Date)
    quality_score: Mapped[int] = mapped_column(Integer)
    delivery_score: Mapped[int] = mapped_column(Integer)
    documentation_score: Mapped[int] = mapped_column(Integer)
    service_score: Mapped[int] = mapped_column(Integer)
    total_score: Mapped[Decimal] = mapped_column(Numeric(5, 1))
    recommendation: Mapped[SupplierStatus] = mapped_column(text_enum(SupplierStatus))
    lots_received: Mapped[int] = mapped_column(Integer)
    lots_blocked: Mapped[int] = mapped_column(Integer)
    comments: Mapped[str | None] = mapped_column(Text)
    evaluated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    evaluated_by: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id"))


class TrainingCourse(IdMixin, TenantMixin, CreatedAtMixin, Base):
    """A training course or competence (e.g. food hygiene, HACCP, allergen control).

    `required_roles` makes it part of the training matrix for those roles; `control_point_ids`
    names the CCPs a person may only record after passing it (when the competence gate is on).
    """

    __tablename__ = "training_courses"
    __table_args__ = (
        UniqueConstraint("tenant_id", "code"),
        CheckConstraint("validity_months IS NULL OR validity_months > 0", name="positive_validity"),
    )

    code: Mapped[str] = mapped_column(String(64))
    title: Mapped[str] = mapped_column(String(200))
    category: Mapped[str | None] = mapped_column(String(100))
    description: Mapped[str | None] = mapped_column(Text)
    # Months a pass stays valid before refresher training; empty = does not expire.
    validity_months: Mapped[int | None] = mapped_column(Integer)
    required_roles: Mapped[list[str]] = mapped_column(JSONB, default=list)
    control_point_ids: Mapped[list[str]] = mapped_column(JSONB, default=list)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    updated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class TrainingRecord(IdMixin, TenantMixin, CreatedAtMixin, Base):
    """One person's attendance or result on a course, signed by whoever recorded it.
    `expires_on` is fixed when recorded, from the course validity at that time."""

    __tablename__ = "training_records"
    __table_args__ = (UniqueConstraint("tenant_id", "serial"),)

    serial: Mapped[str | None] = mapped_column(String(32))
    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id"), index=True)
    course_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("training_courses.id"), index=True)
    trained_on: Mapped[date] = mapped_column(Date)
    expires_on: Mapped[date | None] = mapped_column(Date)
    trainer: Mapped[str] = mapped_column(String(200))
    method: Mapped[TrainingMethod] = mapped_column(text_enum(TrainingMethod))
    duration_hours: Mapped[Decimal | None] = mapped_column(Numeric(5, 1))
    result: Mapped[TrainingResult] = mapped_column(text_enum(TrainingResult))
    score: Mapped[Decimal | None] = mapped_column(Numeric(5, 1))
    certificate_ref: Mapped[str | None] = mapped_column(String(100))
    notes: Mapped[str | None] = mapped_column(Text)
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    recorded_by: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id"))


class TenantSettings(Base):
    """Settings a factory manages from the app. Mail and WhatsApp set here take precedence
    over the server's CE_SMTP_* / CE_WHATSAPP_* values. Secrets are stored encrypted
    (core/secrets.py) and are never sent back to the browser."""

    __tablename__ = "tenant_settings"

    tenant_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("tenants.id"), primary_key=True)
    # Refuse CCP readings from people without a valid pass on the courses linked to that CCP.
    enforce_training: Mapped[bool] = mapped_column(Boolean, default=False)
    # Warn this many days before a supplier document or a training expires.
    expiry_warning_days: Mapped[int] = mapped_column(Integer, default=30)
    smtp_host: Mapped[str | None] = mapped_column(String(200))
    smtp_port: Mapped[int | None] = mapped_column(Integer)
    smtp_security: Mapped[SmtpSecurity | None] = mapped_column(text_enum(SmtpSecurity))
    smtp_username: Mapped[str | None] = mapped_column(String(254))
    smtp_password_enc: Mapped[str | None] = mapped_column(Text)
    smtp_from: Mapped[str | None] = mapped_column(String(254))
    whatsapp_phone_number_id: Mapped[str | None] = mapped_column(String(64))
    whatsapp_token_enc: Mapped[str | None] = mapped_column(Text)
    whatsapp_template: Mapped[str | None] = mapped_column(String(100))
    whatsapp_template_language: Mapped[str | None] = mapped_column(String(16))
    updated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    updated_by: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id"))
