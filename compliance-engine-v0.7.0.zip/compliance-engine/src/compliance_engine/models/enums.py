from enum import StrEnum


class ItemType(StrEnum):
    RAW_MATERIAL = "raw_material"
    PACKAGING = "packaging"
    WORK_IN_PROGRESS = "work_in_progress"
    FINISHED_GOOD = "finished_good"


class UnitOfMeasure(StrEnum):
    KG = "kg"
    G = "g"
    L = "l"
    ML = "ml"
    PCS = "pcs"


class LotStatus(StrEnum):
    QUARANTINE = "quarantine"
    RELEASED = "released"
    BLOCKED = "blocked"


class LotOrigin(StrEnum):
    RECEIVED = "received"
    PRODUCED = "produced"


class TransactionType(StrEnum):
    RECEIPT = "receipt"
    PRODUCTION_OUTPUT = "production_output"
    CONSUMPTION = "consumption"
    DISPATCH = "dispatch"


class SanitationActivity(StrEnum):
    PRE_OP_INSPECTION = "pre_op_inspection"
    CLEANING = "cleaning"
    SANITIZING = "sanitizing"
    DEEP_CLEAN = "deep_clean"
    AFTER_USE = "after_use"  # cleaning of equipment or utensils right after use


class SanitationResult(StrEnum):
    PASS = "pass"
    FAIL = "fail"


class SignatureMeaning(StrEnum):
    """What the signer attests to (shown next to the name on every signed record)."""

    PERFORMED = "performed"  # I did this check / task and the entry is true
    VERIFIED = "verified"  # I reviewed this record, including any corrective action
    APPROVED = "approved"  # I approve closing this corrective action


class CorrectiveActionStatus(StrEnum):
    OPEN = "open"
    CLOSED = "closed"


class ProductDisposition(StrEnum):
    """What happened to product made while a CCP was out of control."""

    NOT_APPLICABLE = "not_applicable"  # no product affected (e.g. a sanitation failure)
    RELEASED_AFTER_EVALUATION = "released_after_evaluation"
    REWORKED = "reworked"
    DIVERTED = "diverted"  # used for another, safe purpose
    DESTROYED = "destroyed"


class AlertKind(StrEnum):
    CCP_DEVIATION = "ccp_deviation"
    SANITATION_FAILURE = "sanitation_failure"
    MISSED_CHECK = "missed_check"
    SUPPLIER_DOCUMENT_EXPIRING = "supplier_document_expiring"
    SUPPLIER_DOCUMENT_EXPIRED = "supplier_document_expired"
    SUPPLIER_REVIEW_DUE = "supplier_review_due"
    TRAINING_EXPIRING = "training_expiring"
    TRAINING_EXPIRED = "training_expired"


class AlertSeverity(StrEnum):
    CRITICAL = "critical"
    MAJOR = "major"


class NotificationChannel(StrEnum):
    EMAIL = "email"
    WHATSAPP = "whatsapp"


class DeliveryStatus(StrEnum):
    PENDING = "pending"  # waiting to be sent, or to be retried
    SENT = "sent"
    FAILED = "failed"  # gave up after the last retry


class SupplierStatus(StrEnum):
    """Where a supplier stands in the approval process. Goods are received only from
    approved and conditionally approved suppliers."""

    PENDING = "pending"  # new supplier, being assessed
    APPROVED = "approved"
    CONDITIONAL = "conditional"  # approved with conditions, e.g. a certificate to follow
    SUSPENDED = "suspended"  # temporarily stopped, e.g. after a serious complaint
    REJECTED = "rejected"


RECEIVING_ALLOWED = frozenset({SupplierStatus.APPROVED, SupplierStatus.CONDITIONAL})


class RiskLevel(StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class SupplierDocumentType(StrEnum):
    FOOD_SAFETY_CERTIFICATE = "food_safety_certificate"  # ISO 22000, FSSC 22000, BRCGS, IFS
    HALAL_CERTIFICATE = "halal_certificate"
    COMMERCIAL_REGISTRATION = "commercial_registration"
    HEALTH_LICENSE = "health_license"  # licence from the food authority / municipality
    SPECIFICATION = "specification"  # product specification or certificate of analysis
    AUDIT_REPORT = "audit_report"  # supplier audit (ours or third party)
    QUESTIONNAIRE = "questionnaire"  # supplier self-assessment questionnaire
    OTHER = "other"


class TrainingMethod(StrEnum):
    CLASSROOM = "classroom"
    ON_THE_JOB = "on_the_job"
    ONLINE = "online"
    EXTERNAL = "external"


class TrainingResult(StrEnum):
    PASSED = "passed"
    FAILED = "failed"
    ATTENDED = "attended"  # attendance only, no assessment


class SmtpSecurity(StrEnum):
    STARTTLS = "starttls"
    SSL = "ssl"
    NONE = "none"
