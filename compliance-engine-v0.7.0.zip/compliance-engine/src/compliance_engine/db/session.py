from functools import lru_cache
from uuid import UUID

from sqlalchemy import Engine, create_engine, text
from sqlalchemy.orm import Session, sessionmaker

from compliance_engine.core.config import get_settings


@lru_cache
def get_engine() -> Engine:
    return create_engine(get_settings().database_url, pool_pre_ping=True)


@lru_cache
def get_session_factory() -> sessionmaker[Session]:
    return sessionmaker(bind=get_engine(), expire_on_commit=False)


def bind_tenant(session: Session, tenant_id: UUID) -> None:
    """Scope the current transaction to one tenant.

    Every tenant table has a row-level security policy that reads `app.tenant_id`,
    so after this call the session can only see and write that tenant's rows.
    The setting is transaction-local and disappears on commit or rollback.
    """
    session.execute(
        text("SELECT set_config('app.tenant_id', :tenant_id, true)"),
        {"tenant_id": str(tenant_id)},
    )
