"""Operator commands.

    python -m compliance_engine.cli create-tenant --slug awrad --name "Awrad Foods" \
        --admin-email qa@example.com --admin-name "QA Admin"
    python -m compliance_engine.cli reset-password --tenant awrad --email qa@example.com
"""

import argparse
import getpass
import sys

from pydantic import ValidationError

from compliance_engine.core.errors import DomainError
from compliance_engine.db.session import get_session_factory
from compliance_engine.schemas.identity import CreateTenant
from compliance_engine.services.identity import provision_tenant, reset_password_by_email


def _create_tenant(args: argparse.Namespace) -> int:
    password = getpass.getpass("Admin password (min 10 characters): ")
    try:
        command = CreateTenant(
            slug=args.slug,
            name=args.name,
            admin_email=args.admin_email,
            admin_full_name=args.admin_name,
            admin_password=password,
        )
    except ValidationError as exc:
        print(exc, file=sys.stderr)
        return 1

    with get_session_factory().begin() as session:
        try:
            tenant, admin = provision_tenant(session, command)
        except DomainError as exc:
            print(f"Error: {exc}", file=sys.stderr)
            return 1
        print(f"Created tenant '{tenant.slug}' ({tenant.id}) with admin {admin.email}")
    return 0


def _reset_password(args: argparse.Namespace) -> int:
    password = getpass.getpass("New password (min 10 characters): ")
    with get_session_factory().begin() as session:
        try:
            user = reset_password_by_email(session, args.tenant, args.email, password)
        except (DomainError, ValidationError) as exc:
            print(f"Error: {exc}", file=sys.stderr)
            return 1
        print(f"Password changed for {user.email}")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(prog="compliance-engine")
    commands = parser.add_subparsers(dest="command", required=True)

    tenant = commands.add_parser("create-tenant", help="Create a tenant and its first admin")
    tenant.add_argument("--slug", required=True)
    tenant.add_argument("--name", required=True)
    tenant.add_argument("--admin-email", required=True)
    tenant.add_argument("--admin-name", required=True)
    tenant.set_defaults(handler=_create_tenant)

    reset = commands.add_parser("reset-password", help="Set a new password for a user")
    reset.add_argument("--tenant", required=True)
    reset.add_argument("--email", required=True)
    reset.set_defaults(handler=_reset_password)

    args = parser.parse_args()
    exit_code: int = args.handler(args)
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
