"""Encrypting secrets kept in the database (mail password, WhatsApp token).

Keys are derived from CE_JWT_SECRET, so a copy of the database alone does not reveal them.
Uses only the standard library: HMAC-SHA256 in counter mode for the key stream, and
HMAC-SHA256 over nonce and ciphertext to detect tampering (encrypt-then-MAC).
If CE_JWT_SECRET changes, stored secrets can no longer be read and must be entered again.
"""

import base64
import hashlib
import hmac
import secrets

from compliance_engine.core.config import get_settings

_PREFIX = "v1:"
_NONCE = 16
_TAG = 32


def _keys() -> tuple[bytes, bytes]:
    master = get_settings().jwt_secret.get_secret_value().encode()
    return (
        hmac.new(master, b"compliance-engine/settings/encrypt", hashlib.sha256).digest(),
        hmac.new(master, b"compliance-engine/settings/mac", hashlib.sha256).digest(),
    )


def _stream(key: bytes, nonce: bytes, length: int) -> bytes:
    blocks = (
        hmac.new(key, nonce + counter.to_bytes(4, "big"), hashlib.sha256).digest()
        for counter in range((length + 31) // 32)
    )
    return b"".join(blocks)[:length]


def encrypt(plain: str) -> str:
    enc_key, mac_key = _keys()
    nonce = secrets.token_bytes(_NONCE)
    data = plain.encode()
    cipher = bytes(a ^ b for a, b in zip(data, _stream(enc_key, nonce, len(data)), strict=True))
    tag = hmac.new(mac_key, nonce + cipher, hashlib.sha256).digest()
    return _PREFIX + base64.b64encode(nonce + cipher + tag).decode()


def decrypt(token: str) -> str | None:
    """The secret, or None when it cannot be read (other CE_JWT_SECRET, damaged value)."""
    if not token.startswith(_PREFIX):
        return None
    try:
        raw = base64.b64decode(token[len(_PREFIX) :], validate=True)
    except ValueError:
        return None
    if len(raw) < _NONCE + _TAG:
        return None
    nonce, cipher, tag = raw[:_NONCE], raw[_NONCE:-_TAG], raw[-_TAG:]
    enc_key, mac_key = _keys()
    if not hmac.compare_digest(tag, hmac.new(mac_key, nonce + cipher, hashlib.sha256).digest()):
        return None
    plain = bytes(a ^ b for a, b in zip(cipher, _stream(enc_key, nonce, len(cipher)), strict=True))
    try:
        return plain.decode()
    except UnicodeDecodeError:
        return None
