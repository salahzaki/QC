"""Domain errors. Services raise these; the API layer maps them to HTTP responses."""

from dataclasses import dataclass
from uuid import UUID


class DomainError(Exception):
    """Base class for expected, user-facing errors."""


class NotFoundError(DomainError):
    def __init__(self, entity: str, key: object) -> None:
        super().__init__(f"{entity} '{key}' was not found")


class ConflictError(DomainError):
    """The request clashes with existing data (e.g. a duplicate code)."""


class BusinessRuleError(DomainError):
    """The request breaks a compliance or inventory rule."""


class AuthenticationError(DomainError):
    pass


class PermissionDeniedError(DomainError):
    pass


@dataclass(frozen=True)
class PasswordFailure:
    """A wrong password typed by a known user, counted towards locking the account."""

    tenant_id: UUID
    user_id: UUID
    context: str  # "login", "signature" or "password_change"


class LoginRejectedError(AuthenticationError):
    def __init__(self, message: str, failure: PasswordFailure | None = None) -> None:
        super().__init__(message)
        self.failure = failure


class PasswordRejectedError(PermissionDeniedError):
    """A signature or password change with the wrong password."""

    def __init__(self, message: str, failure: PasswordFailure | None = None) -> None:
        super().__init__(message)
        self.failure = failure
