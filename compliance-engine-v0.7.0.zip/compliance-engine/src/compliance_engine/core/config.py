from functools import lru_cache
from typing import Literal

from pydantic import Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings, read from environment variables prefixed with CE_."""

    model_config = SettingsConfigDict(env_prefix="CE_", env_file=".env", extra="ignore")

    database_url: str = "postgresql+psycopg://app_user:app_password@localhost:5432/compliance"
    jwt_secret: SecretStr = Field(min_length=32)
    jwt_algorithm: str = "HS256"
    access_token_minutes: int = 60
    bcrypt_rounds: int = Field(default=12, ge=4, le=16)
    factory_timezone: str = "Asia/Riyadh"
    # Language of texts the system writes into records (deviation descriptions, alerts).
    record_language: Literal["ar", "en"] = "ar"
    # How often the server looks for overdue CCP checks; 0 turns the background scan off.
    alert_scan_seconds: int = Field(default=300, ge=0)
    # Wrong passwords in a row (login, signature, password change) before an account locks.
    max_failed_passwords: int = Field(default=5, ge=1, le=20)
    # Days a corrective action may stay open before the dashboard counts it as overdue.
    capa_target_days: int = Field(default=7, ge=1, le=365)

    # Alert notifications. How often queued messages are sent; 0 turns sending off.
    notify_seconds: int = Field(default=30, ge=0)
    # Link added to messages, e.g. https://qa.example.com (optional).
    public_url: str | None = None
    smtp_host: str | None = None
    smtp_port: int = 587
    smtp_security: Literal["starttls", "ssl", "none"] = "starttls"
    smtp_username: str | None = None
    smtp_password: SecretStr | None = None
    smtp_from: str | None = None
    # WhatsApp Business Cloud API (Meta). Without a template, plain text is sent, which
    # WhatsApp only delivers to people who messaged the business number in the last 24 h.
    whatsapp_token: SecretStr | None = None
    whatsapp_phone_number_id: str | None = None
    whatsapp_template: str | None = None
    whatsapp_template_language: str = "ar"
    whatsapp_api_url: str = "https://graph.facebook.com/v21.0"


@lru_cache
def get_settings() -> Settings:
    return Settings()  # values come from CE_* environment variables
