"""Role-based access control: which role may do what.

Keeping the whole matrix in one place makes it easy to review with a quality manager.
"""

from enum import StrEnum


class Role(StrEnum):
    ADMIN = "admin"
    QUALITY_MANAGER = "quality_manager"
    SUPERVISOR = "supervisor"
    OPERATOR = "operator"
    AUDITOR = "auditor"


class Permission(StrEnum):
    USERS_MANAGE = "users:manage"
    MASTER_DATA_READ = "master_data:read"
    MASTER_DATA_WRITE = "master_data:write"
    LOTS_READ = "lots:read"
    LOTS_RECEIVE = "lots:receive"
    LOTS_RELEASE = "lots:release"
    PRODUCTION_RECORD = "production:record"
    SHIPMENTS_RECORD = "shipments:record"
    TRACE_READ = "trace:read"
    AUDIT_READ = "audit:read"
    CCP_MANAGE = "ccp:manage"
    RECORDS_READ = "records:read"
    RECORDS_WRITE = "records:write"
    RECORDS_VERIFY = "records:verify"
    CAPA_CLOSE = "capa:close"
    NOTIFICATIONS_MANAGE = "notifications:manage"
    DOCUMENTS_MANAGE = "documents:manage"
    SUPPLIERS_MANAGE = "suppliers:manage"
    TRAINING_MANAGE = "training:manage"


_READ_ONLY = {
    Permission.MASTER_DATA_READ,
    Permission.LOTS_READ,
    Permission.TRACE_READ,
    Permission.RECORDS_READ,
}

_FLOOR = _READ_ONLY | {
    Permission.LOTS_RECEIVE,
    Permission.PRODUCTION_RECORD,
    Permission.SHIPMENTS_RECORD,
    Permission.RECORDS_WRITE,
}

ROLE_PERMISSIONS: dict[Role, frozenset[Permission]] = {
    Role.ADMIN: frozenset(Permission),
    Role.QUALITY_MANAGER: frozenset(
        _FLOOR
        | {
            Permission.MASTER_DATA_WRITE,
            Permission.LOTS_RELEASE,
            Permission.AUDIT_READ,
            Permission.CCP_MANAGE,
            Permission.RECORDS_VERIFY,
            Permission.CAPA_CLOSE,
            Permission.NOTIFICATIONS_MANAGE,
            Permission.DOCUMENTS_MANAGE,
            Permission.SUPPLIERS_MANAGE,
            Permission.TRAINING_MANAGE,
        }
    ),
    Role.SUPERVISOR: frozenset(_FLOOR | {Permission.RECORDS_VERIFY}),
    Role.OPERATOR: frozenset(_FLOOR),
    Role.AUDITOR: frozenset(_READ_ONLY | {Permission.AUDIT_READ}),
}


def has_permission(role: Role, permission: Permission) -> bool:
    return permission in ROLE_PERMISSIONS[role]
