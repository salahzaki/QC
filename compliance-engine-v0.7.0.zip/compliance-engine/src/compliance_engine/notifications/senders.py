"""Sending messages by e-mail (SMTP) and WhatsApp (Meta WhatsApp Business Cloud API)."""

import re
import smtplib
import ssl
from collections.abc import Callable
from dataclasses import dataclass
from email.message import EmailMessage
from typing import Protocol

import httpx

from compliance_engine.core.config import Settings, get_settings
from compliance_engine.models.enums import NotificationChannel


@dataclass(frozen=True)
class Message:
    subject: str
    text: str  # full text, for e-mail
    short: str  # one line, for WhatsApp


class DeliveryError(Exception):
    """The message could not be sent. The text is stored on the delivery, so no secrets."""


class Sender(Protocol):
    def send(self, address: str, message: Message) -> None: ...


class NotConfigured:
    def __init__(self, what: str) -> None:
        self._what = what

    def send(self, address: str, message: Message) -> None:
        raise DeliveryError(
            f"{self._what} is not set up: enter it on the notification settings page or in .env"
        )


class EmailSender:
    def __init__(self, settings: Settings) -> None:
        self._s = settings

    def send(self, address: str, message: Message) -> None:
        s = self._s
        assert s.smtp_host is not None
        email = EmailMessage()
        email["From"] = s.smtp_from or s.smtp_username or "compliance-engine@localhost"
        email["To"] = address
        email["Subject"] = message.subject
        email.set_content(message.text)
        try:
            smtp: smtplib.SMTP
            if s.smtp_security == "ssl":
                smtp = smtplib.SMTP_SSL(
                    s.smtp_host, s.smtp_port, timeout=20, context=ssl.create_default_context()
                )
            else:
                smtp = smtplib.SMTP(s.smtp_host, s.smtp_port, timeout=20)
            with smtp:
                if s.smtp_security == "starttls":
                    smtp.starttls(context=ssl.create_default_context())
                if s.smtp_username and s.smtp_password:
                    smtp.login(s.smtp_username, s.smtp_password.get_secret_value())
                smtp.send_message(email)
        except (OSError, smtplib.SMTPException) as exc:
            raise DeliveryError(f"E-mail failed: {type(exc).__name__}: {exc}"[:500]) from exc


def whatsapp_number(address: str) -> str:
    """International number with country code, digits only (what the API expects)."""
    return re.sub(r"[^\d]", "", address)


class WhatsAppSender:
    def __init__(self, settings: Settings, transport: httpx.BaseTransport | None = None) -> None:
        self._s = settings
        self._transport = transport

    def send(self, address: str, message: Message) -> None:
        s = self._s
        assert s.whatsapp_token is not None and s.whatsapp_phone_number_id is not None
        # Template parameters may not contain new lines, tabs or runs of spaces.
        text = re.sub(r"\s+", " ", message.short).strip()[:1000]
        body: dict[str, object] = {"messaging_product": "whatsapp", "to": whatsapp_number(address)}
        if s.whatsapp_template:
            body |= {
                "type": "template",
                "template": {
                    "name": s.whatsapp_template,
                    "language": {"code": s.whatsapp_template_language},
                    "components": [
                        {"type": "body", "parameters": [{"type": "text", "text": text}]}
                    ],
                },
            }
        else:
            body |= {"type": "text", "text": {"body": text}}
        url = f"{s.whatsapp_api_url.rstrip('/')}/{s.whatsapp_phone_number_id}/messages"
        try:
            with httpx.Client(transport=self._transport, timeout=20) as client:
                response = client.post(
                    url,
                    json=body,
                    headers={"Authorization": f"Bearer {s.whatsapp_token.get_secret_value()}"},
                )
        except httpx.HTTPError as exc:
            raise DeliveryError(f"WhatsApp failed: {type(exc).__name__}: {exc}"[:500]) from exc
        if response.status_code >= 300:
            try:
                detail = response.json()["error"]["message"]
            except (ValueError, KeyError, TypeError):
                detail = response.text
            raise DeliveryError(f"WhatsApp failed ({response.status_code}): {detail}"[:500])


def configured_channels(settings: Settings | None = None) -> dict[NotificationChannel, bool]:
    s = settings or get_settings()
    return {
        NotificationChannel.EMAIL: bool(s.smtp_host),
        NotificationChannel.WHATSAPP: bool(s.whatsapp_token and s.whatsapp_phone_number_id),
    }


def default_senders(settings: Settings | None = None) -> dict[NotificationChannel, Sender]:
    """Senders for the given settings (a factory's own settings applied, see
    services/settings.py), or the server's CE_* settings."""
    s = settings or get_settings()
    ready = configured_channels(s)
    return {
        NotificationChannel.EMAIL: EmailSender(s)
        if ready[NotificationChannel.EMAIL]
        else NotConfigured("E-mail"),
        NotificationChannel.WHATSAPP: WhatsAppSender(s)
        if ready[NotificationChannel.WHATSAPP]
        else NotConfigured("WhatsApp"),
    }


# Tests replace this to capture messages instead of sending them.
get_senders: Callable[[Settings | None], dict[NotificationChannel, Sender]] = default_senders
