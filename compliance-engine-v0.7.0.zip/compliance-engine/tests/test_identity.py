from uuid import uuid4

import pytest
from fastapi.testclient import TestClient

from compliance_engine.core.errors import NotFoundError
from compliance_engine.db.session import get_session_factory
from compliance_engine.services.identity import reset_password_by_email
from tests.conftest import PASSWORD, TenantApi, login, make_tenant


def test_login_rejects_wrong_password(client: TestClient, admin: TenantApi) -> None:
    response = client.post(
        "/api/v1/auth/token",
        json={"tenant": "awrad", "email": "admin@awrad.example.com", "password": "wrong-password"},
    )
    assert response.status_code == 401


def test_login_rejects_unknown_tenant(client: TestClient, admin: TenantApi) -> None:
    response = client.post(
        "/api/v1/auth/token",
        json={"tenant": "nope", "email": "admin@awrad.example.com", "password": "whatever-123"},
    )
    assert response.status_code == 401


def test_requests_without_token_are_rejected(client: TestClient, admin: TenantApi) -> None:
    assert client.get("/api/v1/items").status_code == 401


def test_admin_creates_users_and_they_can_log_in(client: TestClient, admin: TenantApi) -> None:
    operator = admin.as_role("operator")
    assert operator.get("/lots") == []
    emails = {user["email"] for user in admin.get("/users")}
    assert emails == {"admin@awrad.example.com", "operator@awrad.example.com"}


def test_duplicate_user_email_conflicts(admin: TenantApi) -> None:
    admin.as_role("operator")
    admin.post(
        "/users",
        {
            "email": "OPERATOR@awrad.example.com",
            "full_name": "Again",
            "role": "operator",
            "password": "another-password",
        },
        expected=409,
    )


def test_permissions_follow_role(admin: TenantApi) -> None:
    operator = admin.as_role("operator")
    auditor = admin.as_role("auditor")

    operator.get("/users", expected=403)
    operator.post(
        "/items",
        {"code": "X", "name": "X", "item_type": "raw_material", "uom": "kg"},
        expected=403,
    )
    auditor.post(
        "/lots/receipts",
        {
            "item_id": "00000000-0000-0000-0000-000000000000",
            "supplier_id": "00000000-0000-0000-0000-000000000000",
            "supplier_lot_code": "S1",
            "quantity": "1",
        },
        expected=403,
    )
    assert auditor.get("/audit/verify")["valid"] is True
    operator.get("/audit/verify", expected=403)


def test_same_email_can_exist_in_two_tenants(client: TestClient, admin: TenantApi) -> None:
    other = make_tenant(client, "other")
    admin.as_role("operator")
    other.as_role("operator")
    assert login(client, "other", "operator@other.example.com")


def test_user_changes_own_password(client: TestClient, admin: TenantApi) -> None:
    operator = admin.as_role("operator")
    body = {"current_password": "wrong-password", "new_password": "New-pass-12345"}
    operator.post("/auth/change-password", body, 403)
    body["current_password"] = PASSWORD
    body["new_password"] = PASSWORD
    operator.post("/auth/change-password", body, 422)
    body["new_password"] = "short"
    operator.post("/auth/change-password", body, 422)

    response = client.post(
        "/api/v1/auth/change-password",
        json={"current_password": PASSWORD, "new_password": "New-pass-12345"},
        headers=operator.headers,
    )
    assert response.status_code == 204, response.text
    login(client, "awrad", "operator@awrad.example.com", "New-pass-12345")
    old = client.post(
        "/api/v1/auth/token",
        json={"tenant": "awrad", "email": "operator@awrad.example.com", "password": PASSWORD},
    )
    assert old.status_code == 401


def test_admin_resets_a_forgotten_password(client: TestClient, admin: TenantApi) -> None:
    operator = admin.as_role("operator")
    [user] = [u for u in admin.get("/users") if u["role"] == "operator"]
    body = {"new_password": "Reset-pass-123"}

    operator.post(f"/users/{user['id']}/reset-password", body, 403)
    admin.post(f"/users/{uuid4()}/reset-password", body, 404)
    reset = admin.post(f"/users/{user['id']}/reset-password", body, 200)

    assert reset["email"] == "operator@awrad.example.com"
    login(client, "awrad", "operator@awrad.example.com", "Reset-pass-123")
    event = admin.get("/audit/events", limit=1)[0]
    assert event["action"] == "user.password_reset"
    assert "Reset-pass-123" not in str(admin.get("/audit/events"))
    assert admin.get("/audit/verify")["valid"] is True


def test_admin_cannot_reset_another_tenants_user(client: TestClient, admin: TenantApi) -> None:
    other = make_tenant(client, "other")
    [user] = other.get("/users")
    admin.post(f"/users/{user['id']}/reset-password", {"new_password": "Reset-pass-123"}, 404)


def test_console_reset_password(client: TestClient, admin: TenantApi) -> None:
    with get_session_factory().begin() as session:
        reset_password_by_email(session, "awrad", "ADMIN@awrad.example.com", "Console-pass-1")
    login(client, "awrad", "admin@awrad.example.com", "Console-pass-1")
    with get_session_factory().begin() as session, pytest.raises(NotFoundError):
        reset_password_by_email(session, "awrad", "nobody@awrad.example.com", "Console-pass-1")
