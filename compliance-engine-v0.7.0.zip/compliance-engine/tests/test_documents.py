"""Record numbers, controlled forms and the issued-report register."""

from typing import Any

from compliance_engine.services.context import factory_today
from tests.conftest import TenantApi, make_tenant
from tests.test_records import cooking_ccp, reading, sanitation

YEAR = factory_today().year


def test_records_are_numbered_in_order_per_series(admin: TenantApi) -> None:
    qm = admin.as_role("quality_manager")
    operator = admin.as_role("operator")
    ccp = cooking_ccp(qm)

    first = reading(operator, ccp, "75")
    reading(operator, ccp, "75", password="wrong-password", expected=403)  # rolled back
    second = reading(operator, ccp, "68", corrective_action="Re-cooked")
    check = sanitation(operator)

    assert first["serial"] == f"CCP-{YEAR}-000001"
    assert second["serial"] == f"CCP-{YEAR}-000002"  # no gap after the rejected one
    assert check["serial"] == f"SAN-{YEAR}-000001"
    [action] = qm.get("/corrective-actions")
    assert action["serial"] == f"CA-{YEAR}-000001"
    record = operator.post(
        f"/ccp-readings/{first['id']}/amendments",
        {"value": "76", "reason": "Typo", "password": "correct-horse-battery"},
    )
    assert record["serial"] == f"CCP-{YEAR}-000001"
    assert record["amendments"][0]["serial"] == f"AMD-{YEAR}-000001"


def test_each_tenant_has_its_own_series(admin: TenantApi, client: Any) -> None:
    other = make_tenant(client, "other")
    assert reading(admin, cooking_ccp(admin), "75")["serial"] == f"CCP-{YEAR}-000001"
    assert reading(other, cooking_ccp(other), "75")["serial"] == f"CCP-{YEAR}-000001"


def test_default_forms_are_listed(admin: TenantApi) -> None:
    forms = {f["key"]: f for f in admin.get("/document-forms")}
    assert set(forms) == {
        "ccp_log",
        "corrective_actions",
        "sanitation_log",
        "supplier_list",
        "training_matrix",
        "training_log",
        "trace",
    }
    assert forms["supplier_list"]["code"] == "F-SUP-01"
    assert forms["ccp_log"]["code"] == "F-HACCP-01"
    assert forms["ccp_log"]["revision"] == "00"


def test_changing_a_form_needs_a_new_revision(admin: TenantApi) -> None:
    qm = admin.as_role("quality_manager")
    change = {"code": "QF-CCP-07", "reason": "Align with our HACCP manual"}
    response = qm.patch("/document-forms/ccp_log", change, expected=422)
    assert "revision" in response["detail"]

    form = qm.patch(
        "/document-forms/ccp_log",
        {**change, "revision": "01", "effective_date": "2026-01-01", "approved_by_name": "QA"},
    )
    assert (form["code"], form["revision"]) == ("QF-CCP-07", "01")
    [event] = [e for e in qm.get("/audit/events") if e["action"] == "document_form.updated"]
    assert event["payload"]["changes"]["code"] == {"from": "F-HACCP-01", "to": "QF-CCP-07"}

    clash = {"code": "QF-CCP-07", "revision": "01", "reason": "Same code"}
    qm.patch("/document-forms/sanitation_log", clash, expected=409)
    operator = admin.as_role("operator")
    operator.patch("/document-forms/trace", {"revision": "09", "reason": "No"}, expected=403)


def test_every_report_is_numbered_registered_and_checkable(admin: TenantApi) -> None:
    qm = admin.as_role("quality_manager")
    reading(qm, cooking_ccp(qm), "75")

    responses = [
        qm.client.get("/api/v1/reports/ccp-log", headers=qm.headers),
        qm.client.get("/api/v1/reports/sanitation-log", params={"lang": "en"}, headers=qm.headers),
    ]
    numbers = [r.headers["x-report-number"] for r in responses]
    assert numbers == [f"RPT-{YEAR}-000001", f"RPT-{YEAR}-000002"]
    assert f"RPT-{YEAR}-000001_ccp-log_" in responses[0].headers["content-disposition"]

    register = qm.get("/issued-reports")
    assert [r["serial"] for r in register] == list(reversed(numbers))
    assert register[1]["form_code"] == "F-HACCP-01"
    assert register[1]["parameters"]["date_to"] == factory_today().isoformat()

    def check(content: bytes) -> Any:
        response = qm.client.post(
            "/api/v1/issued-reports/check",
            content=content,
            headers={**qm.headers, "Content-Type": "application/pdf"},
        )
        assert response.status_code == 200, response.text
        return response.json()

    genuine = check(responses[0].content)
    assert genuine["genuine"] is True
    assert genuine["report"]["serial"] == numbers[0]
    assert check(responses[0].content + b"\n")["genuine"] is False
    assert qm.get(f"/issued-reports/{numbers[1]}")["lang"] == "en"
