from datetime import timedelta
from typing import Any

import pytest

from compliance_engine.services.context import factory_today
from tests.conftest import PASSWORD, TenantApi
from tests.test_records import cooking_ccp, reading, sanitation, verify


def pdf(api: TenantApi, path: str, expected: int = 200, **params: Any) -> bytes:
    response = api.client.get(f"/api/v1/reports{path}", params=params, headers=api.headers)
    assert response.status_code == expected, response.text
    if expected == 200:
        assert response.headers["content-type"] == "application/pdf"
        assert response.headers["content-disposition"].startswith("attachment; filename*=UTF-8''")
        assert response.content.startswith(b"%PDF")
    return bytes(response.content)


@pytest.fixture
def factory(admin: TenantApi) -> dict[str, Any]:
    """A small week of records: readings, a deviation, an amendment, sanitation, a trace."""
    qm = admin.as_role("quality_manager")
    operator = admin.as_role("operator")
    ccp = cooking_ccp(qm, monitoring_frequency="Every batch")
    flour = qm.receive(qm.item("FLOUR"), qm.supplier(), supplier_lot_code="MILL-42")
    qm.release(flour)
    bread = qm.produce(qm.item("BREAD", "finished_good"), "50", [(flour, "20")])
    qm.release(bread["output_lot"])
    qm.ship(qm.customer(), [(bread["output_lot"], "10")])

    ok = reading(operator, ccp, "75", lot_id=bread["output_lot"]["id"])
    verify(qm, f"/ccp-readings/{ok['id']}")
    reading(operator, ccp, "68", corrective_action="Re-cooked to 75 °C core")
    operator.post(
        f"/ccp-readings/{ok['id']}/amendments",
        {"value": "76", "reason": "Wrong digit typed", "password": PASSWORD},
    )
    sanitation(operator)
    sanitation(operator, "fail", corrective_action="إعادة التنظيف والتعقيم")
    return {"admin": admin, "qm": qm, "operator": operator, "ccp": ccp, "lot": bread["output_lot"]}


def test_haccp_summary_counts_the_period(factory: dict[str, Any]) -> None:
    summary = factory["qm"].get("/reports/haccp-summary")

    assert summary["date_to"] == factory_today().isoformat()
    assert summary["ccp_readings"] == 2
    assert summary["ccp_deviations"] == 1
    assert summary["sanitation_checks"] == 2
    assert summary["sanitation_failures"] == 1
    assert summary["unverified_records"] == 4  # the amended reading needs review again
    assert summary["corrective_actions_opened"] == 2
    [point] = summary["control_points"]
    assert (point["code"], point["readings"], point["deviations"]) == ("CCP-1", 2, 1)


@pytest.mark.parametrize("lang", ["ar", "en"])
def test_reports_render_as_pdf(factory: dict[str, Any], lang: str) -> None:
    qm = factory["qm"]
    assert len(pdf(qm, "/ccp-log", lang=lang)) > 5_000
    pdf(qm, "/ccp-log", lang=lang, control_point_id=factory["ccp"]["id"])
    pdf(qm, "/sanitation-log", lang=lang)
    pdf(qm, "/sanitation-log", lang=lang, area="MIXER-1")
    pdf(qm, "/corrective-actions", lang=lang)
    pdf(qm, "/corrective-actions", lang=lang, status="open")
    pdf(qm, f"/trace/{factory['lot']['id']}", lang=lang)


def test_empty_period_still_renders(qm: TenantApi) -> None:
    pdf(qm, "/ccp-log")
    cooking_ccp(qm)
    long_ago = factory_today() - timedelta(days=300)
    pdf(qm, "/ccp-log", date_from=long_ago.isoformat(), date_to=long_ago.isoformat())
    pdf(qm, "/corrective-actions", lang="en")


def test_report_period_is_checked(qm: TenantApi) -> None:
    today = factory_today()
    pdf(
        qm, "/ccp-log", 422, date_from=today.isoformat(), date_to=(today - timedelta(1)).isoformat()
    )
    pdf(qm, "/ccp-log", 422, date_from=(today - timedelta(days=400)).isoformat())
    pdf(qm, "/ccp-log", 422, lang="fr")
    pdf(qm, "/ccp-log", 404, control_point_id="00000000-0000-0000-0000-000000000000")
    pdf(qm, "/trace/00000000-0000-0000-0000-000000000000", 404)


def test_auditor_can_pull_reports(factory: dict[str, Any]) -> None:
    qm = factory["qm"]
    auditor = factory["admin"].as_role("auditor")
    pdf(auditor, "/ccp-log")
    pdf(auditor, f"/trace/{factory['lot']['id']}")
    response = qm.client.get("/api/v1/reports/ccp-log")
    assert response.status_code == 401
