from fastapi.testclient import TestClient
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from compliance_engine.db.session import bind_tenant
from compliance_engine.models import Item, Tenant
from tests.conftest import TenantApi, make_tenant


def test_tenants_cannot_see_each_others_data(client: TestClient, qm: TenantApi) -> None:
    flour = qm.item("FLOUR")
    lot = qm.receive(flour, qm.supplier())

    other = make_tenant(client, "other")
    assert other.get("/items") == []
    assert other.get("/lots") == []
    other.get(f"/lots/{lot['id']}", expected=404)
    other.get(f"/trace/lots/{lot['id']}", expected=404)


def test_tenant_cannot_reference_another_tenants_records(client: TestClient, qm: TenantApi) -> None:
    flour = qm.item("FLOUR")
    supplier = qm.supplier()

    other = make_tenant(client, "other")
    response = client.post(
        "/api/v1/lots/receipts",
        json={
            "item_id": flour["id"],
            "supplier_id": supplier["id"],
            "supplier_lot_code": "S1",
            "quantity": "5",
        },
        headers=other.headers,
    )
    assert response.status_code == 404


def test_database_hides_rows_when_no_tenant_is_bound(db: Session, qm: TenantApi) -> None:
    qm.item("FLOUR")
    assert db.scalar(select(func.count()).select_from(Item)) == 0

    tenant_id = db.scalar(select(Tenant.id).where(Tenant.slug == "awrad"))
    assert tenant_id is not None
    bind_tenant(db, tenant_id)
    assert db.scalar(select(func.count()).select_from(Item)) == 1
