from datetime import UTC, datetime, timedelta
from typing import Any

import pytest
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError
from sqlalchemy.orm import Session

from tests.conftest import PASSWORD, TenantApi
from tests.test_records import _bind, cooking_ccp, reading, sanitation, verify


def amend(api: TenantApi, path: str, expected: int = 201, **changes: Any) -> Any:
    body = {"reason": "Typed the wrong number", "password": PASSWORD, **changes}
    return api.post(f"{path}/amendments", body, expected)


def test_amendment_corrects_a_reading_without_touching_the_original(admin: TenantApi) -> None:
    qm = admin.as_role("quality_manager")
    operator = admin.as_role("operator")
    entry = reading(operator, cooking_ccp(qm), "75")
    path = f"/ccp-readings/{entry['id']}"
    verify(qm, path)

    amended = amend(operator, path, value="78", notes="Probe re-read")

    assert amended["value"] == "78.000"
    assert amended["notes"] == "Probe re-read"
    assert amended["amended"] is True
    # The original signatures still match the stored (unchanged) record.
    assert all(s["intact"] for s in amended["signatures"])
    [amendment] = amended["amendments"]
    assert amendment["changes"] == {
        "value": {"from": "75", "to": "78"},
        "notes": {"from": None, "to": "Probe re-read"},
    }
    assert amendment["reason"] == "Typed the wrong number"
    assert amendment["signatures"][0]["meaning"] == "performed"
    # The verification covered the old content, so the record needs review again.
    assert amended["verified"] is False
    assert [r["id"] for r in qm.get("/ccp-readings", unverified_only=True)] == [entry["id"]]

    verify(operator, f"/amendments/{amendment['id']}", expected=403)
    verify(qm, f"/amendments/{amendment['id']}")
    assert qm.get(path)["verified"] is True
    assert qm.get("/ccp-readings", unverified_only=True) == []


def test_amendment_author_cannot_verify_it(admin: TenantApi) -> None:
    qm = admin.as_role("quality_manager")
    entry = reading(admin, cooking_ccp(qm), "75")
    amended = amend(qm, f"/ccp-readings/{entry['id']}", value="76")
    [amendment] = amended["amendments"]
    error = verify(qm, f"/amendments/{amendment['id']}", expected=422)
    assert "someone other than its author" in error["detail"]


def test_amendment_needs_a_reason_a_change_and_the_password(qm: TenantApi) -> None:
    path = f"/ccp-readings/{reading(qm, cooking_ccp(qm), '75')['id']}"

    qm.post(f"{path}/amendments", {"value": "76", "password": PASSWORD}, 422)  # no reason
    amend(qm, path, expected=422)  # nothing to correct
    amend(qm, path, expected=422, value=None)  # a value cannot be cleared
    assert "does not change" in amend(qm, path, expected=422, value="75.000")["detail"]
    amend(qm, path, expected=403, value="76", password="wrong-password")
    amend(qm, path, expected=422, control_point_id=qm.get(path)["control_point_id"])
    assert qm.get(path)["amended"] is False


def test_correction_into_a_deviation_opens_a_corrective_action(qm: TenantApi) -> None:
    ccp = cooking_ccp(qm)
    path = f"/ccp-readings/{reading(qm, ccp, '75')['id']}"

    error = amend(qm, path, expected=422, value="65")
    assert "record the corrective action" in error["detail"]
    amended = amend(qm, path, value="65", corrective_action="Batch held for evaluation")

    assert amended["within_limits"] is False
    assert amended["corrective_action"] == "Batch held for evaluation"
    assert amended["corrective_action_status"] == "open"
    assert [r["id"] for r in qm.get("/ccp-readings", deviations_only=True)] == [amended["id"]]
    assert [a["kind"] for a in qm.get("/alerts")] == ["ccp_deviation"]

    # Correcting it back keeps the corrective action open for the quality manager to close.
    back = amend(qm, path, value="76", reason="Probe was not calibrated; re-measured")
    assert back["within_limits"] is True
    assert back["corrective_action_status"] == "open"
    assert len(back["amendments"]) == 2
    assert qm.get("/ccp-readings", deviations_only=True) == []
    # corrective_action is only accepted when a correction creates a new deviation
    amend(qm, path, expected=422, value="77", corrective_action="Not needed here")


def test_measured_at_can_be_corrected_but_not_into_the_future(qm: TenantApi) -> None:
    path = f"/ccp-readings/{reading(qm, cooking_ccp(qm), '75')['id']}"
    earlier = datetime.now(UTC) - timedelta(days=3)
    later = datetime.now(UTC) + timedelta(days=1)

    amend(qm, path, expected=422, measured_at=later.isoformat())
    amended = amend(qm, path, measured_at=earlier.isoformat())

    assert datetime.fromisoformat(amended["measured_at"]) == earlier
    since = (earlier - timedelta(hours=1)).isoformat()
    until = (earlier + timedelta(hours=1)).isoformat()
    in_window = qm.get("/ccp-readings", measured_from=since, measured_to=until)
    assert [r["id"] for r in in_window] == [amended["id"]]
    assert qm.get("/ccp-readings", measured_from=until) == []


def test_sanitation_correction_to_fail_needs_an_action(admin: TenantApi) -> None:
    operator = admin.as_role("operator")
    record = sanitation(operator)
    path = f"/sanitation-records/{record['id']}"

    amend(operator, path, expected=422, result="fail")
    amended = amend(
        operator,
        path,
        result="fail",
        area="MIXER-2",
        corrective_action="Re-cleaned and swabbed again",
        reason="Recorded against the wrong mixer and result",
    )

    assert (amended["result"], amended["area"]) == ("fail", "MIXER-2")
    assert amended["corrective_action_status"] == "open"
    assert [r["id"] for r in operator.get("/sanitation-records", area="MIXER-2")] == [record["id"]]
    assert operator.get("/sanitation-records", area="MIXER-1") == []
    assert len(operator.get("/sanitation-records", failures_only=True)) == 1
    amend(operator, path, expected=422, area=None)


def test_amendment_queue_lists_unverified_corrections(admin: TenantApi) -> None:
    qm = admin.as_role("quality_manager")
    entry = reading(admin, cooking_ccp(qm), "75")
    amend(admin, f"/ccp-readings/{entry['id']}", value="76")

    [pending] = qm.get("/amendments", unverified_only=True)
    assert pending["record_id"] == entry["id"]
    verify(qm, f"/amendments/{pending['id']}")
    assert qm.get("/amendments", unverified_only=True) == []
    assert len(qm.get("/amendments")) == 1


@pytest.mark.parametrize(
    "statement",
    ["UPDATE record_amendments SET reason = 'nothing'", "DELETE FROM record_amendments"],
)
def test_amendments_cannot_be_rewritten(db: Session, qm: TenantApi, statement: str) -> None:
    amend(qm, f"/ccp-readings/{reading(qm, cooking_ccp(qm), '75')['id']}", value="76")
    _bind(db)
    with pytest.raises(DBAPIError, match="not allowed"):
        db.execute(text(statement))


def test_amendment_is_audited(qm: TenantApi) -> None:
    entry = reading(qm, cooking_ccp(qm), "75")
    amend(qm, f"/ccp-readings/{entry['id']}", value="76")

    actions = [e["action"] for e in qm.get("/audit/events", limit=2)]
    assert actions == ["record.signed", "record.amended"]
    assert PASSWORD not in str(qm.get("/audit/events"))
    assert qm.get("/audit/verify")["valid"] is True
