import pytest
from sqlalchemy import select, text
from sqlalchemy.exc import DBAPIError
from sqlalchemy.orm import Session

from compliance_engine.db.session import bind_tenant
from compliance_engine.models import Tenant
from tests.conftest import TenantApi


def _bind(db: Session, slug: str = "awrad") -> None:
    tenant_id = db.scalar(select(Tenant.id).where(Tenant.slug == slug))
    assert tenant_id is not None
    bind_tenant(db, tenant_id)


@pytest.mark.parametrize(
    "statement",
    [
        "UPDATE lot_transactions SET quantity = 999",
        "DELETE FROM lot_transactions",
        "UPDATE audit_events SET action = 'edited'",
        "DELETE FROM audit_events",
        "UPDATE lots SET lot_code = 'FORGED'",
        "DELETE FROM lots",
    ],
)
def test_database_rejects_rewriting_history(db: Session, qm: TenantApi, statement: str) -> None:
    qm.receive(qm.item("FLOUR"), qm.supplier())
    _bind(db)

    with pytest.raises(DBAPIError, match=r"not allowed|Only the status"):
        db.execute(text(statement))


def test_lot_status_is_the_only_mutable_field(db: Session, qm: TenantApi) -> None:
    qm.receive(qm.item("FLOUR"), qm.supplier())
    _bind(db)
    db.execute(text("UPDATE lots SET status = 'blocked'"))  # allowed


def test_every_change_is_in_the_audit_log(qm: TenantApi) -> None:
    lot = qm.receive(qm.item("FLOUR"), qm.supplier())
    qm.release(lot)

    actions = [event["action"] for event in qm.get("/audit/events")]
    assert actions[:4] == [
        "lot.status_changed",
        "lot.received",
        "suppliers.created",
        "items.created",
    ]
    assert qm.get("/audit/events", limit=1, before_seq=2)[0]["action"] == "tenant.provisioned"


def test_audit_chain_verifies_when_untouched(qm: TenantApi) -> None:
    qm.release(qm.receive(qm.item("FLOUR"), qm.supplier()))
    result = qm.get("/audit/verify")
    assert result == {"valid": True, "events_checked": 6, "first_invalid_seq": None}


def test_audit_chain_detects_tampering_that_bypasses_triggers(db: Session, qm: TenantApi) -> None:
    """Even someone who can disable the trigger cannot edit history without being detected."""
    qm.release(qm.receive(qm.item("FLOUR"), qm.supplier()))

    _bind(db)
    db.execute(text("ALTER TABLE audit_events DISABLE TRIGGER audit_events_append_only"))
    forged = """UPDATE audit_events SET payload = jsonb_set(payload, '{quantity}', '"1"')
                WHERE seq = 4"""
    db.execute(text(forged))
    db.execute(text("ALTER TABLE audit_events ENABLE TRIGGER audit_events_append_only"))
    db.commit()

    assert qm.get("/audit/verify") == {"valid": False, "events_checked": 3, "first_invalid_seq": 4}
