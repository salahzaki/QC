"""Tests run against a real PostgreSQL database, because row-level security, triggers and
recursive queries are the behaviour under test.

Set CE_TEST_DATABASE_URL to point at an empty database owned by a non-superuser role
(superusers bypass row-level security).
"""

import os
from collections.abc import Iterator
from dataclasses import dataclass
from typing import Any

import pytest

TEST_DATABASE_URL = os.environ.get(
    "CE_TEST_DATABASE_URL",
    "postgresql+psycopg://app_user:app_password@localhost:5432/compliance_test",
)
os.environ["CE_DATABASE_URL"] = TEST_DATABASE_URL
os.environ.setdefault("CE_JWT_SECRET", "test-secret-test-secret-test-secret-0000")
os.environ.setdefault("CE_BCRYPT_ROUNDS", "4")  # fast hashing; production uses 12
os.environ["CE_ALERT_SCAN_SECONDS"] = "0"  # tests run the scan themselves
os.environ["CE_NOTIFY_SECONDS"] = "0"  # and send notifications themselves
os.environ["CE_RECORD_LANGUAGE"] = "en"  # most assertions use the English wording

from alembic import command  # noqa: E402
from alembic.config import Config  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402
from sqlalchemy import text  # noqa: E402
from sqlalchemy.orm import Session  # noqa: E402

from compliance_engine.db.session import get_engine, get_session_factory  # noqa: E402
from compliance_engine.main import app  # noqa: E402
from compliance_engine.models import Base  # noqa: E402
from compliance_engine.models.enums import NotificationChannel  # noqa: E402
from compliance_engine.notifications import senders  # noqa: E402
from compliance_engine.notifications.senders import DeliveryError, Message  # noqa: E402
from compliance_engine.schemas.identity import CreateTenant  # noqa: E402
from compliance_engine.services.identity import provision_tenant  # noqa: E402

PASSWORD = "correct-horse-battery"


@pytest.fixture(scope="session", autouse=True)
def _migrated_database() -> None:
    config = Config("alembic.ini")
    config.attributes["database_url"] = TEST_DATABASE_URL
    command.downgrade(config, "base")
    command.upgrade(config, "head")


@pytest.fixture(autouse=True)
def _clean_tables() -> None:
    tables = ", ".join(table.name for table in Base.metadata.sorted_tables)
    with get_engine().begin() as connection:
        connection.execute(text(f"TRUNCATE {tables} CASCADE"))


class FakeSender:
    """Captures messages instead of sending them; set `error` to make sends fail."""

    def __init__(self) -> None:
        self.sent: list[tuple[str, Message]] = []
        self.error: str | None = None

    def send(self, address: str, message: Message) -> None:
        if self.error:
            raise DeliveryError(self.error)
        self.sent.append((address, message))


@pytest.fixture(autouse=True)
def outbox(monkeypatch: pytest.MonkeyPatch) -> dict[NotificationChannel, FakeSender]:
    fakes = {channel: FakeSender() for channel in NotificationChannel}
    monkeypatch.setattr(senders, "get_senders", lambda _settings=None: fakes)
    return fakes


@pytest.fixture
def client() -> TestClient:
    return TestClient(app)


@pytest.fixture
def db() -> Iterator[Session]:
    """A raw session with no tenant bound, for checks below the API."""
    with get_session_factory()() as session:
        yield session
        session.rollback()


@dataclass
class TenantApi:
    """A logged-in API client for one tenant, with helpers that build test data."""

    client: TestClient
    slug: str
    headers: dict[str, str]

    def post(self, path: str, body: dict[str, Any], expected: int = 201) -> Any:
        response = self.client.post(f"/api/v1{path}", json=body, headers=self.headers)
        assert response.status_code == expected, response.text
        return response.json()

    def patch(self, path: str, body: dict[str, Any], expected: int = 200) -> Any:
        response = self.client.patch(f"/api/v1{path}", json=body, headers=self.headers)
        assert response.status_code == expected, response.text
        return response.json()

    def get(self, path: str, expected: int = 200, **params: Any) -> Any:
        response = self.client.get(f"/api/v1{path}", params=params, headers=self.headers)
        assert response.status_code == expected, response.text
        return response.json()

    def as_role(self, role: str) -> "TenantApi":
        email = f"{role}@{self.slug}.example.com"
        self.post(
            "/users",
            {"email": email, "full_name": role.title(), "role": role, "password": PASSWORD},
        )
        return TenantApi(self.client, self.slug, login(self.client, self.slug, email))

    # --- data builders ---

    def item(self, code: str, item_type: str = "raw_material", **extra: Any) -> Any:
        return self.post(
            "/items",
            {"code": code, "name": code.title(), "item_type": item_type, "uom": "kg", **extra},
        )

    def supplier(self, code: str = "SUP-1", approved: bool = True) -> Any:
        return self.post("/suppliers", {"code": code, "name": code, "is_approved": approved})

    def customer(self, code: str = "CUS-1") -> Any:
        return self.post("/customers", {"code": code, "name": code})

    def receive(
        self, item: Any, supplier: Any, quantity: str = "100", expected: int = 201, **extra: Any
    ) -> Any:
        return self.post(
            "/lots/receipts",
            {
                "item_id": item["id"],
                "supplier_id": supplier["id"],
                "supplier_lot_code": extra.pop("supplier_lot_code", "S-LOT-1"),
                "quantity": quantity,
                **extra,
            },
            expected,
        )

    def release(self, lot: Any) -> Any:
        return self.post(
            f"/lots/{lot['id']}/status", {"status": "released", "reason": "QC passed"}, 200
        )

    def produce(self, output_item: Any, quantity: str, inputs: list[tuple[Any, str]]) -> Any:
        return self.post(
            "/production-runs",
            {
                "reference": f"RUN-{output_item['code']}",
                "output_item_id": output_item["id"],
                "output_quantity": quantity,
                "inputs": [{"lot_id": lot["id"], "quantity": qty} for lot, qty in inputs],
            },
        )

    def ship(self, customer: Any, lines: list[tuple[Any, str]], reference: str = "SO-1") -> Any:
        return self.post(
            "/shipments",
            {
                "reference": reference,
                "customer_id": customer["id"],
                "lines": [{"lot_id": lot["id"], "quantity": qty} for lot, qty in lines],
            },
        )


def login(client: TestClient, tenant: str, email: str, password: str = PASSWORD) -> dict[str, str]:
    response = client.post(
        "/api/v1/auth/token", json={"tenant": tenant, "email": email, "password": password}
    )
    assert response.status_code == 200, response.text
    return {"Authorization": f"Bearer {response.json()['access_token']}"}


def make_tenant(client: TestClient, slug: str) -> TenantApi:
    with get_session_factory().begin() as session:
        provision_tenant(
            session,
            CreateTenant(
                slug=slug,
                name=slug.title(),
                admin_email=f"admin@{slug}.example.com",
                admin_full_name="Admin",
                admin_password=PASSWORD,
            ),
        )
    return TenantApi(client, slug, login(client, slug, f"admin@{slug}.example.com"))


@pytest.fixture
def admin(client: TestClient) -> TenantApi:
    return make_tenant(client, "awrad")


@pytest.fixture
def qm(admin: TenantApi) -> TenantApi:
    return admin.as_role("quality_manager")
