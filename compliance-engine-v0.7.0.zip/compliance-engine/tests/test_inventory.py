from datetime import date, timedelta
from decimal import Decimal

from tests.conftest import TenantApi


def test_received_lot_starts_in_quarantine_with_its_balance(qm: TenantApi) -> None:
    lot = qm.receive(qm.item("FLOUR"), qm.supplier(), quantity="250.5")

    assert lot["status"] == "quarantine"
    assert lot["origin"] == "received"
    assert lot["lot_code"].startswith("RM-")
    assert Decimal(lot["balance"]) == Decimal("250.5")


def test_cannot_receive_from_unapproved_supplier(qm: TenantApi) -> None:
    flour = qm.item("FLOUR")
    supplier = qm.supplier(approved=False)
    qm.post(
        "/lots/receipts",
        {
            "item_id": flour["id"],
            "supplier_id": supplier["id"],
            "supplier_lot_code": "A",
            "quantity": "1",
        },
        expected=422,
    )


def test_cannot_receive_expired_material(qm: TenantApi) -> None:
    flour, supplier = qm.item("FLOUR"), qm.supplier()
    yesterday = (date.today() - timedelta(days=2)).isoformat()
    qm.post(
        "/lots/receipts",
        {
            "item_id": flour["id"],
            "supplier_id": supplier["id"],
            "supplier_lot_code": "A",
            "quantity": "1",
            "expiry_date": yesterday,
        },
        expected=422,
    )


def test_quarantined_lot_cannot_be_used_in_production(qm: TenantApi) -> None:
    flour = qm.item("FLOUR")
    dough = qm.item("DOUGH", "work_in_progress")
    lot = qm.receive(flour, qm.supplier())

    response = qm.client.post(
        "/api/v1/production-runs",
        json={
            "reference": "RUN-1",
            "output_item_id": dough["id"],
            "output_quantity": "10",
            "inputs": [{"lot_id": lot["id"], "quantity": "10"}],
        },
        headers=qm.headers,
    )
    assert response.status_code == 422
    assert "not released" in response.json()["detail"]


def test_production_consumes_inputs_and_creates_output_lot(qm: TenantApi) -> None:
    flour = qm.item("FLOUR")
    biscuits = qm.item("BISCUIT", "finished_good", shelf_life_days=180)
    flour_lot = qm.release(qm.receive(flour, qm.supplier(), quantity="100"))

    run = qm.produce(biscuits, "40", [(flour_lot, "30")])

    output = run["output_lot"]
    assert output["status"] == "quarantine"
    assert output["lot_code"].startswith("FG-")
    assert output["expiry_date"] is not None
    assert Decimal(output["balance"]) == 40
    assert Decimal(qm.get(f"/lots/{flour_lot['id']}")["balance"]) == 70


def test_cannot_consume_more_than_the_balance(qm: TenantApi) -> None:
    flour = qm.item("FLOUR")
    dough = qm.item("DOUGH", "work_in_progress")
    lot = qm.release(qm.receive(flour, qm.supplier(), quantity="5"))

    qm.post(
        "/production-runs",
        {
            "reference": "RUN-1",
            "output_item_id": dough["id"],
            "output_quantity": "6",
            "inputs": [{"lot_id": lot["id"], "quantity": "6"}],
        },
        expected=422,
    )
    assert Decimal(qm.get(f"/lots/{lot['id']}")["balance"]) == 5


def test_failed_request_leaves_no_partial_data(qm: TenantApi) -> None:
    flour = qm.item("FLOUR")
    dough = qm.item("DOUGH", "work_in_progress")
    good = qm.release(qm.receive(flour, qm.supplier(), quantity="50"))
    blocked = qm.receive(flour, qm.supplier("SUP-2"), quantity="50")
    events_before = len(qm.get("/audit/events"))

    qm.post(
        "/production-runs",
        {
            "reference": "RUN-1",
            "output_item_id": dough["id"],
            "output_quantity": "20",
            "inputs": [
                {"lot_id": good["id"], "quantity": "10"},
                {"lot_id": blocked["id"], "quantity": "10"},
            ],
        },
        expected=422,
    )
    assert len(qm.get("/lots")) == 2
    assert Decimal(qm.get(f"/lots/{good['id']}")["balance"]) == 50
    assert len(qm.get("/audit/events")) == events_before


def test_duplicate_lots_in_one_request_are_rejected(qm: TenantApi) -> None:
    flour = qm.item("FLOUR")
    dough = qm.item("DOUGH", "work_in_progress")
    lot = qm.release(qm.receive(flour, qm.supplier()))
    qm.post(
        "/production-runs",
        {
            "reference": "RUN-1",
            "output_item_id": dough["id"],
            "output_quantity": "2",
            "inputs": [
                {"lot_id": lot["id"], "quantity": "1"},
                {"lot_id": lot["id"], "quantity": "1"},
            ],
        },
        expected=422,
    )


def test_status_changes_follow_allowed_transitions(qm: TenantApi) -> None:
    lot = qm.receive(qm.item("FLOUR"), qm.supplier())

    blocked = qm.post(
        f"/lots/{lot['id']}/status", {"status": "blocked", "reason": "Mould found"}, 200
    )
    assert blocked["status"] == "blocked"
    qm.post(f"/lots/{lot['id']}/status", {"status": "quarantine", "reason": "undo"}, 422)
    assert qm.release(lot)["status"] == "released"


def test_only_quality_roles_can_release_lots(admin: TenantApi) -> None:
    operator = admin.as_role("operator")
    lot = admin.receive(admin.item("FLOUR"), admin.supplier())
    operator.post(f"/lots/{lot['id']}/status", {"status": "released", "reason": "ok"}, 403)


def test_only_released_finished_goods_can_be_shipped(qm: TenantApi) -> None:
    flour = qm.item("FLOUR")
    biscuits = qm.item("BISCUIT", "finished_good")
    customer = qm.customer()
    flour_lot = qm.release(qm.receive(flour, qm.supplier()))
    fg_lot = qm.produce(biscuits, "10", [(flour_lot, "5")])["output_lot"]

    for lot, reason in ((flour_lot, "not a finished good"), (fg_lot, "not released")):
        response = qm.client.post(
            "/api/v1/shipments",
            json={
                "reference": "SO-1",
                "customer_id": customer["id"],
                "lines": [{"lot_id": lot["id"], "quantity": "1"}],
            },
            headers=qm.headers,
        )
        assert response.status_code == 422
        assert reason in response.json()["detail"]

    qm.release(fg_lot)
    shipment = qm.ship(customer, [(fg_lot, "4")])
    assert Decimal(shipment["lines"][0]["quantity"]) == 4
    assert Decimal(qm.get(f"/lots/{fg_lot['id']}")["balance"]) == 6


def test_fefo_lists_earliest_expiry_first_and_skips_empty_lots(qm: TenantApi) -> None:
    flour = qm.item("FLOUR")
    dough = qm.item("DOUGH", "work_in_progress")
    supplier = qm.supplier()
    soon = (date.today() + timedelta(days=10)).isoformat()
    later = (date.today() + timedelta(days=90)).isoformat()

    late_lot = qm.release(qm.receive(flour, supplier, expiry_date=later))
    early_lot = qm.release(qm.receive(flour, supplier, expiry_date=soon))
    used_up = qm.release(qm.receive(flour, supplier, quantity="5", expiry_date=soon))
    qm.produce(dough, "5", [(used_up, "5")])
    qm.receive(flour, supplier, expiry_date=soon)  # still in quarantine

    fefo = qm.get(f"/items/{flour['id']}/fefo")
    assert [lot["id"] for lot in fefo] == [early_lot["id"], late_lot["id"]]
