from typing import Any

import pytest
from fastapi.testclient import TestClient

from tests.conftest import PASSWORD, TenantApi, login
from tests.test_records import cooking_ccp, reading

OPERATOR = "operator@awrad.example.com"


def _user(admin: TenantApi, email: str) -> Any:
    [user] = [u for u in admin.get("/users") if u["email"] == email]
    return user


def _login(client: TestClient, email: str, password: str) -> Any:
    return client.post(
        "/api/v1/auth/token", json={"tenant": "awrad", "email": email, "password": password}
    )


# ----- editing users ---------------------------------------------------------------------


def test_admin_renames_and_changes_role(admin: TenantApi) -> None:
    operator = admin.as_role("operator")
    user = _user(admin, OPERATOR)

    updated = admin.patch(f"/users/{user['id']}", {"full_name": "Sara Ali", "role": "supervisor"})
    assert (updated["full_name"], updated["role"]) == ("Sara Ali", "supervisor")
    # The new role applies to the token already issued.
    assert operator.get("/auth/me")["role"] == "supervisor"
    event = admin.get("/audit/events", limit=1)[0]
    assert event["action"] == "user.updated"
    assert event["payload"]["role"] == {"from": "operator", "to": "supervisor"}

    admin.patch(f"/users/{user['id']}", {"full_name": "Sara Ali"}, 422)  # no change
    admin.patch(f"/users/{user['id']}", {}, 422)
    admin.patch(f"/users/{user['id']}", {"full_name": None}, 422)
    admin.patch(f"/users/{user['id']}", {"email": "x@y.com"}, 422)
    operator.patch(f"/users/{user['id']}", {"full_name": "Me"}, 403)


def test_old_signatures_keep_the_name_at_signing(admin: TenantApi) -> None:
    operator = admin.as_role("operator")
    entry = reading(operator, cooking_ccp(admin), "75")
    admin.patch(f"/users/{_user(admin, OPERATOR)['id']}", {"full_name": "Renamed"})
    [signature] = admin.get(f"/ccp-readings/{entry['id']}")["signatures"]
    assert signature["signer_name"] == "Operator"


def test_deactivated_user_is_locked_out_at_once(client: TestClient, admin: TenantApi) -> None:
    operator = admin.as_role("operator")
    user = _user(admin, OPERATOR)
    admin.patch(f"/users/{user['id']}", {"is_active": False})

    assert operator.get("/lots", expected=401)
    assert _login(client, OPERATOR, PASSWORD).status_code == 401
    admin.patch(f"/users/{user['id']}", {"is_active": True})
    assert operator.get("/lots") == []


def test_admin_cannot_demote_or_deactivate_self(admin: TenantApi) -> None:
    me = admin.get("/auth/me")
    assert me["role"] == "admin"
    error = admin.patch(f"/users/{me['id']}", {"role": "operator"}, 422)
    assert "your own role" in error["detail"]
    admin.patch(f"/users/{me['id']}", {"is_active": False}, 422)
    assert admin.patch(f"/users/{me['id']}", {"full_name": "QA Admin"})["full_name"] == "QA Admin"


# ----- lockout ---------------------------------------------------------------------------


def test_wrong_logins_lock_the_account(client: TestClient, admin: TenantApi) -> None:
    admin.as_role("operator")
    for _ in range(4):
        response = _login(client, OPERATOR, "wrong-password")
        assert response.status_code == 401
        assert response.json()["detail"] == "Invalid tenant, email or password"
    assert _user(admin, OPERATOR)["failed_password_attempts"] == 4

    _login(client, OPERATOR, "wrong-password")
    locked = _login(client, OPERATOR, PASSWORD)  # even the right password is refused now
    assert locked.status_code == 401
    assert "locked" in locked.json()["detail"]
    user = _user(admin, OPERATOR)
    assert user["locked_at"] is not None

    actions = [e["action"] for e in admin.get("/audit/events", limit=3)]
    assert actions == ["user.locked", "user.password_rejected", "user.password_rejected"]

    admin.post(f"/users/{user['id']}/unlock", {}, 200)
    assert _login(client, OPERATOR, PASSWORD).status_code == 200
    assert _user(admin, OPERATOR)["failed_password_attempts"] == 0
    admin.post(f"/users/{user['id']}/unlock", {}, 409)


def test_correct_password_resets_the_count(client: TestClient, admin: TenantApi) -> None:
    admin.as_role("operator")
    for _ in range(3):
        _login(client, OPERATOR, "wrong-password")
    assert _login(client, OPERATOR, PASSWORD).status_code == 200
    assert _user(admin, OPERATOR)["failed_password_attempts"] == 0


def test_wrong_signature_passwords_lock_and_block_the_session(admin: TenantApi) -> None:
    operator = admin.as_role("operator")
    ccp = cooking_ccp(admin)
    for left in (4, 3, 2, 1):
        error = reading(operator, ccp, "75", expected=403, password="wrong-password")
        assert f"({left} attempt" in error["detail"]
    error = reading(operator, ccp, "75", expected=403, password="wrong-password")
    assert "now locked" in error["detail"]

    # Nothing was recorded by the rejected requests, and the open session is cut off.
    assert admin.get("/ccp-readings") == []
    operator.get("/ccp-readings", expected=401)
    payload = admin.get("/audit/events", limit=2)[1]["payload"]
    assert payload == {"context": "signature", "attempts": 5}


def test_reset_password_unlocks(client: TestClient, admin: TenantApi) -> None:
    admin.as_role("operator")
    for _ in range(5):
        _login(client, OPERATOR, "wrong-password")
    user = _user(admin, OPERATOR)
    admin.post(f"/users/{user['id']}/reset-password", {"new_password": "Brand-new-pass-1"}, 200)
    login(client, "awrad", OPERATOR, "Brand-new-pass-1")


def test_wrong_current_password_counts(admin: TenantApi) -> None:
    operator = admin.as_role("operator")
    body = {"current_password": "nope", "new_password": "New-pass-12345"}
    error = operator.post("/auth/change-password", body, 403)
    assert "4 attempts left" in error["detail"]


def test_lockout_limit_is_configurable(
    client: TestClient, admin: TenantApi, monkeypatch: pytest.MonkeyPatch
) -> None:
    from compliance_engine.core.config import get_settings

    monkeypatch.setattr(get_settings(), "max_failed_passwords", 2)
    admin.as_role("operator")
    _login(client, OPERATOR, "wrong-password")
    _login(client, OPERATOR, "wrong-password")
    assert "after 2 wrong" in _login(client, OPERATOR, PASSWORD).json()["detail"]


def test_unknown_user_wrong_password_is_not_counted(client: TestClient, admin: TenantApi) -> None:
    assert _login(client, "nobody@awrad.example.com", "x").status_code == 401
    assert admin.get("/audit/verify")["valid"] is True
