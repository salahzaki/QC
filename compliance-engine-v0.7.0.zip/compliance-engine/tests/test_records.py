from datetime import UTC, datetime, timedelta
from typing import Any

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select, text
from sqlalchemy.exc import DBAPIError
from sqlalchemy.orm import Session

from compliance_engine.db.session import bind_tenant
from compliance_engine.models import Tenant
from tests.conftest import PASSWORD, TenantApi, make_tenant


def _bind(db: Session, slug: str = "awrad") -> None:
    tenant_id = db.scalar(select(Tenant.id).where(Tenant.slug == slug))
    assert tenant_id is not None
    bind_tenant(db, tenant_id)


def cooking_ccp(api: TenantApi, expected: int = 201, **extra: Any) -> Any:
    return api.post(
        "/control-points",
        {
            "code": "CCP-1",
            "name": "Cooking",
            "hazard": "Survival of Salmonella and Listeria",
            "parameter": "Core temperature",
            "unit": "°C",
            "critical_min": "72",
            **extra,
        },
        expected,
    )


def reading(api: TenantApi, ccp: Any, value: str, expected: int = 201, **extra: Any) -> Any:
    body = {"control_point_id": ccp["id"], "value": value, "password": PASSWORD, **extra}
    return api.post("/ccp-readings", body, expected)


def sanitation(api: TenantApi, result: str = "pass", expected: int = 201, **extra: Any) -> Any:
    body = {
        "area": "MIXER-1",
        "activity": "sanitizing",
        "chemical": "Chlorine",
        "concentration_ppm": "200",
        "result": result,
        "password": PASSWORD,
        **extra,
    }
    return api.post("/sanitation-records", body, expected)


def verify(api: TenantApi, path: str, expected: int = 200, password: str = PASSWORD) -> Any:
    return api.post(f"{path}/verify", {"password": password, "comment": "Reviewed"}, expected)


# ----- control points --------------------------------------------------------------------


def test_control_point_needs_a_limit_in_order(qm: TenantApi) -> None:
    cooking_ccp(qm, critical_min=None, critical_max=None, expected=422)
    qm.post(
        "/control-points",
        {
            "code": "CCP-2",
            "name": "Chilling",
            "hazard": "Growth of pathogens",
            "parameter": "Product temperature",
            "unit": "°C",
            "critical_min": "5",
            "critical_max": "0",
        },
        422,
    )
    assert qm.get("/control-points") == []


def test_only_quality_manager_defines_control_points(admin: TenantApi) -> None:
    operator = admin.as_role("operator")
    cooking_ccp(operator, expected=403)


# ----- CCP readings ----------------------------------------------------------------------


def test_reading_within_limits_is_signed_by_its_author(admin: TenantApi) -> None:
    ccp = cooking_ccp(admin.as_role("quality_manager"))
    operator = admin.as_role("operator")

    result = reading(operator, ccp, "75.5")

    assert result["within_limits"] is True
    assert result["critical_min"] == "72.000"
    assert result["verified"] is False
    [signature] = result["signatures"]
    assert signature["meaning"] == "performed"
    assert signature["signer_name"] == "Operator"
    assert signature["signer_role"] == "operator"
    assert signature["intact"] is True


def test_deviation_requires_a_corrective_action(qm: TenantApi) -> None:
    ccp = cooking_ccp(qm)

    error = reading(qm, ccp, "65", expected=422)
    assert "outside the critical limits" in error["detail"]

    result = reading(qm, ccp, "65", corrective_action="Re-cooked batch to 75 °C core")
    assert result["within_limits"] is False
    reading(qm, ccp, "80")

    deviations = qm.get("/ccp-readings", deviations_only=True)
    assert [r["id"] for r in deviations] == [result["id"]]


def test_wrong_signature_password_saves_nothing(qm: TenantApi) -> None:
    ccp = cooking_ccp(qm)
    body = {"control_point_id": ccp["id"], "value": "75", "password": "not-my-password"}

    error = qm.post("/ccp-readings", body, 403)

    assert "password is incorrect" in error["detail"]
    assert qm.get("/ccp-readings") == []


def test_future_readings_are_rejected(qm: TenantApi) -> None:
    ccp = cooking_ccp(qm)
    tomorrow = (datetime.now(UTC) + timedelta(days=1)).isoformat()
    reading(qm, ccp, "75", expected=422, measured_at=tomorrow)


def test_reading_can_reference_a_lot(qm: TenantApi) -> None:
    ccp = cooking_ccp(qm)
    lot = qm.receive(qm.item("FLOUR"), qm.supplier())
    assert reading(qm, ccp, "75", lot_id=lot["id"])["lot_id"] == lot["id"]
    missing = "00000000-0000-0000-0000-000000000000"
    reading(qm, ccp, "75", expected=404, lot_id=missing)


def test_supervisor_verifies_a_reading_once(admin: TenantApi) -> None:
    ccp = cooking_ccp(admin.as_role("quality_manager"))
    operator = admin.as_role("operator")
    supervisor = admin.as_role("supervisor")
    entry = reading(operator, ccp, "75")
    path = f"/ccp-readings/{entry['id']}"

    verify(operator, path, expected=403)  # operators cannot verify
    verify(supervisor, path, expected=403, password="wrong-password")
    result = verify(supervisor, path)

    assert result["verified"] is True
    assert [s["meaning"] for s in result["signatures"]] == ["performed", "verified"]
    assert result["signatures"][1]["comment"] == "Reviewed"
    verify(supervisor, path, expected=409)


def test_author_cannot_verify_their_own_reading(qm: TenantApi) -> None:
    entry = reading(qm, cooking_ccp(qm), "75")
    error = verify(qm, f"/ccp-readings/{entry['id']}", expected=422)
    assert "someone other than its author" in error["detail"]


def test_unverified_filter_lists_the_review_queue(admin: TenantApi) -> None:
    qm = admin.as_role("quality_manager")
    operator = admin.as_role("operator")
    ccp = cooking_ccp(qm)
    first = reading(operator, ccp, "75")
    second = reading(operator, ccp, "76")
    verify(qm, f"/ccp-readings/{first['id']}")

    pending = qm.get("/ccp-readings", unverified_only=True)
    assert [r["id"] for r in pending] == [second["id"]]


def test_auditor_reads_but_cannot_record(admin: TenantApi) -> None:
    entry = reading(admin, cooking_ccp(admin), "75")
    auditor = admin.as_role("auditor")

    assert auditor.get(f"/ccp-readings/{entry['id']}")["id"] == entry["id"]
    reading(auditor, {"id": entry["control_point_id"]}, "75", expected=403)


def test_records_are_invisible_to_other_tenants(client: TestClient, qm: TenantApi) -> None:
    entry = reading(qm, cooking_ccp(qm), "75")
    other = make_tenant(client, "other")
    other.get(f"/ccp-readings/{entry['id']}", expected=404)
    assert other.get("/ccp-readings") == []


def test_signature_shows_tampering_that_bypasses_triggers(db: Session, qm: TenantApi) -> None:
    entry = reading(qm, cooking_ccp(qm), "65", corrective_action="Re-cooked the batch")

    _bind(db)
    db.execute(text("ALTER TABLE ccp_readings DISABLE TRIGGER ccp_readings_append_only"))
    db.execute(text("UPDATE ccp_readings SET value = 75, within_limits = true"))
    db.execute(text("ALTER TABLE ccp_readings ENABLE TRIGGER ccp_readings_append_only"))
    db.commit()

    [signature] = qm.get(f"/ccp-readings/{entry['id']}")["signatures"]
    assert signature["intact"] is False


def test_signing_is_audited_without_the_password(qm: TenantApi) -> None:
    reading(qm, cooking_ccp(qm), "75")

    events = qm.get("/audit/events", limit=2)
    assert [e["action"] for e in events] == ["record.signed", "ccp_reading.recorded"]
    assert "password" not in events[1]["payload"]
    assert PASSWORD not in str(events)
    assert qm.get("/audit/verify")["valid"] is True


# ----- sanitation ------------------------------------------------------------------------


def test_sanitation_failure_requires_a_corrective_action(qm: TenantApi) -> None:
    error = sanitation(qm, "fail", expected=422)
    assert "needs a corrective_action" in str(error)
    assert PASSWORD not in str(error)  # validation errors never echo the signature password
    failed = sanitation(qm, "fail", corrective_action="Re-cleaned and swabbed again")
    sanitation(qm, "pass")

    failures = qm.get("/sanitation-records", failures_only=True)
    assert [r["id"] for r in failures] == [failed["id"]]
    assert failed["concentration_ppm"] == "200.00"
    assert failed["signatures"][0]["intact"] is True


def test_sanitation_is_verified_by_a_second_person(admin: TenantApi) -> None:
    operator = admin.as_role("operator")
    supervisor = admin.as_role("supervisor")
    record = sanitation(operator, activity="pre_op_inspection", chemical=None)
    path = f"/sanitation-records/{record['id']}"

    assert supervisor.get("/sanitation-records", unverified_only=True, area="MIXER-1") != []
    result = verify(supervisor, path)

    assert result["verified"] is True
    assert all(s["intact"] for s in result["signatures"])
    assert supervisor.get("/sanitation-records", unverified_only=True) == []


# ----- immutability ----------------------------------------------------------------------


@pytest.mark.parametrize(
    "statement",
    [
        "UPDATE ccp_readings SET value = 99",
        "DELETE FROM ccp_readings",
        "UPDATE sanitation_records SET result = 'pass'",
        "DELETE FROM sanitation_records",
        "UPDATE record_signatures SET signer_name = 'Someone else'",
        "DELETE FROM record_signatures",
    ],
)
def test_signed_records_cannot_be_rewritten(db: Session, qm: TenantApi, statement: str) -> None:
    reading(qm, cooking_ccp(qm), "75")
    sanitation(qm)
    _bind(db)

    with pytest.raises(DBAPIError, match="not allowed"):
        db.execute(text(statement))


def test_cleaning_after_use_is_a_sanitation_activity(qm: TenantApi) -> None:
    record = sanitation(qm, activity="after_use", area="SLICER-2", chemical=None)
    assert record["activity"] == "after_use"
    sanitation(qm, "fail", activity="after_use", corrective_action="Cleaned again and rinsed")
    [alert] = qm.get("/alerts")
    assert alert["message"] == "Sanitation check failed: after use of MIXER-1"
