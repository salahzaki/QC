from typing import Any

from tests.conftest import TenantApi


def _bakery(qm: TenantApi) -> dict[str, Any]:
    """Flour + sugar -> dough -> biscuits (+ packaging) -> two customers.
    A second, unrelated flour lot must never appear in the trace."""
    flour, sugar = qm.item("FLOUR"), qm.item("SUGAR")
    box = qm.item("BOX", "packaging")
    dough = qm.item("DOUGH", "work_in_progress")
    biscuits = qm.item("BISCUIT", "finished_good", shelf_life_days=180)
    mill, refinery = qm.supplier("MILL"), qm.supplier("REFINERY")

    flour_lot = qm.release(qm.receive(flour, mill, supplier_lot_code="M-77"))
    other_flour = qm.release(qm.receive(flour, mill, supplier_lot_code="M-78"))
    sugar_lot = qm.release(qm.receive(sugar, refinery, supplier_lot_code="R-12"))
    box_lot = qm.release(qm.receive(box, mill, supplier_lot_code="B-1"))

    dough_lot = qm.release(
        qm.produce(dough, "60", [(flour_lot, "50"), (sugar_lot, "10")])["output_lot"]
    )
    biscuit_lot = qm.release(
        qm.produce(biscuits, "55", [(dough_lot, "60"), (box_lot, "5")])["output_lot"]
    )
    unrelated = qm.release(qm.produce(dough, "10", [(other_flour, "10")])["output_lot"])

    qm.ship(qm.customer("TAMIMI"), [(biscuit_lot, "30")], reference="SO-1")
    qm.ship(qm.customer("DANUBE"), [(biscuit_lot, "20")], reference="SO-2")
    return {
        "flour": flour_lot,
        "sugar": sugar_lot,
        "box": box_lot,
        "dough": dough_lot,
        "biscuit": biscuit_lot,
        "unrelated": unrelated,
        "other_flour": other_flour,
    }


def test_backward_trace_reaches_every_ingredient_and_supplier(qm: TenantApi) -> None:
    lots = _bakery(qm)

    report = qm.get(f"/trace/lots/{lots['biscuit']['id']}", direction="backward")

    depth_by_lot = {lot["lot_id"]: lot["depth"] for lot in report["lots"]}
    assert depth_by_lot == {
        lots["biscuit"]["id"]: 0,
        lots["dough"]["id"]: 1,
        lots["box"]["id"]: 1,
        lots["flour"]["id"]: 2,
        lots["sugar"]["id"]: 2,
    }
    suppliers = {(lot["supplier_code"], lot["supplier_lot_code"]) for lot in report["lots"]}
    assert ("MILL", "M-77") in suppliers
    assert ("REFINERY", "R-12") in suppliers
    assert len(report["links"]) == 4
    assert report["shipments"] == []


def test_forward_trace_from_a_raw_lot_finds_every_customer(qm: TenantApi) -> None:
    lots = _bakery(qm)

    report = qm.get(f"/trace/lots/{lots['flour']['id']}", direction="forward")

    traced = {lot["lot_id"] for lot in report["lots"]}
    assert traced == {lots["flour"]["id"], lots["dough"]["id"], lots["biscuit"]["id"]}
    customers = {(s["customer_code"], s["reference"]) for s in report["shipments"]}
    assert customers == {("TAMIMI", "SO-1"), ("DANUBE", "SO-2")}


def test_trace_does_not_leak_into_unrelated_lots(qm: TenantApi) -> None:
    lots = _bakery(qm)

    report = qm.get(f"/trace/lots/{lots['other_flour']['id']}", direction="forward")

    assert {lot["lot_id"] for lot in report["lots"]} == {
        lots["other_flour"]["id"],
        lots["unrelated"]["id"],
    }
    assert report["shipments"] == []


def test_deep_genealogy_traces_well_under_five_seconds(qm: TenantApi) -> None:
    """Mock recall: 40 chained production steps, each adding a fresh ingredient lot."""
    flour = qm.item("FLOUR")
    wip = qm.item("WIP", "work_in_progress")
    supplier = qm.supplier()

    current = qm.release(qm.receive(flour, supplier, quantity="1000"))
    for step in range(40):
        extra = qm.release(
            qm.receive(flour, supplier, quantity="10", supplier_lot_code=f"S-{step}")
        )
        current = qm.release(qm.produce(wip, "100", [(current, "50"), (extra, "5")])["output_lot"])

    report = qm.get(f"/trace/lots/{current['id']}", direction="backward")

    assert len(report["lots"]) == 81  # 40 produced lots + 41 raw lots
    assert max(lot["depth"] for lot in report["lots"]) == 40
    assert report["elapsed_ms"] < 5000
