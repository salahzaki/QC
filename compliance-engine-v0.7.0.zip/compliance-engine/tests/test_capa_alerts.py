from datetime import UTC, datetime, timedelta
from typing import Any

import pytest
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError
from sqlalchemy.orm import Session

from compliance_engine.db.session import get_session_factory
from compliance_engine.services.alerts import scan_all_tenants
from tests.conftest import PASSWORD, TenantApi
from tests.test_records import _bind, cooking_ccp, reading, sanitation

ACTION = "Held the batch and re-cooked it to 75 °C core"


def close(api: TenantApi, action: Any, expected: int = 200, **extra: Any) -> Any:
    body = {
        "root_cause": "Steam valve partly closed",
        "preventive_action": "Valve added to the daily pre-op checklist",
        "product_disposition": "reworked",
        "password": PASSWORD,
        **extra,
    }
    return api.post(f"/corrective-actions/{action['id']}/close", body, expected)


def test_deviation_opens_a_corrective_action_and_an_alert(admin: TenantApi) -> None:
    qm = admin.as_role("quality_manager")
    operator = admin.as_role("operator")
    ccp = cooking_ccp(qm)
    lot = qm.receive(qm.item("CHICKEN"), qm.supplier())

    entry = reading(operator, ccp, "68", corrective_action=ACTION, lot_id=lot["id"])
    reading(operator, ccp, "75")

    assert entry["corrective_action_status"] == "open"
    [action] = qm.get("/corrective-actions", status="open")
    assert action["id"] == entry["corrective_action_id"]
    assert action["record_type"] == "ccp_reading"
    assert action["record_id"] == entry["id"]
    assert action["lot_id"] == lot["id"]
    assert action["immediate_action"] == ACTION
    assert "68 °C is outside the critical limits (min 72 °C)" in action["description"]

    [alert] = qm.get("/alerts")
    assert alert["kind"] == "ccp_deviation"
    assert alert["severity"] == "critical"
    assert alert["record_id"] == entry["id"]
    assert alert["control_point_id"] == ccp["id"]


def test_sanitation_failure_opens_a_corrective_action(qm: TenantApi) -> None:
    failed = sanitation(qm, "fail", corrective_action="Re-cleaned and swabbed again")
    sanitation(qm, "pass")

    [action] = qm.get("/corrective-actions")
    assert action["record_id"] == failed["id"]
    assert action["description"] == "Sanitation check failed: sanitizing of MIXER-1"
    [alert] = qm.get("/alerts")
    assert (alert["kind"], alert["severity"]) == ("sanitation_failure", "major")


def test_quality_manager_closes_a_corrective_action_once(admin: TenantApi) -> None:
    qm = admin.as_role("quality_manager")
    supervisor = admin.as_role("supervisor")
    operator = admin.as_role("operator")
    reading(operator, cooking_ccp(qm), "68", corrective_action=ACTION)
    [action] = qm.get("/corrective-actions")

    close(supervisor, action, expected=403)  # supervisors verify records, QM closes CAPA
    close(qm, action, expected=403, password="wrong-password")
    close(qm, action, expected=422, product_disposition="sold_anyway")
    closed = close(qm, action, comment="Root cause confirmed with maintenance")

    assert closed["status"] == "closed"
    assert closed["product_disposition"] == "reworked"
    assert closed["closed_by"] is not None
    [signature] = closed["signatures"]
    assert signature["meaning"] == "approved"
    assert signature["signer_role"] == "quality_manager"
    assert signature["intact"] is True
    close(qm, action, expected=409)
    assert qm.get("/corrective-actions", status="open") == []
    assert qm.get(f"/ccp-readings/{action['record_id']}")["corrective_action_status"] == "closed"


def test_corrective_action_is_closed_by_someone_else(qm: TenantApi) -> None:
    reading(qm, cooking_ccp(qm), "68", corrective_action=ACTION)
    [action] = qm.get("/corrective-actions")
    error = close(qm, action, expected=422)
    assert "someone other than" in error["detail"]


@pytest.mark.parametrize(
    "statement",
    [
        "UPDATE corrective_actions SET description = 'nothing happened'",
        "UPDATE corrective_actions SET root_cause = 'changed later'",
        "DELETE FROM corrective_actions",
        "UPDATE alerts SET message = 'hidden'",
        "DELETE FROM alerts",
    ],
)
def test_closed_corrective_actions_and_alerts_cannot_be_rewritten(
    db: Session, admin: TenantApi, statement: str
) -> None:
    qm = admin.as_role("quality_manager")
    reading(admin, cooking_ccp(qm), "68", corrective_action=ACTION)
    [action] = qm.get("/corrective-actions")
    close(qm, action)
    _bind(db)

    with pytest.raises(DBAPIError, match=r"not allowed|only be"):
        db.execute(text(statement))


def test_supervisor_acknowledges_an_alert_once(admin: TenantApi) -> None:
    operator = admin.as_role("operator")
    supervisor = admin.as_role("supervisor")
    reading(operator, cooking_ccp(admin), "68", corrective_action=ACTION)
    [alert] = supervisor.get("/alerts")
    path = f"/alerts/{alert['id']}/acknowledge"

    operator.post(path, {"comment": "seen"}, 403)
    acknowledged = supervisor.post(path, {"comment": "Line stopped, QA informed"}, 200)
    supervisor.post(path, {}, 409)

    assert acknowledged["acknowledgement"] == "Line stopped, QA informed"
    assert acknowledged["acknowledged_at"] is not None
    assert supervisor.get("/alerts") == []
    assert len(supervisor.get("/alerts", open_only=False)) == 1


def test_alert_summary_counts_what_needs_attention(admin: TenantApi) -> None:
    operator = admin.as_role("operator")
    ccp = cooking_ccp(admin)
    reading(operator, ccp, "68", corrective_action=ACTION)
    reading(operator, ccp, "75")
    sanitation(operator, "fail", corrective_action="Re-cleaned and swabbed again")

    summary = admin.get("/alerts/summary")
    assert summary == {
        "open_alerts": 2,
        "open_critical": 1,
        "open_corrective_actions": 2,
        "unverified_records": 3,
    }


# ----- missed checks ---------------------------------------------------------------------


def _backdate_control_point(db: Session, minutes: int) -> None:
    _bind(db)
    db.execute(
        text("UPDATE control_points SET created_at = :at"),
        {"at": datetime.now(UTC) - timedelta(minutes=minutes)},
    )
    db.commit()


def test_overdue_check_raises_one_alert_per_gap(db: Session, qm: TenantApi) -> None:
    ccp = cooking_ccp(qm, check_interval_minutes=60)
    assert ccp["check_interval_minutes"] == 60
    assert qm.post("/alerts/scan-missed-checks", {}, 200)["alerts_raised"] == []

    _backdate_control_point(db, 90)
    [alert] = qm.post("/alerts/scan-missed-checks", {}, 200)["alerts_raised"]
    assert alert["kind"] == "missed_check"
    assert "CCP-1 (Cooking): no reading for 90 minutes" in alert["message"]
    assert qm.post("/alerts/scan-missed-checks", {}, 200)["alerts_raised"] == []

    # A reading closes the gap; the next gap would raise a new alert.
    reading(qm, ccp, "75")
    assert qm.post("/alerts/scan-missed-checks", {}, 200)["alerts_raised"] == []


def test_background_scan_covers_every_tenant(db: Session, qm: TenantApi) -> None:
    cooking_ccp(qm, check_interval_minutes=30)
    _backdate_control_point(db, 45)

    assert scan_all_tenants(get_session_factory()) == 1
    assert scan_all_tenants(get_session_factory()) == 0
    assert [a["kind"] for a in qm.get("/alerts")] == ["missed_check"]


def test_control_point_settings_change_with_a_reason(admin: TenantApi) -> None:
    qm = admin.as_role("quality_manager")
    ccp = cooking_ccp(qm)
    path = f"/control-points/{ccp['id']}"
    old = reading(qm, ccp, "73")

    changed = qm.patch(
        path,
        {"critical_min": "74", "check_interval_minutes": 120, "reason": "Validation study"},
    )
    assert changed["critical_min"] == "74.000"
    assert changed["check_interval_minutes"] == 120

    # Readings keep the limits in force when they were taken.
    assert qm.get(f"/ccp-readings/{old['id']}")["within_limits"] is True
    new = reading(qm, ccp, "73", expected=422)
    assert "min 74 °C" in new["detail"]

    qm.patch(path, {"critical_max": "70", "reason": "Typo in the plan"}, 422)
    qm.patch(path, {"name": None, "reason": "Clearing the name"}, 422)
    admin.as_role("operator").patch(path, {"name": "X", "reason": "No right"}, 403)
    [event] = [e for e in qm.get("/audit/events") if e["action"] == "control_point.updated"]
    assert event["payload"]["reason"] == "Validation study"
    assert event["payload"]["before"]["critical_min"] == "72.000"
