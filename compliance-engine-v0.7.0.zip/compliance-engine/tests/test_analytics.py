from datetime import UTC, datetime, timedelta
from typing import Any

from compliance_engine.services.analytics import _cpk, _on_time
from tests.conftest import TenantApi
from tests.test_records import cooking_ccp, reading, sanitation, verify


def test_analytics_figures(admin: TenantApi) -> None:
    qm = admin.as_role("quality_manager")
    operator = admin.as_role("operator")
    ccp = cooking_ccp(qm, check_interval_minutes=60)
    now = datetime.now(UTC).replace(microsecond=0)
    times = [now - timedelta(minutes=m) for m in (200, 140, 80, 10)]  # gaps 60, 60, 70 min
    readings = [
        reading(operator, ccp, value, measured_at=at.isoformat(), **extra)
        for at, value, extra in zip(
            times,
            ("75", "76", "68", "74"),
            ({}, {}, {"corrective_action": "Re-cooked"}, {}),
            strict=True,
        )
    ]
    verify(qm, f"/ccp-readings/{readings[0]['id']}")
    sanitation(operator)
    sanitation(operator, "fail", corrective_action="Cleaned again")

    data = qm.get("/analytics")
    k = data["kpis"]
    assert (k["ccp_readings"], k["ccp_deviations"], k["ccp_compliance_pct"]) == (4, 1, 75.0)
    assert (k["sanitation_checks"], k["sanitation_failures"], k["sanitation_pass_pct"]) == (
        2,
        1,
        50.0,
    )
    assert k["verified_pct"] == round(100 / 6, 1)
    assert k["on_time_pct"] == round(200 / 3, 1)  # the 70-minute gap is late
    assert k["capa_opened"] == 2 and k["capa_closed"] == 0
    assert data["previous"]["ccp_readings"] == 0
    assert data["score"]["score"] is not None
    assert {p["key"] for p in data["score"]["parts"]} == {
        "ccp_compliance",
        "sanitation_pass",
        "verified",
        "on_time",
    }
    assert sum(d["ccp_readings"] for d in data["daily"]) == 4
    assert len(data["daily"]) == 7
    [point] = data["control_points"]
    assert (point["readings"], point["deviations"], point["minimum"]) == (4, 1, 68.0)
    spc = data["spc"]
    assert spc["code"] == "CCP-1" and len(spc["points"]) == 4
    assert [p["value"] for p in spc["points"]] == [75.0, 76.0, 68.0, 74.0]
    assert sum(c["records"] for c in data["heatmap"]) == 6
    assert sum(c["problems"] for c in data["heatmap"]) == 2
    [area] = data["areas"]
    assert (area["area"], area["failures"]) == ("MIXER-1", 1)
    assert data["capa"]["open_now"] == 2 and data["capa"]["buckets"]["0-2"] == 2
    people = {p["name"]: p for p in data["people"]}
    assert people["Operator"]["records"] == 6 and people["Operator"]["problems"] == 2
    assert people["Quality_Manager"]["verifications"] == 1

    # Operators see the figures but not the per-person table.
    assert operator.get("/analytics")["people"] is None


def test_live_status_board(admin: TenantApi) -> None:
    qm = admin.as_role("quality_manager")
    operator = admin.as_role("operator")
    ccp = cooking_ccp(qm, check_interval_minutes=30)
    late = datetime.now(UTC) - timedelta(minutes=45)
    reading(operator, ccp, "75", measured_at=late.isoformat())
    live = qm.get("/analytics/live")
    [point] = live["control_points"]
    assert point["status"] == "overdue" and point["last_value"] == 75.0

    reading(operator, ccp, "60", corrective_action="Stopped the line")
    live = qm.get("/analytics/live")
    assert live["control_points"][0]["status"] == "deviation"
    assert live["today_problems"] >= 1
    kinds = {a["kind"] for a in live["activity"]}
    assert kinds == {"ccp_reading", "corrective_action"}


def test_analytics_period_rules(qm: TenantApi) -> None:
    qm.get("/analytics", 422, date_from="2026-02-01", date_to="2026-01-01")
    data = qm.get("/analytics", date_from="2026-01-01", date_to="2026-01-31")
    assert (data["previous_from"], data["previous_to"]) == ("2025-12-01", "2025-12-31")
    assert data["kpis"]["ccp_compliance_pct"] is None  # nothing to measure, not 0 or 100
    assert data["spc"] is None and data["score"]["score"] is None


def test_capability_and_timeliness_helpers() -> None:
    assert _cpk([75.0] * 12, 72, None) is None  # no spread
    values: list[Any] = [74, 75, 76] * 4
    assert _cpk(values, 72, None) == round((75 - 72) / (3 * 0.8528028654224418), 2)
    assert _cpk(values[:5], 72, None) is None  # too few readings
    start = datetime(2026, 1, 1, tzinfo=UTC)
    times = [start + timedelta(minutes=m) for m in (0, 60, 125, 200)]
    assert _on_time(times, 60) == (2, 3)
    assert _on_time(times, None) == (0, 0)
