from typing import Any

import pytest
from sqlalchemy import select
from sqlalchemy.orm import Session

from compliance_engine.core import secrets
from compliance_engine.core.config import Settings
from compliance_engine.models import TenantSettings
from compliance_engine.models.enums import NotificationChannel
from compliance_engine.notifications import senders
from tests.conftest import FakeSender, TenantApi
from tests.test_records import _bind

EMAIL = {
    "smtp_host": "smtp.example.com",
    "smtp_port": 465,
    "smtp_security": "ssl",
    "smtp_username": "alerts@example.com",
    "smtp_password": "mail-secret-123",
    "smtp_from": "Alerts@Example.com",
}


def test_secrets_round_trip_and_detect_tampering() -> None:
    token = secrets.encrypt("كلمة سر 123")
    assert "123" not in token
    assert secrets.decrypt(token) == "كلمة سر 123"
    assert secrets.encrypt("same") != secrets.encrypt("same")
    damaged = token[:-6] + ("A" if token[-6] != "A" else "B") + token[-5:]
    assert secrets.decrypt(damaged) is None
    assert secrets.decrypt("plain") is None


def test_mail_settings_from_the_app_replace_the_server_ones(
    qm: TenantApi, db: Session, monkeypatch: pytest.MonkeyPatch
) -> None:
    initial = qm.get("/settings/notifications")
    assert initial["email"] == {"configured": False, "source": None}
    assert initial["smtp_password_set"] is False

    saved = qm.client.put(
        "/api/v1/settings/notifications/email", json=EMAIL, headers=qm.headers
    ).json()
    assert saved["email"] == {"configured": True, "source": "app"}
    assert saved["smtp_password_set"] is True
    assert saved["smtp_from"] == "alerts@example.com"
    assert "smtp_password" not in saved
    assert "mail-secret-123" not in str(saved)
    assert qm.get("/notifications/channels")["email"] is True

    _bind(db)
    row = db.scalar(select(TenantSettings))
    assert row is not None and row.smtp_password_enc is not None
    assert "mail-secret-123" not in row.smtp_password_enc
    db.rollback()
    [event] = [e for e in qm.get("/audit/events") if e["action"] == "settings.email_updated"]
    assert "mail-secret-123" not in str(event)

    # Sending uses the factory's settings, with the password decrypted.
    seen: list[Settings | None] = []
    fake = FakeSender()

    def capture(settings: Settings | None = None) -> dict[NotificationChannel, Any]:
        seen.append(settings)
        return {NotificationChannel.EMAIL: fake, NotificationChannel.WHATSAPP: fake}

    monkeypatch.setattr(senders, "get_senders", capture)
    recipient = qm.post(
        "/notification-recipients", {"name": "QA", "channel": "email", "address": "qa@x.com"}
    )
    assert qm.post(f"/notification-recipients/{recipient['id']}/test", {}, 200)["sent"] is True
    [settings] = seen
    assert settings is not None
    assert settings.smtp_host == "smtp.example.com"
    assert settings.smtp_port == 465
    assert settings.smtp_password is not None
    assert settings.smtp_password.get_secret_value() == "mail-secret-123"

    # Saving again without a password keeps the stored one.
    kept = {**EMAIL, "smtp_port": 587, "smtp_security": "starttls"}
    del kept["smtp_password"]
    put = qm.client.put("/api/v1/settings/notifications/email", json=kept, headers=qm.headers)
    assert put.status_code == 200
    assert put.json()["smtp_password_set"] is True

    cleared = qm.client.put(
        "/api/v1/settings/notifications/email", json={"smtp_host": None}, headers=qm.headers
    ).json()
    assert cleared["email"] == {"configured": False, "source": None}
    assert cleared["smtp_password_set"] is False


def test_whatsapp_settings_need_a_token(admin: TenantApi) -> None:
    url = "/api/v1/settings/notifications/whatsapp"
    missing = admin.client.put(url, json={"phone_number_id": "123456789"}, headers=admin.headers)
    assert missing.status_code == 422
    saved = admin.client.put(
        url,
        json={"phone_number_id": "123456789", "token": "EAAG-token", "template": "qa_alert"},
        headers=admin.headers,
    ).json()
    assert saved["whatsapp"] == {"configured": True, "source": "app"}
    assert saved["whatsapp_token_set"] is True
    assert saved["whatsapp_template"] == "qa_alert"
    assert "EAAG" not in str(saved)
    operator = admin.as_role("operator")
    assert (
        operator.client.get("/api/v1/settings/notifications", headers=operator.headers).status_code
        == 403
    )


def test_users_have_an_optional_mobile_number(admin: TenantApi) -> None:
    user = admin.post(
        "/users",
        {
            "email": "sup@x.com",
            "full_name": "Supervisor",
            "role": "supervisor",
            "password": "correct-horse-battery",
            "phone": "+966 50 123 4567",
        },
    )
    assert user["phone"] == "+966501234567"
    assert admin.patch(f"/users/{user['id']}", {"phone": "0501"}, 422)
    assert admin.patch(f"/users/{user['id']}", {"phone": None})["phone"] is None


def test_people_list_for_quality_managers_only(admin: TenantApi) -> None:
    qm = admin.as_role("quality_manager")
    names = {p["full_name"] for p in qm.get("/people")}
    assert names == {"Admin", "Quality_Manager"}
    admin.as_role("operator").get("/people", 403)
