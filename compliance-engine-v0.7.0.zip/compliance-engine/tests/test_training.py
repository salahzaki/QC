from datetime import timedelta
from typing import Any

from sqlalchemy import text
from sqlalchemy.orm import Session

from compliance_engine.db.session import get_session_factory
from compliance_engine.services.alerts import scan_all_tenants
from compliance_engine.services.context import factory_today
from compliance_engine.services.suppliers import add_months
from tests.conftest import PASSWORD, TenantApi
from tests.test_records import _bind, cooking_ccp, reading


def course(api: TenantApi, code: str = "HYG-01", **extra: Any) -> Any:
    body = {
        "code": code,
        "title": "Basic food hygiene",
        "validity_months": 12,
        "required_roles": ["operator", "supervisor"],
        **extra,
    }
    return api.post("/training/courses", body)


def train(
    api: TenantApi,
    course: Any,
    users: list[Any],
    days_ago: int = 0,
    expected: int = 201,
    **extra: Any,
) -> Any:
    body = {
        "course_id": course["id"],
        "trained_on": str(factory_today() - timedelta(days=days_ago)),
        "trainer": "Dr. Sara Ahmed",
        "duration_hours": "4",
        "attendees": [{"user_id": u["id"]} for u in users],
        "password": PASSWORD,
        **extra,
    }
    return api.post("/training/records", body, expected)


def users_by_role(api: TenantApi) -> dict[str, Any]:
    return {u["role"]: u for u in api.get("/users")}


def test_training_session_records_each_attendee(admin: TenantApi) -> None:
    qm = admin.as_role("quality_manager")
    admin.as_role("operator")
    admin.as_role("supervisor")
    people = users_by_role(admin)
    hygiene = course(qm)

    records = train(qm, hygiene, [people["operator"], people["supervisor"]], days_ago=10)
    assert len(records) == 2
    assert {r["serial"][:4] for r in records} == {"TRN-"}
    expected_expiry = add_months(factory_today() - timedelta(days=10), 12)
    assert {r["expires_on"] for r in records} == {str(expected_expiry)}
    assert records[0]["state"] == "valid"
    assert records[0]["signatures"][0]["meaning"] == "performed"
    assert records[0]["course_code"] == "HYG-01"

    matrix = qm.get("/training/matrix")
    assert matrix["required"] == 2
    assert matrix["compliant"] == 2
    assert matrix["compliance_pct"] == 100.0
    by_role = {row["role"]: row for row in matrix["rows"]}
    assert by_role["admin"]["cells"][0]["status"] == "not_required"
    assert by_role["operator"]["cells"][0]["status"] == "valid"

    mine = qm.get("/training/records", user_id=people["operator"]["id"])
    assert [r["user_name"] for r in mine] == ["Operator"]

    train(qm, hygiene, [people["operator"]], days_ago=-1, expected=422)
    duplicate = [people["operator"], people["operator"]]
    train(qm, hygiene, duplicate, expected=422)
    train(qm, hygiene, [people["operator"]], password="wrong-password", expected=403)
    admin.as_role("auditor").post("/training/courses", {"code": "X", "title": "XX"}, 403)


def test_failed_and_expired_training_count_as_gaps(admin: TenantApi) -> None:
    qm = admin.as_role("quality_manager")
    admin.as_role("operator")
    admin.as_role("supervisor")
    people = users_by_role(admin)
    hygiene = course(qm, validity_months=6)
    failed = qm.post(
        "/training/records",
        {
            "course_id": hygiene["id"],
            "trained_on": str(factory_today()),
            "trainer": "Dr. Sara Ahmed",
            "attendees": [{"user_id": people["operator"]["id"], "result": "failed", "score": "40"}],
            "password": PASSWORD,
        },
    )
    assert failed[0]["state"] == "failed"
    assert failed[0]["expires_on"] is None
    train(qm, hygiene, [people["supervisor"]], days_ago=200)

    matrix = qm.get("/training/matrix")
    statuses = {row["role"]: row["cells"][0]["status"] for row in matrix["rows"]}
    assert statuses["operator"] == "failed"
    assert statuses["supervisor"] == "expired"
    assert matrix["compliance_pct"] == 0.0
    assert matrix["expired"] == 1
    assert matrix["missing"] == 1


def test_competence_gate_refuses_untrained_readings(admin: TenantApi) -> None:
    qm = admin.as_role("quality_manager")
    operator = admin.as_role("operator")
    people = users_by_role(admin)
    ccp = cooking_ccp(qm)
    course(qm, "CCP-COOK", title="Cooking CCP monitoring", control_point_ids=[ccp["id"]])
    reading(operator, ccp, "75")  # gate is off by default

    assert qm.patch("/settings/quality", {"enforce_training": True})["enforce_training"] is True
    refused = reading(operator, ccp, "75", expected=422)
    assert "not qualified to record" in refused["detail"]
    assert "CCP-COOK" in refused["detail"]
    [competence] = operator.get("/training/my-competence")
    assert competence["qualified"] is False

    cook = next(c for c in qm.get("/training/courses") if c["code"] == "CCP-COOK")
    train(qm, cook, [people["operator"]])
    reading(operator, ccp, "75")
    assert operator.get("/training/my-competence")[0]["qualified"] is True

    operator.patch("/settings/quality", {"enforce_training": False}, 403)
    qm.patch(f"/training/courses/{cook['id']}", {"is_active": False})
    assert qm.get("/settings/quality")["expiry_warning_days"] == 30


def test_training_expiry_alerts(admin: TenantApi, db: Session) -> None:
    qm = admin.as_role("quality_manager")
    admin.as_role("operator")
    people = users_by_role(admin)
    hygiene = course(qm, validity_months=1)
    train(qm, hygiene, [people["operator"]], days_ago=10)  # expires in about 20 days

    assert scan_all_tenants(get_session_factory()) == 1
    assert scan_all_tenants(get_session_factory()) == 0
    [alert] = qm.get("/alerts")
    assert alert["kind"] == "training_expiring"
    assert "Operator: training HYG-01" in alert["message"]

    qm.patch("/settings/quality", {"expiry_warning_days": 7})
    train(qm, hygiene, [people["operator"]], days_ago=40)  # older and already expired
    assert scan_all_tenants(get_session_factory()) == 0  # the newer pass still counts

    _bind(db)
    db.execute(text("UPDATE users SET is_active = false WHERE role = 'operator'"))
    db.commit()
    assert scan_all_tenants(get_session_factory()) == 0


def test_training_and_supplier_reports_are_controlled_pdfs(admin: TenantApi) -> None:
    qm = admin.as_role("quality_manager")
    admin.as_role("operator")
    people = users_by_role(admin)
    for index in range(10):  # more courses than fit one table
        course(qm, f"C-{index}", title=f"Course {index}")
    first = next(c for c in qm.get("/training/courses") if c["code"] == "C-0")
    train(qm, first, [people["operator"]], days_ago=3)
    supplier = qm.supplier("MILLS", approved=False)
    qm.post(
        f"/suppliers/{supplier['id']}/decisions",
        {
            "to_status": "conditional",
            "reason": "Audit",
            "conditions": "Halal cert",
            "password": PASSWORD,
        },
    )
    for path, code in (
        ("/reports/training-matrix", "F-TRN-01"),
        ("/reports/training-log", "F-TRN-02"),
        ("/reports/supplier-list", "F-SUP-01"),
    ):
        for lang in ("ar", "en"):
            response = qm.client.get(f"/api/v1{path}?lang={lang}", headers=qm.headers)
            assert response.status_code == 200, response.text
            assert response.content.startswith(b"%PDF")
            serial = response.headers["X-Report-Number"]
            assert qm.get(f"/issued-reports/{serial}")["form_code"] == code
