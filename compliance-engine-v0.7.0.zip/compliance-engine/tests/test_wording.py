"""Texts the system writes into records follow CE_RECORD_LANGUAGE (Arabic by default)."""

from datetime import timedelta
from decimal import Decimal

import pytest

from compliance_engine.core.config import get_settings
from compliance_engine.models.enums import SanitationActivity
from compliance_engine.services import wording


@pytest.fixture
def arabic(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(get_settings(), "record_language", "ar")


def test_default_record_language_is_arabic(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("CE_RECORD_LANGUAGE")
    assert type(get_settings())(jwt_secret="x" * 32).record_language == "ar"


@pytest.mark.usefixtures("arabic")
def test_arabic_deviation_text() -> None:
    text = wording.ccp_deviation("CCP-1", "Cooking", Decimal("68.0"), "°C", Decimal("72"), None)
    assert text == "CCP-1 (Cooking): القيمة 68 °C خارج الحدود الحرجة (حد أدنى 72 °C)"
    assert wording.limits_text(Decimal("2"), Decimal("4.50"), "pH") == "من 2 إلى 4.5 pH"


@pytest.mark.usefixtures("arabic")
def test_arabic_sanitation_and_missed_check_texts() -> None:
    assert (
        wording.sanitation_failure(SanitationActivity.SANITIZING, "MIXER-1")
        == "عدم مطابقة في فحص النظافة: تعقيم - MIXER-1"
    )
    text = wording.missed_check(
        "CCP-1", "Cooking", timedelta(minutes=95), True, timedelta(minutes=60)
    )
    assert text == (
        "CCP-1 (Cooking): لم تُسجَّل أي قراءة منذ 95 دقيقة من آخر قراءة، والمطلوب قراءة كل 60 دقيقة"
    )


@pytest.mark.usefixtures("arabic")
@pytest.mark.parametrize(
    ("count", "expected"),
    [(1, "دقيقة واحدة"), (2, "دقيقتين"), (5, "5 دقائق"), (11, "11 دقيقة"), (90, "90 دقيقة")],
)
def test_arabic_minutes(count: int, expected: str) -> None:
    assert wording.minutes(timedelta(minutes=count)) == expected
