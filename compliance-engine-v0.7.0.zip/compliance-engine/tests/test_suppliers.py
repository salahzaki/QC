import base64
import hashlib
from datetime import timedelta
from typing import Any

import pytest
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError
from sqlalchemy.orm import Session

from compliance_engine.db.session import get_session_factory
from compliance_engine.services.alerts import scan_all_tenants
from compliance_engine.services.context import factory_today
from compliance_engine.services.suppliers import add_months
from tests.conftest import PASSWORD, TenantApi
from tests.test_records import _bind

BASIS = "Site audit passed and FSSC 22000 certificate checked"


def decide(api: TenantApi, supplier: Any, to: str, expected: int = 201, **extra: Any) -> Any:
    body = {"to_status": to, "reason": BASIS, "password": PASSWORD, **extra}
    return api.post(f"/suppliers/{supplier['id']}/decisions", body, expected)


def document(api: TenantApi, supplier: Any, expires_in: int | None, **extra: Any) -> Any:
    today = factory_today()
    body = {
        "doc_type": "food_safety_certificate",
        "title": "FSSC 22000 certificate",
        "number": "FS-123",
        "issuer": "SGS",
        "issued_on": str(today - timedelta(days=400)),
        "expires_on": None if expires_in is None else str(today + timedelta(days=expires_in)),
        **extra,
    }
    return api.post(f"/suppliers/{supplier['id']}/documents", body)


def test_new_supplier_needs_a_signed_approval_before_receiving(admin: TenantApi) -> None:
    qm = admin.as_role("quality_manager")
    supplier = qm.supplier("MILLS", approved=False)
    flour = qm.item("FLOUR")
    assert supplier["approval_status"] == "pending"
    refused = qm.receive(flour, supplier, expected=422)
    assert "is not approved (status: pending)" in refused["detail"]

    wrong = decide(qm, supplier, "approved", 403, password="wrong-password")
    assert "password" in wrong["detail"]
    assert qm.get(f"/suppliers/{supplier['id']}")["supplier"]["approval_status"] == "pending"

    decision = decide(qm, supplier, "approved")
    assert decision["serial"].startswith("SAP-")
    assert decision["from_status"] == "pending"
    assert decision["next_review_date"] == str(add_months(factory_today(), 12))
    [signature] = decision["signatures"]
    assert signature["meaning"] == "approved"
    assert signature["intact"] is True

    detail = qm.get(f"/suppliers/{supplier['id']}")
    assert detail["supplier"]["approval_status"] == "approved"
    assert detail["supplier"]["is_approved"] is True
    assert detail["can_receive"] is True
    assert [a["to_status"] for a in detail["approvals"]] == ["approved"]
    qm.receive(flour, supplier)

    decide(qm, supplier, "suspended", reason="Two foreign-body complaints in one month")
    assert "suspended" in qm.receive(flour, supplier, expected=422)["detail"]
    admin.as_role("operator").post(
        f"/suppliers/{supplier['id']}/decisions",
        {"to_status": "approved", "reason": BASIS, "password": PASSWORD},
        403,
    )


def test_conditional_approval_needs_conditions_and_high_risk_reviews_sooner(qm: TenantApi) -> None:
    supplier = qm.supplier("SPICES", approved=False)
    decide(qm, supplier, "conditional", 422)
    decision = decide(
        qm,
        supplier,
        "conditional",
        conditions="Send the halal certificate within 30 days",
        risk_level="high",
    )
    assert decision["risk_level"] == "high"
    assert decision["next_review_date"] == str(add_months(factory_today(), 6))
    assert qm.get(f"/suppliers/{supplier['id']}")["can_receive"] is True
    decide(qm, supplier, "pending", 422)
    yesterday = str(factory_today() - timedelta(days=1))
    decide(qm, supplier, "approved", 422, next_review_date=yesterday)


def test_expired_required_document_blocks_receipt_and_approval(qm: TenantApi) -> None:
    supplier = qm.supplier("OILS")
    flour = qm.item("OIL")
    old = document(qm, supplier, -3)
    assert old["state"] == "expired"
    assert old["days_left"] == -3

    refused = qm.receive(flour, supplier, expected=422)
    assert "expired required document: FSSC 22000 certificate" in refused["detail"]
    assert "required document" in decide(qm, supplier, "approved", 422)["detail"]
    [row] = qm.get("/suppliers/overview")
    assert row["can_receive"] is False
    assert row["stats"]["required_expired"] == 1

    renewed = document(qm, supplier, 365)
    assert renewed["state"] == "valid"
    qm.post(f"/supplier-documents/{old['id']}/withdraw", {"reason": "Renewed"}, 200)
    qm.post(f"/supplier-documents/{old['id']}/withdraw", {"reason": "Again"}, 409)
    qm.receive(flour, supplier)

    optional = document(qm, supplier, -1, is_required=False, title="Old price list")
    assert optional["state"] == "expired"
    qm.receive(flour, supplier, supplier_lot_code="S-LOT-2")  # optional documents do not block
    assert document(qm, supplier, 10)["state"] == "expiring"


def test_document_file_is_stored_with_its_fingerprint(qm: TenantApi, db: Session) -> None:
    supplier = qm.supplier()
    content = b"%PDF-1.4 certificate scan"
    added = document(
        qm,
        supplier,
        200,
        file_name="certificate.pdf",
        content_type="application/pdf",
        file_base64=base64.b64encode(content).decode(),
    )
    assert added["file_sha256"] == hashlib.sha256(content).hexdigest()
    assert added["file_size"] == len(content)
    response = qm.client.get(f"/api/v1/supplier-documents/{added['id']}/file", headers=qm.headers)
    assert response.status_code == 200
    assert response.content == content
    assert response.headers["content-type"] == "application/pdf"

    bad = {"doc_type": "other", "title": "Bad", "file_name": "x.exe"}
    qm.post(f"/suppliers/{supplier['id']}/documents", {**bad, "content_type": "x/y"}, 422)
    qm.post(
        f"/suppliers/{supplier['id']}/documents",
        {**bad, "content_type": "application/pdf", "file_base64": "not base64!"},
        422,
    )

    _bind(db)
    with pytest.raises(DBAPIError, match="immutable"):
        db.execute(text("UPDATE supplier_documents SET title = 'Forged'"))
    db.rollback()
    _bind(db)
    with pytest.raises(DBAPIError, match="not allowed"):
        db.execute(text("DELETE FROM supplier_documents"))


def test_decisions_and_evaluations_are_append_only(qm: TenantApi, db: Session) -> None:
    supplier = qm.supplier(approved=False)
    decide(qm, supplier, "approved")
    _bind(db)
    with pytest.raises(DBAPIError, match="not allowed"):
        db.execute(text("UPDATE supplier_approvals SET reason = 'edited'"))


def test_evaluation_scores_and_recommendation(qm: TenantApi) -> None:
    supplier = qm.supplier()
    flour = qm.item("FLOUR")
    lot = qm.receive(flour, supplier)
    qm.receive(flour, supplier, supplier_lot_code="S-LOT-2")
    qm.post(f"/lots/{lot['id']}/status", {"status": "blocked", "reason": "Insects found"}, 200)
    today = factory_today()
    body = {
        "period_from": str(today - timedelta(days=90)),
        "period_to": str(today),
        "quality_score": 70,
        "delivery_score": 90,
        "documentation_score": 80,
        "service_score": 60,
        "comments": "One blocked lot",
        "password": PASSWORD,
    }
    evaluation = qm.post(f"/suppliers/{supplier['id']}/evaluations", body)
    # 70*0.40 + 90*0.25 + 80*0.20 + 60*0.15 = 75.5
    assert evaluation["total_score"] == "75.5"
    assert evaluation["recommendation"] == "conditional"
    assert evaluation["lots_received"] == 2
    assert evaluation["lots_blocked"] == 1
    assert evaluation["serial"].startswith("SEV-")
    assert evaluation["signatures"][0]["meaning"] == "performed"

    [row] = qm.get("/suppliers/overview")
    assert row["stats"]["last_score"] == "75.5"
    assert row["stats"]["lots_blocked"] == 1

    future = {**body, "period_to": str(today + timedelta(days=1))}
    qm.post(f"/suppliers/{supplier['id']}/evaluations", future, 422)
    low = {**body, "quality_score": 30, "delivery_score": 40}
    assert qm.post(f"/suppliers/{supplier['id']}/evaluations", low)["recommendation"] == (
        "suspended"
    )


def test_supplier_details_change_with_audit(qm: TenantApi) -> None:
    supplier = qm.post(
        "/suppliers",
        {"code": "SUGAR", "name": "Sugar Co", "category": "Sugar", "contact_email": "QA@S.com"},
    )
    assert supplier["approval_status"] == "pending"
    changed = qm.patch(f"/suppliers/{supplier['id']}", {"contact_phone": "+966 50 111 2222"})
    assert changed["contact_phone"] == "+966 50 111 2222"
    qm.patch(f"/suppliers/{supplier['id']}", {"contact_phone": "+966 50 111 2222"}, 422)
    qm.patch(f"/suppliers/{supplier['id']}", {"name": None}, 422)
    assert any(e["action"] == "supplier.updated" for e in qm.get("/audit/events"))


def test_expiry_scan_warns_once_then_when_expired(qm: TenantApi, db: Session) -> None:
    supplier = qm.supplier()
    soon = document(qm, supplier, 5)
    document(qm, supplier, 300)
    assert scan_all_tenants(get_session_factory()) == 1
    assert scan_all_tenants(get_session_factory()) == 0
    [alert] = qm.get("/alerts")
    assert alert["kind"] == "supplier_document_expiring"
    assert alert["record_id"] == soon["id"]
    assert "expires on" in alert["message"]

    _bind(db)
    db.execute(
        text("ALTER TABLE supplier_documents DISABLE TRIGGER supplier_documents_guard_update")
    )
    db.execute(
        text("UPDATE supplier_documents SET expires_on = :d WHERE id = :id"),
        {"d": factory_today() - timedelta(days=1), "id": soon["id"]},
    )
    db.execute(
        text("ALTER TABLE supplier_documents ENABLE TRIGGER supplier_documents_guard_update")
    )
    db.execute(text("UPDATE suppliers SET next_review_date = :d"), {"d": factory_today()})
    db.commit()
    assert scan_all_tenants(get_session_factory()) == 1  # expired; review not overdue yet
    _bind(db)
    db.execute(
        text("UPDATE suppliers SET next_review_date = :d"),
        {"d": factory_today() - timedelta(days=1)},
    )
    db.commit()
    assert scan_all_tenants(get_session_factory()) == 1
    kinds = sorted(a["kind"] for a in qm.get("/alerts"))
    assert kinds == [
        "supplier_document_expired",
        "supplier_document_expiring",
        "supplier_review_due",
    ]
    decide(qm, supplier, "conditional", conditions="Renew the certificate")
    assert scan_all_tenants(get_session_factory()) == 0
