import email
import socket
from typing import Any

import httpx
import pytest
from aiosmtpd.controller import Controller

from compliance_engine.core.config import Settings
from compliance_engine.models.enums import NotificationChannel
from compliance_engine.notifications.senders import (
    DeliveryError,
    EmailSender,
    Message,
    WhatsAppSender,
    whatsapp_number,
)
from tests.conftest import FakeSender, TenantApi
from tests.test_records import cooking_ccp, reading, sanitation

Outbox = dict[NotificationChannel, FakeSender]


def recipient(api: TenantApi, channel: str, address: str, expected: int = 201, **extra: Any) -> Any:
    body = {"name": "QA team", "channel": channel, "address": address, **extra}
    return api.post("/notification-recipients", body, expected)


def deviation(qm: TenantApi) -> Any:
    return reading(qm, cooking_ccp(qm), "65", corrective_action="Line stopped")


def test_alert_is_sent_to_matching_recipients(qm: TenantApi, outbox: Outbox) -> None:
    recipient(qm, "email", "QA@Factory.com")
    recipient(qm, "whatsapp", "+966 50 123 4567", min_severity="critical")
    deviation(qm)

    queued = qm.get("/notification-deliveries")
    assert {(d["channel"], d["address"], d["status"]) for d in queued} == {
        ("email", "qa@factory.com", "pending"),
        ("whatsapp", "+966501234567", "pending"),
    }
    assert qm.post("/notifications/dispatch", {}, 200) == {"sent": 2, "retrying": 0, "failed": 0}

    [(address, message)] = outbox[NotificationChannel.EMAIL].sent
    assert address == "qa@factory.com"
    assert message.subject.startswith("[حرج] انحراف في نقطة تحكم حرجة")
    assert "CCP-1 (Cooking): 65" in message.text
    assert "\n" not in outbox[NotificationChannel.WHATSAPP].sent[0][1].short
    assert {d["status"] for d in qm.get("/notification-deliveries")} == {"sent"}
    # Nothing is sent twice.
    assert qm.post("/notifications/dispatch", {}, 200)["sent"] == 0


def test_critical_only_recipient_skips_major_alerts(qm: TenantApi) -> None:
    recipient(qm, "email", "boss@factory.com", min_severity="critical")
    recipient(qm, "email", "line@factory.com")
    sanitation(qm, result="fail", corrective_action="Re-cleaned")  # a major alert
    assert [d["address"] for d in qm.get("/notification-deliveries")] == ["line@factory.com"]


def test_inactive_recipient_gets_nothing(qm: TenantApi) -> None:
    r = recipient(qm, "email", "old@factory.com")
    qm.patch(f"/notification-recipients/{r['id']}", {"is_active": False})
    deviation(qm)
    assert qm.get("/notification-deliveries") == []


def test_failed_send_is_retried_then_given_up(qm: TenantApi, outbox: Outbox, db: Any) -> None:
    from sqlalchemy import text

    from tests.test_records import _bind

    recipient(qm, "email", "qa@factory.com")
    deviation(qm)
    outbox[NotificationChannel.EMAIL].error = "E-mail failed: connection refused"

    for attempt in range(1, 6):
        _bind(db)
        db.execute(text("UPDATE notification_deliveries SET next_attempt_at = now()"))
        db.commit()
        result = qm.post("/notifications/dispatch", {}, 200)
        assert result == (
            {"sent": 0, "retrying": 0, "failed": 1}
            if attempt == 5
            else {"sent": 0, "retrying": 1, "failed": 0}
        )
    [delivery] = qm.get("/notification-deliveries")
    assert (delivery["status"], delivery["attempts"]) == ("failed", 5)
    assert delivery["last_error"] == "E-mail failed: connection refused"

    # After fixing the settings, failed deliveries can be queued again.
    outbox[NotificationChannel.EMAIL].error = None
    assert qm.post("/notifications/retry-failed", {}, 200) == {"requeued": 1}
    assert qm.post("/notifications/dispatch", {}, 200)["sent"] == 1


def test_waits_before_retrying(qm: TenantApi, outbox: Outbox) -> None:
    recipient(qm, "email", "qa@factory.com")
    deviation(qm)
    outbox[NotificationChannel.EMAIL].error = "down"
    assert qm.post("/notifications/dispatch", {}, 200)["retrying"] == 1
    assert qm.post("/notifications/dispatch", {}, 200) == {"sent": 0, "retrying": 0, "failed": 0}


def test_test_message(qm: TenantApi, outbox: Outbox) -> None:
    r = recipient(qm, "whatsapp", "+201001234567")
    assert qm.post(f"/notification-recipients/{r['id']}/test", {}, 200) == {
        "sent": True,
        "error": None,
    }
    outbox[NotificationChannel.WHATSAPP].error = "WhatsApp failed (401): bad token"
    result = qm.post(f"/notification-recipients/{r['id']}/test", {}, 200)
    assert result == {"sent": False, "error": "WhatsApp failed (401): bad token"}


def test_recipient_validation_and_permissions(admin: TenantApi) -> None:
    qm = admin.as_role("quality_manager")
    supervisor = admin.as_role("supervisor")
    recipient(qm, "email", "not-an-email", 422)
    recipient(qm, "whatsapp", "0501234567x", 422)
    recipient(qm, "whatsapp", "123", 422)
    recipient(qm, "sms", "+966501234567", 422)
    recipient(supervisor, "email", "a@b.com", 403)
    supervisor.get("/notification-recipients", expected=403)
    r = recipient(qm, "email", "a@b.com")
    recipient(qm, "email", "A@b.com", 409)  # same address twice
    qm.patch(f"/notification-recipients/{r['id']}", {"address": "bad"}, 422)
    assert qm.patch(f"/notification-recipients/{r['id']}", {"address": "C@b.com"})["address"] == (
        "c@b.com"
    )
    assert qm.get("/notifications/channels") == {"email": False, "whatsapp": False}
    assert "notification_recipient.updated" in [e["action"] for e in qm.get("/audit/events")]


def test_recipients_are_per_tenant(client: Any, admin: TenantApi) -> None:
    from tests.conftest import make_tenant

    other = make_tenant(client, "other")
    recipient(other, "email", "other@other.com")
    recipient(admin, "email", "qa@awrad.com")
    assert [r["address"] for r in admin.get("/notification-recipients")] == ["qa@awrad.com"]
    deviation(admin)
    assert [d["address"] for d in admin.get("/notification-deliveries")] == ["qa@awrad.com"]


# ----- the WhatsApp request itself --------------------------------------------------------


def _settings(**extra: Any) -> Settings:
    return Settings(
        jwt_secret="x" * 32,
        whatsapp_token="secret-token",
        whatsapp_phone_number_id="12345",
        **extra,
    )


def _capture(status: int = 200, body: Any = None) -> tuple[list[httpx.Request], Any]:
    seen: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        seen.append(request)
        return httpx.Response(status, json=body or {"messages": [{"id": "wamid.1"}]})

    return seen, httpx.MockTransport(handler)


MESSAGE = Message(subject="s", text="t", short="CCP-1:\n 65 °C   low")


def test_whatsapp_template_request() -> None:
    seen, transport = _capture()
    sender = WhatsAppSender(_settings(whatsapp_template="ccp_alert"), transport)
    sender.send("+966 50 123 4567", MESSAGE)
    [request] = seen
    assert str(request.url) == "https://graph.facebook.com/v21.0/12345/messages"
    assert request.headers["authorization"] == "Bearer secret-token"
    body = request.read().decode()
    assert '"to":"966501234567"' in body.replace(" ", "")
    assert '"name":"ccp_alert"' in body.replace(" ", "")
    assert '"code":"ar"' in body.replace(" ", "")
    assert "CCP-1: 65 °C low" in body


def test_whatsapp_text_request_and_errors() -> None:
    seen, transport = _capture()
    WhatsAppSender(_settings(), transport).send("+201001234567", MESSAGE)
    assert '"type":"text"' in seen[0].read().decode().replace(" ", "")

    _, failing = _capture(401, {"error": {"message": "Invalid OAuth access token"}})
    with pytest.raises(DeliveryError, match=r"\(401\): Invalid OAuth access token"):
        WhatsAppSender(_settings(), failing).send("+201001234567", MESSAGE)


def test_whatsapp_number() -> None:
    assert whatsapp_number("+20 100-123-4567") == "201001234567"


# ----- a real SMTP conversation -----------------------------------------------------------


class _Inbox:
    def __init__(self) -> None:
        self.messages: list[email.message.Message] = []

    async def handle_DATA(self, server: Any, session: Any, envelope: Any) -> str:  # noqa: N802
        self.messages.append(email.message_from_bytes(envelope.content))
        return "250 OK"


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return int(s.getsockname()[1])


def test_email_is_sent_over_smtp() -> None:
    inbox = _Inbox()
    port = _free_port()
    controller = Controller(inbox, hostname="127.0.0.1", port=port)
    controller.start()
    try:
        settings = Settings(
            jwt_secret="x" * 32,
            smtp_host="127.0.0.1",
            smtp_port=port,
            smtp_security="none",
            smtp_from="qa-alerts@factory.com",
        )
        EmailSender(settings).send(
            "qa@factory.com", Message(subject="[حرج] انحراف", text="CCP-1: 65 °C\n", short="x")
        )
    finally:
        controller.stop()
    [received] = inbox.messages
    assert received["To"] == "qa@factory.com"
    assert received["From"] == "qa-alerts@factory.com"
    subject = str(email.header.make_header(email.header.decode_header(received["Subject"])))
    assert subject == "[حرج] انحراف"
    assert "CCP-1: 65 °C" in received.get_payload(decode=True).decode()


def test_email_connection_error_is_reported() -> None:
    settings = Settings(
        jwt_secret="x" * 32, smtp_host="127.0.0.1", smtp_port=_free_port(), smtp_security="none"
    )
    with pytest.raises(DeliveryError, match="E-mail failed: ConnectionRefusedError"):
        EmailSender(settings).send("qa@factory.com", MESSAGE)
