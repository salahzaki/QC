"""Supplier approval (decisions, documents, evaluations), training records, settings the
factory manages from the app (mail and WhatsApp channels, competence gate), and the
"cleaning after use" sanitation activity.

Existing suppliers keep their state: approved ones become "approved", the rest "pending".

Revision ID: 0007
Revises: 0006
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision: str = "0007"
down_revision: str | None = "0006"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

SUPPLIER_STATUS = ("pending", "approved", "conditional", "suspended", "rejected")
RISK = ("low", "medium", "high")
DOCUMENT_TYPES = (
    "food_safety_certificate",
    "halal_certificate",
    "commercial_registration",
    "health_license",
    "specification",
    "audit_report",
    "questionnaire",
    "other",
)
OLD_ALERT_KINDS = ("ccp_deviation", "sanitation_failure", "missed_check")
NEW_ALERT_KINDS = (
    *OLD_ALERT_KINDS,
    "supplier_document_expiring",
    "supplier_document_expired",
    "supplier_review_due",
    "training_expiring",
    "training_expired",
)
NEW_TENANT_TABLES = (
    "supplier_approvals",
    "supplier_documents",
    "supplier_evaluations",
    "training_courses",
    "training_records",
    "tenant_settings",
)
APPEND_ONLY = ("supplier_approvals", "supplier_evaluations", "training_records")


def _text_enum(name: str, *values: str) -> sa.Enum:
    return sa.Enum(*values, name=name, native_enum=False, create_constraint=True, length=32)


def _common_columns() -> list[sa.Column[object]]:
    return [
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("tenant_id", sa.Uuid(), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
    ]


def _tenant_fk(table: str) -> sa.ForeignKeyConstraint:
    return sa.ForeignKeyConstraint(
        ["tenant_id"], ["tenants.id"], name=op.f(f"fk_{table}_tenant_id_tenants")
    )


def _user_fk(table: str, column: str) -> sa.ForeignKeyConstraint:
    return sa.ForeignKeyConstraint([column], ["users.id"], name=op.f(f"fk_{table}_{column}_users"))


def _supplier_fk(table: str) -> sa.ForeignKeyConstraint:
    return sa.ForeignKeyConstraint(
        ["supplier_id"], ["suppliers.id"], name=op.f(f"fk_{table}_supplier_id_suppliers")
    )


def _alert_kinds(values: Sequence[str]) -> None:
    op.drop_constraint(op.f("ck_alerts_alertkind"), "alerts", "check")
    allowed = ", ".join(f"'{v}'" for v in values)
    op.create_check_constraint(op.f("ck_alerts_alertkind"), "alerts", f"kind IN ({allowed})")


OLD_ACTIVITIES = ("pre_op_inspection", "cleaning", "sanitizing", "deep_clean")


def _activities(values: Sequence[str]) -> None:
    op.drop_constraint(
        op.f("ck_sanitation_records_sanitationactivity"), "sanitation_records", "check"
    )
    allowed = ", ".join(f"'{v}'" for v in values)
    op.create_check_constraint(
        op.f("ck_sanitation_records_sanitationactivity"),
        "sanitation_records",
        f"activity IN ({allowed})",
    )


def upgrade() -> None:
    # ----- suppliers and users ---------------------------------------------------------
    op.add_column(
        "suppliers",
        sa.Column(
            "approval_status",
            _text_enum("supplierstatus", *SUPPLIER_STATUS),
            server_default="pending",
            nullable=False,
        ),
    )
    # Row-level security would hide every row from this tenant-less session.
    op.execute("ALTER TABLE suppliers NO FORCE ROW LEVEL SECURITY")
    op.execute("UPDATE suppliers SET approval_status = 'approved' WHERE is_approved")
    op.execute("ALTER TABLE suppliers FORCE ROW LEVEL SECURITY")
    op.add_column(
        "suppliers",
        sa.Column(
            "risk_level", _text_enum("risklevel", *RISK), server_default="medium", nullable=False
        ),
    )
    for name, column_type in (
        ("category", sa.String(length=200)),
        ("contact_name", sa.String(length=200)),
        ("contact_phone", sa.String(length=32)),
        ("contact_email", sa.String(length=254)),
        ("next_review_date", sa.Date()),
        ("notes", sa.Text()),
    ):
        op.add_column("suppliers", sa.Column(name, column_type, nullable=True))
    op.add_column("users", sa.Column("phone", sa.String(length=20), nullable=True))
    _alert_kinds(NEW_ALERT_KINDS)
    _activities((*OLD_ACTIVITIES, "after_use"))  # cleaning after use

    # ----- supplier approval -----------------------------------------------------------
    op.create_table(
        "supplier_approvals",
        sa.Column("serial", sa.String(length=32), nullable=True),
        sa.Column("supplier_id", sa.Uuid(), nullable=False),
        sa.Column("from_status", _text_enum("from_status", *SUPPLIER_STATUS), nullable=False),
        sa.Column("to_status", _text_enum("to_status", *SUPPLIER_STATUS), nullable=False),
        sa.Column("risk_level", _text_enum("risklevel", *RISK), nullable=False),
        sa.Column("reason", sa.Text(), nullable=False),
        sa.Column("conditions", sa.Text(), nullable=True),
        sa.Column("next_review_date", sa.Date(), nullable=True),
        sa.Column("decided_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("decided_by", sa.Uuid(), nullable=False),
        *_common_columns(),
        _supplier_fk("supplier_approvals"),
        _user_fk("supplier_approvals", "decided_by"),
        _tenant_fk("supplier_approvals"),
        sa.PrimaryKeyConstraint("id", name=op.f("pk_supplier_approvals")),
        sa.UniqueConstraint(
            "tenant_id", "serial", name=op.f("uq_supplier_approvals_tenant_id_serial")
        ),
    )
    op.create_table(
        "supplier_documents",
        sa.Column("supplier_id", sa.Uuid(), nullable=False),
        sa.Column("doc_type", _text_enum("supplierdocumenttype", *DOCUMENT_TYPES), nullable=False),
        sa.Column("title", sa.String(length=200), nullable=False),
        sa.Column("number", sa.String(length=100), nullable=True),
        sa.Column("issuer", sa.String(length=200), nullable=True),
        sa.Column("issued_on", sa.Date(), nullable=True),
        sa.Column("expires_on", sa.Date(), nullable=True),
        sa.Column("is_required", sa.Boolean(), nullable=False),
        sa.Column("file_name", sa.String(length=200), nullable=True),
        sa.Column("content_type", sa.String(length=100), nullable=True),
        sa.Column("file_size", sa.Integer(), nullable=True),
        sa.Column("file_sha256", sa.String(length=64), nullable=True),
        sa.Column("file_data", sa.LargeBinary(), nullable=True),
        sa.Column("uploaded_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("uploaded_by", sa.Uuid(), nullable=False),
        sa.Column("withdrawn_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("withdrawn_by", sa.Uuid(), nullable=True),
        sa.Column("withdrawn_reason", sa.String(length=500), nullable=True),
        *_common_columns(),
        _supplier_fk("supplier_documents"),
        _user_fk("supplier_documents", "uploaded_by"),
        _user_fk("supplier_documents", "withdrawn_by"),
        _tenant_fk("supplier_documents"),
        sa.PrimaryKeyConstraint("id", name=op.f("pk_supplier_documents")),
    )
    op.create_index(op.f("ix_supplier_documents_expires_on"), "supplier_documents", ["expires_on"])
    op.create_table(
        "supplier_evaluations",
        sa.Column("serial", sa.String(length=32), nullable=True),
        sa.Column("supplier_id", sa.Uuid(), nullable=False),
        sa.Column("period_from", sa.Date(), nullable=False),
        sa.Column("period_to", sa.Date(), nullable=False),
        sa.Column("quality_score", sa.Integer(), nullable=False),
        sa.Column("delivery_score", sa.Integer(), nullable=False),
        sa.Column("documentation_score", sa.Integer(), nullable=False),
        sa.Column("service_score", sa.Integer(), nullable=False),
        sa.Column("total_score", sa.Numeric(5, 1), nullable=False),
        sa.Column("recommendation", _text_enum("supplierstatus", *SUPPLIER_STATUS), nullable=False),
        sa.Column("lots_received", sa.Integer(), nullable=False),
        sa.Column("lots_blocked", sa.Integer(), nullable=False),
        sa.Column("comments", sa.Text(), nullable=True),
        sa.Column("evaluated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("evaluated_by", sa.Uuid(), nullable=False),
        *_common_columns(),
        sa.CheckConstraint(
            "period_from <= period_to", name=op.f("ck_supplier_evaluations_period_ordered")
        ),
        _supplier_fk("supplier_evaluations"),
        _user_fk("supplier_evaluations", "evaluated_by"),
        _tenant_fk("supplier_evaluations"),
        sa.PrimaryKeyConstraint("id", name=op.f("pk_supplier_evaluations")),
        sa.UniqueConstraint(
            "tenant_id", "serial", name=op.f("uq_supplier_evaluations_tenant_id_serial")
        ),
    )

    # ----- training --------------------------------------------------------------------
    op.create_table(
        "training_courses",
        sa.Column("code", sa.String(length=64), nullable=False),
        sa.Column("title", sa.String(length=200), nullable=False),
        sa.Column("category", sa.String(length=100), nullable=True),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("validity_months", sa.Integer(), nullable=True),
        sa.Column("required_roles", postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column("control_point_ids", postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column("is_active", sa.Boolean(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
        *_common_columns(),
        sa.CheckConstraint(
            "validity_months IS NULL OR validity_months > 0",
            name=op.f("ck_training_courses_positive_validity"),
        ),
        _tenant_fk("training_courses"),
        sa.PrimaryKeyConstraint("id", name=op.f("pk_training_courses")),
        sa.UniqueConstraint("tenant_id", "code", name=op.f("uq_training_courses_tenant_id_code")),
    )
    op.create_table(
        "training_records",
        sa.Column("serial", sa.String(length=32), nullable=True),
        sa.Column("user_id", sa.Uuid(), nullable=False),
        sa.Column("course_id", sa.Uuid(), nullable=False),
        sa.Column("trained_on", sa.Date(), nullable=False),
        sa.Column("expires_on", sa.Date(), nullable=True),
        sa.Column("trainer", sa.String(length=200), nullable=False),
        sa.Column(
            "method",
            _text_enum("trainingmethod", "classroom", "on_the_job", "online", "external"),
            nullable=False,
        ),
        sa.Column("duration_hours", sa.Numeric(5, 1), nullable=True),
        sa.Column(
            "result", _text_enum("trainingresult", "passed", "failed", "attended"), nullable=False
        ),
        sa.Column("score", sa.Numeric(5, 1), nullable=True),
        sa.Column("certificate_ref", sa.String(length=100), nullable=True),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("recorded_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("recorded_by", sa.Uuid(), nullable=False),
        *_common_columns(),
        sa.ForeignKeyConstraint(
            ["course_id"],
            ["training_courses.id"],
            name=op.f("fk_training_records_course_id_training_courses"),
        ),
        _user_fk("training_records", "user_id"),
        _user_fk("training_records", "recorded_by"),
        _tenant_fk("training_records"),
        sa.PrimaryKeyConstraint("id", name=op.f("pk_training_records")),
        sa.UniqueConstraint(
            "tenant_id", "serial", name=op.f("uq_training_records_tenant_id_serial")
        ),
    )

    # ----- settings managed from the app -----------------------------------------------
    op.create_table(
        "tenant_settings",
        sa.Column("tenant_id", sa.Uuid(), nullable=False),
        sa.Column("enforce_training", sa.Boolean(), nullable=False),
        sa.Column("expiry_warning_days", sa.Integer(), nullable=False),
        sa.Column("smtp_host", sa.String(length=200), nullable=True),
        sa.Column("smtp_port", sa.Integer(), nullable=True),
        sa.Column(
            "smtp_security", _text_enum("smtpsecurity", "starttls", "ssl", "none"), nullable=True
        ),
        sa.Column("smtp_username", sa.String(length=254), nullable=True),
        sa.Column("smtp_password_enc", sa.Text(), nullable=True),
        sa.Column("smtp_from", sa.String(length=254), nullable=True),
        sa.Column("whatsapp_phone_number_id", sa.String(length=64), nullable=True),
        sa.Column("whatsapp_token_enc", sa.Text(), nullable=True),
        sa.Column("whatsapp_template", sa.String(length=100), nullable=True),
        sa.Column("whatsapp_template_language", sa.String(length=16), nullable=True),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("updated_by", sa.Uuid(), nullable=True),
        _tenant_fk("tenant_settings"),
        _user_fk("tenant_settings", "updated_by"),
        sa.PrimaryKeyConstraint("tenant_id", name=op.f("pk_tenant_settings")),
    )

    for table in NEW_TENANT_TABLES:
        if table != "tenant_settings":
            op.create_index(op.f(f"ix_{table}_tenant_id"), table, ["tenant_id"])
    for table, column in (
        ("supplier_approvals", "supplier_id"),
        ("supplier_documents", "supplier_id"),
        ("supplier_evaluations", "supplier_id"),
        ("training_records", "user_id"),
        ("training_records", "course_id"),
    ):
        op.create_index(op.f(f"ix_{table}_{column}"), table, [column])

    for table in APPEND_ONLY:
        op.execute(
            f"CREATE TRIGGER {table}_append_only BEFORE UPDATE OR DELETE "
            f"ON {table} FOR EACH ROW EXECUTE FUNCTION reject_mutation()"
        )
    # A document can be withdrawn once; nothing else about it ever changes.
    op.execute(
        """
        CREATE FUNCTION guard_supplier_document_update() RETURNS trigger LANGUAGE plpgsql AS $$
        DECLARE
          withdraw_fields text[] := ARRAY['withdrawn_at', 'withdrawn_by', 'withdrawn_reason'];
        BEGIN
          IF OLD.withdrawn_at IS NOT NULL
             OR (to_jsonb(NEW) - withdraw_fields) <> (to_jsonb(OLD) - withdraw_fields) THEN
            RAISE EXCEPTION 'supplier_documents rows are immutable except for one withdrawal'
              USING ERRCODE = 'integrity_constraint_violation';
          END IF;
          RETURN NEW;
        END;
        $$
        """
    )
    op.execute(
        "CREATE TRIGGER supplier_documents_guard_update BEFORE UPDATE ON supplier_documents "
        "FOR EACH ROW EXECUTE FUNCTION guard_supplier_document_update()"
    )
    op.execute(
        "CREATE TRIGGER supplier_documents_no_delete BEFORE DELETE ON supplier_documents "
        "FOR EACH ROW EXECUTE FUNCTION reject_mutation()"
    )

    for table in NEW_TENANT_TABLES:
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
        op.execute(
            f"""
            CREATE POLICY tenant_isolation ON {table}
              USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
              WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
            """
        )


def downgrade() -> None:
    op.drop_table("tenant_settings")
    op.drop_table("training_records")
    op.drop_table("training_courses")
    op.drop_table("supplier_evaluations")
    op.drop_table("supplier_documents")
    op.execute("DROP FUNCTION guard_supplier_document_update()")
    op.drop_table("supplier_approvals")
    # Alerts of the new kinds go with the features (owner-only, outside tenant isolation).
    old_kinds = ", ".join(f"'{k}'" for k in OLD_ALERT_KINDS)
    for table in ("alerts", "notification_deliveries"):
        op.execute(f"ALTER TABLE {table} NO FORCE ROW LEVEL SECURITY")
    op.execute("ALTER TABLE alerts DISABLE TRIGGER alerts_no_delete")
    op.execute(
        "DELETE FROM notification_deliveries WHERE alert_id IN "
        f"(SELECT id FROM alerts WHERE kind NOT IN ({old_kinds}))"
    )
    op.execute(f"DELETE FROM alerts WHERE kind NOT IN ({old_kinds})")
    op.execute("ALTER TABLE alerts ENABLE TRIGGER alerts_no_delete")
    for table in ("alerts", "notification_deliveries"):
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
    _alert_kinds(OLD_ALERT_KINDS)
    # Older versions do not know "cleaning after use": such records become "cleaning".
    op.execute("ALTER TABLE sanitation_records NO FORCE ROW LEVEL SECURITY")
    op.execute("ALTER TABLE sanitation_records DISABLE TRIGGER sanitation_records_append_only")
    op.execute("UPDATE sanitation_records SET activity = 'cleaning' WHERE activity = 'after_use'")
    op.execute("ALTER TABLE sanitation_records ENABLE TRIGGER sanitation_records_append_only")
    op.execute("ALTER TABLE sanitation_records FORCE ROW LEVEL SECURITY")
    _activities(OLD_ACTIVITIES)
    op.drop_column("users", "phone")
    for name in (
        "notes",
        "next_review_date",
        "contact_email",
        "contact_phone",
        "contact_name",
        "category",
        "risk_level",
        "approval_status",
    ):
        op.drop_column("suppliers", name)
