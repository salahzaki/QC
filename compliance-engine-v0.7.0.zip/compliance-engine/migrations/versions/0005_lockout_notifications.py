"""Account lockout after wrong passwords, and alert notifications by e-mail and WhatsApp.

Revision ID: 0005
Revises: 0004
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "0005"
down_revision: str | None = "0004"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

NEW_TENANT_TABLES = ("notification_recipients", "notification_deliveries")


def _text_enum(name: str, *values: str) -> sa.Enum:
    return sa.Enum(*values, name=name, native_enum=False, create_constraint=True, length=32)


def _common_columns() -> list[sa.Column[object]]:
    return [
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("tenant_id", sa.Uuid(), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
    ]


def upgrade() -> None:
    op.add_column(
        "users",
        sa.Column("failed_password_attempts", sa.Integer(), server_default="0", nullable=False),
    )
    op.add_column("users", sa.Column("locked_at", sa.DateTime(timezone=True), nullable=True))

    op.create_table(
        "notification_recipients",
        sa.Column("name", sa.String(length=200), nullable=False),
        sa.Column(
            "channel", _text_enum("notificationchannel", "email", "whatsapp"), nullable=False
        ),
        sa.Column("address", sa.String(length=254), nullable=False),
        sa.Column("min_severity", _text_enum("alertseverity", "critical", "major"), nullable=False),
        sa.Column("is_active", sa.Boolean(), nullable=False),
        *_common_columns(),
        sa.ForeignKeyConstraint(
            ["tenant_id"],
            ["tenants.id"],
            name=op.f("fk_notification_recipients_tenant_id_tenants"),
        ),
        sa.PrimaryKeyConstraint("id", name=op.f("pk_notification_recipients")),
        sa.UniqueConstraint(
            "tenant_id",
            "channel",
            "address",
            name=op.f("uq_notification_recipients_tenant_id_channel_address"),
        ),
    )
    op.create_index(
        op.f("ix_notification_recipients_tenant_id"),
        "notification_recipients",
        ["tenant_id"],
        unique=False,
    )

    op.create_table(
        "notification_deliveries",
        sa.Column("alert_id", sa.Uuid(), nullable=False),
        sa.Column("recipient_id", sa.Uuid(), nullable=False),
        sa.Column(
            "channel", _text_enum("notificationchannel", "email", "whatsapp"), nullable=False
        ),
        sa.Column("address", sa.String(length=254), nullable=False),
        sa.Column(
            "status", _text_enum("deliverystatus", "pending", "sent", "failed"), nullable=False
        ),
        sa.Column("attempts", sa.Integer(), nullable=False),
        sa.Column("next_attempt_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("sent_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_error", sa.String(length=500), nullable=True),
        *_common_columns(),
        sa.ForeignKeyConstraint(
            ["alert_id"], ["alerts.id"], name=op.f("fk_notification_deliveries_alert_id_alerts")
        ),
        sa.ForeignKeyConstraint(
            ["recipient_id"],
            ["notification_recipients.id"],
            name=op.f("fk_notification_deliveries_recipient_id_notification_recipients"),
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id"],
            ["tenants.id"],
            name=op.f("fk_notification_deliveries_tenant_id_tenants"),
        ),
        sa.PrimaryKeyConstraint("id", name=op.f("pk_notification_deliveries")),
    )
    for column in ("alert_id", "status", "tenant_id"):
        op.create_index(
            op.f(f"ix_notification_deliveries_{column}"),
            "notification_deliveries",
            [column],
            unique=False,
        )

    for table in NEW_TENANT_TABLES:
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
        op.execute(
            f"""
            CREATE POLICY tenant_isolation ON {table}
              USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
              WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
            """
        )


def downgrade() -> None:
    op.drop_table("notification_deliveries")
    op.drop_table("notification_recipients")
    op.drop_column("users", "locked_at")
    op.drop_column("users", "failed_password_attempts")
