"""Corrective actions, record amendments, alerts and missed-check intervals.

Revision ID: 0004
Revises: 0003
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision: str = "0004"
down_revision: str | None = "0003"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

NEW_TENANT_TABLES = ("record_amendments", "corrective_actions", "alerts")
MEANINGS_BEFORE = ("performed", "verified")
MEANINGS_AFTER = ("performed", "verified", "approved")


def _text_enum(name: str, *values: str) -> sa.Enum:
    return sa.Enum(*values, name=name, native_enum=False, create_constraint=True, length=32)


def _common_columns() -> list[sa.Column[object]]:
    return [
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("tenant_id", sa.Uuid(), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
    ]


def _meaning_check(values: Sequence[str]) -> None:
    op.drop_constraint(op.f("ck_record_signatures_signaturemeaning"), "record_signatures", "check")
    allowed = ", ".join(f"'{v}'" for v in values)
    op.create_check_constraint(
        op.f("ck_record_signatures_signaturemeaning"),
        "record_signatures",
        f"meaning IN ({allowed})",
    )


def upgrade() -> None:
    op.add_column("control_points", sa.Column("check_interval_minutes", sa.Integer()))
    op.create_check_constraint(
        op.f("ck_control_points_positive_interval"),
        "control_points",
        "check_interval_minutes IS NULL OR check_interval_minutes > 0",
    )
    _meaning_check(MEANINGS_AFTER)

    op.create_table(
        "record_amendments",
        sa.Column("record_type", sa.String(length=32), nullable=False),
        sa.Column("record_id", sa.Uuid(), nullable=False),
        sa.Column("changes", postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column("reason", sa.Text(), nullable=False),
        sa.Column("amended_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("amended_by", sa.Uuid(), nullable=False),
        *_common_columns(),
        sa.ForeignKeyConstraint(
            ["amended_by"], ["users.id"], name=op.f("fk_record_amendments_amended_by_users")
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id"], ["tenants.id"], name=op.f("fk_record_amendments_tenant_id_tenants")
        ),
        sa.PrimaryKeyConstraint("id", name=op.f("pk_record_amendments")),
    )
    op.create_index(
        op.f("ix_record_amendments_record_id"), "record_amendments", ["record_id"], unique=False
    )
    op.create_index(
        op.f("ix_record_amendments_tenant_id"), "record_amendments", ["tenant_id"], unique=False
    )

    op.create_table(
        "corrective_actions",
        sa.Column("record_type", sa.String(length=32), nullable=False),
        sa.Column("record_id", sa.Uuid(), nullable=False),
        sa.Column("control_point_id", sa.Uuid(), nullable=True),
        sa.Column("lot_id", sa.Uuid(), nullable=True),
        sa.Column("description", sa.Text(), nullable=False),
        sa.Column("immediate_action", sa.Text(), nullable=False),
        sa.Column("opened_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("opened_by", sa.Uuid(), nullable=False),
        sa.Column("status", _text_enum("correctiveactionstatus", "open", "closed"), nullable=False),
        sa.Column("root_cause", sa.Text(), nullable=True),
        sa.Column("preventive_action", sa.Text(), nullable=True),
        sa.Column(
            "product_disposition",
            _text_enum(
                "productdisposition",
                "not_applicable",
                "released_after_evaluation",
                "reworked",
                "diverted",
                "destroyed",
            ),
            nullable=True,
        ),
        sa.Column("closed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("closed_by", sa.Uuid(), nullable=True),
        *_common_columns(),
        sa.CheckConstraint(
            "status = 'open' OR (root_cause IS NOT NULL AND preventive_action IS NOT NULL "
            "AND product_disposition IS NOT NULL AND closed_at IS NOT NULL "
            "AND closed_by IS NOT NULL)",
            name=op.f("ck_corrective_actions_closed_is_complete"),
        ),
        sa.ForeignKeyConstraint(
            ["closed_by"], ["users.id"], name=op.f("fk_corrective_actions_closed_by_users")
        ),
        sa.ForeignKeyConstraint(
            ["control_point_id"],
            ["control_points.id"],
            name=op.f("fk_corrective_actions_control_point_id_control_points"),
        ),
        sa.ForeignKeyConstraint(
            ["lot_id"], ["lots.id"], name=op.f("fk_corrective_actions_lot_id_lots")
        ),
        sa.ForeignKeyConstraint(
            ["opened_by"], ["users.id"], name=op.f("fk_corrective_actions_opened_by_users")
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id"], ["tenants.id"], name=op.f("fk_corrective_actions_tenant_id_tenants")
        ),
        sa.PrimaryKeyConstraint("id", name=op.f("pk_corrective_actions")),
        sa.UniqueConstraint(
            "tenant_id",
            "record_type",
            "record_id",
            name=op.f("uq_corrective_actions_tenant_id_record_type_record_id"),
        ),
    )
    op.create_index(
        op.f("ix_corrective_actions_opened_at"), "corrective_actions", ["opened_at"], unique=False
    )
    op.create_index(
        op.f("ix_corrective_actions_record_id"), "corrective_actions", ["record_id"], unique=False
    )
    op.create_index(
        op.f("ix_corrective_actions_tenant_id"), "corrective_actions", ["tenant_id"], unique=False
    )

    op.create_table(
        "alerts",
        sa.Column(
            "kind",
            _text_enum("alertkind", "ccp_deviation", "sanitation_failure", "missed_check"),
            nullable=False,
        ),
        sa.Column("severity", _text_enum("alertseverity", "critical", "major"), nullable=False),
        sa.Column("message", sa.String(length=500), nullable=False),
        sa.Column("record_type", sa.String(length=32), nullable=True),
        sa.Column("record_id", sa.Uuid(), nullable=True),
        sa.Column("control_point_id", sa.Uuid(), nullable=True),
        sa.Column("raised_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("acknowledged_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("acknowledged_by", sa.Uuid(), nullable=True),
        sa.Column("acknowledgement", sa.String(length=500), nullable=True),
        *_common_columns(),
        sa.ForeignKeyConstraint(
            ["acknowledged_by"], ["users.id"], name=op.f("fk_alerts_acknowledged_by_users")
        ),
        sa.ForeignKeyConstraint(
            ["control_point_id"],
            ["control_points.id"],
            name=op.f("fk_alerts_control_point_id_control_points"),
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id"], ["tenants.id"], name=op.f("fk_alerts_tenant_id_tenants")
        ),
        sa.PrimaryKeyConstraint("id", name=op.f("pk_alerts")),
    )
    op.create_index(
        op.f("ix_alerts_control_point_id"), "alerts", ["control_point_id"], unique=False
    )
    op.create_index(op.f("ix_alerts_raised_at"), "alerts", ["raised_at"], unique=False)
    op.create_index(op.f("ix_alerts_tenant_id"), "alerts", ["tenant_id"], unique=False)

    for table in NEW_TENANT_TABLES:
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
        op.execute(
            f"""
            CREATE POLICY tenant_isolation ON {table}
              USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
              WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
            """
        )

    # Amendments are evidence like the records they correct: never edited, never deleted.
    op.execute(
        "CREATE TRIGGER record_amendments_append_only BEFORE UPDATE OR DELETE "
        "ON record_amendments FOR EACH ROW EXECUTE FUNCTION reject_mutation()"
    )

    # Corrective actions: closed exactly once; only the closing fields may be filled in.
    op.execute(
        """
        CREATE FUNCTION guard_corrective_action_update() RETURNS trigger LANGUAGE plpgsql AS $$
        DECLARE
          closing_fields text[] := ARRAY['status', 'root_cause', 'preventive_action',
                                         'product_disposition', 'closed_at', 'closed_by'];
        BEGIN
          IF OLD.status <> 'open' OR NEW.status <> 'closed'
             OR (to_jsonb(NEW) - closing_fields) <> (to_jsonb(OLD) - closing_fields) THEN
            RAISE EXCEPTION 'A corrective action can only be closed once, and only by '
                            'adding its closing details'
              USING ERRCODE = 'insufficient_privilege';
          END IF;
          RETURN NEW;
        END;
        $$
        """
    )
    op.execute(
        "CREATE TRIGGER corrective_actions_guard_update BEFORE UPDATE ON corrective_actions "
        "FOR EACH ROW EXECUTE FUNCTION guard_corrective_action_update()"
    )

    # Alerts: acknowledged exactly once; nothing else changes.
    op.execute(
        """
        CREATE FUNCTION guard_alert_update() RETURNS trigger LANGUAGE plpgsql AS $$
        DECLARE
          ack_fields text[] := ARRAY['acknowledged_at', 'acknowledged_by', 'acknowledgement'];
        BEGIN
          IF OLD.acknowledged_at IS NOT NULL OR NEW.acknowledged_at IS NULL
             OR NEW.acknowledged_by IS NULL
             OR (to_jsonb(NEW) - ack_fields) <> (to_jsonb(OLD) - ack_fields) THEN
            RAISE EXCEPTION 'An alert can only be acknowledged once'
              USING ERRCODE = 'insufficient_privilege';
          END IF;
          RETURN NEW;
        END;
        $$
        """
    )
    op.execute(
        "CREATE TRIGGER alerts_guard_update BEFORE UPDATE ON alerts "
        "FOR EACH ROW EXECUTE FUNCTION guard_alert_update()"
    )
    for table in ("corrective_actions", "alerts"):
        op.execute(
            f"CREATE TRIGGER {table}_no_delete BEFORE DELETE ON {table} "
            "FOR EACH ROW EXECUTE FUNCTION reject_mutation()"
        )
    _backfill_corrective_actions()


# Deviations recorded before this version get an open corrective action, so nothing that
# needs follow-up is missed. Row-level security is lifted for the table owner meanwhile,
# because the migration works across all tenants.
BACKFILL_TABLES = ("corrective_actions", "ccp_readings", "sanitation_records", "control_points")
BACKFILL_SQL = (
    """
    INSERT INTO corrective_actions (id, tenant_id, record_type, record_id, control_point_id,
        lot_id, description, immediate_action, opened_at, opened_by, status)
    SELECT gen_random_uuid(), r.tenant_id, 'ccp_reading', r.id, r.control_point_id, r.lot_id,
        cp.code || ' (' || cp.name || '): ' || trim_scale(r.value) || ' ' || r.unit
          || ' is outside the critical limits ('
          || CASE
               WHEN r.critical_min IS NOT NULL AND r.critical_max IS NOT NULL
                 THEN trim_scale(r.critical_min) || ' to ' || trim_scale(r.critical_max)
               WHEN r.critical_min IS NOT NULL THEN 'min ' || trim_scale(r.critical_min)
               ELSE 'max ' || trim_scale(r.critical_max)
             END || ' ' || r.unit || ')',
        r.corrective_action, r.created_at, r.recorded_by, 'open'
    FROM ccp_readings AS r JOIN control_points AS cp ON cp.id = r.control_point_id
    WHERE NOT r.within_limits
    """,
    """
    INSERT INTO corrective_actions (id, tenant_id, record_type, record_id, description,
        immediate_action, opened_at, opened_by, status)
    SELECT gen_random_uuid(), s.tenant_id, 'sanitation_record', s.id,
        'Sanitation check failed: ' || replace(s.activity, '_', ' ') || ' of ' || s.area,
        s.corrective_action, s.created_at, s.recorded_by, 'open'
    FROM sanitation_records AS s
    WHERE s.result = 'fail'
    """,
)


def _backfill_corrective_actions() -> None:
    for table in BACKFILL_TABLES:
        op.execute(f"ALTER TABLE {table} NO FORCE ROW LEVEL SECURITY")
    for statement in BACKFILL_SQL:
        op.execute(statement)
    for table in BACKFILL_TABLES:
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")


def downgrade() -> None:
    for table in ("corrective_actions", "alerts"):
        op.execute(f"DROP TRIGGER {table}_no_delete ON {table}")
    op.execute("DROP TRIGGER alerts_guard_update ON alerts")
    op.execute("DROP FUNCTION guard_alert_update()")
    op.execute("DROP TRIGGER corrective_actions_guard_update ON corrective_actions")
    op.execute("DROP FUNCTION guard_corrective_action_update()")
    op.execute("DROP TRIGGER record_amendments_append_only ON record_amendments")
    op.drop_table("alerts")
    op.drop_table("corrective_actions")
    op.drop_table("record_amendments")
    # Approval signatures cannot be expressed in the old schema; remove them first
    # (for every tenant, so row-level security is lifted for the table owner meanwhile).
    op.execute("ALTER TABLE record_signatures NO FORCE ROW LEVEL SECURITY")
    op.execute("ALTER TABLE record_signatures DISABLE TRIGGER record_signatures_append_only")
    op.execute("DELETE FROM record_signatures WHERE meaning = 'approved'")
    op.execute("ALTER TABLE record_signatures ENABLE TRIGGER record_signatures_append_only")
    op.execute("ALTER TABLE record_signatures FORCE ROW LEVEL SECURITY")
    _meaning_check(MEANINGS_BEFORE)
    op.drop_constraint(op.f("ck_control_points_positive_interval"), "control_points", "check")
    op.drop_column("control_points", "check_interval_minutes")
