"""Record numbers (CCP-2026-000123, ...), controlled forms and the issued-report register.

Existing records get numbers in the order they were created, per tenant, series and year
(factory time zone). The append-only triggers are switched off for that one backfill only.

Revision ID: 0006
Revises: 0005
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

from compliance_engine.core.config import get_settings

revision: str = "0006"
down_revision: str | None = "0005"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

# table -> (series, trigger that blocks updates)
NUMBERED = {
    "ccp_readings": ("CCP", "ccp_readings_append_only"),
    "sanitation_records": ("SAN", "sanitation_records_append_only"),
    "record_amendments": ("AMD", "record_amendments_append_only"),
    "corrective_actions": ("CA", "corrective_actions_guard_update"),
}
NEW_TENANT_TABLES = ("record_counters", "document_forms", "issued_reports")


def _common_columns() -> list[sa.Column[object]]:
    return [
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("tenant_id", sa.Uuid(), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
    ]


def upgrade() -> None:
    op.create_table(
        "record_counters",
        sa.Column("tenant_id", sa.Uuid(), nullable=False),
        sa.Column("series", sa.String(length=16), nullable=False),
        sa.Column("year", sa.Integer(), nullable=False),
        sa.Column("last_number", sa.Integer(), nullable=False),
        sa.ForeignKeyConstraint(
            ["tenant_id"], ["tenants.id"], name=op.f("fk_record_counters_tenant_id_tenants")
        ),
        sa.PrimaryKeyConstraint("tenant_id", "series", "year", name=op.f("pk_record_counters")),
    )
    op.create_table(
        "document_forms",
        sa.Column("key", sa.String(length=32), nullable=False),
        sa.Column("code", sa.String(length=32), nullable=False),
        sa.Column("title_ar", sa.String(length=200), nullable=False),
        sa.Column("title_en", sa.String(length=200), nullable=False),
        sa.Column("revision", sa.String(length=8), nullable=False),
        sa.Column("effective_date", sa.Date(), nullable=False),
        sa.Column("reference", sa.String(length=300), nullable=True),
        sa.Column("retention_years", sa.Integer(), nullable=False),
        sa.Column("approved_by_name", sa.String(length=200), nullable=True),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
        *_common_columns(),
        sa.ForeignKeyConstraint(
            ["tenant_id"], ["tenants.id"], name=op.f("fk_document_forms_tenant_id_tenants")
        ),
        sa.PrimaryKeyConstraint("id", name=op.f("pk_document_forms")),
        sa.UniqueConstraint("tenant_id", "code", name=op.f("uq_document_forms_tenant_id_code")),
        sa.UniqueConstraint("tenant_id", "key", name=op.f("uq_document_forms_tenant_id_key")),
    )
    op.create_index(
        op.f("ix_document_forms_tenant_id"), "document_forms", ["tenant_id"], unique=False
    )
    op.create_table(
        "issued_reports",
        sa.Column("serial", sa.String(length=32), nullable=False),
        sa.Column("form_key", sa.String(length=32), nullable=False),
        sa.Column("form_code", sa.String(length=32), nullable=False),
        sa.Column("form_revision", sa.String(length=8), nullable=False),
        sa.Column("title", sa.String(length=200), nullable=False),
        sa.Column("lang", sa.String(length=2), nullable=False),
        sa.Column("parameters", postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column("filename", sa.String(length=200), nullable=False),
        sa.Column("sha256", sa.String(length=64), nullable=False),
        sa.Column("issued_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("issued_by", sa.Uuid(), nullable=False),
        sa.Column("issued_by_name", sa.String(length=200), nullable=False),
        *_common_columns(),
        sa.ForeignKeyConstraint(
            ["issued_by"], ["users.id"], name=op.f("fk_issued_reports_issued_by_users")
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id"], ["tenants.id"], name=op.f("fk_issued_reports_tenant_id_tenants")
        ),
        sa.PrimaryKeyConstraint("id", name=op.f("pk_issued_reports")),
        sa.UniqueConstraint("tenant_id", "serial", name=op.f("uq_issued_reports_tenant_id_serial")),
    )
    op.create_index(op.f("ix_issued_reports_sha256"), "issued_reports", ["sha256"], unique=False)
    op.create_index(
        op.f("ix_issued_reports_tenant_id"), "issued_reports", ["tenant_id"], unique=False
    )
    op.execute(
        "CREATE TRIGGER issued_reports_append_only BEFORE UPDATE OR DELETE "
        "ON issued_reports FOR EACH ROW EXECUTE FUNCTION reject_mutation()"
    )
    for table in NEW_TENANT_TABLES:
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
        op.execute(
            f"""
            CREATE POLICY tenant_isolation ON {table}
              USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
              WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
            """
        )

    for table in NUMBERED:
        op.add_column(table, sa.Column("serial", sa.String(length=32), nullable=True))
        op.create_unique_constraint(
            op.f(f"uq_{table}_tenant_id_serial"), table, ["tenant_id", "serial"]
        )
    _number_existing_records()


def _number_existing_records() -> None:
    connection = op.get_bind()
    timezone = get_settings().factory_timezone
    tenant_ids = connection.execute(sa.text("SELECT id FROM tenants")).scalars().all()
    for table, (_series, trigger) in NUMBERED.items():
        op.execute(f"ALTER TABLE {table} DISABLE TRIGGER {trigger}")
    for tenant_id in tenant_ids:
        # Row-level security is forced on the owner too, so scope each pass to one tenant.
        connection.execute(
            sa.text("SELECT set_config('app.tenant_id', :t, true)"), {"t": str(tenant_id)}
        )
        for table, (series, _trigger) in NUMBERED.items():
            connection.execute(
                sa.text(
                    f"""
                    WITH numbered AS (
                      SELECT id,
                             EXTRACT(YEAR FROM created_at AT TIME ZONE :tz)::int AS year,
                             row_number() OVER (
                               PARTITION BY EXTRACT(YEAR FROM created_at AT TIME ZONE :tz)
                               ORDER BY created_at, id
                             ) AS n
                      FROM {table}
                    )
                    UPDATE {table} AS t
                       SET serial = :series || '-' || numbered.year || '-' || lpad(n::text, 6, '0')
                      FROM numbered
                     WHERE t.id = numbered.id
                    """
                ),
                {"tz": timezone, "series": series},
            )
            connection.execute(
                sa.text(
                    f"""
                    INSERT INTO record_counters (tenant_id, series, year, last_number)
                    SELECT tenant_id, :series,
                           EXTRACT(YEAR FROM created_at AT TIME ZONE :tz)::int, count(*)
                      FROM {table}
                     GROUP BY tenant_id, EXTRACT(YEAR FROM created_at AT TIME ZONE :tz)
                    """
                ),
                {"tz": timezone, "series": series},
            )
    connection.execute(sa.text("SELECT set_config('app.tenant_id', '', true)"))
    for table, (_series, trigger) in NUMBERED.items():
        op.execute(f"ALTER TABLE {table} ENABLE TRIGGER {trigger}")


def downgrade() -> None:
    for table in NUMBERED:
        op.drop_constraint(op.f(f"uq_{table}_tenant_id_serial"), table, type_="unique")
        op.drop_column(table, "serial")
    op.drop_table("issued_reports")
    op.drop_table("document_forms")
    op.drop_table("record_counters")
