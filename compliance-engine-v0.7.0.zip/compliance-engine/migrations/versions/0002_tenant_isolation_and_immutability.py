"""Tenant isolation (row-level security) and immutable records.

Revision ID: 0002
Revises: 0001
"""

from collections.abc import Sequence

from alembic import op

revision: str = "0002"
down_revision: str | None = "0001"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

TENANT_TABLES = (
    "users",
    "suppliers",
    "customers",
    "items",
    "production_runs",
    "lots",
    "lot_transactions",
    "lot_links",
    "shipments",
    "shipment_lines",
    "audit_events",
)

APPEND_ONLY_TABLES = (
    "production_runs",
    "lot_transactions",
    "lot_links",
    "shipments",
    "shipment_lines",
    "audit_events",
)


def upgrade() -> None:
    # Row-level security: a session sees only rows of the tenant in `app.tenant_id`.
    # FORCE applies the policy to the table owner too, so the app role cannot bypass it.
    for table in TENANT_TABLES:
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
        op.execute(
            f"""
            CREATE POLICY tenant_isolation ON {table}
              USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
              WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
            """
        )

    op.execute(
        """
        CREATE FUNCTION reject_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
        BEGIN
          RAISE EXCEPTION '% on % is not allowed: records are append-only', TG_OP, TG_TABLE_NAME
            USING ERRCODE = 'insufficient_privilege';
        END;
        $$
        """
    )
    for table in APPEND_ONLY_TABLES:
        op.execute(
            f"""
            CREATE TRIGGER {table}_append_only
              BEFORE UPDATE OR DELETE ON {table}
              FOR EACH ROW EXECUTE FUNCTION reject_mutation()
            """
        )

    # Lots: identity, origin and genealogy fields are fixed; only `status` may change.
    op.execute(
        """
        CREATE FUNCTION guard_lot_update() RETURNS trigger LANGUAGE plpgsql AS $$
        BEGIN
          IF (to_jsonb(NEW) - 'status') <> (to_jsonb(OLD) - 'status') THEN
            RAISE EXCEPTION 'Only the status of a lot can change'
              USING ERRCODE = 'insufficient_privilege';
          END IF;
          RETURN NEW;
        END;
        $$
        """
    )
    op.execute(
        "CREATE TRIGGER lots_guard_update BEFORE UPDATE ON lots "
        "FOR EACH ROW EXECUTE FUNCTION guard_lot_update()"
    )
    op.execute(
        "CREATE TRIGGER lots_no_delete BEFORE DELETE ON lots "
        "FOR EACH ROW EXECUTE FUNCTION reject_mutation()"
    )


def downgrade() -> None:
    op.execute("DROP TRIGGER lots_no_delete ON lots")
    op.execute("DROP TRIGGER lots_guard_update ON lots")
    op.execute("DROP FUNCTION guard_lot_update()")
    for table in APPEND_ONLY_TABLES:
        op.execute(f"DROP TRIGGER {table}_append_only ON {table}")
    op.execute("DROP FUNCTION reject_mutation()")
    for table in TENANT_TABLES:
        op.execute(f"DROP POLICY tenant_isolation ON {table}")
        op.execute(f"ALTER TABLE {table} NO FORCE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {table} DISABLE ROW LEVEL SECURITY")
