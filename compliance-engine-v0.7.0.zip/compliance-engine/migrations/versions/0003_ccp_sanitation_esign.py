"""CCP readings, sanitation records and electronic signatures.

Revision ID: 0003
Revises: 0002
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "0003"
down_revision: str | None = "0002"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

NEW_TENANT_TABLES = ("control_points", "ccp_readings", "sanitation_records", "record_signatures")
NEW_APPEND_ONLY_TABLES = ("ccp_readings", "sanitation_records", "record_signatures")


def upgrade() -> None:
    op.create_table(
        "control_points",
        sa.Column("code", sa.String(length=64), nullable=False),
        sa.Column("name", sa.String(length=200), nullable=False),
        sa.Column("hazard", sa.String(length=500), nullable=False),
        sa.Column("parameter", sa.String(length=100), nullable=False),
        sa.Column("unit", sa.String(length=16), nullable=False),
        sa.Column("critical_min", sa.Numeric(precision=12, scale=3), nullable=True),
        sa.Column("critical_max", sa.Numeric(precision=12, scale=3), nullable=True),
        sa.Column("monitoring_frequency", sa.String(length=100), nullable=True),
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("tenant_id", sa.Uuid(), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.CheckConstraint(
            "critical_min IS NOT NULL OR critical_max IS NOT NULL",
            name=op.f("ck_control_points_has_a_limit"),
        ),
        sa.CheckConstraint(
            "critical_min IS NULL OR critical_max IS NULL OR critical_min <= critical_max",
            name=op.f("ck_control_points_limits_ordered"),
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id"], ["tenants.id"], name=op.f("fk_control_points_tenant_id_tenants")
        ),
        sa.PrimaryKeyConstraint("id", name=op.f("pk_control_points")),
        sa.UniqueConstraint("tenant_id", "code", name=op.f("uq_control_points_tenant_id_code")),
    )
    op.create_index(
        op.f("ix_control_points_tenant_id"), "control_points", ["tenant_id"], unique=False
    )
    op.create_table(
        "record_signatures",
        sa.Column("record_type", sa.String(length=32), nullable=False),
        sa.Column("record_id", sa.Uuid(), nullable=False),
        sa.Column(
            "meaning",
            sa.Enum(
                "performed",
                "verified",
                name="signaturemeaning",
                native_enum=False,
                create_constraint=True,
                length=32,
            ),
            nullable=False,
        ),
        sa.Column("signer_id", sa.Uuid(), nullable=False),
        sa.Column("signer_name", sa.String(length=200), nullable=False),
        sa.Column(
            "signer_role",
            sa.Enum(
                "admin",
                "quality_manager",
                "supervisor",
                "operator",
                "auditor",
                name="role",
                native_enum=False,
                create_constraint=True,
                length=32,
            ),
            nullable=False,
        ),
        sa.Column("signed_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("comment", sa.String(length=500), nullable=True),
        sa.Column("record_hash", sa.String(length=64), nullable=False),
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("tenant_id", sa.Uuid(), nullable=False),
        sa.ForeignKeyConstraint(
            ["signer_id"], ["users.id"], name=op.f("fk_record_signatures_signer_id_users")
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id"], ["tenants.id"], name=op.f("fk_record_signatures_tenant_id_tenants")
        ),
        sa.PrimaryKeyConstraint("id", name=op.f("pk_record_signatures")),
        sa.UniqueConstraint(
            "tenant_id",
            "record_type",
            "record_id",
            "meaning",
            name=op.f("uq_record_signatures_tenant_id_record_type_record_id_meaning"),
        ),
    )
    op.create_index(
        op.f("ix_record_signatures_record_id"), "record_signatures", ["record_id"], unique=False
    )
    op.create_index(
        op.f("ix_record_signatures_tenant_id"), "record_signatures", ["tenant_id"], unique=False
    )
    op.create_table(
        "sanitation_records",
        sa.Column("area", sa.String(length=64), nullable=False),
        sa.Column(
            "activity",
            sa.Enum(
                "pre_op_inspection",
                "cleaning",
                "sanitizing",
                "deep_clean",
                name="sanitationactivity",
                native_enum=False,
                create_constraint=True,
                length=32,
            ),
            nullable=False,
        ),
        sa.Column("chemical", sa.String(length=100), nullable=True),
        sa.Column("concentration_ppm", sa.Numeric(precision=10, scale=2), nullable=True),
        sa.Column(
            "result",
            sa.Enum(
                "pass",
                "fail",
                name="sanitationresult",
                native_enum=False,
                create_constraint=True,
                length=32,
            ),
            nullable=False,
        ),
        sa.Column("corrective_action", sa.Text(), nullable=True),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("performed_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("recorded_by", sa.Uuid(), nullable=False),
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("tenant_id", sa.Uuid(), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.CheckConstraint(
            "result = 'pass' OR corrective_action IS NOT NULL",
            name=op.f("ck_sanitation_records_failure_has_action"),
        ),
        sa.ForeignKeyConstraint(
            ["recorded_by"], ["users.id"], name=op.f("fk_sanitation_records_recorded_by_users")
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id"], ["tenants.id"], name=op.f("fk_sanitation_records_tenant_id_tenants")
        ),
        sa.PrimaryKeyConstraint("id", name=op.f("pk_sanitation_records")),
    )
    op.create_index(
        op.f("ix_sanitation_records_area"), "sanitation_records", ["area"], unique=False
    )
    op.create_index(
        op.f("ix_sanitation_records_performed_at"),
        "sanitation_records",
        ["performed_at"],
        unique=False,
    )
    op.create_index(
        op.f("ix_sanitation_records_tenant_id"), "sanitation_records", ["tenant_id"], unique=False
    )
    op.create_table(
        "ccp_readings",
        sa.Column("control_point_id", sa.Uuid(), nullable=False),
        sa.Column("value", sa.Numeric(precision=12, scale=3), nullable=False),
        sa.Column("unit", sa.String(length=16), nullable=False),
        sa.Column("critical_min", sa.Numeric(precision=12, scale=3), nullable=True),
        sa.Column("critical_max", sa.Numeric(precision=12, scale=3), nullable=True),
        sa.Column("within_limits", sa.Boolean(), nullable=False),
        sa.Column("corrective_action", sa.Text(), nullable=True),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("lot_id", sa.Uuid(), nullable=True),
        sa.Column("production_run_id", sa.Uuid(), nullable=True),
        sa.Column("measured_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("recorded_by", sa.Uuid(), nullable=False),
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("tenant_id", sa.Uuid(), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.CheckConstraint(
            "within_limits OR corrective_action IS NOT NULL",
            name=op.f("ck_ccp_readings_deviation_has_action"),
        ),
        sa.ForeignKeyConstraint(
            ["control_point_id"],
            ["control_points.id"],
            name=op.f("fk_ccp_readings_control_point_id_control_points"),
        ),
        sa.ForeignKeyConstraint(["lot_id"], ["lots.id"], name=op.f("fk_ccp_readings_lot_id_lots")),
        sa.ForeignKeyConstraint(
            ["production_run_id"],
            ["production_runs.id"],
            name=op.f("fk_ccp_readings_production_run_id_production_runs"),
        ),
        sa.ForeignKeyConstraint(
            ["recorded_by"], ["users.id"], name=op.f("fk_ccp_readings_recorded_by_users")
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id"], ["tenants.id"], name=op.f("fk_ccp_readings_tenant_id_tenants")
        ),
        sa.PrimaryKeyConstraint("id", name=op.f("pk_ccp_readings")),
    )
    op.create_index(
        op.f("ix_ccp_readings_control_point_id"), "ccp_readings", ["control_point_id"], unique=False
    )
    op.create_index(op.f("ix_ccp_readings_lot_id"), "ccp_readings", ["lot_id"], unique=False)
    op.create_index(
        op.f("ix_ccp_readings_measured_at"), "ccp_readings", ["measured_at"], unique=False
    )
    op.create_index(op.f("ix_ccp_readings_tenant_id"), "ccp_readings", ["tenant_id"], unique=False)

    for table in NEW_TENANT_TABLES:
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
        op.execute(
            f"""
            CREATE POLICY tenant_isolation ON {table}
              USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
              WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
            """
        )
    # Monitoring records and their signatures are evidence: never edited, never deleted.
    for table in NEW_APPEND_ONLY_TABLES:
        op.execute(
            f"""
            CREATE TRIGGER {table}_append_only
              BEFORE UPDATE OR DELETE ON {table}
              FOR EACH ROW EXECUTE FUNCTION reject_mutation()
            """
        )


def downgrade() -> None:
    for table in NEW_APPEND_ONLY_TABLES:
        op.execute(f"DROP TRIGGER {table}_append_only ON {table}")
    op.drop_index(op.f("ix_ccp_readings_tenant_id"), table_name="ccp_readings")
    op.drop_index(op.f("ix_ccp_readings_measured_at"), table_name="ccp_readings")
    op.drop_index(op.f("ix_ccp_readings_lot_id"), table_name="ccp_readings")
    op.drop_index(op.f("ix_ccp_readings_control_point_id"), table_name="ccp_readings")
    op.drop_table("ccp_readings")
    op.drop_index(op.f("ix_sanitation_records_tenant_id"), table_name="sanitation_records")
    op.drop_index(op.f("ix_sanitation_records_performed_at"), table_name="sanitation_records")
    op.drop_index(op.f("ix_sanitation_records_area"), table_name="sanitation_records")
    op.drop_table("sanitation_records")
    op.drop_index(op.f("ix_record_signatures_tenant_id"), table_name="record_signatures")
    op.drop_index(op.f("ix_record_signatures_record_id"), table_name="record_signatures")
    op.drop_table("record_signatures")
    op.drop_index(op.f("ix_control_points_tenant_id"), table_name="control_points")
    op.drop_table("control_points")
