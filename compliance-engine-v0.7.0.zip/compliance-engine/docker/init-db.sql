-- The application connects as app_user, which owns the tables but is NOT a superuser,
-- so row-level security applies to it. Change these passwords outside local development.
CREATE ROLE app_user LOGIN PASSWORD 'app_password';
CREATE DATABASE compliance OWNER app_user;
CREATE DATABASE compliance_test OWNER app_user;
